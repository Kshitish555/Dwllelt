/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Value
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.strategy.Value;

class ObjectInstance
implements Instance {
    private final Context context;
    private final Class type;
    private final Value value;

    public ObjectInstance(Context context, Value value) {
        this.type = value.getType();
        this.context = context;
        this.value = value;
    }

    public Object getInstance() throws Exception {
        if (this.value.isReference()) {
            return this.value.getValue();
        }
        Object object = this.getInstance(this.type);
        Value value = this.value;
        if (value != null) {
            value.setValue(object);
        }
        return object;
    }

    public Object getInstance(Class class_) throws Exception {
        return this.context.getInstance(class_).getInstance();
    }

    public Class getType() {
        return this.type;
    }

    public boolean isReference() {
        return this.value.isReference();
    }

    public Object setInstance(Object object) {
        Value value = this.value;
        if (value != null) {
            value.setValue(object);
        }
        return object;
    }
}

