/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.net.Uri$Builder
 *  java.io.BufferedReader
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.io.UnsupportedEncodingException
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.net.MalformedURLException
 *  java.net.URL
 *  java.net.URLEncoder
 *  java.text.SimpleDateFormat
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  javax.net.ssl.HttpsURLConnection
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import android.net.Uri;
import com.adjust.sdk.ActivityKind;
import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.ResponseData;
import com.adjust.sdk.TrackingState;
import com.adjust.sdk.Util;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONException;
import org.json.JSONObject;

public class UtilNetworking {
    private static String userAgent;

    static /* synthetic */ String access$000() {
        return userAgent;
    }

    private static String buildAuthorizationHeader(Map<String, String> map, String string, String string2, String string3) {
        if (string != null && string.length() != 0) {
            Map<String, String> map2 = UtilNetworking.getSignature(map, string3, string);
            String string4 = Util.sha256((String)map2.get((Object)"clear_signature"));
            String string5 = (String)map2.get((Object)"fields");
            String string6 = Util.formatString("Signature %s,%s,%s,%s", Util.formatString("secret_id=\"%s\"", string2), Util.formatString("signature=\"%s\"", string4), Util.formatString("algorithm=\"%s\"", "sha256"), Util.formatString("headers=\"%s\"", string5));
            UtilNetworking.getLogger().verbose("authorizationHeader: %s", string6);
            return string6;
        }
        return null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static Uri buildUri(String string, Map<String, String> map, String string2) {
        String string3;
        Uri.Builder builder = new Uri.Builder();
        String string4 = "https";
        String string5 = "app.adjust.com";
        try {
            String string6 = AdjustFactory.getBaseUrl();
            if (string2 != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string6);
                stringBuilder.append(string2);
                string6 = stringBuilder.toString();
            }
            URL uRL = new URL(string6);
            string4 = uRL.getProtocol();
            string5 = uRL.getAuthority();
            string3 = uRL.getPath();
        }
        catch (MalformedURLException malformedURLException) {
            ILogger iLogger = UtilNetworking.getLogger();
            Object[] arrobject = new Object[]{malformedURLException.getMessage()};
            iLogger.error("Unable to parse endpoint (%s)", arrobject);
            string3 = "";
        }
        builder.scheme(string4);
        builder.encodedAuthority(string5);
        builder.path(string3);
        builder.appendPath(string);
        Iterator iterator = map.entrySet().iterator();
        do {
            if (!iterator.hasNext()) {
                long l2 = System.currentTimeMillis();
                builder.appendQueryParameter("sent_at", Util.dateFormatter.format((Object)l2));
                return builder.build();
            }
            Map.Entry entry = (Map.Entry)iterator.next();
            builder.appendQueryParameter((String)entry.getKey(), (String)entry.getValue());
        } while (true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static ResponseData createGETHttpsURLConnection(ActivityPackage activityPackage, String string) throws Exception {
        HashMap hashMap = new HashMap(activityPackage.getParameters());
        String string2 = UtilNetworking.extractAppSecret((Map<String, String>)hashMap);
        String string3 = UtilNetworking.extractSecretId((Map<String, String>)hashMap);
        UtilNetworking.extractEventCallbackId((Map<String, String>)hashMap);
        HttpsURLConnection httpsURLConnection = AdjustFactory.getHttpsURLConnection(new URL(UtilNetworking.buildUri(activityPackage.getPath(), (Map<String, String>)hashMap, string).toString()));
        AdjustFactory.getConnectionOptions().applyConnectionOptions(httpsURLConnection, activityPackage.getClientSdk());
        String string4 = UtilNetworking.buildAuthorizationHeader((Map<String, String>)hashMap, string2, string3, activityPackage.getActivityKind().toString());
        if (string4 != null) {
            httpsURLConnection.setRequestProperty("Authorization", string4);
        }
        httpsURLConnection.setRequestMethod("GET");
        return UtilNetworking.readHttpResponse(httpsURLConnection, activityPackage);
    }

    /*
     * Exception decompiling
     */
    public static ResponseData createPOSTHttpsURLConnection(String var0, ActivityPackage var1, int var2) throws Exception {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private static String extractAppSecret(Map<String, String> map) {
        return (String)map.remove((Object)"app_secret");
    }

    private static void extractEventCallbackId(Map<String, String> map) {
        map.remove((Object)"event_callback_id");
    }

    private static String extractSecretId(Map<String, String> map) {
        return (String)map.remove((Object)"secret_id");
    }

    private static ILogger getLogger() {
        return AdjustFactory.getLogger();
    }

    private static String getPostDataString(Map<String, String> map, int n2) throws UnsupportedEncodingException {
        String string;
        StringBuilder stringBuilder = new StringBuilder();
        Iterator iterator = map.entrySet().iterator();
        do {
            boolean bl = iterator.hasNext();
            string = "";
            if (!bl) break;
            Map.Entry entry = (Map.Entry)iterator.next();
            String string2 = URLEncoder.encode((String)((String)entry.getKey()), (String)"UTF-8");
            String string3 = (String)entry.getValue();
            if (string3 != null) {
                string = URLEncoder.encode((String)string3, (String)"UTF-8");
            }
            if (stringBuilder.length() > 0) {
                stringBuilder.append("&");
            }
            stringBuilder.append(string2);
            stringBuilder.append("=");
            stringBuilder.append(string);
        } while (true);
        long l2 = System.currentTimeMillis();
        String string4 = Util.dateFormatter.format((Object)l2);
        stringBuilder.append("&");
        stringBuilder.append(URLEncoder.encode((String)"sent_at", (String)"UTF-8"));
        stringBuilder.append("=");
        stringBuilder.append(URLEncoder.encode((String)string4, (String)"UTF-8"));
        if (n2 > 0) {
            stringBuilder.append("&");
            stringBuilder.append(URLEncoder.encode((String)"queue_size", (String)"UTF-8"));
            stringBuilder.append("=");
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string);
            stringBuilder2.append(n2);
            stringBuilder.append(URLEncoder.encode((String)stringBuilder2.toString(), (String)"UTF-8"));
        }
        return stringBuilder.toString();
    }

    private static Map<String, String> getSignature(Map<String, String> map, String string, String string2) {
        String string3;
        String string4 = (String)map.get((Object)"created_at");
        String string5 = UtilNetworking.getValidIdentifier(map);
        String string6 = (String)map.get((Object)string5);
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"app_secret", (Object)string2);
        hashMap.put((Object)"created_at", (Object)string4);
        hashMap.put((Object)"activity_kind", (Object)string);
        hashMap.put((Object)string5, (Object)string6);
        Iterator iterator = hashMap.entrySet().iterator();
        String string7 = string3 = "";
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            if (entry.getValue() == null) continue;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string3);
            stringBuilder.append((String)entry.getKey());
            stringBuilder.append(" ");
            string3 = stringBuilder.toString();
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string7);
            stringBuilder2.append((String)entry.getValue());
            string7 = stringBuilder2.toString();
        }
        String string8 = string3.substring(0, -1 + string3.length());
        HashMap hashMap2 = new HashMap();
        hashMap2.put((Object)"clear_signature", (Object)string7);
        hashMap2.put((Object)"fields", (Object)string8);
        return hashMap2;
    }

    private static String getValidIdentifier(Map<String, String> map) {
        if (map.get((Object)"gps_adid") != null) {
            return "gps_adid";
        }
        if (map.get((Object)"fire_adid") != null) {
            return "fire_adid";
        }
        if (map.get((Object)"android_id") != null) {
            return "android_id";
        }
        if (map.get((Object)"mac_sha1") != null) {
            return "mac_sha1";
        }
        if (map.get((Object)"mac_md5") != null) {
            return "mac_md5";
        }
        if (map.get((Object)"android_uuid") != null) {
            return "android_uuid";
        }
        return null;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static ResponseData readHttpResponse(HttpsURLConnection httpsURLConnection, ActivityPackage activityPackage) throws Exception {
        Integer n2;
        ILogger iLogger;
        String string;
        Throwable throwable2222;
        StringBuffer stringBuffer;
        ResponseData responseData;
        JSONObject jSONObject;
        block13 : {
            String string2;
            stringBuffer = new StringBuffer();
            iLogger = UtilNetworking.getLogger();
            responseData = ResponseData.buildResponseData(activityPackage);
            httpsURLConnection.connect();
            n2 = httpsURLConnection.getResponseCode();
            InputStream inputStream = n2 >= 400 ? httpsURLConnection.getErrorStream() : httpsURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(inputStream));
            while ((string2 = bufferedReader.readLine()) != null) {
                stringBuffer.append(string2);
            }
            if (httpsURLConnection == null) break block13;
            httpsURLConnection.disconnect();
        }
        String string3 = stringBuffer.toString();
        iLogger.verbose("Response: %s", string3);
        if (n2 == 429) {
            iLogger.error("Too frequent requests to the endpoint (429)", new Object[0]);
            return responseData;
        }
        if (string3 == null) return responseData;
        if (string3.length() == 0) {
            return responseData;
        }
        try {
            jSONObject = new JSONObject(string3);
        }
        catch (JSONException jSONException) {
            Object[] arrobject = new Object[]{jSONException.getMessage()};
            String string4 = Util.formatString("Failed to parse json response. (%s)", arrobject);
            iLogger.error(string4, new Object[0]);
            responseData.message = string4;
            jSONObject = null;
        }
        if (jSONObject == null) {
            return responseData;
        }
        responseData.jsonResponse = jSONObject;
        responseData.message = string = jSONObject.optString("message", null);
        responseData.timestamp = jSONObject.optString("timestamp", null);
        responseData.adid = jSONObject.optString("adid", null);
        String string5 = jSONObject.optString("tracking_state", null);
        if (string5 != null && string5.equals((Object)"opted_out")) {
            responseData.trackingState = TrackingState.OPTED_OUT;
        }
        if (string == null) {
            string = "No message found";
        }
        if (n2 != null && n2 == 200) {
            iLogger.info("%s", string);
            responseData.success = true;
            return responseData;
        }
        iLogger.error("%s", string);
        return responseData;
        {
            catch (Throwable throwable2222) {
            }
            catch (Exception exception) {}
            {
                Object[] arrobject = new Object[]{exception.getMessage()};
                iLogger.error("Failed to read response. (%s)", arrobject);
                throw exception;
            }
        }
        if (httpsURLConnection == null) throw throwable2222;
        httpsURLConnection.disconnect();
        throw throwable2222;
    }

    public static void setUserAgent(String string) {
        userAgent = string;
    }

    public static interface IConnectionOptions {
        public void applyConnectionOptions(HttpsURLConnection var1, String var2);
    }

}

