/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.SubMenu
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  microsoft.mappoint.TileSystem
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$bitmap
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.api.IProjection
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.tileprovider.tilesource.TileSourceFactory
 *  org.osmdroid.util.TileLooper
 *  org.osmdroid.views.overlay.IOverlayMenuProvider
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import microsoft.mappoint.TileSystem;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IProjection;
import org.osmdroid.tileprovider.MapTileProviderBase;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.TileLooper;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.IOverlayMenuProvider;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.TilesOverlay;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TilesOverlay
extends Overlay
implements IOverlayMenuProvider {
    public static final int MENU_MAP_MODE;
    public static final int MENU_OFFLINE;
    public static final int MENU_TILE_SOURCE_STARTING_ID;
    private static final Logger logger;
    protected final Paint mDebugPaint = new Paint();
    private int mLoadingBackgroundColor = Color.rgb((int)216, (int)208, (int)208);
    private int mLoadingLineColor = Color.rgb((int)200, (int)192, (int)192);
    private BitmapDrawable mLoadingTile = null;
    private boolean mOptionsMenuEnabled = true;
    private int mOvershootTileCache = 0;
    private final TileLooper mTileLooper = new TileLooper(this){
        final /* synthetic */ TilesOverlay this$0;
        {
            this.this$0 = tilesOverlay;
        }

        public void finaliseLoop() {
        }

        public void handleTile(Canvas canvas, int n2, org.osmdroid.tileprovider.MapTile mapTile, int n3, int n4) {
            Drawable drawable = this.this$0.mTileProvider.getMapTile(mapTile);
            if (drawable == null) {
                drawable = TilesOverlay.access$100(this.this$0);
            }
            if (drawable != null) {
                Rect rect = TilesOverlay.access$200(this.this$0);
                int n5 = n3 * n2;
                int n6 = n4 * n2;
                rect.set(n5, n6, n5 + n2, n2 + n6);
                TilesOverlay tilesOverlay = this.this$0;
                tilesOverlay.onTileReadyToDraw(canvas, drawable, TilesOverlay.access$200(tilesOverlay));
            }
        }

        public void initialiseLoop(int n2, int n3) {
            android.graphics.Point point = this.mLowerRight;
            int n4 = point.y;
            android.graphics.Point point2 = this.mUpperLeft;
            int n5 = (1 + (n4 - point2.y)) * (1 + (point.x - point2.x));
            TilesOverlay tilesOverlay = this.this$0;
            tilesOverlay.mTileProvider.ensureCapacity(n5 + TilesOverlay.access$000(tilesOverlay));
        }
    };
    protected final MapTileProviderBase mTileProvider;
    private final Rect mTileRect = new Rect();
    private final Rect mViewPort = new Rect();
    private int mWorldSize_2;

    static {
        logger = LoggerFactory.getLogger(TilesOverlay.class);
        MENU_MAP_MODE = Overlay.getSafeMenuId();
        MENU_TILE_SOURCE_STARTING_ID = Overlay.getSafeMenuIdSequence(TileSourceFactory.getTileSources().size());
        MENU_OFFLINE = Overlay.getSafeMenuId();
    }

    public TilesOverlay(MapTileProviderBase mapTileProviderBase, Context context) {
        this(mapTileProviderBase, new DefaultResourceProxyImpl(context));
    }

    public TilesOverlay(MapTileProviderBase mapTileProviderBase, ResourceProxy resourceProxy) {
        super(resourceProxy);
        if (mapTileProviderBase != null) {
            this.mTileProvider = mapTileProviderBase;
            return;
        }
        throw new IllegalArgumentException("You must pass a valid tile provider to the tiles overlay.");
    }

    static /* synthetic */ int access$000(TilesOverlay tilesOverlay) {
        return tilesOverlay.mOvershootTileCache;
    }

    static /* synthetic */ Drawable access$100(TilesOverlay tilesOverlay) {
        return tilesOverlay.getLoadingTile();
    }

    static /* synthetic */ Rect access$200(TilesOverlay tilesOverlay) {
        return tilesOverlay.mTileRect;
    }

    private void clearLoadingTile() {
        BitmapDrawable bitmapDrawable = this.mLoadingTile;
        this.mLoadingTile = null;
        if (bitmapDrawable != null) {
            bitmapDrawable.getBitmap().recycle();
        }
    }

    /*
     * Exception decompiling
     */
    private Drawable getLoadingTile() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl87 : ALOAD_0 : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    protected void draw(Canvas canvas, MapView mapView, boolean bl) {
        if (bl) {
            return;
        }
        IProjection iProjection = mapView.getProjection();
        this.mWorldSize_2 = TileSystem.MapSize((int)iProjection.getZoomLevel()) >> 1;
        this.mViewPort.set(iProjection.getScreenRect());
        Rect rect = this.mViewPort;
        int n2 = this.mWorldSize_2;
        rect.offset(n2, n2);
        this.drawTiles(canvas, iProjection.getZoomLevel(), TileSystem.getTileSize(), this.mViewPort);
    }

    public void drawTiles(Canvas canvas, int n2, int n3, Rect rect) {
        this.mTileLooper.loop(canvas, n2, n3, rect);
    }

    public int getLoadingBackgroundColor() {
        return this.mLoadingBackgroundColor;
    }

    public int getLoadingLineColor() {
        return this.mLoadingLineColor;
    }

    public int getMaximumZoomLevel() {
        return this.mTileProvider.getMaximumZoomLevel();
    }

    public int getMinimumZoomLevel() {
        return this.mTileProvider.getMinimumZoomLevel();
    }

    public int getOvershootTileCache() {
        return this.mOvershootTileCache;
    }

    public boolean isOptionsMenuEnabled() {
        return this.mOptionsMenuEnabled;
    }

    public boolean onCreateOptionsMenu(Menu menu, int n2, MapView mapView) {
        SubMenu subMenu = menu.addSubMenu(0, n2 + MENU_MAP_MODE, 0, (CharSequence)this.mResourceProxy.getString(ResourceProxy.string.map_mode)).setIcon(this.mResourceProxy.getDrawable(ResourceProxy.bitmap.ic_menu_mapmode));
        for (int i2 = 0; i2 < TileSourceFactory.getTileSources().size(); ++i2) {
            ITileSource iTileSource = (ITileSource)TileSourceFactory.getTileSources().get(i2);
            subMenu.add(n2 + MENU_MAP_MODE, n2 + (i2 + MENU_TILE_SOURCE_STARTING_ID), 0, (CharSequence)iTileSource.localizedName(this.mResourceProxy));
        }
        subMenu.setGroupCheckable(n2 + MENU_MAP_MODE, true, true);
        ResourceProxy resourceProxy = mapView.getResourceProxy();
        ResourceProxy.string string2 = mapView.useDataConnection() ? ResourceProxy.string.offline_mode : ResourceProxy.string.online_mode;
        String string3 = resourceProxy.getString(string2);
        Drawable drawable = mapView.getResourceProxy().getDrawable(ResourceProxy.bitmap.ic_menu_offline);
        menu.add(0, n2 + MENU_OFFLINE, 0, (CharSequence)string3).setIcon(drawable);
        return true;
    }

    @Override
    public void onDetach(MapView mapView) {
        this.mTileProvider.detach();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem, int n2, MapView mapView) {
        int n3;
        int n4 = menuItem.getItemId() - n2;
        if (n4 >= (n3 = MENU_TILE_SOURCE_STARTING_ID) && n4 < n3 + TileSourceFactory.getTileSources().size()) {
            mapView.setTileSource((ITileSource)TileSourceFactory.getTileSources().get(n4 - MENU_TILE_SOURCE_STARTING_ID));
            return true;
        }
        if (n4 == MENU_OFFLINE) {
            mapView.setUseDataConnection(true ^ mapView.useDataConnection());
            return true;
        }
        return false;
    }

    public boolean onPrepareOptionsMenu(Menu menu, int n2, MapView mapView) {
        int n3 = TileSourceFactory.getTileSources().indexOf((Object)mapView.getTileProvider().getTileSource());
        if (n3 >= 0) {
            menu.findItem(n2 + (n3 + MENU_TILE_SOURCE_STARTING_ID)).setChecked(true);
        }
        MenuItem menuItem = menu.findItem(n2 + MENU_OFFLINE);
        ResourceProxy resourceProxy = mapView.getResourceProxy();
        ResourceProxy.string string2 = mapView.useDataConnection() ? ResourceProxy.string.offline_mode : ResourceProxy.string.online_mode;
        menuItem.setTitle((CharSequence)resourceProxy.getString(string2));
        return true;
    }

    protected void onTileReadyToDraw(Canvas canvas, Drawable drawable, Rect rect) {
        int n2 = this.mWorldSize_2;
        rect.offset(-n2, -n2);
        drawable.setBounds(rect);
        drawable.draw(canvas);
    }

    public void setLoadingBackgroundColor(int n2) {
        if (this.mLoadingBackgroundColor != n2) {
            this.mLoadingBackgroundColor = n2;
            this.clearLoadingTile();
        }
    }

    public void setLoadingLineColor(int n2) {
        if (this.mLoadingLineColor != n2) {
            this.mLoadingLineColor = n2;
            this.clearLoadingTile();
        }
    }

    public void setOptionsMenuEnabled(boolean bl) {
        this.mOptionsMenuEnabled = bl;
    }

    public void setOvershootTileCache(int n2) {
        this.mOvershootTileCache = n2;
    }

    public void setUseDataConnection(boolean bl) {
        this.mTileProvider.setUseDataConnection(bl);
    }

    public boolean useDataConnection() {
        return this.mTileProvider.useDataConnection();
    }
}

