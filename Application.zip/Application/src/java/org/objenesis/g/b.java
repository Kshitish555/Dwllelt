/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  org.objenesis.f.a
 */
package org.objenesis.g;

import org.objenesis.f.a;

public interface b {
    public <T> a<T> a(Class<T> var1);
}

