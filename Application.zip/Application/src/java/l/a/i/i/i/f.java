/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Map
 *  l.a.b
 *  l.a.h.i.a
 *  l.a.h.i.a$d
 *  l.a.h.i.a$g
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.i.i.d
 *  l.a.i.i.d$d
 *  l.a.i.i.d$d$b
 *  l.a.i.i.i.d
 *  l.a.i.i.i.d$c
 *  l.a.j.e$g
 *  l.a.j.e$g$a$a
 *  l.a.j.e$g$b
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.l.c
 *  l.a.k.a.r
 */
package l.a.i.i.i;

import java.util.Map;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.i.i.d;
import l.a.i.i.i.d;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.l.c;
import l.a.k.a.r;

public class f
extends e.g$a {
    private final Map<a.g, d.c> d;

    protected f(l.a.h.k.c c2, d.c c3, e.g$a.a a2, Map<a.g, d.c> map) {
        super(c2, c3, a2);
        this.d = map;
    }

    private e.f a(d.d d2) {
        if (d2.k().e()) {
            return e.f.c.a(d2.e(), this.a.a0().y0());
        }
        return e.f.b.c;
    }

    private e.f a(d.c c2) {
        if (c2.b()) {
            return b.a((l.a.h.i.a)c2.c(), this.a, c2.a());
        }
        return e.f.c.a((l.a.h.i.a)c2.c(), this.a);
    }

    protected static e.g a(l.a.h.k.c c2, d.c c3, l.a.b b2, l.a.i.i.i.d d2) {
        return new f(c2, c3, e.g$a.a.a((l.a.b)b2), (Map<a.g, d.c>)d2.c());
    }

    public l.a.h.k.c a() {
        return this.a;
    }

    @Override
    protected boolean a(Object object) {
        return object instanceof f;
    }

    public e.f b(a.g g2) {
        d.c c2 = (d.c)this.d.get((Object)g2);
        if (c2 == null) {
            return this.a(this.b.c().a(g2));
        }
        return this.a(c2);
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof f)) {
            return false;
        }
        f f2 = (f)object;
        if (!f2.a(this)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        Map<a.g, d.c> map = this.d;
        Map<a.g, d.c> map2 = f2.d;
        return !(map == null ? map2 != null : !map.equals(map2));
    }

    @Override
    public int hashCode() {
        int n2 = 59 + super.hashCode();
        Map<a.g, d.c> map = this.d;
        int n3 = n2 * 59;
        int n4 = map == null ? 43 : map.hashCode();
        return n3 + n4;
    }

}

