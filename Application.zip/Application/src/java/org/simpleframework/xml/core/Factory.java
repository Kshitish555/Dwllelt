/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Modifier
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Modifier;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.InstantiationException;
import org.simpleframework.xml.core.OverrideType;
import org.simpleframework.xml.core.OverrideValue;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Position;

abstract class Factory {
    protected Context context;
    protected Class override;
    protected Support support;
    protected Type type;

    protected Factory(Context context, Type type) {
        this(context, type, null);
    }

    protected Factory(Context context, Type type, Class class_) {
        this.support = context.getSupport();
        this.override = class_;
        this.context = context;
        this.type = type;
    }

    private Type getPrimitive(Type type, Class class_) throws Exception {
        Class class_2 = Support.getPrimitive(class_);
        if (class_2 != class_) {
            return new OverrideType(type, class_2);
        }
        return type;
    }

    public static boolean isCompatible(Class class_, Class class_2) {
        if (class_.isArray()) {
            class_ = class_.getComponentType();
        }
        return class_.isAssignableFrom(class_2);
    }

    public static boolean isInstantiable(Class class_) {
        int n2 = class_.getModifiers();
        if (Modifier.isAbstract((int)n2)) {
            return false;
        }
        return true ^ Modifier.isInterface((int)n2);
    }

    public Value getConversion(InputNode inputNode) throws Exception {
        Class class_;
        Value value = this.context.getOverride(this.type, inputNode);
        if (value != null && this.override != null && !Factory.isCompatible(this.override, class_ = value.getType())) {
            return new OverrideValue(value, this.override);
        }
        return value;
    }

    public Object getInstance() throws Exception {
        Class class_ = this.getType();
        if (Factory.isInstantiable(class_)) {
            return class_.newInstance();
        }
        throw new InstantiationException("Type %s can not be instantiated", new Object[]{class_});
    }

    protected Value getOverride(InputNode inputNode) throws Exception {
        Value value = this.getConversion(inputNode);
        if (value != null) {
            Position position = inputNode.getPosition();
            Class class_ = value.getType();
            if (Factory.isCompatible(this.getType(), class_)) {
                return value;
            }
            Object[] arrobject = new Object[]{class_, this.type, position};
            throw new InstantiationException("Incompatible %s for %s at %s", arrobject);
        }
        return value;
    }

    public Class getType() {
        Class class_ = this.override;
        if (class_ != null) {
            return class_;
        }
        return this.type.getType();
    }

    public boolean setOverride(Type type, Object object, OutputNode outputNode) throws Exception {
        Class class_ = type.getType();
        if (class_.isPrimitive()) {
            type = this.getPrimitive(type, class_);
        }
        return this.context.setOverride(type, object, outputNode);
    }
}

