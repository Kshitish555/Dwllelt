/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 *  org.simpleframework.xml.core.Model
 *  org.simpleframework.xml.core.ModelList
 *  org.simpleframework.xml.core.ModelMap
 *  org.simpleframework.xml.core.Section
 */
package org.simpleframework.xml.core;

import java.util.ArrayList;
import java.util.Iterator;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.Model;
import org.simpleframework.xml.core.ModelList;
import org.simpleframework.xml.core.ModelMap;
import org.simpleframework.xml.core.Section;

class ModelSection
implements Section {
    private LabelMap attributes;
    private LabelMap elements;
    private Model model;
    private ModelMap models;

    public ModelSection(Model model) {
        this.model = model;
    }

    public String getAttribute(String string2) throws Exception {
        Expression expression = this.model.getExpression();
        if (expression == null) {
            return string2;
        }
        return expression.getAttribute(string2);
    }

    public LabelMap getAttributes() throws Exception {
        if (this.attributes == null) {
            this.attributes = this.model.getAttributes();
        }
        return this.attributes;
    }

    public Label getElement(String string2) throws Exception {
        return this.getElements().getLabel(string2);
    }

    public LabelMap getElements() throws Exception {
        if (this.elements == null) {
            this.elements = this.model.getElements();
        }
        return this.elements;
    }

    public ModelMap getModels() throws Exception {
        if (this.models == null) {
            this.models = this.model.getModels();
        }
        return this.models;
    }

    public String getName() {
        return this.model.getName();
    }

    public String getPath(String string2) throws Exception {
        Expression expression = this.model.getExpression();
        if (expression == null) {
            return string2;
        }
        return expression.getElement(string2);
    }

    public String getPrefix() {
        return this.model.getPrefix();
    }

    public Section getSection(String string2) throws Exception {
        Model model;
        ModelList modelList = (ModelList)this.getModels().get((Object)string2);
        if (modelList != null && (model = modelList.take()) != null) {
            return new ModelSection(model);
        }
        return null;
    }

    public Label getText() throws Exception {
        return this.model.getText();
    }

    public boolean isSection(String string2) throws Exception {
        return this.getModels().get((Object)string2) != null;
    }

    public Iterator<String> iterator() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.model.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((String)iterator.next()));
        }
        return arrayList.iterator();
    }
}

