/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.Set
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Entry
 */
package org.simpleframework.xml.core;

import java.util.Map;
import java.util.Set;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Entry;
import org.simpleframework.xml.core.MapFactory;
import org.simpleframework.xml.core.Repeater;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.Mode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Style;

class CompositeInlineMap
implements Repeater {
    private final Entry entry;
    private final MapFactory factory;
    private final Converter key;
    private final Style style;
    private final Converter value;

    public CompositeInlineMap(Context context, Entry entry, Type type) throws Exception {
        this.factory = new MapFactory(context, type);
        this.value = entry.getValue(context);
        this.key = entry.getKey(context);
        this.style = context.getStyle();
        this.entry = entry;
    }

    private Object read(InputNode inputNode, Map map) throws Exception {
        InputNode inputNode2 = inputNode.getParent();
        String string2 = inputNode.getName();
        while (inputNode != null) {
            Object object = this.key.read(inputNode);
            Object object2 = this.value.read(inputNode);
            if (map != null) {
                map.put(object, object2);
            }
            inputNode = inputNode2.getNext(string2);
        }
        return map;
    }

    private void write(OutputNode outputNode, Map map, Mode mode) throws Exception {
        String string2 = this.entry.getEntry();
        String string3 = this.style.getElement(string2);
        for (Object object : map.keySet()) {
            OutputNode outputNode2 = outputNode.getChild(string3);
            Object object2 = map.get(object);
            outputNode2.setMode(mode);
            this.key.write(outputNode2, object);
            this.value.write(outputNode2, object2);
        }
    }

    public Object read(InputNode inputNode) throws Exception {
        Map map = (Map)this.factory.getInstance();
        if (map != null) {
            return this.read(inputNode, map);
        }
        return null;
    }

    @Override
    public Object read(InputNode inputNode, Object object) throws Exception {
        Map map = (Map)object;
        if (map != null) {
            return this.read(inputNode, map);
        }
        return this.read(inputNode);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        InputNode inputNode2 = inputNode.getParent();
        String string2 = inputNode.getName();
        while (inputNode != null) {
            if (!this.key.validate(inputNode)) {
                return false;
            }
            if (!this.value.validate(inputNode)) {
                return false;
            }
            inputNode = inputNode2.getNext(string2);
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        OutputNode outputNode2 = outputNode.getParent();
        Mode mode = outputNode.getMode();
        Map map = (Map)object;
        if (!outputNode.isCommitted()) {
            outputNode.remove();
        }
        this.write(outputNode2, map, mode);
    }
}

