/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.lang.reflect.Field
 *  java.lang.reflect.Type
 *  l.a.h.h.a
 *  l.a.h.h.a$b
 *  l.a.h.i.a
 *  l.a.h.i.c
 *  l.a.h.i.d
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.h.k.c$f
 *  l.a.i.i.a
 *  l.a.i.i.a$b
 *  l.a.j.c$c
 *  l.a.j.c$c$b
 *  l.a.j.c$d
 *  l.a.j.c$f$b
 *  l.a.j.e$g
 *  l.a.j.q.b
 *  l.a.j.q.b$c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 *  l.a.j.q.l.a
 *  l.a.j.q.l.e
 *  l.a.k.a.r
 */
package l.a.j;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import l.a.h.h.a;
import l.a.h.k.c;
import l.a.i.i.a;
import l.a.j.c;
import l.a.j.e;
import l.a.j.q.b;
import l.a.j.q.e;
import l.a.j.q.i.a;
import l.a.k.a.r;

public abstract class c
implements l.a.j.e {
    protected final c c;
    protected final l.a.j.q.i.a d;
    protected final a.d f;

    protected c(c c2, l.a.j.q.i.a a2, a.d d2) {
        this.c = c2;
        this.d = a2;
        this.f = d2;
    }

    public static b a(Field field) {
        return c.a((l.a.h.h.a)new a.b(field));
    }

    public static b a(l.a.h.h.a a2) {
        return new g(new a(a2)){
            {
                this(c2, l.a.j.q.i.a.w0, a.d.d);
            }

            @Override
            public b a(Class<?> class_) {
                return this.b((l.a.h.k.c)new c.d(class_));
            }

            @Override
            public b a(a.b b2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public h a(l.a.j.q.i.a a2, a.d d2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public e.b a(int n2) {
                if (n2 >= 0) {
                    return new e.b(this.c, this.d, this.f, n2){
                        private final int h;
                        private final b o;
                        {
                            this(c2, a2, d2, n2, b.c);
                        }
                        {
                            this.h = n2;
                            this.o = b2;
                        }

                        @Override
                        public l.a.j.e a(l.a.j.e e2) {
                            l.a.j.e[] arre = new l.a.j.e[2];
                            e.b b2 = new /* invalid duplicate definition of identical inner class */;
                            arre[0] = b2;
                            arre[1] = e2;
                            return new l.a.j.e(arre){
                                private final java.util.List<l.a.j.e> c;
                                {
                                    this.c = new java.util.ArrayList();
                                    for (l.a.j.e e2 : list) {
                                        if (e2 instanceof e.c) {
                                            this.c.addAll((e2).c);
                                            continue;
                                        }
                                        this.c.add((Object)e2);
                                    }
                                }
                                {
                                    this((java.util.List<? extends l.a.j.e>)java.util.Arrays.asList((Object[])arre));
                                }

                                public l.a.i.i.c a(l.a.i.i.c c2) {
                                    java.util.Iterator iterator = this.c.iterator();
                                    while (iterator.hasNext()) {
                                        c2 = ((l.a.j.e)iterator.next()).a(c2);
                                    }
                                    return c2;
                                }

                                public l.a.j.q.b a(e.g g2) {
                                    l.a.j.q.b[] arrb = new l.a.j.q.b[this.c.size()];
                                    java.util.Iterator iterator = this.c.iterator();
                                    int n2 = 0;
                                    while (iterator.hasNext()) {
                                        l.a.j.e e2 = (l.a.j.e)iterator.next();
                                        int n3 = n2 + 1;
                                        arrb[n2] = e2.a(g2);
                                        n2 = n3;
                                    }
                                    return new l.a.j.q.b$a(arrb);
                                }

                                protected boolean a(Object object) {
                                    return object instanceof e.c;
                                }

                                public boolean equals(Object object) {
                                    if (object == this) {
                                        return true;
                                    }
                                    if (!(object instanceof e.c)) {
                                        return false;
                                    }
                                    e.c c2 = object;
                                    if (!c2.a(this)) {
                                        return false;
                                    }
                                    java.util.List<l.a.j.e> list = this.c;
                                    java.util.List<l.a.j.e> list2 = c2.c;
                                    return !(list == null ? list2 != null : !list.equals(list2));
                                }

                                public int hashCode() {
                                    java.util.List<l.a.j.e> list = this.c;
                                    int n2 = list == null ? 43 : list.hashCode();
                                    return 59 + n2;
                                }
                            };
                        }

                        @Override
                        public l.a.j.q.b a(e.g g2) {
                            return new l.a.j.q.b(this.c.a(g2.c())){
                                private final b c;
                                {
                                    this.c = b2;
                                }

                                private f a() {
                                    return f.this;
                                }

                                public b.c a(r r2, e.d d2, l.a.h.i.a a2) {
                                    if (a2.getParameters().size() > f.this.h) {
                                        l.a.j.q.e[] arre = new l.a.j.q.e[]{f.this.a(this.c.a(a2), (l.a.h.i.c)a2.getParameters().get(f.this.h)), f.this.o.a(a2)};
                                        return new b.c(new e.a(arre).a(r2, d2).a(), a2.l());
                                    }
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append((Object)a2);
                                    stringBuilder.append(" does not define a parameter with index ");
                                    stringBuilder.append(f.this.h);
                                    throw new IllegalStateException(stringBuilder.toString());
                                }

                                public boolean equals(Object object) {
                                    if (this == object) {
                                        return true;
                                    }
                                    if (object != null) {
                                        if (a.class != object.getClass()) {
                                            return false;
                                        }
                                        a a2 = object;
                                        return this.c.equals((Object)a2.c) && f.this.equals(a2.a());
                                    }
                                    return false;
                                }

                                public int hashCode() {
                                    return this.c.hashCode() + 31 * f.this.hashCode();
                                }
                            };
                        }

                        @Override
                        protected boolean a(Object object) {
                            return object instanceof f;
                        }

                        @Override
                        public boolean equals(Object object) {
                            if (object == this) {
                                return true;
                            }
                            if (!(object instanceof f)) {
                                return false;
                            }
                            f f2 = object;
                            if (!f2.a((Object)this)) {
                                return false;
                            }
                            if (!super.equals(object)) {
                                return false;
                            }
                            if (this.h != f2.h) {
                                return false;
                            }
                            b b2 = this.o;
                            b b3 = f2.o;
                            return !(b2 == null ? b3 != null : !b2.equals((Object)b3));
                        }

                        @Override
                        public int hashCode() {
                            int n2 = 59 * (59 + super.hashCode()) + this.h;
                            b b2 = this.o;
                            int n3 = n2 * 59;
                            int n4 = b2 == null ? 43 : b2.hashCode();
                            return n3 + n4;
                        }

                    };
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("A parameter index cannot be negative: ");
                stringBuilder.append(n2);
                throw new IllegalArgumentException(stringBuilder.toString());
            }

            @Override
            public l.a.j.q.b a(e.g g2) {
                return new l.a.j.q.b(this.c.a(g2.c())){
                    private final b c;
                    {
                        this.c = b2;
                    }

                    private e a() {
                        return e.this;
                    }

                    public b.c a(r r2, e.d d2, l.a.h.i.a a2) {
                        block2 : {
                            block5 : {
                                e.a a3;
                                block4 : {
                                    l.a.h.h.a a4;
                                    block3 : {
                                        if (!a2.Y0()) break block2;
                                        a4 = this.c.a(a2);
                                        if (a2.getReturnType().a((Type)Void.TYPE)) break block3;
                                        l.a.j.q.e[] arre = new l.a.j.q.e[]{e.this.a(a4, a2), l.a.j.q.l.d.a((l.a.h.k.b)a2.getReturnType())};
                                        a3 = new e.a(arre);
                                        break block4;
                                    }
                                    if (!a2.getReturnType().a((Type)Void.TYPE) || a2.getParameters().size() != 1) break block5;
                                    l.a.j.q.e[] arre = new l.a.j.q.e[]{e.this.a(a4, (l.a.h.i.c)a2.getParameters().get(0)), l.a.j.q.l.d.t};
                                    a3 = new e.a(arre);
                                }
                                return new b.c(a3.a(r2, d2).a(), a2.l());
                            }
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Method ");
                            stringBuilder.append((Object)d2);
                            stringBuilder.append(" is no bean property");
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append((Object)a2);
                        stringBuilder.append(" does not describe a field getter or setter");
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }

                    public boolean equals(Object object) {
                        if (this == object) {
                            return true;
                        }
                        if (object != null) {
                            if (a.class != object.getClass()) {
                                return false;
                            }
                            a a2 = object;
                            return this.c.equals((Object)a2.c) && e.this.equals(a2.a());
                        }
                        return false;
                    }

                    public int hashCode() {
                        return this.c.hashCode() + 31 * e.this.hashCode();
                    }
                };
            }

            @Override
            public b b(l.a.h.k.c c2) {
                return this.a(new a.b(c2){
                    private final l.a.h.k.c c;
                    {
                        this.c = c2;
                    }

                    public l.a.i.i.a a(l.a.h.k.c c2) {
                        return new a.d(this.c, c2);
                    }

                    protected boolean a(Object object) {
                        return object instanceof a.d.a;
                    }

                    public boolean equals(Object object) {
                        if (object == this) {
                            return true;
                        }
                        if (!(object instanceof a.d.a)) {
                            return false;
                        }
                        a.d.a a2 = object;
                        if (!a2.a(this)) {
                            return false;
                        }
                        l.a.h.k.c c2 = this.c;
                        l.a.h.k.c c3 = a2.c;
                        return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
                    }

                    public int hashCode() {
                        l.a.h.k.c c2 = this.c;
                        int n2 = c2 == null ? 43 : c2.hashCode();
                        return 59 + n2;
                    }
                });
            }

        };
    }

    public static g a() {
        return c.a(a.c);
    }

    public static g a(String string) {
        return c.a(new b(string));
    }

    public static g a(d d2) {
        return new /* invalid duplicate definition of identical inner class */;
    }

    private l.a.j.q.e a(l.a.h.h.a a2, l.a.h.i.a a3, l.a.j.q.e e2) {
        if (e2.x()) {
            if (a3.isStatic() && !a2.isStatic()) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot call instance field ");
                stringBuilder.append((Object)a2);
                stringBuilder.append(" from static method ");
                stringBuilder.append((Object)a3);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            l.a.j.q.e[] arre = new l.a.j.q.e[2];
            e.d d2 = a2.isStatic() ? e.d.c : l.a.j.q.l.e.c();
            arre[0] = d2;
            arre[1] = e2;
            return new e.a(arre);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Incompatible type of ");
        stringBuilder.append((Object)a2);
        stringBuilder.append(" and ");
        stringBuilder.append((Object)a3);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public l.a.i.i.c a(l.a.i.i.c c2) {
        return c2;
    }

    protected l.a.j.q.e a(l.a.h.h.a a2, l.a.h.i.a a3) {
        l.a.j.q.e[] arre = new l.a.j.q.e[]{l.a.j.q.l.a.a((l.a.h.h.a)a2).read(), this.d.a(a2.getType(), a3.getReturnType(), this.f)};
        return this.a(a2, a3, (l.a.j.q.e)new e.a(arre));
    }

    protected l.a.j.q.e a(l.a.h.h.a a2, l.a.h.i.c c2) {
        if (a2.isFinal() && c2.c().Y0()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot set final field ");
            stringBuilder.append((Object)a2);
            stringBuilder.append(" from ");
            stringBuilder.append((Object)c2.c());
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        l.a.h.i.a a3 = c2.c();
        l.a.j.q.e[] arre = new l.a.j.q.e[]{l.a.j.q.l.e.a((l.a.h.i.c)c2), this.d.a(c2.getType(), a2.getType(), this.f), l.a.j.q.l.a.a((l.a.h.h.a)a2).a()};
        return this.a(a2, a3, (l.a.j.q.e)new e.a(arre));
    }

    protected boolean a(Object object) {
        return object instanceof c;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof c)) {
            return false;
        }
        c c2 = (c)object;
        if (!c2.a(this)) {
            return false;
        }
        c c3 = this.c;
        c c4 = c2.c;
        if (c3 == null ? c4 != null : !c3.equals((Object)c4)) {
            return false;
        }
        l.a.j.q.i.a a2 = this.d;
        l.a.j.q.i.a a3 = c2.d;
        if (a2 == null ? a3 != null : !a2.equals((Object)a3)) {
            return false;
        }
        a.d d2 = this.f;
        a.d d3 = c2.f;
        return !(d2 == null ? d3 != null : !d2.equals((Object)d3));
    }

    public int hashCode() {
        c c2 = this.c;
        int n2 = 43;
        int n3 = c2 == null ? 43 : c2.hashCode();
        int n4 = n3 + 59;
        l.a.j.q.i.a a2 = this.d;
        int n5 = n4 * 59;
        int n6 = a2 == null ? 43 : a2.hashCode();
        int n7 = n5 + n6;
        a.d d2 = this.f;
        int n8 = n7 * 59;
        if (d2 != null) {
            n2 = d2.hashCode();
        }
        return n8 + n2;
    }

    public static interface h
    extends l.a.j.e {
        public e.b a(int var1);
    }

}

