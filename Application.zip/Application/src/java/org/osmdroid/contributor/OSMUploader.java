/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedInputStream
 *  java.io.DataOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.GregorianCalendar
 *  org.osmdroid.contributor.OSMUploader$1
 *  org.osmdroid.contributor.util.RecordedGeoPoint
 *  org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants
 */
package org.osmdroid.contributor;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import org.osmdroid.contributor.OSMUploader;
import org.osmdroid.contributor.util.RecordedGeoPoint;
import org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants;

public class OSMUploader
implements OpenStreetMapContributorConstants {
    public static final String API_VERSION = "0.5";
    private static final String BASE64_ENC = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    private static final String BOUNDARY = "----------------------------d10f7aa230e8";
    private static final int BUFFER_SIZE = 65535;
    private static final String DEFAULT_DESCRIPTION = "AndNav - automatically created route.";
    private static final String DEFAULT_TAGS = "AndNav";
    private static final String LINE_END = "\r\n";
    private static final SimpleDateFormat autoTagFormat;
    public static final SimpleDateFormat pseudoFileNameFormat;

    static {
        pseudoFileNameFormat = new SimpleDateFormat("yyyyMMdd'_'HHmmss'_'SSS");
        autoTagFormat = new SimpleDateFormat("MMMM yyyy");
    }

    private OSMUploader() {
    }

    static /* synthetic */ SimpleDateFormat access$000() {
        return autoTagFormat;
    }

    static /* synthetic */ String access$100(String string2) {
        return OSMUploader.encodeBase64(string2);
    }

    static /* synthetic */ void access$200(DataOutputStream dataOutputStream, String string2, InputStream inputStream, String string3) throws IOException {
        OSMUploader.writeContentDispositionFile(dataOutputStream, string2, inputStream, string3);
    }

    static /* synthetic */ void access$300(DataOutputStream dataOutputStream, String string2, String string3) throws IOException {
        OSMUploader.writeContentDisposition(dataOutputStream, string2, string3);
    }

    private static String encodeBase64(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < (2 + string2.length()) / 3; ++i) {
            char c;
            int n = string2.length();
            int n2 = i * 3;
            int n3 = Math.min((int)3, (int)(n - n2));
            String string3 = string2.substring(n2, n2 + n3);
            stringBuilder.append(BASE64_ENC.charAt(string3.charAt(0) >> 2));
            int n4 = (3 & string3.charAt(0)) << 4;
            int n5 = n3 == 1 ? 0 : (240 & string3.charAt(1)) >> 4;
            stringBuilder.append(BASE64_ENC.charAt(n4 | n5));
            char c2 = '=';
            if (n3 > 1) {
                int n6 = (15 & string3.charAt(1)) << 2;
                int n7 = n3 == 2 ? 0 : (192 & string3.charAt(2)) >> 6;
                c = BASE64_ENC.charAt(n6 | n7);
            } else {
                c = '=';
            }
            stringBuilder.append(c);
            if (n3 > 2) {
                c2 = BASE64_ENC.charAt(63 & string3.charAt(2));
            }
            stringBuilder.append(c2);
        }
        return stringBuilder.toString();
    }

    public static void upload(String string2, String string3, String string4, String string5, boolean bl, ArrayList<RecordedGeoPoint> arrayList, String string6) throws IOException {
        OSMUploader.uploadAsync(string2, string3, string4, string5, bl, arrayList, string6);
    }

    public static void uploadAsync(String string2, String string3, String string4, String string5, boolean bl, ArrayList<RecordedGeoPoint> arrayList, String string6) {
        if (string2 != null) {
            if (string2.length() == 0) {
                return;
            }
            if (string3 != null) {
                if (string3.length() == 0) {
                    return;
                }
                if (string4 != null) {
                    if (string4.length() == 0) {
                        return;
                    }
                    if (string5 != null) {
                        if (string5.length() == 0) {
                            return;
                        }
                        if (string6 != null) {
                            if (string6.endsWith(".gpx")) {
                                return;
                            }
                            1 var7_7 = new 1(arrayList, string5, bl, string4, string2, string3, string6);
                            new Thread((Runnable)var7_7, "OSMUpload-Thread").start();
                        }
                    }
                }
            }
        }
    }

    public static void uploadAsync(String string2, String string3, boolean bl, ArrayList<RecordedGeoPoint> arrayList) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(pseudoFileNameFormat.format(new GregorianCalendar().getTime()));
        stringBuilder.append("_");
        stringBuilder.append("PUT_YOUR_USERNAME_HERE");
        stringBuilder.append(".gpx");
        OSMUploader.uploadAsync("PUT_YOUR_USERNAME_HERE", "PUT_YOUR_PASSWORD_HERE", string2, string3, bl, arrayList, stringBuilder.toString());
    }

    public static void uploadAsync(ArrayList<RecordedGeoPoint> arrayList) {
        OSMUploader.uploadAsync(DEFAULT_DESCRIPTION, DEFAULT_TAGS, true, arrayList);
    }

    private static void writeContentDisposition(DataOutputStream dataOutputStream, String string2, String string3) throws IOException {
        dataOutputStream.writeBytes("------------------------------d10f7aa230e8\r\n");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Content-Disposition: form-data; name=\"");
        stringBuilder.append(string2);
        stringBuilder.append("\"");
        stringBuilder.append(LINE_END);
        dataOutputStream.writeBytes(stringBuilder.toString());
        dataOutputStream.writeBytes(LINE_END);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(string3);
        stringBuilder2.append(LINE_END);
        dataOutputStream.writeBytes(stringBuilder2.toString());
    }

    private static void writeContentDispositionFile(DataOutputStream dataOutputStream, String string2, InputStream inputStream, String string3) throws IOException {
        int n;
        dataOutputStream.writeBytes("------------------------------d10f7aa230e8\r\n");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Content-Disposition: form-data; name=\"");
        stringBuilder.append(string2);
        stringBuilder.append("\"; filename=\"");
        stringBuilder.append(string3);
        stringBuilder.append("\"");
        stringBuilder.append(LINE_END);
        dataOutputStream.writeBytes(stringBuilder.toString());
        dataOutputStream.writeBytes("Content-Type: application/octet-stream\r\n");
        dataOutputStream.writeBytes(LINE_END);
        byte[] arrby = new byte[65535];
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        while ((n = bufferedInputStream.read(arrby)) >= 0) {
            dataOutputStream.write(arrby, 0, n);
            dataOutputStream.flush();
        }
        bufferedInputStream.close();
        dataOutputStream.writeBytes(LINE_END);
    }
}

