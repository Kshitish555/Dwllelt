/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import com.adjust.sdk.Util;
import org.json.JSONObject;

public class AdjustEventSuccess {
    public String adid;
    public String callbackId;
    public String eventToken;
    public JSONObject jsonResponse;
    public String message;
    public String timestamp;

    public String toString() {
        Object[] arrobject = new Object[]{this.message, this.timestamp, this.adid, this.eventToken, this.callbackId, this.jsonResponse};
        return Util.formatString("Event Success msg:%s time:%s adid:%s event:%s cid:%s json:%s", arrobject);
    }
}

