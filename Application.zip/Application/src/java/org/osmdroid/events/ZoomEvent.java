/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.events.MapEvent
 */
package org.osmdroid.events;

import org.osmdroid.events.MapEvent;
import org.osmdroid.views.MapView;

public class ZoomEvent
implements MapEvent {
    protected MapView source;
    protected int zoomLevel;

    public ZoomEvent(MapView mapView, int n) {
        this.source = mapView;
        this.zoomLevel = n;
    }

    public MapView getSource() {
        return this.source;
    }

    public int getZoomLevel() {
        return this.zoomLevel;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ZoomEvent [source=");
        stringBuilder.append((Object)this.source);
        stringBuilder.append(", zoomLevel=");
        stringBuilder.append(this.zoomLevel);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

