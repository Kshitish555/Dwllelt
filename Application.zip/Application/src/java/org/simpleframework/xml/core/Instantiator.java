/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package org.simpleframework.xml.core;

import java.util.List;
import org.simpleframework.xml.core.Creator;
import org.simpleframework.xml.core.Criteria;
import org.simpleframework.xml.core.Parameter;

interface Instantiator {
    public List<Creator> getCreators();

    public Object getInstance() throws Exception;

    public Object getInstance(Criteria var1) throws Exception;

    public Parameter getParameter(String var1);

    public List<Parameter> getParameters();

    public boolean isDefault();
}

