/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.i.a
 *  l.a.h.i.b
 *  l.a.h.i.d
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.h.k.d
 *  l.a.h.k.d$f
 *  l.a.l.c0
 *  l.a.l.r
 *  l.a.l.r$a
 *  l.a.l.s
 */
package l.a.i.i.i;

import l.a.h.i.a;
import l.a.h.i.d;
import l.a.h.k.c;
import l.a.h.k.d;
import l.a.l.c0;
import l.a.l.r;
import l.a.l.s;

public class b
implements c0<a> {
    private final c0<? super a> c;
    private final r<? super a> d;

    protected b(c0<? super a> c02, r<? super a> r2) {
        this.c = c02;
        this.d = r2;
    }

    protected static c0<a> a(c0<? super a> c02, c c2) {
        r.a a2 = s.M();
        for (a a3 : c2.u()) {
            r.a a4 = a3.p1() ? s.g() : s.m((String)a3.getName());
            a2 = a2.b((r)a4.a((r)s.p((c)a3.getReturnType().y0())).a((r)s.d((Iterable)a3.getParameters().E().m1())));
        }
        return new b(c02, (r<? super a>)a2);
    }

    public r<? super a> a(c c2) {
        return s.F((r)this.c.a(c2)).a((r)s.K().a((r)s.F((r)s.n())).b((r)s.i((c)c2))).b((r)s.i((c)c2).a((r)s.F(this.d)));
    }

    protected boolean a(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (!b2.a(this)) {
            return false;
        }
        c0<? super a> c02 = this.c;
        c0<? super a> c03 = b2.c;
        if (c02 == null ? c03 != null : !c02.equals(c03)) {
            return false;
        }
        r<? super a> r2 = this.d;
        r<? super a> r3 = b2.d;
        return !(r2 == null ? r3 != null : !r2.equals(r3));
    }

    public int hashCode() {
        c0<? super a> c02 = this.c;
        int n2 = 43;
        int n3 = c02 == null ? 43 : c02.hashCode();
        int n4 = n3 + 59;
        r<? super a> r2 = this.d;
        int n5 = n4 * 59;
        if (r2 != null) {
            n2 = r2.hashCode();
        }
        return n5 + n2;
    }
}

