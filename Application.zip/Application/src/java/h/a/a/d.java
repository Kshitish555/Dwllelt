/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.c
 *  h.a.a.d$a
 *  java.lang.FunctionalInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package h.a.a;

import h.a.a.c;
import h.a.a.d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class d
extends ArrayList<c> {
    static final d c = new a();

    d() {
    }

    d(int n2) {
        super(n2);
    }

    d(Collection<c> collection) {
        super(collection);
    }

    public d a(b b2) {
        d d2 = new d();
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            c c2 = (c)iterator.next();
            if (!b2.a(c2)) continue;
            d2.add((Object)c2);
        }
        return d2;
    }

    public boolean a(String string) {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            if (!((c)iterator.next()).h().equals((Object)string)) continue;
            return true;
        }
        return false;
    }

    public List<String> b() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((c)iterator.next()).toString());
        }
        return arrayList;
    }

    public List<String> c() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((c)iterator.next()).h());
        }
        return arrayList;
    }

    public c get(String string) {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            c c2 = (c)iterator.next();
            if (!c2.h().equals((Object)string)) continue;
            return c2;
        }
        return null;
    }

    @FunctionalInterface
    public static interface b {
        public boolean a(c var1);
    }

}

