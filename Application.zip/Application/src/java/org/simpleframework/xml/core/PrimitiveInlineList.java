/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  org.simpleframework.xml.core.Context
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import org.simpleframework.xml.core.CollectionFactory;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Primitive;
import org.simpleframework.xml.core.Repeater;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.Mode;
import org.simpleframework.xml.stream.OutputNode;

class PrimitiveInlineList
implements Repeater {
    private final Type entry;
    private final CollectionFactory factory;
    private final String parent;
    private final Primitive root;

    public PrimitiveInlineList(Context context, Type type, Type type2, String string2) {
        this.factory = new CollectionFactory(context, type);
        this.root = new Primitive(context, type2);
        this.parent = string2;
        this.entry = type2;
    }

    private boolean isOverridden(OutputNode outputNode, Object object) throws Exception {
        return this.factory.setOverride(this.entry, object, outputNode);
    }

    private Object read(InputNode inputNode, Collection collection) throws Exception {
        InputNode inputNode2 = inputNode.getParent();
        String string2 = inputNode.getName();
        while (inputNode != null) {
            Object object = this.root.read(inputNode);
            if (object != null) {
                collection.add(object);
            }
            inputNode = inputNode2.getNext(string2);
        }
        return collection;
    }

    private void write(OutputNode outputNode, Object object, Mode mode) throws Exception {
        for (Object object2 : (Collection)object) {
            OutputNode outputNode2;
            if (object2 == null || this.isOverridden(outputNode2 = outputNode.getChild(this.parent), object2)) continue;
            outputNode2.setMode(mode);
            this.root.write(outputNode2, object2);
        }
    }

    public Object read(InputNode inputNode) throws Exception {
        Collection collection = (Collection)this.factory.getInstance();
        if (collection != null) {
            return this.read(inputNode, collection);
        }
        return null;
    }

    @Override
    public Object read(InputNode inputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        if (collection != null) {
            return this.read(inputNode, collection);
        }
        return this.read(inputNode);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        InputNode inputNode2 = inputNode.getParent();
        String string2 = inputNode.getName();
        while (inputNode != null) {
            if (!this.root.validate(inputNode)) {
                return false;
            }
            inputNode = inputNode2.getNext(string2);
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        OutputNode outputNode2 = outputNode.getParent();
        Mode mode = outputNode.getMode();
        if (!outputNode.isCommitted()) {
            outputNode.remove();
        }
        this.write(outputNode2, object, mode);
    }
}

