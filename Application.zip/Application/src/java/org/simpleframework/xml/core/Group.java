/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;

interface Group {
    public LabelMap getElements() throws Exception;

    public Label getLabel(Class var1);

    public Label getText() throws Exception;

    public boolean isInline();

    public boolean isTextList();

    public String toString();
}

