/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.c
 *  h.a.a.c0
 *  h.a.a.j
 *  h.a.a.p0
 *  h.a.a.v
 *  h.a.a.z
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.BitSet
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 */
package h.a.a;

import h.a.a.a0;
import h.a.a.b0;
import h.a.a.c;
import h.a.a.c0;
import h.a.a.d;
import h.a.a.j;
import h.a.a.k;
import h.a.a.l0;
import h.a.a.p0;
import h.a.a.v;
import h.a.a.w;
import h.a.a.z;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

class x {
    private static final int a = 40;
    private static final char b = '\u00a0';
    private static final BitSet c = new BitSet(65536);

    static {
        for (int i2 = 0; i2 < 26; ++i2) {
            c.set((int)"\t\n\u000b\f\r \u0085\u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000".charAt(i2));
        }
    }

    x() {
    }

    static String a(k k2, float f2, float f3, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5, l0 l02) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("digraph {\n");
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("size=\"");
        stringBuilder2.append(f2);
        stringBuilder2.append(",");
        stringBuilder2.append(f3);
        stringBuilder2.append("\";\n");
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append("layout=dot;\n");
        stringBuilder.append("rankdir=\"BT\";\n");
        stringBuilder.append("overlap=false;\n");
        stringBuilder.append("splines=true;\n");
        stringBuilder.append("pack=true;\n");
        stringBuilder.append("graph [fontname = \"Courier, Regular\"]\n");
        stringBuilder.append("node [fontname = \"Courier, Regular\"]\n");
        stringBuilder.append("edge [fontname = \"Courier, Regular\"]\n");
        k k3 = k2.F();
        k k4 = k2.A0();
        k k5 = k2.d();
        Iterator iterator = k3.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            stringBuilder.append("\"");
            stringBuilder.append(j2.P());
            stringBuilder.append("\"");
            x.a(j2, "box", "fff2b6", bl, bl3, l02, stringBuilder);
            stringBuilder.append(";\n");
        }
        Iterator iterator2 = k4.iterator();
        while (iterator2.hasNext()) {
            j j3 = (j)iterator2.next();
            stringBuilder.append("\"");
            stringBuilder.append(j3.P());
            stringBuilder.append("\"");
            x.a(j3, "diamond", "b6e7ff", bl, bl3, l02, stringBuilder);
            stringBuilder.append(";\n");
        }
        Iterator iterator3 = k5.iterator();
        while (iterator3.hasNext()) {
            j j4 = (j)iterator3.next();
            stringBuilder.append("\"");
            stringBuilder.append(j4.P());
            stringBuilder.append("\"");
            x.a(j4, "oval", "f3c9ff", bl, bl3, l02, stringBuilder);
            stringBuilder.append(";\n");
        }
        HashSet hashSet = new HashSet();
        hashSet.addAll(k3.x());
        hashSet.addAll(k4.x());
        hashSet.addAll(k5.x());
        stringBuilder.append("\n");
        Iterator iterator4 = k3.iterator();
        while (iterator4.hasNext()) {
            j j5 = (j)iterator4.next();
            Iterator iterator5 = j5.U().b().iterator();
            while (iterator5.hasNext()) {
                j j6 = (j)iterator5.next();
                if (j6 == null || !hashSet.contains((Object)j6.P()) || j6.P().equals((Object)"java.lang.Object")) continue;
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("  \"");
                stringBuilder3.append(j5.P());
                stringBuilder3.append("\" -> \"");
                stringBuilder3.append(j6.P());
                stringBuilder3.append("\" [arrowsize=2.5]\n");
                stringBuilder.append(stringBuilder3.toString());
            }
            Iterator iterator6 = j5.E().b().iterator();
            while (iterator6.hasNext()) {
                j j7 = (j)iterator6.next();
                if (!hashSet.contains((Object)j7.P())) continue;
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("  \"");
                stringBuilder4.append(j5.P());
                stringBuilder4.append("\" -> \"");
                stringBuilder4.append(j7.P());
                stringBuilder4.append("\" [arrowhead=diamond, arrowsize=2.5]\n");
                stringBuilder.append(stringBuilder4.toString());
            }
            if (bl2) {
                HashSet hashSet2 = new HashSet();
                w w2 = j5.Z4;
                if (w2 != null) {
                    Iterator iterator7 = w2.iterator();
                    while (iterator7.hasNext()) {
                        p0 p02 = ((v)iterator7.next()).q();
                        if (p02 == null) continue;
                        p02.a((Set)hashSet2);
                    }
                }
                for (String string : hashSet2) {
                    if (!hashSet.contains((Object)string) || "java.lang.Object".equals((Object)string)) continue;
                    StringBuilder stringBuilder5 = new StringBuilder();
                    stringBuilder5.append("  \"");
                    stringBuilder5.append(string);
                    stringBuilder5.append("\" -> \"");
                    stringBuilder5.append(j5.P());
                    stringBuilder5.append("\" [arrowtail=obox, arrowsize=2.5, dir=back]\n");
                    stringBuilder.append(stringBuilder5.toString());
                }
            }
            if (!bl4) continue;
            HashSet hashSet3 = new HashSet();
            a0 a02 = j5.a5;
            if (a02 != null) {
                Iterator iterator8 = a02.iterator();
                while (iterator8.hasNext()) {
                    c0 c02 = ((z)iterator8.next()).q();
                    if (c02 == null) continue;
                    c02.a((Set)hashSet3);
                }
            }
            for (String string : hashSet3) {
                if (!hashSet.contains((Object)string) || "java.lang.Object".equals((Object)string)) continue;
                StringBuilder stringBuilder6 = new StringBuilder();
                stringBuilder6.append("  \"");
                stringBuilder6.append(string);
                stringBuilder6.append("\" -> \"");
                stringBuilder6.append(j5.P());
                stringBuilder6.append("\" [arrowtail=box, arrowsize=2.5, dir=back]\n");
                stringBuilder.append(stringBuilder6.toString());
            }
        }
        Iterator iterator9 = k4.iterator();
        while (iterator9.hasNext()) {
            j j8 = (j)iterator9.next();
            Iterator iterator10 = j8.E().b().iterator();
            while (iterator10.hasNext()) {
                j j9 = (j)iterator10.next();
                if (!hashSet.contains((Object)j9.P())) continue;
                StringBuilder stringBuilder7 = new StringBuilder();
                stringBuilder7.append("  \"");
                stringBuilder7.append(j8.P());
                stringBuilder7.append("\" -> \"");
                stringBuilder7.append(j9.P());
                stringBuilder7.append("\" [arrowhead=diamond, arrowsize=2.5]\n");
                stringBuilder.append(stringBuilder7.toString());
            }
        }
        if (bl5) {
            Iterator iterator11 = k5.iterator();
            while (iterator11.hasNext()) {
                j j10 = (j)iterator11.next();
                Iterator iterator12 = j10.m().iterator();
                while (iterator12.hasNext()) {
                    j j11 = (j)iterator12.next();
                    if (!hashSet.contains((Object)j11.P())) continue;
                    StringBuilder stringBuilder8 = new StringBuilder();
                    stringBuilder8.append("  \"");
                    stringBuilder8.append(j11.P());
                    stringBuilder8.append("\" -> \"");
                    stringBuilder8.append(j10.P());
                    stringBuilder8.append("\" [arrowhead=dot, arrowsize=2.5]\n");
                    stringBuilder.append(stringBuilder8.toString());
                }
                Iterator iterator13 = j10.q().iterator();
                while (iterator13.hasNext()) {
                    j j12 = (j)iterator13.next();
                    if (!hashSet.contains((Object)j12.P())) continue;
                    StringBuilder stringBuilder9 = new StringBuilder();
                    stringBuilder9.append("  \"");
                    stringBuilder9.append(j12.P());
                    stringBuilder9.append("\" -> \"");
                    stringBuilder9.append(j10.P());
                    stringBuilder9.append("\" [arrowhead=odot, arrowsize=2.5]\n");
                    stringBuilder.append(stringBuilder9.toString());
                }
                Iterator iterator14 = j10.o().iterator();
                while (iterator14.hasNext()) {
                    j j13 = (j)iterator14.next();
                    if (!hashSet.contains((Object)j13.P())) continue;
                    StringBuilder stringBuilder10 = new StringBuilder();
                    stringBuilder10.append("  \"");
                    stringBuilder10.append(j13.P());
                    stringBuilder10.append("\" -> \"");
                    stringBuilder10.append(j10.P());
                    stringBuilder10.append("\" [arrowhead=odot, arrowsize=2.5]\n");
                    stringBuilder.append(stringBuilder10.toString());
                }
            }
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    private static void a(j j2, String string, String string2, boolean bl, boolean bl2, l0 l02, StringBuilder stringBuilder) {
        String string3;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("[shape=");
        stringBuilder2.append(string);
        stringBuilder2.append(",style=filled,fillcolor=\"#");
        stringBuilder2.append(string2);
        stringBuilder2.append("\",label=");
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append("<");
        stringBuilder.append("<table border='0' cellborder='0' cellspacing='1'>");
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("<tr><td>");
        stringBuilder3.append(j2.L());
        stringBuilder3.append(" ");
        String string4 = j2.a0() ? "enum" : (j2.Y() ? "@interface" : (j2.g0() ? "interface" : "class"));
        stringBuilder3.append(string4);
        stringBuilder3.append("</td></tr>");
        stringBuilder.append(stringBuilder3.toString());
        String string5 = j2.P();
        int n2 = string5.lastIndexOf(46);
        if (n2 > 0) {
            stringBuilder.append("<tr><td><b>");
            x.a(string5.substring(0, n2 + 1), stringBuilder);
            stringBuilder.append("</b></td></tr>");
        }
        stringBuilder.append("<tr><td><font point-size='24'><b>");
        x.a(string5.substring(n2 + 1), stringBuilder);
        stringBuilder.append("</b></font></td></tr>");
        int n3 = (int)(0.8f * (float)Integer.parseInt((String)string2.substring(0, 2), (int)16));
        int n4 = (int)(0.8f * (float)Integer.parseInt((String)string2.substring(2, 4), (int)16));
        int n5 = (int)(0.8f * (float)Integer.parseInt((String)string2.substring(4, 6), (int)16));
        Object[] arrobject = new Object[]{Integer.toString((int)(n3 >> 4), (int)16), Integer.toString((int)(n3 & 15), (int)16), Integer.toString((int)(n4 >> 4), (int)16), Integer.toString((int)(n4 & 15), (int)16), Integer.toString((int)(n5 >> 4), (int)16), Integer.toString((int)(n5 & 15), (int)16)};
        String string6 = String.format((String)"#%s%s%s%s%s%s", (Object[])arrobject);
        d d2 = j2.Y4;
        if (d2 != null && d2.size() > 0) {
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("<tr><td colspan='3' bgcolor='");
            stringBuilder4.append(string6);
            stringBuilder4.append("'><font point-size='12'><b>ANNOTATIONS</b></font></td></tr>");
            stringBuilder.append(stringBuilder4.toString());
            d d3 = new d((Collection<c>)d2);
            Collections.sort((List)d3);
            Iterator iterator = d3.iterator();
            while (iterator.hasNext()) {
                c c2 = (c)iterator.next();
                if (c2.h().startsWith("java.lang.annotation.")) continue;
                stringBuilder.append("<tr>");
                stringBuilder.append("<td align='center' valign='top'>");
                x.a(c2.toString(), stringBuilder);
                stringBuilder.append("</td></tr>");
            }
        }
        w w2 = j2.Z4;
        if (bl && w2 != null && w2.size() > 0) {
            StringBuilder stringBuilder5 = new StringBuilder();
            stringBuilder5.append("<tr><td colspan='3' bgcolor='");
            stringBuilder5.append(string6);
            stringBuilder5.append("'><font point-size='12'><b>");
            string3 = "PUBLIC ";
            String string7 = l02.y ? "" : string3;
            stringBuilder5.append(string7);
            stringBuilder5.append("FIELDS</b></font></td></tr>");
            stringBuilder.append(stringBuilder5.toString());
            stringBuilder.append("<tr><td cellpadding='0'>");
            stringBuilder.append("<table border='0' cellborder='0'>");
            w w3 = new w((Collection<v>)w2);
            Collections.sort((List)w3);
            Iterator iterator = w3.iterator();
            while (iterator.hasNext()) {
                char c3;
                v v2 = (v)iterator.next();
                stringBuilder.append("<tr>");
                stringBuilder.append("<td align='right' valign='top'>");
                d d4 = v2.S4;
                if (d4 != null) {
                    Iterator iterator2 = d4.iterator();
                    while (iterator2.hasNext()) {
                        c c4 = (c)iterator2.next();
                        int n6 = stringBuilder.length();
                        Iterator iterator3 = iterator;
                        char c5 = stringBuilder.charAt(n6 - 1);
                        Iterator iterator4 = iterator2;
                        if (c5 != ' ') {
                            stringBuilder.append(' ');
                        }
                        x.a(c4.toString(), stringBuilder);
                        iterator = iterator3;
                        iterator2 = iterator4;
                    }
                }
                Iterator iterator5 = iterator;
                if (l02.y) {
                    char c6 = stringBuilder.charAt(stringBuilder.length() - 1);
                    if (c6 != (c3 = ' ')) {
                        stringBuilder.append(c3);
                    }
                    stringBuilder.append(v2.l());
                } else {
                    c3 = ' ';
                }
                if (stringBuilder.charAt(-1 + stringBuilder.length()) != c3) {
                    stringBuilder.append(c3);
                }
                x.a(v2.q().toString(), stringBuilder);
                stringBuilder.append("</td>");
                stringBuilder.append("<td align='left' valign='top'><b>");
                x.a(v2.n(), stringBuilder);
                stringBuilder.append("</b></td></tr>");
                iterator = iterator5;
            }
            stringBuilder.append("</table>");
            stringBuilder.append("</td></tr>");
        } else {
            string3 = "PUBLIC ";
        }
        a0 a02 = j2.a5;
        if (bl2 && a02 != null && a02.size() > 0) {
            stringBuilder.append("<tr><td cellpadding='0'>");
            stringBuilder.append("<table border='0' cellborder='0'>");
            StringBuilder stringBuilder6 = new StringBuilder();
            stringBuilder6.append("<tr><td colspan='3' bgcolor='");
            stringBuilder6.append(string6);
            stringBuilder6.append("'><font point-size='12'><b>");
            String string8 = l02.z ? "" : string3;
            stringBuilder6.append(string8);
            stringBuilder6.append("METHODS</b></font></td></tr>");
            stringBuilder.append(stringBuilder6.toString());
            a0 a03 = new a0((Collection<z>)a02);
            Collections.sort((List)a03);
            Iterator iterator = a03.iterator();
            while (iterator.hasNext()) {
                int n7;
                char c7;
                z z2 = (z)iterator.next();
                if (z2.m().equals((Object)"<clinit>")) continue;
                stringBuilder.append("<tr>");
                stringBuilder.append("<td align='right' valign='top'>");
                d d5 = z2.t;
                if (d5 != null) {
                    Iterator iterator6 = d5.iterator();
                    while (iterator6.hasNext()) {
                        c c8 = (c)iterator6.next();
                        if (stringBuilder.charAt(stringBuilder.length() - 1) != ' ') {
                            stringBuilder.append(' ');
                        }
                        x.a(c8.toString(), stringBuilder);
                    }
                }
                if (l02.z) {
                    int n8 = stringBuilder.length();
                    char c9 = stringBuilder.charAt(n8 - (n7 = 1));
                    if (c9 != (c7 = ' ')) {
                        stringBuilder.append(c7);
                    }
                    stringBuilder.append(z2.l());
                } else {
                    n7 = 1;
                    c7 = ' ';
                }
                if (stringBuilder.charAt(stringBuilder.length() - n7) != c7) {
                    stringBuilder.append(c7);
                }
                if (!z2.m().equals((Object)"<init>")) {
                    x.a(z2.q().toString(), stringBuilder);
                } else {
                    stringBuilder.append("<b>&lt;constructor&gt;</b>");
                }
                stringBuilder.append("</td>");
                stringBuilder.append("<td align='left' valign='top'>");
                stringBuilder.append("<b>");
                if (z2.m().equals((Object)"<init>")) {
                    x.a(z2.i().substring(1 + z2.i().lastIndexOf(46)), stringBuilder);
                } else {
                    x.a(z2.m(), stringBuilder);
                }
                stringBuilder.append("</b>&nbsp;");
                stringBuilder.append("</td>");
                stringBuilder.append("<td align='left' valign='top'>");
                int n9 = 40;
                stringBuilder.append((char)n9);
                b0[] arrb0 = z2.n();
                if (arrb0.length != 0) {
                    int n10 = 0;
                    for (int i2 = 0; i2 < arrb0.length; ++i2) {
                        c[] arrc;
                        if (i2 > 0) {
                            stringBuilder.append(", ");
                            n10 += 2;
                        }
                        if (n10 > n9) {
                            stringBuilder.append("</td></tr><tr><td></td><td></td><td align='left' valign='top'>");
                            n10 = 0;
                        }
                        if ((arrc = arrb0[i2].b) != null) {
                            int n11 = arrc.length;
                            for (int i3 = 0; i3 < n11; ++i3) {
                                String string9 = arrc[i3].toString();
                                if (string9.isEmpty()) continue;
                                if (stringBuilder.charAt(-1 + stringBuilder.length()) != ' ') {
                                    stringBuilder.append(' ');
                                }
                                x.a(string9, stringBuilder);
                                if ((n10 += 1 + string9.length()) <= 40) continue;
                                stringBuilder.append("</td></tr><tr><td></td><td></td><td align='left' valign='top'>");
                                n10 = 0;
                            }
                        }
                        String string10 = arrb0[i2].h().toString();
                        x.a(string10, stringBuilder);
                        n10 += string10.length();
                        String string11 = arrb0[i2].e();
                        if (string11 != null) {
                            stringBuilder.append(" <B>");
                            x.a(string11, stringBuilder);
                            n10 += 1 + string11.length();
                            stringBuilder.append("</B>");
                        }
                        n9 = 40;
                    }
                }
                stringBuilder.append(')');
                stringBuilder.append("</td></tr>");
            }
            stringBuilder.append("</table>");
            stringBuilder.append("</td></tr>");
        }
        stringBuilder.append("</table>");
        stringBuilder.append(">]");
    }

    private static void a(CharSequence charSequence, StringBuilder stringBuilder) {
        x.a(charSequence, false, stringBuilder);
    }

    private static void a(CharSequence charSequence, boolean bl, StringBuilder stringBuilder) {
        int n2 = charSequence.length();
        block22 : for (int i2 = 0; i2 < n2; ++i2) {
            block24 : {
                char c2 = charSequence.charAt(i2);
                switch (c2) {
                    default: {
                        if (c2 > ' ' && !x.a(c2)) break;
                        break block24;
                    }
                    case '\u201d': {
                        stringBuilder.append("&rdquo;");
                        continue block22;
                    }
                    case '\u201c': {
                        stringBuilder.append("&ldquo;");
                        continue block22;
                    }
                    case '\u2019': {
                        stringBuilder.append("&rsquo;");
                        continue block22;
                    }
                    case '\u2018': {
                        stringBuilder.append("&lsquo;");
                        continue block22;
                    }
                    case '\u2014': {
                        stringBuilder.append("&mdash;");
                        continue block22;
                    }
                    case '\u2013': {
                        stringBuilder.append("&ndash;");
                        continue block22;
                    }
                    case '\u00bb': {
                        stringBuilder.append("&raquo;");
                        continue block22;
                    }
                    case '\u00ae': {
                        stringBuilder.append("&reg;");
                        continue block22;
                    }
                    case '\u00ab': {
                        stringBuilder.append("&laquo;");
                        continue block22;
                    }
                    case '\u00a9': {
                        stringBuilder.append("&copy;");
                        continue block22;
                    }
                    case '\u00a3': {
                        stringBuilder.append("&pound;");
                        continue block22;
                    }
                    case '\u00a0': {
                        stringBuilder.append("&nbsp;");
                        continue block22;
                    }
                    case '\\': {
                        stringBuilder.append("&lsol;");
                        continue block22;
                    }
                    case '>': {
                        stringBuilder.append("&gt;");
                        continue block22;
                    }
                    case '<': {
                        stringBuilder.append("&lt;");
                        continue block22;
                    }
                    case '/': {
                        stringBuilder.append("&#x2F;");
                        continue block22;
                    }
                    case '\'': {
                        stringBuilder.append("&#x27;");
                        continue block22;
                    }
                    case '&': {
                        stringBuilder.append("&amp;");
                        continue block22;
                    }
                    case '\"': {
                        stringBuilder.append("&quot;");
                        continue block22;
                    }
                    case '\n': {
                        if (bl) {
                            stringBuilder.append("<br>");
                            continue block22;
                        }
                        stringBuilder.append(' ');
                        continue block22;
                    }
                }
                stringBuilder.append(c2);
                continue;
            }
            stringBuilder.append(' ');
        }
    }

    private static boolean a(char c2) {
        return c.get((int)c2);
    }
}

