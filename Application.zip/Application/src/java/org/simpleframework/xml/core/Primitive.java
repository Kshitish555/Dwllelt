/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.core.PersistenceException
 *  org.simpleframework.xml.strategy.Type
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.PrimitiveFactory;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;

class Primitive
implements Converter {
    private final Context context;
    private final String empty;
    private final Class expect;
    private final PrimitiveFactory factory;
    private final Type type;

    public Primitive(Context context, Type type) {
        this(context, type, null);
    }

    public Primitive(Context context, Type type, String string2) {
        this.factory = new PrimitiveFactory(context, type);
        this.expect = type.getType();
        this.context = context;
        this.empty = string2;
        this.type = type;
    }

    private Object readElement(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            return this.readElement(inputNode, instance);
        }
        return instance.getInstance();
    }

    private Object readElement(InputNode inputNode, Instance instance) throws Exception {
        Object object = this.read(inputNode, this.expect);
        if (instance != null) {
            instance.setInstance(object);
        }
        return object;
    }

    private Object readTemplate(String string2, Class class_) throws Exception {
        String string3 = this.context.getProperty(string2);
        if (string3 != null) {
            return this.factory.getInstance(string3, class_);
        }
        return null;
    }

    private boolean validateElement(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            instance.setInstance(null);
        }
        return true;
    }

    public Object read(InputNode inputNode) throws Exception {
        if (inputNode.isElement()) {
            return this.readElement(inputNode);
        }
        return this.read(inputNode, this.expect);
    }

    public Object read(InputNode inputNode, Class class_) throws Exception {
        String string2 = inputNode.getValue();
        if (string2 == null) {
            return null;
        }
        String string3 = this.empty;
        if (string3 != null && string2.equals((Object)string3)) {
            return this.empty;
        }
        return this.readTemplate(string2, class_);
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        if (object == null) {
            return this.read(inputNode);
        }
        Object[] arrobject = new Object[]{this.expect, this.type};
        throw new PersistenceException("Can not read existing %s for %s", arrobject);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        if (inputNode.isElement()) {
            this.validateElement(inputNode);
        } else {
            inputNode.getValue();
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        String string2 = this.factory.getText(object);
        if (string2 != null) {
            outputNode.setValue(string2);
        }
    }
}

