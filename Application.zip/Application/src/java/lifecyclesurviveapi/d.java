/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accounts.Account
 *  j.a.a
 *  java.lang.Object
 *  lifecyclesurviveapi.f
 *  lifecyclesurviveapi.n
 *  lifecyclesurviveapi.r.a
 *  lifecyclesurviveapi.r.b
 */
package lifecyclesurviveapi;

import android.accounts.Account;
import lifecyclesurviveapi.f;
import lifecyclesurviveapi.n;
import lifecyclesurviveapi.r.a;
import lifecyclesurviveapi.r.b;

public abstract class d<T>
extends f<T> {
    @j.a.a
    public a mAccountStorageWrapper;
    @j.a.a
    public b mAuthenticatedApplicationWrapper;

    protected boolean checkRecreated(n n2) {
        return super.checkRecreated(n2) && this.getAccount() == null;
    }

    public Account getAccount() {
        a a2 = this.mAccountStorageWrapper;
        if (a2 != null && a2.h() != null) {
            return this.mAccountStorageWrapper.h();
        }
        return null;
    }

    protected void onRecreated() {
        super.onRecreated();
        this.mAuthenticatedApplicationWrapper.a();
    }
}

