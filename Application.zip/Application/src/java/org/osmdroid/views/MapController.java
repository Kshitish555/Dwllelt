/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  android.widget.Scroller
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Thread
 *  microsoft.mappoint.TileSystem
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IMapController
 *  org.osmdroid.views.MapController$1
 *  org.osmdroid.views.MapController$AbstractAnimationRunner
 *  org.osmdroid.views.MapController$AnimationType
 *  org.osmdroid.views.MapController$HalfCosinusalDeceleratingAnimationRunner
 *  org.osmdroid.views.MapController$MiddlePeakSpeedAnimationRunner
 *  org.osmdroid.views.MapController$QuarterCosinusalDeceleratingAnimationRunner
 *  org.osmdroid.views.util.MyMath
 *  org.osmdroid.views.util.constants.MapViewConstants
 *  org.osmdroid.views.util.constants.MathConstants
 */
package org.osmdroid.views;

import android.graphics.Point;
import android.widget.Scroller;
import microsoft.mappoint.TileSystem;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IMapController;
import org.osmdroid.util.BoundingBoxE6;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.util.MyMath;
import org.osmdroid.views.util.constants.MapViewConstants;
import org.osmdroid.views.util.constants.MathConstants;

/*
 * Exception performing whole class analysis.
 */
public class MapController
implements IMapController,
MapViewConstants {
    private AbstractAnimationRunner mCurrentAnimationRunner;
    private final MapView mOsmv;

    public MapController(MapView mapView) {
        this.mOsmv = mapView;
    }

    public void animateTo(double d, double d2) {
        int n = this.mOsmv.getScrollX();
        int n2 = this.mOsmv.getScrollY();
        Point point = TileSystem.LatLongToPixelXY((double)d, (double)d2, (int)this.mOsmv.getZoomLevel(), null);
        int n3 = TileSystem.MapSize((int)this.mOsmv.getZoomLevel()) / 2;
        this.mOsmv.getScroller().startScroll(n, n2, point.x - n3 - n, point.y - n3 - n2, 1000);
        this.mOsmv.postInvalidate();
    }

    public void animateTo(int n, int n2, AnimationType animationType) {
        this.animateTo(n, n2, animationType, 10, 1000);
    }

    public void animateTo(int n, int n2, AnimationType animationType, int n3, int n4) {
        this.stopAnimation(false);
        int n5 = 1.$SwitchMap$org$osmdroid$views$MapController$AnimationType[animationType.ordinal()];
        if (n5 != 1) {
            if (n5 != 2) {
                if (n5 != 3) {
                    if (n5 != 4) {
                        if (n5 == 5) {
                            MiddlePeakSpeedAnimationRunner middlePeakSpeedAnimationRunner = new /* Unavailable Anonymous Inner Class!! */;
                            this.mCurrentAnimationRunner = middlePeakSpeedAnimationRunner;
                        }
                    } else {
                        HalfCosinusalDeceleratingAnimationRunner halfCosinusalDeceleratingAnimationRunner = new /* Unavailable Anonymous Inner Class!! */;
                        this.mCurrentAnimationRunner = halfCosinusalDeceleratingAnimationRunner;
                    }
                } else {
                    QuarterCosinusalDeceleratingAnimationRunner quarterCosinusalDeceleratingAnimationRunner = new /* Unavailable Anonymous Inner Class!! */;
                    this.mCurrentAnimationRunner = quarterCosinusalDeceleratingAnimationRunner;
                }
            } else {
                ExponentialDeceleratingAnimationRunner exponentialDeceleratingAnimationRunner = new ExponentialDeceleratingAnimationRunner(n, n2, n3, n4);
                this.mCurrentAnimationRunner = exponentialDeceleratingAnimationRunner;
            }
        } else {
            LinearAnimationRunner linearAnimationRunner = new LinearAnimationRunner(n, n2, n3, n4);
            this.mCurrentAnimationRunner = linearAnimationRunner;
        }
        this.mCurrentAnimationRunner.start();
    }

    public void animateTo(IGeoPoint iGeoPoint) {
        double d = iGeoPoint.getLatitudeE6();
        Double.isNaN((double)d);
        double d2 = d / 1000000.0;
        double d3 = iGeoPoint.getLongitudeE6();
        Double.isNaN((double)d3);
        this.animateTo(d2, d3 / 1000000.0);
    }

    public void animateTo(GeoPoint geoPoint, AnimationType animationType) {
        this.animateTo(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6(), animationType, 1000, 10);
    }

    public void animateTo(GeoPoint geoPoint, AnimationType animationType, int n, int n2) {
        this.animateTo(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6(), animationType, n, n2);
    }

    public void scrollBy(int n, int n2) {
        this.mOsmv.scrollBy(n, n2);
    }

    public void setCenter(IGeoPoint iGeoPoint) {
        double d = iGeoPoint.getLatitudeE6();
        Double.isNaN((double)d);
        double d2 = d / 1000000.0;
        double d3 = iGeoPoint.getLongitudeE6();
        Double.isNaN((double)d3);
        Point point = TileSystem.LatLongToPixelXY((double)d2, (double)(d3 / 1000000.0), (int)this.mOsmv.getZoomLevel(), null);
        int n = TileSystem.MapSize((int)this.mOsmv.getZoomLevel()) / 2;
        this.mOsmv.scrollTo(point.x - n, point.y - n);
    }

    public int setZoom(int n) {
        return this.mOsmv.setZoomLevel(n);
    }

    public void stopAnimation(boolean bl) {
        AbstractAnimationRunner abstractAnimationRunner = this.mCurrentAnimationRunner;
        if (abstractAnimationRunner != null && !abstractAnimationRunner.isDone()) {
            abstractAnimationRunner.interrupt();
            if (bl) {
                this.setCenter(new GeoPoint(abstractAnimationRunner.mTargetLatitudeE6, abstractAnimationRunner.mTargetLongitudeE6));
            }
        }
    }

    public boolean zoomIn() {
        return this.mOsmv.zoomIn();
    }

    public boolean zoomInFixing(int n, int n2) {
        return this.mOsmv.zoomInFixing(n, n2);
    }

    public boolean zoomInFixing(GeoPoint geoPoint) {
        return this.mOsmv.zoomInFixing(geoPoint);
    }

    public boolean zoomOut() {
        return this.mOsmv.zoomOut();
    }

    public boolean zoomOutFixing(int n, int n2) {
        return this.mOsmv.zoomOutFixing(n, n2);
    }

    public boolean zoomOutFixing(GeoPoint geoPoint) {
        return this.mOsmv.zoomOutFixing(geoPoint);
    }

    public void zoomToSpan(int n, int n2) {
        if (n > 0) {
            int n3;
            if (n2 <= 0) {
                return;
            }
            BoundingBoxE6 boundingBoxE6 = this.mOsmv.getBoundingBox();
            int n4 = this.mOsmv.getZoomLevel();
            int n5 = boundingBoxE6.getLatitudeSpanE6();
            float f = Math.max((float)((float)n / (float)n5), (float)((float)n2 / (float)(n3 = boundingBoxE6.getLongitudeSpanE6())));
            if (f > 1.0f) {
                this.mOsmv.setZoomLevel(n4 - MyMath.getNextSquareNumberAbove((float)f));
                return;
            }
            if ((double)f < 0.5) {
                this.mOsmv.setZoomLevel(-1 + (n4 + MyMath.getNextSquareNumberAbove((float)(1.0f / f))));
            }
        }
    }

    public void zoomToSpan(BoundingBoxE6 boundingBoxE6) {
        this.zoomToSpan(boundingBoxE6.getLatitudeSpanE6(), boundingBoxE6.getLongitudeSpanE6());
    }

    private class CosinusalBasedAnimationRunner
    extends AbstractAnimationRunner
    implements MathConstants {
        protected final float mAmountStretch;
        protected final float mStart;
        protected final float mStepIncrement;
        protected final float mYOffset;

        public CosinusalBasedAnimationRunner(int n, int n2, float f, float f2, float f3) {
            this(n, n2, 10, 1000, f, f2, f3);
        }

        public CosinusalBasedAnimationRunner(int n, int n2, int n3, int n4, float f, float f2, float f3) {
            super(MapController.this, n, n2, n3, n4);
            this.mYOffset = f3;
            this.mStart = f;
            this.mStepIncrement = f2 / (float)n3;
            float f4 = 0.0f;
            for (int i = 0; i < n3; ++i) {
                double d = f4;
                double d2 = f3;
                double d3 = Math.cos((double)(f + this.mStepIncrement * (float)i));
                Double.isNaN((double)d2);
                double d4 = d2 + d3;
                Double.isNaN((double)d);
                f4 = (float)(d + d4);
            }
            this.mAmountStretch = 1.0f / f4;
            this.setName("QuarterCosinusalDeceleratingAnimationRunner");
        }

        public void onRunAnimation() {
            MapView mapView = MapController.this.mOsmv;
            IGeoPoint iGeoPoint = mapView.getMapCenter();
            int n = this.mStepDuration;
            float f = this.mAmountStretch;
            int n2 = 0;
            do {
                if (n2 >= this.mSmoothness) break;
                double d = this.mYOffset;
                double d2 = Math.cos((double)(this.mStepIncrement * (float)n2 + this.mStart));
                Double.isNaN((double)d);
                double d3 = d + d2;
                double d4 = f;
                Double.isNaN((double)d4);
                double d5 = d3 * d4;
                int n3 = this.mPanTotalLatitudeE6;
                double d6 = n3;
                Double.isNaN((double)d6);
                int n4 = (int)(d6 * d5);
                int n5 = this.mPanTotalLongitudeE6;
                double d7 = n5;
                Double.isNaN((double)d7);
                int n6 = (int)(d7 * d5);
                mapView.setMapCenter(iGeoPoint.getLatitudeE6() - n4, iGeoPoint.getLongitudeE6() - n6);
                Thread.sleep((long)n);
                ++n2;
            } while (true);
            try {
                mapView.setMapCenter(this.mTargetLatitudeE6, this.mTargetLongitudeE6);
                return;
            }
            catch (Exception exception) {
                this.interrupt();
                return;
            }
        }
    }

    private class ExponentialDeceleratingAnimationRunner
    extends AbstractAnimationRunner {
        public ExponentialDeceleratingAnimationRunner(int n, int n2) {
            this(n, n2, 10, 1000);
        }

        public ExponentialDeceleratingAnimationRunner(int n, int n2, int n3, int n4) {
            super(MapController.this, n, n2, n3, n4);
            this.setName("ExponentialDeceleratingAnimationRunner");
        }

        /*
         * Exception decompiling
         */
        public void onRunAnimation() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [5[UNCONDITIONALDOLOOP]], but top level block is 3[TRYBLOCK]
            // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
            // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
            // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
            // java.lang.Thread.run(Thread.java:764)
            throw new IllegalStateException("Decompilation failed");
        }
    }

    private class LinearAnimationRunner
    extends AbstractAnimationRunner {
        protected final int mPanPerStepLatitudeE6;
        protected final int mPanPerStepLongitudeE6;

        public LinearAnimationRunner(int n, int n2) {
            this(n, n2, 10, 1000);
        }

        public LinearAnimationRunner(int n, int n2, int n3, int n4) {
            super(MapController.this, n, n2, n3, n4);
            IGeoPoint iGeoPoint = MapController.this.mOsmv.getMapCenter();
            this.mPanPerStepLatitudeE6 = (iGeoPoint.getLatitudeE6() - n) / n3;
            this.mPanPerStepLongitudeE6 = (iGeoPoint.getLongitudeE6() - n2) / n3;
            this.setName("LinearAnimationRunner");
        }

        /*
         * Exception decompiling
         */
        public void onRunAnimation() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl39 : RETURN : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
            // java.lang.Thread.run(Thread.java:764)
            throw new IllegalStateException("Decompilation failed");
        }
    }

}

