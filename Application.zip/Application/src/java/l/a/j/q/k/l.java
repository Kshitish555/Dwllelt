/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public class l
implements e {
    private final String c;

    public l(String string) {
        this.c = string;
    }

    public e.c a(r r2, e.d d2) {
        r2.a((Object)this.c);
        return f.f.f();
    }

    protected boolean b(Object object) {
        return object instanceof l;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof l)) {
            return false;
        }
        l l2 = (l)object;
        if (!l2.b(this)) {
            return false;
        }
        String string = this.c;
        String string2 = l2.c;
        return !(string == null ? string2 != null : !string.equals((Object)string2));
    }

    public int hashCode() {
        String string = this.c;
        int n2 = string == null ? 43 : string.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }
}

