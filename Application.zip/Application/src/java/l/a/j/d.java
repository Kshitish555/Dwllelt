/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Type
 *  l.a.h.h.a
 *  l.a.h.h.a$c
 *  l.a.h.h.b
 *  l.a.h.i.a
 *  l.a.h.i.c
 *  l.a.h.i.d
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.h.k.c$f
 *  l.a.h.k.c$f$f
 *  l.a.h.k.c$f$f$b
 *  l.a.j.d$a
 *  l.a.j.e$g
 *  l.a.j.h
 *  l.a.j.q.b
 *  l.a.j.q.b$c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 *  l.a.j.q.l.a
 *  l.a.j.q.l.e
 *  l.a.k.a.r
 *  l.a.l.r
 *  l.a.l.s
 *  l.a.l.x
 *  l.a.n.b
 *  l.a.n.b$a
 *  l.a.n.b$b
 *  l.a.n.d
 *  l.a.n.e
 */
package l.a.j;

import java.lang.reflect.Type;
import l.a.h.h.a;
import l.a.h.k.c;
import l.a.j.d;
import l.a.j.e;
import l.a.j.h;
import l.a.j.q.b;
import l.a.j.q.e;
import l.a.j.q.i.a;
import l.a.j.q.k.j;
import l.a.j.q.k.l;
import l.a.l.r;
import l.a.l.s;
import l.a.l.x;
import l.a.n.b;

public abstract class d
implements l.a.j.e {
    protected final l.a.j.q.i.a c;
    protected final a.d d;

    protected d(l.a.j.q.i.a a2, a.d d2) {
        this.c = a2;
        this.d = d2;
    }

    public static b a(Object object, String string) {
        return new b(string, object){
            private static final String s = "value";
            private final String f;
            private final Object h;
            private final c.f o;
            {
                Object[] arrobject = new Object[]{s, l.a.n.e.a((int)object.hashCode())};
                this(String.format((String)"%s$%s", (Object[])arrobject), object);
            }
            {
                this(l.a.j.q.i.a.w0, a.d.d, string, object);
            }
            {
                this.f = string;
                this.h = object;
                this.o = new c.f.f.b(object.getClass());
            }

            public l.a.i.i.c a(l.a.i.i.c c2) {
                return c2.a(new a.g(this.f, 4105, this.o)).a(new h.b(this.f, this.h));
            }

            @Override
            public l.a.j.e a(l.a.j.q.i.a a2, a.d d2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public l.a.j.q.b a(e.g g2) {
                return new l.a.j.q.b(g2.c()){
                    private final l.a.j.q.e c;
                    {
                        this.c = l.a.j.q.l.a.a((a.c)((a.c)((l.a.h.h.b)c2.q().b((r)s.m((String)h.this.f))).b1())).read();
                    }

                    public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                        h h2 = h.this;
                        return h2.a(r2, d2, a2, h2.o, this.c);
                    }

                    protected boolean a(Object object) {
                        return object instanceof a;
                    }

                    public boolean equals(Object object) {
                        if (object == this) {
                            return true;
                        }
                        if (!(object instanceof a)) {
                            return false;
                        }
                        a a2 = object;
                        if (!a2.a(this)) {
                            return false;
                        }
                        l.a.j.q.e e2 = this.c;
                        l.a.j.q.e e3 = a2.c;
                        return !(e2 == null ? e3 != null : !e2.equals((Object)e3));
                    }

                    public int hashCode() {
                        l.a.j.q.e e2 = this.c;
                        int n2 = e2 == null ? 43 : e2.hashCode();
                        return 59 + n2;
                    }
                };
            }

            @Override
            protected boolean a(Object object) {
                return object instanceof h;
            }

            @Override
            public boolean equals(Object object) {
                if (object == this) {
                    return true;
                }
                if (!(object instanceof h)) {
                    return false;
                }
                h h2 = object;
                if (!h2.a(this)) {
                    return false;
                }
                if (!super.equals(object)) {
                    return false;
                }
                String string = this.f;
                String string2 = h2.f;
                if (string == null ? string2 != null : !string.equals((Object)string2)) {
                    return false;
                }
                Object object2 = this.h;
                Object object3 = h2.h;
                return !(object2 == null ? object3 != null : !object2.equals(object3));
            }

            @Override
            public int hashCode() {
                int n2 = 59 + super.hashCode();
                String string = this.f;
                int n3 = n2 * 59;
                int n4 = 43;
                int n5 = string == null ? 43 : string.hashCode();
                int n6 = n3 + n5;
                Object object = this.h;
                int n7 = n6 * 59;
                if (object != null) {
                    n4 = object.hashCode();
                }
                return n7 + n4;
            }

        };
    }

    public static b a(l.a.n.b b2) {
        return new b(b2.b(), b2.getType()){
            private final l.a.j.q.e f;
            private final l.a.h.k.c h;
            {
                this(e2, (l.a.h.k.c)new c.d(class_));
            }
            {
                this(l.a.j.q.i.a.w0, a.d.d, e2, c2);
            }
            {
                this.f = e2;
                this.h = c2;
            }

            public l.a.i.i.c a(l.a.i.i.c c2) {
                return c2;
            }

            @Override
            public l.a.j.e a(l.a.j.q.i.a a2, a.d d2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                return this.a(r2, d2, a2, this.h.E0(), this.f);
            }

            @Override
            public l.a.j.q.b a(e.g g2) {
                return this;
            }

            @Override
            protected boolean a(Object object) {
                return object instanceof f;
            }

            @Override
            public boolean equals(Object object) {
                if (object == this) {
                    return true;
                }
                if (!(object instanceof f)) {
                    return false;
                }
                f f2 = object;
                if (!f2.a(this)) {
                    return false;
                }
                if (!super.equals(object)) {
                    return false;
                }
                l.a.j.q.e e2 = this.f;
                l.a.j.q.e e3 = f2.f;
                if (e2 == null ? e3 != null : !e2.equals((Object)e3)) {
                    return false;
                }
                l.a.h.k.c c2 = this.h;
                l.a.h.k.c c3 = f2.h;
                return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
            }

            @Override
            public int hashCode() {
                int n2 = 59 + super.hashCode();
                l.a.j.q.e e2 = this.f;
                int n3 = n2 * 59;
                int n4 = 43;
                int n5 = e2 == null ? 43 : e2.hashCode();
                int n6 = n3 + n5;
                l.a.h.k.c c2 = this.h;
                int n7 = n6 * 59;
                if (c2 != null) {
                    n4 = c2.hashCode();
                }
                return n7 + n4;
            }
        };
    }

    public static l.a.j.e a() {
        return d.c;
    }

    public static b b() {
        return new b(){
            {
                this(l.a.j.q.i.a.w0, a.d.d);
            }

            public l.a.i.i.c a(l.a.i.i.c c2) {
                return c2;
            }

            @Override
            public l.a.j.e a(l.a.j.q.i.a a2, a.d d2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public l.a.j.q.b a(e.g g2) {
                return new l.a.j.q.b(g2.a().y0()){
                    private final l.a.h.k.c c;
                    {
                        this.c = c2;
                    }

                    private e a() {
                        return e.this;
                    }

                    public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                        return e.this.a(r2, d2, a2, l.a.h.k.c.h0.E0(), l.a.j.q.k.a.c(this.c));
                    }

                    public boolean equals(Object object) {
                        if (this == object) {
                            return true;
                        }
                        if (object != null) {
                            if (a.class != object.getClass()) {
                                return false;
                            }
                            a a2 = object;
                            return this.c.equals((Object)a2.c) && this.a().equals(a2.a());
                        }
                        return false;
                    }

                    public int hashCode() {
                        return 31 * this.a().hashCode() + this.c.hashCode();
                    }
                };
            }

        };
    }

    public static b b(int n2) {
        if (n2 >= 0) {
            return new b(n2){
                private final int f;
                {
                    this(l.a.j.q.i.a.w0, a.d.d, n2);
                }
                {
                    this.f = n2;
                }

                public l.a.i.i.c a(l.a.i.i.c c2) {
                    return c2;
                }

                @Override
                public l.a.j.e a(l.a.j.q.i.a a2, a.d d2) {
                    return new /* invalid duplicate definition of identical inner class */;
                }

                public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                    if (a2.getParameters().size() > this.f) {
                        l.a.h.i.c c2 = (l.a.h.i.c)a2.getParameters().get(this.f);
                        l.a.j.q.e[] arre = new l.a.j.q.e[]{l.a.j.q.l.e.a((l.a.h.i.c)c2), this.c.a(c2.getType(), a2.getReturnType(), this.d), l.a.j.q.l.d.a((l.a.h.k.b)a2.getReturnType())};
                        e.a a3 = new e.a(arre);
                        if (a3.x()) {
                            return new b.c(a3.a(r2, d2).a(), a2.l());
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Cannot assign ");
                        stringBuilder.append((Object)a2.getReturnType());
                        stringBuilder.append(" to ");
                        stringBuilder.append((Object)c2);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append((Object)a2);
                    stringBuilder.append(" does not define a parameter with index ");
                    stringBuilder.append(this.f);
                    throw new IllegalStateException(stringBuilder.toString());
                }

                @Override
                public l.a.j.q.b a(e.g g2) {
                    return this;
                }

                @Override
                protected boolean a(Object object) {
                    return object instanceof c;
                }

                @Override
                public boolean equals(Object object) {
                    if (object == this) {
                        return true;
                    }
                    if (!(object instanceof c)) {
                        return false;
                    }
                    c c2 = object;
                    if (!c2.a(this)) {
                        return false;
                    }
                    if (!super.equals(object)) {
                        return false;
                    }
                    return this.f == c2.f;
                }

                @Override
                public int hashCode() {
                    return 59 * (59 + super.hashCode()) + this.f;
                }
            };
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Argument index cannot be negative: ");
        stringBuilder.append(n2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static b b(Object object) {
        return new /* invalid duplicate definition of identical inner class */;
    }

    public static b c(Object object) {
        Class class_ = object.getClass();
        if (class_ == String.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Class.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Boolean.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Byte.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Short.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Character.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Integer.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Long.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Float.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (class_ == Double.class) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (l.a.n.d.d.c().d(class_)) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        if (l.a.n.d.f.c().a((Type)class_)) {
            return new /* invalid duplicate definition of identical inner class */;
        }
        return d.b(object);
    }

    public static b c(l.a.h.k.c c2) {
        return new /* invalid duplicate definition of identical inner class */;
    }

    public static b d() {
        return new b(){

            public l.a.i.i.c a(l.a.i.i.c c2) {
                return c2;
            }

            @Override
            public l.a.j.e a(l.a.j.q.i.a a2, a.d d2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public l.a.j.q.b a(e.g g2) {
                return new l.a.j.q.b(g2.c()){
                    private final l.a.h.k.c c;
                    {
                        this.c = c2;
                    }

                    public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                        if (!a2.isStatic() && this.c.b(a2.getReturnType().y0())) {
                            l.a.j.q.e[] arre = new l.a.j.q.e[]{l.a.j.q.l.e.c(), l.a.j.q.l.d.w};
                            return new b.b(arre).a(r2, d2, a2);
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Cannot return 'this' from ");
                        stringBuilder.append((Object)a2);
                        throw new IllegalStateException(stringBuilder.toString());
                    }

                    protected boolean a(Object object) {
                        return object instanceof a;
                    }

                    public boolean equals(Object object) {
                        if (object == this) {
                            return true;
                        }
                        if (!(object instanceof a)) {
                            return false;
                        }
                        a a2 = object;
                        if (!a2.a(this)) {
                            return false;
                        }
                        l.a.h.k.c c2 = this.c;
                        l.a.h.k.c c3 = a2.c;
                        return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
                    }

                    public int hashCode() {
                        l.a.h.k.c c2 = this.c;
                        int n2 = c2 == null ? 43 : c2.hashCode();
                        return 59 + n2;
                    }
                };
            }

        };
    }

    protected b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2, c.f f2, l.a.j.q.e e2) {
        l.a.j.q.e e3 = this.c.a(f2, a2.getReturnType(), this.d);
        if (e3.x()) {
            l.a.j.q.e[] arre = new l.a.j.q.e[]{e2, e3, l.a.j.q.l.d.a((l.a.h.k.b)a2.getReturnType())};
            return new b.c(new e.a(arre).a(r2, d2).a(), a2.l());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot return value of type ");
        stringBuilder.append((Object)f2);
        stringBuilder.append(" for ");
        stringBuilder.append((Object)a2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    protected boolean a(Object object) {
        return object instanceof d;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof d)) {
            return false;
        }
        d d2 = (d)object;
        if (!d2.a(this)) {
            return false;
        }
        l.a.j.q.i.a a2 = this.c;
        l.a.j.q.i.a a3 = d2.c;
        if (a2 == null ? a3 != null : !a2.equals((Object)a3)) {
            return false;
        }
        a.d d3 = this.d;
        a.d d4 = d2.d;
        return !(d3 == null ? d4 != null : !d3.equals((Object)d4));
    }

    public int hashCode() {
        l.a.j.q.i.a a2 = this.c;
        int n2 = 43;
        int n3 = a2 == null ? 43 : a2.hashCode();
        int n4 = n3 + 59;
        a.d d2 = this.d;
        int n5 = n4 * 59;
        if (d2 != null) {
            n2 = d2.hashCode();
        }
        return n5 + n2;
    }

    public static interface b
    extends l.a.j.e {
        public l.a.j.e a(l.a.j.q.i.a var1, a.d var2);
    }

    protected static final class d
    extends Enum<d>
    implements l.a.j.e,
    l.a.j.q.b {
        public static final /* enum */ d c;
        private static final /* synthetic */ d[] d;

        static {
            d d2;
            c = d2 = new d();
            d = new d[]{d2};
        }

        public static d valueOf(String string) {
            return (d)Enum.valueOf(d.class, (String)string);
        }

        public static d[] values() {
            return (d[])d.clone();
        }

        public l.a.i.i.c a(l.a.i.i.c c2) {
            return c2;
        }

        public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
            if (!a2.getReturnType().isPrimitive()) {
                l.a.j.q.e[] arre = new l.a.j.q.e[]{j.d, l.a.j.q.l.d.w};
                return new b.b(arre).a(r2, d2, a2);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot return null from ");
            stringBuilder.append((Object)a2);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public l.a.j.q.b a(e.g g2) {
            return this;
        }
    }

}

