/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.adjust.sdk;

import com.adjust.sdk.AdjustSessionFailure;

public interface OnSessionTrackingFailedListener {
    public void onFinishedSessionTrackingFailed(AdjustSessionFailure var1);
}

