/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Caller
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.Caller;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.Section;

interface Schema {
    public Caller getCaller();

    public Decorator getDecorator();

    public Instantiator getInstantiator();

    public Version getRevision();

    public Section getSection();

    public Label getText();

    public Label getVersion();

    public boolean isPrimitive();
}

