/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.i.a
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.j.p.c
 *  l.a.j.p.c$b
 *  l.a.j.p.c$b$d
 */
package l.a.j.p;

import l.a.h.i.a;
import l.a.j.p.c;

public final class b
extends Enum<b>
implements c.b {
    public static final /* enum */ b c;
    private static final /* synthetic */ b[] d;

    static {
        b b2;
        c = b2 = new b();
        d = new b[]{b2};
    }

    public static b valueOf(String string) {
        return (b)Enum.valueOf(b.class, (String)string);
    }

    public static b[] values() {
        return (b[])d.clone();
    }

    public c.b.d a(a a2, c.c c2, c.c c3) {
        l.a.h.k.c c4;
        l.a.h.k.c c5 = c2.c().e().y0();
        if (c5.equals((Object)(c4 = c3.c().e().y0()))) {
            return c.b.d.o;
        }
        if (c5.i(c4)) {
            return c.b.d.h;
        }
        if (c5.b(c4)) {
            return c.b.d.f;
        }
        return c.b.d.o;
    }
}

