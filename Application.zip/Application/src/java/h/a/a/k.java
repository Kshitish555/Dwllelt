/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.j
 *  h.a.a.k$a
 *  java.io.File
 *  java.io.IOException
 *  java.io.PrintWriter
 *  java.lang.Class
 *  java.lang.FunctionalInterface
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayDeque
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.LinkedHashSet
 *  java.util.List
 *  java.util.Set
 */
package h.a.a;

import h.a.a.j;
import h.a.a.j0;
import h.a.a.k;
import h.a.a.k0;
import h.a.a.l0;
import h.a.a.x;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class k
extends ArrayList<j> {
    static final k f = new a();
    private final Set<j> c;
    private final boolean d;

    private k() {
        super(1);
        this.d = false;
        this.c = Collections.emptySet();
    }

    k(j.c c2, boolean bl) {
        this(c2.a, c2.b, bl);
    }

    k(Set<j> set, Set<j> set2, boolean bl) {
        super(set);
        this.d = bl;
        if (bl) {
            Collections.sort((List)this);
        }
        if (set2 != null) {
            set = set2;
        }
        this.c = set;
    }

    k(Set<j> set, boolean bl) {
        this(set, null, bl);
    }

    public k A0() {
        LinkedHashSet linkedHashSet = new LinkedHashSet(this.size());
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!j2.g0()) continue;
            linkedHashSet.add((Object)j2);
            if (!this.c.contains((Object)j2)) continue;
            linkedHashSet2.add((Object)j2);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public k F() {
        LinkedHashSet linkedHashSet = new LinkedHashSet(this.size());
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!j2.l0()) continue;
            linkedHashSet.add((Object)j2);
            if (!this.c.contains((Object)j2)) continue;
            linkedHashSet2.add((Object)j2);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public List<Class<?>> I() {
        return this.c(false);
    }

    public k a(b b2) {
        LinkedHashSet linkedHashSet = new LinkedHashSet(this.size());
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!b2.a(j2)) continue;
            linkedHashSet.add((Object)j2);
            if (!this.c.contains((Object)j2)) continue;
            linkedHashSet2.add((Object)j2);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public k a(k k2) {
        LinkedHashSet linkedHashSet = new LinkedHashSet((Collection)this);
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c);
        linkedHashSet.removeAll((Collection)k2);
        linkedHashSet2.removeAll(k2.c);
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public /* varargs */ k a(k ... arrk) {
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.add((Object)this);
        int n2 = arrk.length;
        int n3 = 0;
        boolean bl = false;
        for (int i2 = 0; i2 < n2; ++i2) {
            k k2 = arrk[i2];
            if (k2.d) {
                arrayDeque.add((Object)k2);
                continue;
            }
            if (!bl) {
                arrayDeque.push((Object)k2);
                bl = true;
                continue;
            }
            arrayDeque.add((Object)k2);
        }
        k k3 = (k)((Object)arrayDeque.remove());
        LinkedHashSet linkedHashSet = new LinkedHashSet((Collection)k3);
        while (!arrayDeque.isEmpty()) {
            linkedHashSet.retainAll((Collection)arrayDeque.remove());
        }
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c);
        int n4 = arrk.length;
        while (n3 < n4) {
            linkedHashSet2.retainAll(arrk[n3].c);
            ++n3;
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, k3.d);
    }

    public String a(float f2, float f3) {
        return this.a(f2, f3, true, true, true, true, true);
    }

    public String a(float f2, float f3, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        if (!this.isEmpty()) {
            l0 l02 = ((j)this.get((int)0)).c.c;
            if (l02.q) {
                return x.a(this, f2, f3, bl, bl2, bl3, bl4, bl5, l02);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("List is empty");
    }

    public <T> List<Class<T>> a(Class<T> class_) {
        return this.a(class_, false);
    }

    public <T> List<Class<T>> a(Class<T> class_, boolean bl) {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            Class class_2 = ((j)iterator.next()).a(class_, bl);
            if (class_2 == null) continue;
            arrayList.add((Object)class_2);
        }
        if (arrayList.isEmpty()) {
            arrayList = Collections.emptyList();
        }
        return arrayList;
    }

    public void a(File file) throws IOException {
        PrintWriter printWriter = new PrintWriter(file);
        try {
            printWriter.print(this.c());
        }
        catch (Throwable throwable) {
            try {
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    printWriter.close();
                }
                catch (Throwable throwable3) {
                    throwable.addSuppressed(throwable3);
                }
                throw throwable2;
            }
        }
        printWriter.close();
    }

    public boolean a(String string) {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            if (!((j)iterator.next()).P().equals((Object)string)) continue;
            return true;
        }
        return false;
    }

    public k b() {
        Set<j> set = this.c;
        return new k(set, set, this.d);
    }

    public /* varargs */ k b(k ... arrk) {
        LinkedHashSet linkedHashSet = new LinkedHashSet((Collection)this);
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c);
        for (k k2 : arrk) {
            linkedHashSet.addAll((Collection)k2);
            linkedHashSet2.addAll(k2.c);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public String c() {
        return this.a(10.5f, 8.0f, true, true, true, true, true);
    }

    public List<Class<?>> c(boolean bl) {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            Class class_ = ((j)iterator.next()).a(bl);
            if (class_ == null) continue;
            arrayList.add((Object)class_);
        }
        if (arrayList.isEmpty()) {
            arrayList = Collections.emptyList();
        }
        return arrayList;
    }

    public k d() {
        LinkedHashSet linkedHashSet = new LinkedHashSet(this.size());
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!j2.Y()) continue;
            linkedHashSet.add((Object)j2);
            if (!this.c.contains((Object)j2)) continue;
            linkedHashSet2.add((Object)j2);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public List<String> f() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((j)iterator.next()).toString());
        }
        return arrayList;
    }

    public j get(String string) {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!j2.P().equals((Object)string)) continue;
            return j2;
        }
        return null;
    }

    public k j() {
        LinkedHashSet linkedHashSet = new LinkedHashSet(this.size());
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!j2.a0()) continue;
            linkedHashSet.add((Object)j2);
            if (!this.c.contains((Object)j2)) continue;
            linkedHashSet2.add((Object)j2);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public k r() {
        LinkedHashSet linkedHashSet = new LinkedHashSet(this.size());
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!j2.d0()) continue;
            linkedHashSet.add((Object)j2);
            if (!this.c.contains((Object)j2)) continue;
            linkedHashSet2.add((Object)j2);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public k t() {
        LinkedHashSet linkedHashSet = new LinkedHashSet(this.size());
        LinkedHashSet linkedHashSet2 = new LinkedHashSet(this.c.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            j j2 = (j)iterator.next();
            if (!j2.h0()) continue;
            linkedHashSet.add((Object)j2);
            if (!this.c.contains((Object)j2)) continue;
            linkedHashSet2.add((Object)j2);
        }
        return new k((Set<j>)linkedHashSet, (Set<j>)linkedHashSet2, this.d);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('[');
        int n2 = this.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            if (i2 > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(this.get(i2));
        }
        stringBuilder.append(']');
        return stringBuilder.toString();
    }

    public List<String> x() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((j)iterator.next()).P());
        }
        return arrayList;
    }

    @FunctionalInterface
    public static interface b {
        public boolean a(j var1);
    }

}

