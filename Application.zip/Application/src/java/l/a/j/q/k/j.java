/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public final class j
extends Enum<j>
implements e {
    public static final /* enum */ j d;
    private static final /* synthetic */ j[] f;
    private final e.c c;

    static {
        j j2;
        d = j2 = new j(f.f);
        f = new j[]{j2};
    }

    private j(f f2) {
        this.c = f2.f();
    }

    public static j valueOf(String string) {
        return (j)Enum.valueOf(j.class, (String)string);
    }

    public static j[] values() {
        return (j[])f.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(1);
        return this.c;
    }

    public boolean x() {
        return true;
    }
}

