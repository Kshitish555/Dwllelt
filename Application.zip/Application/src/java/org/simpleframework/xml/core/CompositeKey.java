/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Entry
 *  org.simpleframework.xml.core.PersistenceException
 *  org.simpleframework.xml.core.Traverser
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.Position
 *  org.simpleframework.xml.stream.Style
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.AttributeException;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Entry;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Traverser;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Position;
import org.simpleframework.xml.stream.Style;

class CompositeKey
implements Converter {
    private final Context context;
    private final Entry entry;
    private final Traverser root;
    private final Style style;
    private final Type type;

    public CompositeKey(Context context, Entry entry, Type type) throws Exception {
        this.root = new Traverser(context);
        this.style = context.getStyle();
        this.context = context;
        this.entry = entry;
        this.type = type;
    }

    private Object read(InputNode inputNode, String string2) throws Exception {
        String string3 = this.style.getElement(string2);
        Class class_ = this.type.getType();
        if (string3 != null) {
            inputNode = inputNode.getNext(string3);
        }
        if (inputNode == null) {
            return null;
        }
        if (inputNode.isEmpty()) {
            return null;
        }
        return this.root.read(inputNode, class_);
    }

    private boolean validate(InputNode inputNode, String string2) throws Exception {
        InputNode inputNode2 = inputNode.getNext(this.style.getElement(string2));
        Class class_ = this.type.getType();
        if (inputNode2 == null) {
            return true;
        }
        if (inputNode2.isEmpty()) {
            return true;
        }
        return this.root.validate(inputNode2, class_);
    }

    public Object read(InputNode inputNode) throws Exception {
        Position position = inputNode.getPosition();
        Class class_ = this.type.getType();
        String string2 = this.entry.getKey();
        if (string2 == null) {
            string2 = this.context.getName(class_);
        }
        if (!this.entry.isAttribute()) {
            return this.read(inputNode, string2);
        }
        Object[] arrobject = new Object[]{class_, this.entry, position};
        throw new AttributeException("Can not have %s as an attribute for %s at %s", arrobject);
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Position position = inputNode.getPosition();
        Class class_ = this.type.getType();
        if (object == null) {
            return this.read(inputNode);
        }
        Object[] arrobject = new Object[]{class_, this.entry, position};
        throw new PersistenceException("Can not read key of %s for %s at %s", arrobject);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Position position = inputNode.getPosition();
        Class class_ = this.type.getType();
        String string2 = this.entry.getKey();
        if (string2 == null) {
            string2 = this.context.getName(class_);
        }
        if (!this.entry.isAttribute()) {
            return this.validate(inputNode, string2);
        }
        Object[] arrobject = new Object[]{class_, this.entry, position};
        throw new ElementException("Can not have %s as an attribute for %s at %s", arrobject);
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Class class_ = this.type.getType();
        String string2 = this.entry.getKey();
        if (!this.entry.isAttribute()) {
            if (string2 == null) {
                string2 = this.context.getName(class_);
            }
            String string3 = this.style.getElement(string2);
            this.root.write(outputNode, object, class_, string3);
            return;
        }
        Object[] arrobject = new Object[]{class_, this.entry};
        throw new ElementException("Can not have %s as an attribute for %s", arrobject);
    }
}

