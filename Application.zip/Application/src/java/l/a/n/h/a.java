/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 */
package l.a.n.h;

import l.a.k.a.n;
import l.a.k.a.q;
import l.a.k.a.r;

public abstract class a
extends r {
    private boolean f = true;

    protected a(int n2, r r2) {
        super(n2, r2);
    }

    private void f() {
        if (this.f) {
            this.f = false;
            this.e();
        }
    }

    public final void a(int n2) {
        this.f();
        this.b(n2);
    }

    public final void a(int n2, int n3) {
        this.f();
        this.e(n2, n3);
    }

    public final /* varargs */ void a(int n2, int n3, q q2, q ... arrq) {
        this.f();
        this.b(n2, n3, q2, arrq);
    }

    public final void a(int n2, String string) {
        this.f();
        this.b(n2, string);
    }

    public final void a(int n2, String string, String string2, String string3) {
        this.f();
        this.c(n2, string, string2, string3);
    }

    public final void a(int n2, String string, String string2, String string3, boolean bl) {
        this.f();
        this.b(n2, string, string2, string3, bl);
    }

    public final void a(int n2, q q2) {
        this.f();
        this.c(n2, q2);
    }

    public final void a(Object object) {
        this.f();
        this.b(object);
    }

    public final void a(String string, int n2) {
        this.f();
        this.c(string, n2);
    }

    public final /* varargs */ void a(String string, String string2, n n2, Object ... arrobject) {
        this.f();
        this.b(string, string2, n2, arrobject);
    }

    public final void a(q q2) {
        this.f();
        this.b(q2);
    }

    public final void a(q q2, int[] arrn, q[] arrq) {
        this.f();
        this.b(q2, arrn, arrq);
    }

    protected void b(int n2) {
        super.a(n2);
    }

    public final void b(int n2, int n3) {
        this.f();
        this.f(n2, n3);
    }

    protected /* varargs */ void b(int n2, int n3, q q2, q ... arrq) {
        super.a(n2, n3, q2, arrq);
    }

    protected void b(int n2, String string) {
        super.a(n2, string);
    }

    public final void b(int n2, String string, String string2, String string3) {
        this.f();
        this.d(n2, string, string2, string3);
    }

    protected void b(int n2, String string, String string2, String string3, boolean bl) {
        super.a(n2, string, string2, string3, bl);
    }

    protected void b(Object object) {
        super.a(object);
    }

    protected /* varargs */ void b(String string, String string2, n n2, Object ... arrobject) {
        super.a(string, string2, n2, arrobject);
    }

    protected void b(q q2) {
        super.a(q2);
    }

    protected void b(q q2, int[] arrn, q[] arrq) {
        super.a(q2, arrn, arrq);
    }

    protected void c(int n2, String string, String string2, String string3) {
        super.a(n2, string, string2, string3);
    }

    protected void c(int n2, q q2) {
        super.a(n2, q2);
    }

    protected void c(String string, int n2) {
        super.a(string, n2);
    }

    public final void d(int n2, int n3) {
        this.f();
        this.g(n2, n3);
    }

    @Deprecated
    protected void d(int n2, String string, String string2, String string3) {
        this.f();
        super.b(n2, string, string2, string3);
    }

    protected abstract void e();

    protected void e(int n2, int n3) {
        super.a(n2, n3);
    }

    protected void f(int n2, int n3) {
        super.b(n2, n3);
    }

    protected void g(int n2, int n3) {
        super.d(n2, n3);
    }
}

