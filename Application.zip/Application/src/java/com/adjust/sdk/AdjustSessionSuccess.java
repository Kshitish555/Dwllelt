/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import com.adjust.sdk.Util;
import org.json.JSONObject;

public class AdjustSessionSuccess {
    public String adid;
    public JSONObject jsonResponse;
    public String message;
    public String timestamp;

    public String toString() {
        Object[] arrobject = new Object[]{this.message, this.timestamp, this.adid, this.jsonResponse};
        return Util.formatString("Session Success msg:%s time:%s adid:%s json:%s", arrobject);
    }
}

