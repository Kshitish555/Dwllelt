/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Point
 *  android.graphics.Rect
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IProjection
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import java.util.ArrayList;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IProjection;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

public class PathOverlay
extends Overlay {
    private final Rect mLineBounds = new Rect();
    protected Paint mPaint = new Paint();
    private final Path mPath = new Path();
    private ArrayList<Point> mPoints;
    private int mPointsPrecomputed;
    private final Point mTempPoint1 = new Point();
    private final Point mTempPoint2 = new Point();

    public PathOverlay(int n2, Context context) {
        this(n2, new DefaultResourceProxyImpl(context));
    }

    public PathOverlay(int n2, ResourceProxy resourceProxy) {
        super(resourceProxy);
        this.mPaint.setColor(n2);
        this.mPaint.setStrokeWidth(2.0f);
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.clearPath();
    }

    public void addGreatCircle(GeoPoint geoPoint, GeoPoint geoPoint2) {
        this.addGreatCircle(geoPoint, geoPoint2, geoPoint.distanceTo(geoPoint2) / 100000);
    }

    public void addGreatCircle(GeoPoint geoPoint, GeoPoint geoPoint2, int n2) {
        double d2 = geoPoint.getLatitudeE6();
        Double.isNaN((double)d2);
        double d3 = 3.141592653589793 * (d2 / 1000000.0) / 180.0;
        double d4 = geoPoint.getLongitudeE6();
        Double.isNaN((double)d4);
        double d5 = 3.141592653589793 * (d4 / 1000000.0) / 180.0;
        double d6 = geoPoint2.getLatitudeE6();
        Double.isNaN((double)d6);
        double d7 = 3.141592653589793 * (d6 / 1000000.0) / 180.0;
        double d8 = geoPoint2.getLongitudeE6();
        Double.isNaN((double)d8);
        double d9 = 3.141592653589793 * (d8 / 1000000.0) / 180.0;
        double d10 = Math.pow((double)Math.sin((double)((d3 - d7) / 2.0)), (double)2.0);
        double d11 = Math.cos((double)d3) * Math.cos((double)d7);
        double d12 = d5 - d9;
        double d13 = 2.0 * Math.asin((double)Math.sqrt((double)(d10 + d11 * Math.pow((double)Math.sin((double)(d12 / 2.0)), (double)2.0))));
        Math.atan2((double)(Math.sin((double)d12) * Math.cos((double)d7)), (double)(Math.cos((double)d3) * Math.sin((double)d7) - Math.sin((double)d3) * Math.cos((double)d7) * Math.cos((double)d12))) / -0.017453292519943295 DCMPG 0.0;
        int n3 = n2 + 1;
        for (int i2 = 0; i2 < n3; ++i2) {
            double d14 = n2;
            Double.isNaN((double)d14);
            double d15 = 1.0 / d14;
            double d16 = d9;
            double d17 = i2;
            Double.isNaN((double)d17);
            double d18 = d15 * d17;
            double d19 = Math.sin((double)(d13 * (1.0 - d18))) / Math.sin((double)d13);
            double d20 = Math.sin((double)(d18 * d13)) / Math.sin((double)d13);
            double d21 = d19 * Math.cos((double)d3) * Math.cos((double)d5);
            double d22 = d20 * Math.cos((double)d7) * Math.cos((double)d16);
            double d23 = d13;
            double d24 = d21 + d22;
            double d25 = d19 * Math.cos((double)d3) * Math.sin((double)d5);
            double d26 = d20 * Math.cos((double)d7) * Math.sin((double)d16);
            double d27 = d5;
            double d28 = d25 + d26;
            double d29 = Math.atan2((double)(d19 * Math.sin((double)d3) + d20 * Math.sin((double)d7)), (double)Math.sqrt((double)(Math.pow((double)d24, (double)2.0) + Math.pow((double)d28, (double)2.0))));
            double d30 = Math.atan2((double)d28, (double)d24);
            this.addPoint((int)(1000000.0 * (d29 / 0.017453292519943295)), (int)(1000000.0 * (d30 / 0.017453292519943295)));
            d9 = d16;
            d13 = d23;
            d5 = d27;
        }
    }

    public void addPoint(int n2, int n3) {
        this.mPoints.add((Object)new Point(n2, n3));
    }

    public void addPoint(GeoPoint geoPoint) {
        this.addPoint(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6());
    }

    public void clearPath() {
        this.mPoints = new ArrayList();
        this.mPointsPrecomputed = 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    protected void draw(Canvas canvas, MapView mapView, boolean bl) {
        int n2;
        if (bl) {
            return;
        }
        if (this.mPoints.size() < 2) {
            return;
        }
        IProjection iProjection = mapView.getProjection();
        int n3 = this.mPoints.size();
        while ((n2 = this.mPointsPrecomputed) < n3) {
            Point point = (Point)this.mPoints.get(n2);
            iProjection.toMapPixelsProjected(point.x, point.y, point);
            this.mPointsPrecomputed = 1 + this.mPointsPrecomputed;
        }
        Rect rect = iProjection.fromPixelsToProjected(iProjection.getScreenRect());
        this.mPath.rewind();
        Point point = (Point)this.mPoints.get(n3 - 1);
        Rect rect2 = this.mLineBounds;
        int n4 = point.x;
        int n5 = point.y;
        rect2.set(n4, n5, n4, n5);
        int n6 = n3 - 2;
        Point point2 = null;
        do {
            block11 : {
                Point point3;
                block10 : {
                    block9 : {
                        if (n6 < 0) {
                            canvas.drawPath(this.mPath, this.mPaint);
                            return;
                        }
                        point3 = (Point)this.mPoints.get(n6);
                        this.mLineBounds.union(point3.x, point3.y);
                        if (Rect.intersects((Rect)rect, (Rect)this.mLineBounds)) break block9;
                        point2 = null;
                        break block10;
                    }
                    if (point2 == null) {
                        point2 = iProjection.toMapPixelsTranslated(point, this.mTempPoint1);
                        this.mPath.moveTo((float)point2.x, (float)point2.y);
                    }
                    Point point4 = iProjection.toMapPixelsTranslated(point3, this.mTempPoint2);
                    if (Math.abs((int)(point4.x - point2.x)) + Math.abs((int)(point4.y - point2.y)) <= 1) break block11;
                    this.mPath.lineTo((float)point4.x, (float)point4.y);
                    point2.x = point4.x;
                    point2.y = point4.y;
                    Rect rect3 = this.mLineBounds;
                    int n7 = point3.x;
                    int n8 = point3.y;
                    rect3.set(n7, n8, n7, n8);
                }
                point = point3;
            }
            --n6;
        } while (true);
    }

    public int getNumberOfPoints() {
        return this.mPoints.size();
    }

    public Paint getPaint() {
        return this.mPaint;
    }

    public void setAlpha(int n2) {
        this.mPaint.setAlpha(n2);
    }

    public void setColor(int n2) {
        this.mPaint.setColor(n2);
    }

    public void setPaint(Paint paint) {
        if (paint != null) {
            this.mPaint = paint;
            return;
        }
        throw new IllegalArgumentException("pPaint argument cannot be null");
    }
}

