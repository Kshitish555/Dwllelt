/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.Menu
 *  android.view.MenuItem
 *  java.lang.Object
 */
package org.osmdroid.views.overlay;

import android.view.Menu;
import android.view.MenuItem;
import org.osmdroid.views.MapView;

public interface IOverlayMenuProvider {
    public boolean isOptionsMenuEnabled();

    public boolean onCreateOptionsMenu(Menu var1, int var2, MapView var3);

    public boolean onOptionsItemSelected(MenuItem var1, int var2, MapView var3);

    public boolean onPrepareOptionsMenu(Menu var1, int var2, MapView var3);

    public void setOptionsMenuEnabled(boolean var1);
}

