/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.i.a
 *  l.a.h.i.c
 *  l.a.h.i.d
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.j.p.a$a
 *  l.a.j.p.a$b
 *  l.a.j.p.c
 *  l.a.j.p.c$b
 *  l.a.j.p.c$b$d
 */
package l.a.j.p;

import l.a.h.i.d;
import l.a.h.k.c;
import l.a.j.p.a;
import l.a.j.p.c;

/*
 * Exception performing whole class analysis.
 * Exception performing whole class analysis ignored.
 */
public final class a
extends Enum<a>
implements c.b {
    public static final /* enum */ a c;
    private static final /* synthetic */ a[] d;

    static {
        a a2;
        c = a2 = new a();
        d = new a[]{a2};
    }

    private a() {
    }

    private static c.b.d a(int n2) {
        if (n2 == 0) {
            return c.b.d.o;
        }
        if (n2 > 0) {
            return c.b.d.f;
        }
        return c.b.d.h;
    }

    private static c.b.d a(l.a.h.k.c c2, int n2, c.c c3, int n3, c.c c4) {
        l.a.h.k.c c5;
        l.a.h.k.c c6 = ((l.a.h.i.c)c3.c().getParameters().get(n2)).getType().y0();
        if (!c6.equals((Object)(c5 = ((l.a.h.i.c)c4.c().getParameters().get(n3)).getType().y0()))) {
            if (c6.isPrimitive() && c5.isPrimitive()) {
                return b.a((l.a.h.k.c)c6).a(b.a((l.a.h.k.c)c5));
            }
            if (c6.isPrimitive()) {
                if (c2.isPrimitive()) {
                    return c.b.d.f;
                }
                return c.b.d.h;
            }
            if (c5.isPrimitive()) {
                if (c2.isPrimitive()) {
                    return c.b.d.h;
                }
                return c.b.d.f;
            }
            if (c6.i(c5)) {
                return c.b.d.h;
            }
            if (c5.i(c6)) {
                return c.b.d.f;
            }
            return c.b.d.o;
        }
        return c.b.d.d;
    }

    public static a valueOf(String string) {
        return (a)Enum.valueOf(a.class, (String)string);
    }

    public static a[] values() {
        return (a[])d.clone();
    }

    public c.b.d a(l.a.h.i.a a2, c.c c2, c.c c3) {
        c.b.d d2 = c.b.d.d;
        d d3 = a2.getParameters();
        int n2 = 0;
        int n3 = 0;
        for (int i2 = 0; i2 < d3.size(); ++i2) {
            a a3 = new /* Unavailable Anonymous Inner Class!! */;
            Integer n4 = c2.a((Object)a3);
            Integer n5 = c3.a((Object)a3);
            if (n4 != null && n5 != null) {
                d2 = d2.a(a.a(((l.a.h.i.c)d3.get(i2)).getType().y0(), n4, c2, n5, c3));
                continue;
            }
            if (n4 != null) {
                ++n2;
                continue;
            }
            if (n5 == null) continue;
            ++n3;
        }
        if (d2 == c.b.d.d) {
            d2 = a.a(n2 - n3);
        }
        return d2;
    }
}

