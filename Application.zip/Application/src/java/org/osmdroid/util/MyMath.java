/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  org.osmdroid.views.util.constants.MathConstants
 */
package org.osmdroid.util;

import org.osmdroid.views.util.constants.MathConstants;

public class MyMath
implements MathConstants {
    private MyMath() {
    }

    public static double gudermann(double d) {
        return 57.295780181884766 * Math.atan((double)Math.sinh((double)d));
    }

    public static double gudermannInverse(double d) {
        return Math.log((double)Math.tan((double)(0.7853981852531433 + d * 0.01745329238474369 / 2.0)));
    }

    public static int mod(int n, int n2) {
        if (n > 0) {
            return n % n2;
        }
        while (n < 0) {
            n += n2;
        }
        return n;
    }
}

