/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.preference.PreferenceManager
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  java.io.BufferedReader
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpResponse
 *  org.apache.http.StatusLine
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.util;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CloudmadeUtil
implements OpenStreetMapTileProviderConstants {
    private static final String CLOUDMADE_ID = "CLOUDMADE_ID";
    private static final String CLOUDMADE_KEY = "CLOUDMADE_KEY";
    private static final String CLOUDMADE_TOKEN = "CLOUDMADE_TOKEN";
    private static final Logger logger = LoggerFactory.getLogger(CloudmadeUtil.class);
    private static String mAndroidId = "android_id";
    private static String mKey = "";
    private static SharedPreferences.Editor mPreferenceEditor;
    private static String mToken;

    static {
        mToken = "";
    }

    public static String getCloudmadeKey() {
        return mKey;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String getCloudmadeToken() {
        String string2;
        if (mToken.length() != 0) return mToken;
        String string3 = string2 = mToken;
        synchronized (string3) {
            if (mToken.length() != 0) return mToken;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("http://auth.cloudmade.com/token/");
            stringBuilder.append(mKey);
            stringBuilder.append("?userid=");
            stringBuilder.append(mAndroidId);
            String string4 = stringBuilder.toString();
            DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(string4);
            try {
                String string5;
                HttpResponse httpResponse = defaultHttpClient.execute((HttpUriRequest)httpPost);
                if (httpResponse.getStatusLine().getStatusCode() != 200) return mToken;
                mToken = string5 = new BufferedReader((Reader)new InputStreamReader(httpResponse.getEntity().getContent()), 8192).readLine().trim();
                if (string5.length() > 0) {
                    mPreferenceEditor.putString(CLOUDMADE_TOKEN, mToken);
                    mPreferenceEditor.commit();
                    mPreferenceEditor = null;
                } else {
                    logger.error("No authorization token received from Cloudmade");
                }
            }
            catch (IOException iOException) {
                Logger logger = CloudmadeUtil.logger;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("No authorization token received from Cloudmade: ");
                stringBuilder2.append((Object)iOException);
                logger.error(stringBuilder2.toString());
            }
            return mToken;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void retrieveCloudmadeKey(Context context) {
        mAndroidId = Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"android_id");
        PackageManager packageManager = context.getPackageManager();
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 128);
            if (applicationInfo.metaData == null) {
                logger.info("Cloudmade key not found in manifest");
            } else {
                String string2 = applicationInfo.metaData.getString(CLOUDMADE_KEY);
                if (string2 == null) {
                    logger.info("Cloudmade key not found in manifest");
                } else {
                    mKey = string2.trim();
                }
            }
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            logger.info("Cloudmade key not found in manifest", (Throwable)nameNotFoundException);
        }
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)context);
        mPreferenceEditor = sharedPreferences.edit();
        if (sharedPreferences.getString(CLOUDMADE_ID, "").equals((Object)mAndroidId)) {
            String string3;
            mToken = string3 = sharedPreferences.getString(CLOUDMADE_TOKEN, "");
            if (string3.length() <= 0) return;
            {
                mPreferenceEditor = null;
                return;
            }
        } else {
            mPreferenceEditor.putString(CLOUDMADE_ID, mAndroidId);
            mPreferenceEditor.commit();
        }
    }
}

