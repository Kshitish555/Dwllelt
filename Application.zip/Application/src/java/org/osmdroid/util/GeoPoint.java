/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.location.Location
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Cloneable
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.util.GeoPoint$1
 *  org.osmdroid.util.constants.GeoConstants
 *  org.osmdroid.views.util.constants.MathConstants
 */
package org.osmdroid.util;

import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.constants.GeoConstants;
import org.osmdroid.views.util.constants.MathConstants;

public class GeoPoint
implements IGeoPoint,
MathConstants,
GeoConstants,
Parcelable,
Serializable,
Cloneable {
    public static final Parcelable.Creator<GeoPoint> CREATOR = new 1();
    static final long serialVersionUID = 1L;
    private int mAltitude;
    private int mLatitudeE6;
    private int mLongitudeE6;

    public GeoPoint(double d, double d2) {
        this.mLatitudeE6 = (int)(d * 1000000.0);
        this.mLongitudeE6 = (int)(d2 * 1000000.0);
    }

    public GeoPoint(double d, double d2, double d3) {
        this.mLatitudeE6 = (int)(d * 1000000.0);
        this.mLongitudeE6 = (int)(d2 * 1000000.0);
        this.mAltitude = (int)d3;
    }

    public GeoPoint(int n, int n2) {
        this.mLatitudeE6 = n;
        this.mLongitudeE6 = n2;
    }

    public GeoPoint(int n, int n2, int n3) {
        this.mLatitudeE6 = n;
        this.mLongitudeE6 = n2;
        this.mAltitude = n3;
    }

    public GeoPoint(Location location) {
        this(location.getLatitude(), location.getLongitude(), location.getAltitude());
    }

    private GeoPoint(Parcel parcel) {
        this.mLatitudeE6 = parcel.readInt();
        this.mLongitudeE6 = parcel.readInt();
        this.mAltitude = parcel.readInt();
    }

    public GeoPoint(GeoPoint geoPoint) {
        this.mLatitudeE6 = geoPoint.mLatitudeE6;
        this.mLongitudeE6 = geoPoint.mLongitudeE6;
        this.mAltitude = geoPoint.mAltitude;
    }

    public static GeoPoint fromCenterBetween(GeoPoint geoPoint, GeoPoint geoPoint2) {
        return new GeoPoint((geoPoint.getLatitudeE6() + geoPoint2.getLatitudeE6()) / 2, (geoPoint.getLongitudeE6() + geoPoint2.getLongitudeE6()) / 2);
    }

    public static GeoPoint fromDoubleString(String string2, char c) {
        int n = string2.indexOf((int)c);
        int n2 = n + 1;
        int n3 = string2.indexOf((int)c, n2);
        if (n3 == -1) {
            return new GeoPoint((int)(1000000.0 * Double.parseDouble((String)string2.substring(0, n))), (int)(1000000.0 * Double.parseDouble((String)string2.substring(n2, string2.length()))));
        }
        return new GeoPoint((int)(1000000.0 * Double.parseDouble((String)string2.substring(0, n))), (int)(1000000.0 * Double.parseDouble((String)string2.substring(n2, n3))), (int)Double.parseDouble((String)string2.substring(n3 + 1, string2.length())));
    }

    public static GeoPoint fromIntString(String string2) {
        int n = string2.indexOf(44);
        int n2 = n + 1;
        int n3 = string2.indexOf(44, n2);
        if (n3 == -1) {
            return new GeoPoint(Integer.parseInt((String)string2.substring(0, n)), Integer.parseInt((String)string2.substring(n2, string2.length())));
        }
        return new GeoPoint(Integer.parseInt((String)string2.substring(0, n)), Integer.parseInt((String)string2.substring(n2, n3)), Integer.parseInt((String)string2.substring(n3 + 1, string2.length())));
    }

    public static GeoPoint fromInvertedDoubleString(String string2, char c) {
        int n = string2.indexOf((int)c);
        int n2 = n + 1;
        int n3 = string2.indexOf((int)c, n2);
        if (n3 == -1) {
            return new GeoPoint((int)(1000000.0 * Double.parseDouble((String)string2.substring(n2, string2.length()))), (int)(1000000.0 * Double.parseDouble((String)string2.substring(0, n))));
        }
        return new GeoPoint((int)(1000000.0 * Double.parseDouble((String)string2.substring(n2, n3))), (int)(1000000.0 * Double.parseDouble((String)string2.substring(0, n))), (int)Double.parseDouble((String)string2.substring(n3 + 1, string2.length())));
    }

    public double bearingTo(IGeoPoint iGeoPoint) {
        double d = this.mLatitudeE6;
        Double.isNaN((double)d);
        double d2 = Math.toRadians((double)(d / 1000000.0));
        double d3 = this.mLongitudeE6;
        Double.isNaN((double)d3);
        double d4 = Math.toRadians((double)(d3 / 1000000.0));
        double d5 = iGeoPoint.getLatitudeE6();
        Double.isNaN((double)d5);
        double d6 = Math.toRadians((double)(d5 / 1000000.0));
        double d7 = iGeoPoint.getLongitudeE6();
        Double.isNaN((double)d7);
        double d8 = Math.toRadians((double)(d7 / 1000000.0)) - d4;
        return (360.0 + Math.toDegrees((double)Math.atan2((double)(Math.sin((double)d8) * Math.cos((double)d6)), (double)(Math.cos((double)d2) * Math.sin((double)d6) - Math.sin((double)d2) * Math.cos((double)d6) * Math.cos((double)d8))))) % 360.0;
    }

    public Object clone() {
        return new GeoPoint(this.mLatitudeE6, this.mLongitudeE6);
    }

    public int describeContents() {
        return 0;
    }

    public GeoPoint destinationPoint(double d, float f) {
        double d2 = d / 6378137.0;
        float f2 = f * 0.017453292f;
        double d3 = 0.017453292f * (float)this.getLatitudeE6();
        Double.isNaN((double)d3);
        double d4 = d3 / 1000000.0;
        double d5 = 0.017453292f * (float)this.getLongitudeE6();
        Double.isNaN((double)d5);
        double d6 = d5 / 1000000.0;
        double d7 = Math.sin((double)d4) * Math.cos((double)d2);
        double d8 = Math.cos((double)d4) * Math.sin((double)d2);
        double d9 = f2;
        double d10 = Math.asin((double)(d7 + d8 * Math.cos((double)d9)));
        double d11 = d6 + Math.atan2((double)(Math.sin((double)d9) * Math.sin((double)d2) * Math.cos((double)d4)), (double)(Math.cos((double)d2) - Math.sin((double)d4) * Math.sin((double)d10)));
        return new GeoPoint(d10 / 0.01745329238474369, d11 / 0.01745329238474369);
    }

    public int distanceTo(IGeoPoint iGeoPoint) {
        double d = 0.017453292f * (float)this.mLatitudeE6;
        Double.isNaN((double)d);
        double d2 = d / 1000000.0;
        double d3 = 0.017453292f * (float)this.mLongitudeE6;
        Double.isNaN((double)d3);
        double d4 = d3 / 1000000.0;
        double d5 = 0.017453292f * (float)iGeoPoint.getLatitudeE6();
        Double.isNaN((double)d5);
        double d6 = d5 / 1000000.0;
        double d7 = 0.017453292f * (float)iGeoPoint.getLongitudeE6();
        Double.isNaN((double)d7);
        double d8 = d7 / 1000000.0;
        double d9 = Math.cos((double)d2);
        double d10 = Math.cos((double)d6);
        double d11 = d10 * (d9 * Math.cos((double)d4)) * Math.cos((double)d8);
        double d12 = d10 * (d9 * Math.sin((double)d4)) * Math.sin((double)d8);
        return (int)(6378137.0 * Math.acos((double)(Math.sin((double)d2) * Math.sin((double)d6) + (d11 + d12))));
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (object == this) {
            return true;
        }
        if (object.getClass() != this.getClass()) {
            return false;
        }
        GeoPoint geoPoint = (GeoPoint)object;
        int n = geoPoint.mLatitudeE6;
        int n2 = this.mLatitudeE6;
        boolean bl = false;
        if (n == n2) {
            int n3 = geoPoint.mLongitudeE6;
            int n4 = this.mLongitudeE6;
            bl = false;
            if (n3 == n4) {
                int n5 = geoPoint.mAltitude;
                int n6 = this.mAltitude;
                bl = false;
                if (n5 == n6) {
                    bl = true;
                }
            }
        }
        return bl;
    }

    public int getAltitude() {
        return this.mAltitude;
    }

    public int getLatitudeE6() {
        return this.mLatitudeE6;
    }

    public int getLongitudeE6() {
        return this.mLongitudeE6;
    }

    public int hashCode() {
        return 37 * (17 * this.mLatitudeE6 + this.mLongitudeE6) + this.mAltitude;
    }

    public void setAltitude(int n) {
        this.mAltitude = n;
    }

    public void setCoordsE6(int n, int n2) {
        this.mLatitudeE6 = n;
        this.mLongitudeE6 = n2;
    }

    public void setLatitudeE6(int n) {
        this.mLatitudeE6 = n;
    }

    public void setLongitudeE6(int n) {
        this.mLongitudeE6 = n;
    }

    public String toDoubleString() {
        StringBuilder stringBuilder = new StringBuilder();
        double d = this.mLatitudeE6;
        Double.isNaN((double)d);
        stringBuilder.append(d / 1000000.0);
        stringBuilder.append(",");
        double d2 = this.mLongitudeE6;
        Double.isNaN((double)d2);
        stringBuilder.append(d2 / 1000000.0);
        stringBuilder.append(",");
        stringBuilder.append(this.mAltitude);
        return stringBuilder.toString();
    }

    public String toInvertedDoubleString() {
        StringBuilder stringBuilder = new StringBuilder();
        double d = this.mLongitudeE6;
        Double.isNaN((double)d);
        stringBuilder.append(d / 1000000.0);
        stringBuilder.append(",");
        double d2 = this.mLatitudeE6;
        Double.isNaN((double)d2);
        stringBuilder.append(d2 / 1000000.0);
        stringBuilder.append(",");
        stringBuilder.append(this.mAltitude);
        return stringBuilder.toString();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mLatitudeE6);
        stringBuilder.append(",");
        stringBuilder.append(this.mLongitudeE6);
        stringBuilder.append(",");
        stringBuilder.append(this.mAltitude);
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.mLatitudeE6);
        parcel.writeInt(this.mLongitudeE6);
        parcel.writeInt(this.mAltitude);
    }
}

