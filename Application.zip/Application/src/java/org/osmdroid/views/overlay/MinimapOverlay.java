/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.os.Handler
 *  android.view.MotionEvent
 *  microsoft.mappoint.TileSystem
 *  org.osmdroid.tileprovider.MapTileProviderBase
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.views.MapView
 *  org.osmdroid.views.MapView$Projection
 *  org.osmdroid.views.overlay.TilesOverlay
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.view.MotionEvent;
import microsoft.mappoint.TileSystem;
import org.osmdroid.tileprovider.MapTileProviderBase;
import org.osmdroid.tileprovider.MapTileProviderBasic;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.TilesOverlay;

public class MinimapOverlay
extends TilesOverlay {
    private int mHeight = 100;
    private final Rect mIntersectionRect = new Rect();
    private final Rect mMiniMapCanvasRect = new Rect();
    private int mPadding = 10;
    private final Paint mPaint;
    private final Rect mTileArea = new Rect();
    private final Rect mViewportRect = new Rect();
    private int mWidth = 100;
    private int mWorldSize_2;
    private int mZoomDifference;

    public MinimapOverlay(Context context, Handler handler) {
        this(context, handler, (MapTileProviderBase)new MapTileProviderBasic(context));
    }

    public MinimapOverlay(Context context, Handler handler, MapTileProviderBase mapTileProviderBase) {
        this(context, handler, mapTileProviderBase, 3);
    }

    public MinimapOverlay(Context context, Handler handler, MapTileProviderBase mapTileProviderBase, int n2) {
        Paint paint;
        super(mapTileProviderBase, context);
        this.setZoomDifference(n2);
        this.mTileProvider.setTileRequestCompleteHandler(handler);
        this.setLoadingLineColor(this.getLoadingBackgroundColor());
        this.mPaint = paint = new Paint();
        paint.setColor(-7829368);
        this.mPaint.setStyle(Paint.Style.FILL);
        this.mPaint.setStrokeWidth(2.0f);
    }

    protected void draw(Canvas canvas, MapView mapView, boolean bl) {
        if (bl) {
            return;
        }
        if (mapView.isAnimating()) {
            return;
        }
        MapView.Projection projection = mapView.getProjection();
        int n2 = projection.getZoomLevel();
        this.mWorldSize_2 = TileSystem.MapSize((int)n2) / 2;
        this.mViewportRect.set(projection.getScreenRect());
        Rect rect = this.mViewportRect;
        int n3 = this.mWorldSize_2;
        rect.offset(n3, n3);
        this.mTileArea.set(this.mViewportRect);
        int n4 = this.getZoomDifference();
        if (n2 - this.getZoomDifference() < this.mTileProvider.getMinimumZoomLevel()) {
            n4 += n2 - this.getZoomDifference() - this.mTileProvider.getMinimumZoomLevel();
        }
        Rect rect2 = this.mTileArea;
        rect2.set(rect2.left >> n4, rect2.top >> n4, rect2.right >> n4, rect2.bottom >> n4);
        Rect rect3 = this.mTileArea;
        rect3.set(rect3.centerX() - this.getWidth() / 2, this.mTileArea.centerY() - this.getHeight() / 2, this.mTileArea.centerX() + this.getWidth() / 2, this.mTileArea.centerY() + this.getHeight() / 2);
        this.mMiniMapCanvasRect.set(this.mViewportRect.right - this.getPadding() - this.getWidth(), this.mViewportRect.bottom - this.getPadding() - this.getHeight(), this.mViewportRect.right - this.getPadding(), this.mViewportRect.bottom - this.getPadding());
        Rect rect4 = this.mMiniMapCanvasRect;
        int n5 = this.mWorldSize_2;
        rect4.offset(-n5, -n5);
        Rect rect5 = this.mMiniMapCanvasRect;
        canvas.drawRect((float)(-2 + rect5.left), (float)(-2 + rect5.top), (float)(2 + rect5.right), (float)(2 + rect5.bottom), this.mPaint);
        super.drawTiles(canvas, projection.getZoomLevel() - n4, projection.getTileSizePixels(), this.mTileArea);
    }

    public int getHeight() {
        return this.mHeight;
    }

    public int getPadding() {
        return this.mPadding;
    }

    public int getWidth() {
        return this.mWidth;
    }

    public int getZoomDifference() {
        return this.mZoomDifference;
    }

    public boolean onDoubleTap(MotionEvent motionEvent, MapView mapView) {
        return this.mMiniMapCanvasRect.contains((int)motionEvent.getX() + this.mViewportRect.left - this.mWorldSize_2, (int)motionEvent.getY() + this.mViewportRect.top - this.mWorldSize_2);
    }

    public boolean onLongPress(MotionEvent motionEvent, MapView mapView) {
        return this.mMiniMapCanvasRect.contains((int)motionEvent.getX() + this.mViewportRect.left - this.mWorldSize_2, (int)motionEvent.getY() + this.mViewportRect.top - this.mWorldSize_2);
    }

    public boolean onSingleTapUp(MotionEvent motionEvent, MapView mapView) {
        return this.mMiniMapCanvasRect.contains((int)motionEvent.getX() + this.mViewportRect.left - this.mWorldSize_2, (int)motionEvent.getY() + this.mViewportRect.top - this.mWorldSize_2);
    }

    protected void onTileReadyToDraw(Canvas canvas, Drawable drawable, Rect rect) {
        int n2 = rect.left;
        Rect rect2 = this.mTileArea;
        int n3 = n2 - rect2.left;
        Rect rect3 = this.mMiniMapCanvasRect;
        int n4 = n3 + rect3.left;
        int n5 = rect.top - rect2.top + rect3.top;
        drawable.setBounds(n4, n5, n4 + rect.width(), n5 + rect.height());
        Rect rect4 = canvas.getClipBounds();
        if (this.mIntersectionRect.setIntersect(rect4, this.mMiniMapCanvasRect)) {
            canvas.clipRect(this.mIntersectionRect);
            drawable.draw(canvas);
            canvas.clipRect(rect4);
        }
    }

    public void setHeight(int n2) {
        this.mHeight = n2;
    }

    public void setPadding(int n2) {
        this.mPadding = n2;
    }

    public void setTileSource(ITileSource iTileSource) {
        this.mTileProvider.setTileSource(iTileSource);
    }

    public void setWidth(int n2) {
        this.mWidth = n2;
    }

    public void setZoomDifference(int n2) {
        this.mZoomDifference = n2;
    }
}

