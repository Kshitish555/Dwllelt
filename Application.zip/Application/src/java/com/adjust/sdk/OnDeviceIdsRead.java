/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

public interface OnDeviceIdsRead {
    public void onGoogleAdIdRead(String var1);
}

