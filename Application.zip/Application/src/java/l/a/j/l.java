/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.i.a
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.j.e$g
 *  l.a.j.q.b
 *  l.a.j.q.b$c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.k.a.r
 */
package l.a.j;

import l.a.h.i.a;
import l.a.h.k.c;
import l.a.i.i.c;
import l.a.j.e;
import l.a.j.q.b;
import l.a.j.q.e;
import l.a.j.q.l.d;
import l.a.k.a.r;

public final class l
extends Enum<l>
implements l.a.j.e,
b {
    public static final /* enum */ l c;
    private static final /* synthetic */ l[] d;

    static {
        l l2;
        c = l2 = new l();
        d = new l[]{l2};
    }

    public static l valueOf(String string) {
        return (l)Enum.valueOf(l.class, (String)string);
    }

    public static l[] values() {
        return (l[])d.clone();
    }

    public c a(c c2) {
        return c2;
    }

    public b.c a(r r2, e.d d2, a a2) {
        e[] arre = new e[]{l.a.j.q.k.b.a((l.a.h.k.b)a2.getReturnType()), d.a((l.a.h.k.b)a2.getReturnType())};
        return new b.c(new e.a(arre).a(r2, d2).a(), a2.l());
    }

    @Override
    public b a(e.g g2) {
        return this;
    }
}

