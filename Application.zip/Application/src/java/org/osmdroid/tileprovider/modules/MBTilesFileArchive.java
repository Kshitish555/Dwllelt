/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteException
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.InputStream
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.modules.IArchiveFile
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.modules.IArchiveFile;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MBTilesFileArchive
implements IArchiveFile {
    public static final String COL_TILES_TILE_COLUMN = "tile_column";
    public static final String COL_TILES_TILE_DATA = "tile_data";
    public static final String COL_TILES_TILE_ROW = "tile_row";
    public static final String COL_TILES_ZOOM_LEVEL = "zoom_level";
    public static final String TABLE_TILES = "tiles";
    private static final Logger logger = LoggerFactory.getLogger(MBTilesFileArchive.class);
    private final SQLiteDatabase mDatabase;

    private MBTilesFileArchive(SQLiteDatabase sQLiteDatabase) {
        this.mDatabase = sQLiteDatabase;
    }

    public static MBTilesFileArchive getDatabaseFileArchive(File file) throws SQLiteException {
        return new MBTilesFileArchive(SQLiteDatabase.openDatabase((String)file.getAbsolutePath(), null, (int)17));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public InputStream getInputStream(ITileSource iTileSource, MapTile mapTile) {
        String[] arrstring = new String[]{COL_TILES_TILE_DATA};
        String[] arrstring2 = new String[3];
        arrstring2[0] = Integer.toString((int)mapTile.getX());
        double d = Math.pow((double)2.0, (double)mapTile.getZoomLevel());
        int n = mapTile.getY();
        double d2 = n;
        Double.isNaN((double)d2);
        double d3 = d - d2 - 1.0;
        try {
            ByteArrayInputStream byteArrayInputStream;
            arrstring2[1] = Double.toString((double)d3);
            arrstring2[2] = Integer.toString((int)mapTile.getZoomLevel());
            Cursor cursor = this.mDatabase.query(TABLE_TILES, arrstring, "tile_column=? and tile_row=? and zoom_level=?", arrstring2, null, null, null);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                byteArrayInputStream = new ByteArrayInputStream(cursor.getBlob(0));
            } else {
                byteArrayInputStream = null;
            }
            cursor.close();
            if (byteArrayInputStream == null) return null;
            return byteArrayInputStream;
        }
        catch (Throwable throwable) {
            Logger logger = MBTilesFileArchive.logger;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error getting db stream: ");
            stringBuilder.append((Object)mapTile);
            logger.warn(stringBuilder.toString(), throwable);
        }
        return null;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DatabaseFileArchive [mDatabase=");
        stringBuilder.append(this.mDatabase.getPath());
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

