/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.j.f
 *  l.a.h.j.f$b
 */
package l.a.h.j;

import l.a.h.j.f;

public final class c
extends Enum<c>
implements f.b {
    public static final /* enum */ c d;
    public static final /* enum */ c f;
    private static final /* synthetic */ c[] h;
    private final int c;

    static {
        c c2;
        d = new c(0);
        f = c2 = new c(128);
        c[] arrc = new c[]{d, c2};
        h = arrc;
    }

    private c(int n3) {
        this.c = n3;
    }

    public static c valueOf(String string) {
        return (c)Enum.valueOf(c.class, (String)string);
    }

    public static c[] values() {
        return (c[])h.clone();
    }

    public int c() {
        return 128;
    }

    public boolean e() {
        return this == f;
    }

    public int getMask() {
        return this.c;
    }

    public boolean isDefault() {
        return this == d;
    }
}

