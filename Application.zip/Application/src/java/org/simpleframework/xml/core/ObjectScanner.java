/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.util.List
 *  org.simpleframework.xml.DefaultType
 *  org.simpleframework.xml.Order
 *  org.simpleframework.xml.Root
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Caller
 *  org.simpleframework.xml.core.ClassScanner
 *  org.simpleframework.xml.core.ContactList
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.Function
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.ParameterMap
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.util.List;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.Caller;
import org.simpleframework.xml.core.ClassScanner;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.ContactList;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.Function;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.ParameterMap;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.Section;
import org.simpleframework.xml.core.Signature;
import org.simpleframework.xml.core.Structure;
import org.simpleframework.xml.core.StructureBuilder;
import org.simpleframework.xml.core.Support;

class ObjectScanner
implements Scanner {
    private StructureBuilder builder;
    private Detail detail;
    private ClassScanner scanner;
    private Structure structure;
    private Support support;

    public ObjectScanner(Detail detail, Support support) throws Exception {
        this.scanner = new ClassScanner(detail, support);
        this.builder = new StructureBuilder(this, detail, support);
        this.support = support;
        this.detail = detail;
        this.scan(detail);
    }

    private void commit(Detail detail) throws Exception {
        Class class_ = detail.getType();
        if (this.structure == null) {
            this.structure = this.builder.build(class_);
        }
        this.builder = null;
    }

    private void field(Detail detail) throws Exception {
        Class class_ = detail.getType();
        DefaultType defaultType = detail.getOverride();
        for (Contact contact : this.support.getFields(class_, defaultType)) {
            Annotation annotation = contact.getAnnotation();
            if (annotation == null) continue;
            this.builder.process(contact, annotation);
        }
    }

    private void method(Detail detail) throws Exception {
        Class class_ = detail.getType();
        DefaultType defaultType = detail.getOverride();
        for (Contact contact : this.support.getMethods(class_, defaultType)) {
            Annotation annotation = contact.getAnnotation();
            if (annotation == null) continue;
            this.builder.process(contact, annotation);
        }
    }

    private void order(Detail detail) throws Exception {
        Class class_ = detail.getType();
        this.builder.assemble(class_);
    }

    private void scan(Detail detail) throws Exception {
        this.order(detail);
        this.field(detail);
        this.method(detail);
        this.validate(detail);
        this.commit(detail);
    }

    private void validate(Detail detail) throws Exception {
        Class class_ = detail.getType();
        this.builder.commit(class_);
        this.builder.validate(class_);
    }

    @Override
    public Caller getCaller(Context context) {
        return new Caller((Scanner)this, context);
    }

    @Override
    public Function getCommit() {
        return this.scanner.getCommit();
    }

    @Override
    public Function getComplete() {
        return this.scanner.getComplete();
    }

    @Override
    public Decorator getDecorator() {
        return this.scanner.getDecorator();
    }

    @Override
    public Instantiator getInstantiator() {
        return this.structure.getInstantiator();
    }

    @Override
    public String getName() {
        return this.detail.getName();
    }

    @Override
    public Order getOrder() {
        return this.scanner.getOrder();
    }

    @Override
    public ParameterMap getParameters() {
        return this.scanner.getParameters();
    }

    @Override
    public Function getPersist() {
        return this.scanner.getPersist();
    }

    @Override
    public Function getReplace() {
        return this.scanner.getReplace();
    }

    @Override
    public Function getResolve() {
        return this.scanner.getResolve();
    }

    @Override
    public Version getRevision() {
        return this.structure.getRevision();
    }

    @Override
    public Section getSection() {
        return this.structure.getSection();
    }

    @Override
    public Signature getSignature() {
        return this.scanner.getSignature();
    }

    @Override
    public List<Signature> getSignatures() {
        return this.scanner.getSignatures();
    }

    @Override
    public Label getText() {
        return this.structure.getText();
    }

    @Override
    public Class getType() {
        return this.detail.getType();
    }

    @Override
    public Function getValidate() {
        return this.scanner.getValidate();
    }

    @Override
    public Label getVersion() {
        return this.structure.getVersion();
    }

    @Override
    public boolean isEmpty() {
        return this.scanner.getRoot() == null;
    }

    @Override
    public boolean isPrimitive() {
        return this.structure.isPrimitive();
    }

    @Override
    public boolean isStrict() {
        return this.detail.isStrict();
    }
}

