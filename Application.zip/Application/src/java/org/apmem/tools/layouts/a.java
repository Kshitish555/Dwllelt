/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.apmem.tools.layouts;

public final class a {
    public static final boolean a = false;
    public static final String b = "org.apmem.tools.layouts";
    public static final String c = "release";
    public static final String d = "";
    public static final int e = 4;
    public static final String f = "1.10";
}

