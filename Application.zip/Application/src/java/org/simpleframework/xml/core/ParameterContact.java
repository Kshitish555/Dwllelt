/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Constructor
 *  org.simpleframework.xml.core.Reflector
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Reflector;

abstract class ParameterContact<T extends Annotation>
implements Contact {
    protected final Constructor factory;
    protected final int index;
    protected final T label;
    protected final Annotation[] labels;
    protected final Class owner;

    public ParameterContact(T t2, Constructor constructor, int n2) {
        this.labels = constructor.getParameterAnnotations()[n2];
        this.owner = constructor.getDeclaringClass();
        this.factory = constructor;
        this.index = n2;
        this.label = t2;
    }

    @Override
    public Object get(Object object) {
        return null;
    }

    @Override
    public Annotation getAnnotation() {
        return this.label;
    }

    public <A extends Annotation> A getAnnotation(Class<A> class_) {
        for (Annotation annotation : this.labels) {
            if (!annotation.annotationType().equals(class_)) continue;
            return (A)annotation;
        }
        return null;
    }

    @Override
    public Class getDeclaringClass() {
        return this.owner;
    }

    @Override
    public Class getDependent() {
        return Reflector.getParameterDependent((Constructor)this.factory, (int)this.index);
    }

    @Override
    public Class[] getDependents() {
        return Reflector.getParameterDependents((Constructor)this.factory, (int)this.index);
    }

    @Override
    public abstract String getName();

    @Override
    public Class getType() {
        return this.factory.getParameterTypes()[this.index];
    }

    @Override
    public boolean isReadOnly() {
        return false;
    }

    @Override
    public void set(Object object, Object object2) {
    }

    @Override
    public String toString() {
        Object[] arrobject = new Object[]{this.index, this.factory};
        return String.format((String)"parameter %s of constructor %s", (Object[])arrobject);
    }
}

