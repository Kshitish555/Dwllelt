/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.LinkedHashMap
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.ThreadFactory
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.MapTileRequestState
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.osmdroid.tileprovider.modules.ConfigurablePriorityThreadFactory
 *  org.osmdroid.tileprovider.modules.MapTileModuleProviderBase$1
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import java.util.LinkedHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.MapTileRequestState;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.osmdroid.tileprovider.modules.ConfigurablePriorityThreadFactory;
import org.osmdroid.tileprovider.modules.MapTileModuleProviderBase;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class MapTileModuleProviderBase
implements OpenStreetMapTileProviderConstants {
    private static final Logger logger = LoggerFactory.getLogger(MapTileModuleProviderBase.class);
    private final ExecutorService mExecutor;
    final LinkedHashMap<MapTile, MapTileRequestState> mPending;
    private final ConcurrentHashMap<MapTile, MapTileRequestState> mWorking;

    public MapTileModuleProviderBase(int n, int n2) {
        1 var3_3;
        this.mExecutor = Executors.newFixedThreadPool((int)n, (ThreadFactory)new ConfigurablePriorityThreadFactory(5, this.getThreadGroupName()));
        this.mWorking = new ConcurrentHashMap();
        this.mPending = var3_3 = new 1(this, n2 + 2, 0.1f, true, n2);
    }

    static /* synthetic */ ConcurrentHashMap access$000(MapTileModuleProviderBase mapTileModuleProviderBase) {
        return mapTileModuleProviderBase.mWorking;
    }

    static /* synthetic */ Logger access$100() {
        return logger;
    }

    static /* synthetic */ void access$200(MapTileModuleProviderBase mapTileModuleProviderBase) {
        mapTileModuleProviderBase.clearQueue();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void clearQueue() {
        LinkedHashMap<MapTile, MapTileRequestState> linkedHashMap;
        LinkedHashMap<MapTile, MapTileRequestState> linkedHashMap2 = linkedHashMap = this.mPending;
        synchronized (linkedHashMap2) {
            this.mPending.clear();
        }
        this.mWorking.clear();
    }

    public void detach() {
        this.clearQueue();
        this.mExecutor.shutdown();
    }

    public abstract int getMaximumZoomLevel();

    public abstract int getMinimumZoomLevel();

    protected abstract String getName();

    protected abstract String getThreadGroupName();

    protected abstract Runnable getTileLoader();

    public abstract boolean getUsesDataConnection();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void loadMapTileAsync(MapTileRequestState mapTileRequestState) {
        LinkedHashMap<MapTile, MapTileRequestState> linkedHashMap;
        LinkedHashMap<MapTile, MapTileRequestState> linkedHashMap2 = linkedHashMap = this.mPending;
        synchronized (linkedHashMap2) {
            this.mPending.put((Object)mapTileRequestState.getMapTile(), (Object)mapTileRequestState);
        }
        try {
            this.mExecutor.execute(this.getTileLoader());
            return;
        }
        catch (RejectedExecutionException rejectedExecutionException) {
            logger.warn("RejectedExecutionException", (Throwable)rejectedExecutionException);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void removeTileFromQueues(MapTile mapTile) {
        LinkedHashMap<MapTile, MapTileRequestState> linkedHashMap;
        LinkedHashMap<MapTile, MapTileRequestState> linkedHashMap2 = linkedHashMap = this.mPending;
        synchronized (linkedHashMap2) {
            this.mPending.remove((Object)mapTile);
        }
        this.mWorking.remove((Object)mapTile);
    }

    public abstract void setTileSource(ITileSource var1);
}

