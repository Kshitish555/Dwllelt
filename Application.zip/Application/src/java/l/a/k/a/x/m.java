/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  l.a.k.a.a
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.v
 *  l.a.k.a.x.n
 */
package l.a.k.a.x;

import l.a.k.a.a;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.v;
import l.a.k.a.x.c;
import l.a.k.a.x.n;

public class m
extends r {
    protected final n f;

    protected m(int n2, r r2, n n3) {
        super(n2, r2);
        this.f = n3;
    }

    public m(r r2, n n2) {
        this(327680, r2, n2);
    }

    private Object[] a(int n2, Object[] arrobject) {
        for (int i2 = 0; i2 < n2; ++i2) {
            if (!(arrobject[i2] instanceof String)) continue;
            Object[] arrobject2 = new Object[n2];
            if (i2 > 0) {
                System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)i2);
            }
            do {
                Object object = arrobject[i2];
                int n3 = i2 + 1;
                if (object instanceof String) {
                    object = this.f.d((String)object);
                }
                arrobject2[i2] = object;
                if (n3 >= n2) {
                    return arrobject2;
                }
                i2 = n3;
            } while (true);
        }
        return arrobject;
    }

    private void b(int n2, String string, String string2, String string3, boolean bl) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, this.f.d(string), this.f.b(string, string2, string3), this.f.c(string3), bl);
        }
    }

    public a a() {
        a a2 = super.a();
        if (a2 == null) {
            return a2;
        }
        return new c(a2, this.f);
    }

    public a a(int n2, String string, boolean bl) {
        a a2 = super.a(n2, this.f.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new c(a2, this.f);
    }

    public a a(int n2, v v2, String string, boolean bl) {
        a a2 = super.a(n2, v2, this.f.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new c(a2, this.f);
    }

    public a a(int n2, v v2, q[] arrq, q[] arrq2, int[] arrn, String string, boolean bl) {
        a a2 = super.a(n2, v2, arrq, arrq2, arrn, this.f.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new c(a2, this.f);
    }

    public a a(String string, boolean bl) {
        a a2 = super.a(this.f.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new c(a2, this.f);
    }

    public void a(int n2, int n3, Object[] arrobject, int n4, Object[] arrobject2) {
        super.a(n2, n3, this.a(n3, arrobject), n4, this.a(n4, arrobject2));
    }

    public void a(int n2, String string) {
        super.a(n2, this.f.d(string));
    }

    public void a(int n2, String string, String string2, String string3) {
        super.a(n2, this.f.d(string), this.f.a(string, string2, string3), this.f.b(string3));
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            super.a(n2, string, string2, string3, bl);
            return;
        }
        this.b(n2, string, string2, string3, bl);
    }

    public void a(Object object) {
        super.a(this.f.a(object));
    }

    public void a(String string, int n2) {
        super.a(this.f.b(string), n2);
    }

    public void a(String string, String string2, String string3, q q2, q q3, int n2) {
        super.a(string, this.f.b(string2), this.f.a(string3, true), q2, q3, n2);
    }

    public /* varargs */ void a(String string, String string2, l.a.k.a.n n2, Object ... arrobject) {
        for (int i2 = 0; i2 < arrobject.length; ++i2) {
            arrobject[i2] = this.f.a(arrobject[i2]);
        }
        super.a(this.f.a(string, string2), this.f.c(string2), (l.a.k.a.n)this.f.a((Object)n2), arrobject);
    }

    public void a(q q2, q q3, q q4, String string) {
        String string2 = string == null ? null : this.f.d(string);
        super.a(q2, q3, q4, string2);
    }

    public a b(int n2, v v2, String string, boolean bl) {
        a a2 = super.b(n2, v2, this.f.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new c(a2, this.f);
    }

    public void b(int n2, String string, String string2, String string3) {
        if (this.c >= 327680) {
            super.b(n2, string, string2, string3);
            return;
        }
        boolean bl = n2 == 185;
        this.b(n2, string, string2, string3, bl);
    }

    public a c(int n2, v v2, String string, boolean bl) {
        a a2 = super.c(n2, v2, this.f.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new c(a2, this.f);
    }
}

