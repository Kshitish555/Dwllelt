/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  org.simpleframework.xml.core.DefaultScanner
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.ObjectScanner
 *  org.simpleframework.xml.core.PrimitiveScanner
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.DefaultScanner;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.ObjectScanner;
import org.simpleframework.xml.core.PrimitiveScanner;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.ConcurrentCache;

class ScannerFactory {
    private final Cache<Scanner> cache = new ConcurrentCache<Scanner>();
    private final Support support;

    public ScannerFactory(Support support) {
        this.support = support;
    }

    public Scanner getInstance(Class class_) throws Exception {
        Scanner scanner = this.cache.fetch((Object)class_);
        if (scanner == null) {
            PrimitiveScanner primitiveScanner;
            Detail detail = this.support.getDetail(class_);
            if (this.support.isPrimitive(class_)) {
                primitiveScanner = new PrimitiveScanner(detail);
            } else {
                primitiveScanner = new ObjectScanner(detail, this.support);
                if (primitiveScanner.isPrimitive() && !this.support.isContainer(class_)) {
                    primitiveScanner = new DefaultScanner(detail, this.support);
                }
            }
            scanner = primitiveScanner;
            this.cache.cache((Object)class_, scanner);
        }
        return scanner;
    }
}

