/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.LinkedList
 *  java.util.Queue
 */
package org.osmdroid.tileprovider;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import org.osmdroid.tileprovider.IMapTileProviderCallback;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.modules.MapTileModuleProviderBase;

public class MapTileRequestState {
    private final IMapTileProviderCallback mCallback;
    private MapTileModuleProviderBase mCurrentProvider;
    private final MapTile mMapTile;
    private final Queue<MapTileModuleProviderBase> mProviderQueue;

    public MapTileRequestState(MapTile mapTile, MapTileModuleProviderBase[] arrmapTileModuleProviderBase, IMapTileProviderCallback iMapTileProviderCallback) {
        LinkedList linkedList;
        this.mProviderQueue = linkedList = new LinkedList();
        Collections.addAll((Collection)linkedList, (Object[])arrmapTileModuleProviderBase);
        this.mMapTile = mapTile;
        this.mCallback = iMapTileProviderCallback;
    }

    public IMapTileProviderCallback getCallback() {
        return this.mCallback;
    }

    public MapTileModuleProviderBase getCurrentProvider() {
        return this.mCurrentProvider;
    }

    public MapTile getMapTile() {
        return this.mMapTile;
    }

    public MapTileModuleProviderBase getNextProvider() {
        MapTileModuleProviderBase mapTileModuleProviderBase;
        this.mCurrentProvider = mapTileModuleProviderBase = (MapTileModuleProviderBase)this.mProviderQueue.poll();
        return mapTileModuleProviderBase;
    }

    public boolean isEmpty() {
        return this.mProviderQueue.isEmpty();
    }
}

