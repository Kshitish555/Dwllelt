/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Type
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.h.k.c$f
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 *  l.a.j.q.i.c.c$c
 *  l.a.j.q.i.c.d
 *  l.a.k.a.r
 */
package l.a.j.q.i.c;

import java.lang.reflect.Type;
import l.a.h.k.c;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.j.q.i.a;
import l.a.j.q.i.c.c;
import l.a.j.q.i.c.d;
import l.a.k.a.r;

public final class c
extends Enum<c>
implements e {
    public static final /* enum */ c P4;
    public static final /* enum */ c Q4;
    public static final /* enum */ c R4;
    public static final /* enum */ c S4;
    public static final /* enum */ c T4;
    private static final /* synthetic */ c[] U4;
    public static final /* enum */ c s;
    public static final /* enum */ c t;
    public static final /* enum */ c w;
    private final l.a.h.k.c c;
    private final l.a.h.k.c d;
    private final e.c f;
    private final String h;
    private final String o;

    static {
        c c2;
        c c3;
        c c4;
        c c5;
        c c6;
        c c7;
        c c8;
        c c9;
        s = c3 = new c(Boolean.class, Boolean.TYPE, f.d, "booleanValue", "()Z");
        t = c9 = new c(Byte.class, Byte.TYPE, f.d, "byteValue", "()B");
        w = c4 = new c(Short.class, Short.TYPE, f.d, "shortValue", "()S");
        P4 = c5 = new c(Character.class, Character.TYPE, f.d, "charValue", "()C");
        Q4 = c7 = new c(Integer.class, Integer.TYPE, f.d, "intValue", "()I");
        R4 = c2 = new c(Long.class, Long.TYPE, f.f, "longValue", "()J");
        S4 = c8 = new c(Float.class, Float.TYPE, f.d, "floatValue", "()F");
        T4 = c6 = new c(Double.class, Double.TYPE, f.f, "doubleValue", "()D");
        c[] arrc = new c[]{s, t, w, P4, Q4, R4, S4, c6};
        U4 = arrc;
    }

    private c(Class<?> class_, Class<?> class_2, f f2, String string2, String string3) {
        this.f = f2.f();
        this.c = new c.d(class_);
        this.d = new c.d(class_2);
        this.h = string2;
        this.o = string3;
    }

    public static c a(l.a.h.k.b b2) {
        if (!b2.isPrimitive()) {
            if (b2.a(Boolean.class)) {
                return a.d;
            }
            if (b2.a(Byte.class)) {
                return a.f;
            }
            if (b2.a(Short.class)) {
                return a.h;
            }
            if (b2.a(Character.class)) {
                return a.o;
            }
            if (b2.a(Integer.class)) {
                return a.s;
            }
            if (b2.a(Long.class)) {
                return a.t;
            }
            if (b2.a(Float.class)) {
                return a.w;
            }
            if (b2.a(Double.class)) {
                return a.P4;
            }
            return new b(b2.E0());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Expected reference type instead of ");
        stringBuilder.append((Object)b2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    protected static c a(c.f f2) {
        if (f2.a((Type)Boolean.TYPE)) {
            return s;
        }
        if (f2.a((Type)Byte.TYPE)) {
            return t;
        }
        if (f2.a((Type)Short.TYPE)) {
            return w;
        }
        if (f2.a((Type)Character.TYPE)) {
            return P4;
        }
        if (f2.a((Type)Integer.TYPE)) {
            return Q4;
        }
        if (f2.a((Type)Long.TYPE)) {
            return R4;
        }
        if (f2.a((Type)Float.TYPE)) {
            return S4;
        }
        if (f2.a((Type)Double.TYPE)) {
            return T4;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Expected non-void primitive type instead of ");
        stringBuilder.append((Object)f2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static c valueOf(String string) {
        return (c)Enum.valueOf(c.class, (String)string);
    }

    public static c[] values() {
        return (c[])U4.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(182, this.c.y0().d(), this.h, this.o, false);
        return this.f;
    }

    protected c.f k() {
        return this.c.E0();
    }

    public boolean x() {
        return true;
    }

    protected static final class a
    extends Enum<a>
    implements c {
        public static final /* enum */ a P4;
        private static final /* synthetic */ a[] Q4;
        public static final /* enum */ a d;
        public static final /* enum */ a f;
        public static final /* enum */ a h;
        public static final /* enum */ a o;
        public static final /* enum */ a s;
        public static final /* enum */ a t;
        public static final /* enum */ a w;
        private final c c;

        static {
            a a2;
            d = new a(c.s);
            f = new a(c.t);
            h = new a(c.w);
            o = new a(c.P4);
            s = new a(c.Q4);
            t = new a(c.R4);
            w = new a(c.S4);
            P4 = a2 = new a(c.T4);
            a[] arra = new a[]{d, f, h, o, s, t, w, a2};
            Q4 = arra;
        }

        private a(c c2) {
            this.c = c2;
        }

        public static a valueOf(String string) {
            return (a)Enum.valueOf(a.class, (String)string);
        }

        public static a[] values() {
            return (a[])Q4.clone();
        }

        public e a(c.f f2, l.a.j.q.i.a a2, a.d d2) {
            e[] arre = new e[2];
            c c2 = this.c;
            arre[0] = c2;
            arre[1] = d.b((l.a.h.k.b)c2.d).a((l.a.h.k.b)f2);
            return new e.a(arre);
        }
    }

    protected static class b
    implements c {
        private final c.f c;

        protected b(c.f f2) {
            this.c = f2;
        }

        public e a(c.f f2, l.a.j.q.i.a a2, a.d d2) {
            c c2 = c.a(f2);
            e[] arre = new e[]{a2.a(this.c, c2.k(), d2), c2};
            return new e.a(arre);
        }

        protected boolean a(Object object) {
            return object instanceof b;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof b)) {
                return false;
            }
            b b2 = (b)object;
            if (!b2.a(this)) {
                return false;
            }
            c.f f2 = this.c;
            c.f f3 = b2.c;
            return !(f2 == null ? f3 != null : !f2.equals((Object)f3));
        }

        public int hashCode() {
            c.f f2 = this.c;
            int n2 = f2 == null ? 43 : f2.hashCode();
            return 59 + n2;
        }
    }

}

