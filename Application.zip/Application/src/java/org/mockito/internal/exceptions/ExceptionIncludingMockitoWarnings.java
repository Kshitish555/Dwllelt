/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package org.mockito.internal.exceptions;

public class ExceptionIncludingMockitoWarnings
extends RuntimeException {
    private static final long c = -5925150219446765679L;

    public ExceptionIncludingMockitoWarnings(String string2, Throwable throwable) {
        super(string2, throwable);
    }
}

