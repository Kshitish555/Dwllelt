/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.adjust.sdk.SdkClickResponseData
 *  com.adjust.sdk.SessionResponseData
 *  java.lang.Object
 */
package com.adjust.sdk;

import com.adjust.sdk.IActivityHandler;
import com.adjust.sdk.SdkClickResponseData;
import com.adjust.sdk.SessionResponseData;

public interface IAttributionHandler {
    public void checkSdkClickResponse(SdkClickResponseData var1);

    public void checkSessionResponse(SessionResponseData var1);

    public void getAttribution();

    public void init(IActivityHandler var1, boolean var2);

    public void pauseSending();

    public void resumeSending();

    public void teardown();
}

