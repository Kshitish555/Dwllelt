/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  java.lang.Object
 */
package com.adjust.sdk;

import android.net.Uri;

public interface OnDeeplinkResponseListener {
    public boolean launchReceivedDeeplink(Uri var1);
}

