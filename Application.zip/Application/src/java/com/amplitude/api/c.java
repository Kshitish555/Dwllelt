/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.location.Location
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Pair
 *  c.a.a.a
 *  com.amplitude.api.c$a$a
 *  java.io.IOException
 *  java.io.UnsupportedEncodingException
 *  java.lang.AssertionError
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.net.ConnectException
 *  java.net.UnknownHostException
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  java.util.UUID
 *  java.util.concurrent.atomic.AtomicBoolean
 *  m.c0
 *  m.c0$a
 *  m.d0
 *  m.e
 *  m.e0
 *  m.f0
 *  m.s
 *  m.s$a
 *  m.z
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amplitude.api;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Build;
import android.util.Pair;
import com.amplitude.api.CursorWindowAllocationException;
import com.amplitude.api.c;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import m.c0;
import m.d0;
import m.e0;
import m.f0;
import m.s;
import m.z;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class c {
    public static final String O = "com.amplitude.api.AmplitudeClient";
    public static final String P = "session_start";
    public static final String Q = "session_end";
    public static final String R = "device_id";
    public static final String S = "user_id";
    public static final String T = "opt_out";
    public static final String U = "sequence_number";
    public static final String V = "last_event_time";
    public static final String W = "last_event_id";
    public static final String X = "last_identify_id";
    public static final String Y = "previous_session_id";
    private static final com.amplitude.api.d Z = com.amplitude.api.d.a();
    private long A = 300000L;
    private long B = 1800000L;
    private boolean C = false;
    private int D = 50;
    private boolean E = false;
    private boolean F = false;
    private boolean G = false;
    private boolean H = true;
    private AtomicBoolean I = new AtomicBoolean(false);
    AtomicBoolean J = new AtomicBoolean(false);
    Throwable K;
    String L = "https://api.amplitude.com/";
    com.amplitude.api.o M = new com.amplitude.api.o("logThread");
    com.amplitude.api.o N = new com.amplitude.api.o("httpThread");
    protected Context a;
    protected z b;
    protected com.amplitude.api.f c;
    protected String d;
    protected String e;
    protected String f;
    protected String g;
    private boolean h = false;
    private boolean i = false;
    protected boolean j = false;
    private boolean k = false;
    private boolean l = false;
    com.amplitude.api.m m = new com.amplitude.api.m();
    JSONObject n;
    protected String o;
    long p = -1L;
    long q = 0L;
    long r = -1L;
    long s = -1L;
    long t = -1L;
    long u = -1L;
    private com.amplitude.api.h v;
    private int w = 30;
    private int x = 50;
    private int y = 1000;
    private long z = 30000L;

    public c() {
        this(null);
    }

    public c(String string) {
        this.e = com.amplitude.api.n.b(string);
        this.M.start();
        this.N.start();
    }

    private long a(String string, long l2) {
        Long l3 = this.c.c(string);
        if (l3 == null) {
            return l2;
        }
        return l3;
    }

    private static void a(SharedPreferences sharedPreferences, String string, long l2, com.amplitude.api.f f2, String string2) {
        if (f2.c(string2) != null) {
            return;
        }
        f2.a(string2, (Long)sharedPreferences.getLong(string, l2));
        sharedPreferences.edit().remove(string).apply();
    }

    private static void a(SharedPreferences sharedPreferences, String string, String string2, com.amplitude.api.f f2, String string3) {
        if (!com.amplitude.api.n.a(f2.d(string3))) {
            return;
        }
        String string4 = sharedPreferences.getString(string, string2);
        if (!com.amplitude.api.n.a(string4)) {
            f2.c(string3, string4);
            sharedPreferences.edit().remove(string).apply();
        }
    }

    private static void a(SharedPreferences sharedPreferences, String string, boolean bl, com.amplitude.api.f f2, String string2) {
        if (f2.c(string2) != null) {
            return;
        }
        long l2 = sharedPreferences.getBoolean(string, bl) ? 1L : 0L;
        f2.a(string2, (Long)l2);
        sharedPreferences.edit().remove(string).apply();
    }

    static boolean a(Context context) {
        return c.b(context, null, null);
    }

    static boolean b(Context context) {
        return c.b(context, null);
    }

    static boolean b(Context context, String string) {
        if (string == null) {
            string = "com.amplitude.api";
        }
        com.amplitude.api.f f2 = com.amplitude.api.f.a(context);
        String string2 = f2.d(R);
        Long l2 = f2.c(Y);
        Long l3 = f2.c(V);
        if (!com.amplitude.api.n.a(string2) && l2 != null && l3 != null) {
            return true;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(".");
        stringBuilder.append(context.getPackageName());
        SharedPreferences sharedPreferences = context.getSharedPreferences(stringBuilder.toString(), 0);
        c.a(sharedPreferences, "com.amplitude.api.deviceId", null, f2, R);
        c.a(sharedPreferences, "com.amplitude.api.lastEventTime", -1L, f2, V);
        c.a(sharedPreferences, "com.amplitude.api.lastEventId", -1L, f2, W);
        c.a(sharedPreferences, "com.amplitude.api.lastIdentifyId", -1L, f2, X);
        c.a(sharedPreferences, "com.amplitude.api.previousSessionId", -1L, f2, Y);
        c.a(sharedPreferences, "com.amplitude.api.userId", null, f2, S);
        c.a(sharedPreferences, "com.amplitude.api.optOut", false, f2, T);
        return true;
    }

    /*
     * Exception decompiling
     */
    static boolean b(Context var0, String var1, String var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl10 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private void h(String string) {
        if (!this.a(String.format((String)"sendSessionEvent('%s')", (Object[])new Object[]{string}))) {
            return;
        }
        if (!this.u()) {
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("special", (Object)string);
        }
        catch (JSONException jSONException) {
            com.amplitude.api.i.c().a(String.format((String)"Failed to generate API Properties JSON for session event %s", (Object[])new Object[]{string}), jSONException);
            return;
        }
        this.a(string, null, jSONObject, null, null, null, this.t, false);
    }

    public static String i(String string) {
        if (string.length() <= 1024) {
            return string;
        }
        return string.substring(0, 1024);
    }

    private boolean k(long l2) {
        long l3 = this.E ? this.A : this.B;
        return l2 - this.t < l3;
    }

    private void l(long l2) {
        this.p = l2;
        this.h(l2);
    }

    private void m(long l2) {
        if (this.F) {
            this.h(Q);
        }
        this.l(l2);
        this.c(l2);
        if (this.F) {
            this.h(P);
        }
    }

    private void n(long l2) {
        if (this.I.getAndSet(true)) {
            return;
        }
        this.M.a(new Runnable(){

            public void run() {
                c.this.I.set(false);
                c.this.o();
            }
        }, l2);
    }

    private Set<String> t() {
        HashSet hashSet = new HashSet();
        hashSet.add((Object)"");
        hashSet.add((Object)"9774d56d682e549c");
        hashSet.add((Object)"unknown");
        hashSet.add((Object)"000000000000000");
        hashSet.add((Object)"Android");
        hashSet.add((Object)"DEFACE");
        hashSet.add((Object)"00000000-0000-0000-0000-000000000000");
        return hashSet;
    }

    private boolean u() {
        return this.p >= 0L;
    }

    private String v() {
        String string;
        Set<String> set = this.t();
        String string2 = this.c.d(R);
        if (!com.amplitude.api.n.a(string2) && !set.contains((Object)string2)) {
            return string2;
        }
        if (!(this.h || !this.i || this.v.n() || com.amplitude.api.n.a(string = this.v.a()) || set.contains((Object)string))) {
            this.c.c(R, string);
            return string;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(com.amplitude.api.h.q());
        stringBuilder.append("R");
        String string3 = stringBuilder.toString();
        this.c.c(R, string3);
        return string3;
    }

    private void w() {
        this.v = new com.amplitude.api.h(this.a);
        this.g = this.v();
        this.v.p();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected long a(String string, JSONObject jSONObject, JSONObject jSONObject2, JSONObject jSONObject3, JSONObject jSONObject4, JSONObject jSONObject5, long l2, boolean bl) {
        JSONObject jSONObject6;
        JSONObject jSONObject7;
        block21 : {
            block20 : {
                String string2;
                void var17_27;
                block22 : {
                    Location location;
                    com.amplitude.api.d d2 = Z;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Logged event to Amplitude: ");
                    stringBuilder.append(string);
                    d2.a(O, stringBuilder.toString());
                    if (this.k) {
                        return -1L;
                    }
                    boolean bl2 = this.F && (string.equals((Object)P) || string.equals((Object)Q));
                    if (!bl2 && !bl) {
                        if (!this.G) {
                            this.j(l2);
                        } else {
                            this.c(l2);
                        }
                    }
                    jSONObject6 = new JSONObject();
                    jSONObject6.put("event_type", this.a((Object)string));
                    jSONObject6.put("timestamp", l2);
                    jSONObject6.put(S, this.a((Object)this.f));
                    jSONObject6.put(R, this.a((Object)this.g));
                    long l3 = bl ? -1L : this.p;
                    jSONObject6.put("session_id", l3);
                    jSONObject6.put("uuid", (Object)UUID.randomUUID().toString());
                    jSONObject6.put(U, this.h());
                    if (this.m.G()) {
                        jSONObject6.put("version_name", this.a((Object)this.v.l()));
                    }
                    if (this.m.C()) {
                        jSONObject6.put("os_name", this.a((Object)this.v.j()));
                    }
                    if (this.m.D()) {
                        jSONObject6.put("os_version", this.a((Object)this.v.k()));
                    }
                    if (this.m.v()) {
                        jSONObject6.put("device_brand", this.a((Object)this.v.b()));
                    }
                    if (this.m.w()) {
                        jSONObject6.put("device_manufacturer", this.a((Object)this.v.g()));
                    }
                    if (this.m.x()) {
                        jSONObject6.put("device_model", this.a((Object)this.v.h()));
                    }
                    if (this.m.s()) {
                        jSONObject6.put("carrier", this.a((Object)this.v.c()));
                    }
                    if (this.m.u()) {
                        jSONObject6.put("country", this.a((Object)this.v.d()));
                    }
                    if (this.m.A()) {
                        jSONObject6.put("language", this.a((Object)this.v.f()));
                    }
                    if (this.m.E()) {
                        jSONObject6.put("platform", (Object)this.o);
                    }
                    JSONObject jSONObject8 = new JSONObject();
                    jSONObject8.put("name", (Object)"amplitude-android");
                    jSONObject8.put("version", (Object)"2.22.0");
                    jSONObject6.put("library", (Object)jSONObject8);
                    jSONObject7 = jSONObject2 == null ? new JSONObject() : jSONObject2;
                    if (this.n != null && this.n.length() > 0) {
                        jSONObject7.put("tracking_options", (Object)this.n);
                    }
                    if (!this.m.B() || (location = this.v.i()) == null) break block20;
                    JSONObject jSONObject9 = new JSONObject();
                    jSONObject9.put("lat", location.getLatitude());
                    string2 = O;
                    try {
                        jSONObject9.put("lng", location.getLongitude());
                        jSONObject7.put("location", (Object)jSONObject9);
                        break block21;
                    }
                    catch (JSONException jSONException) {
                        break block22;
                    }
                    catch (JSONException jSONException) {
                        string2 = O;
                    }
                }
                com.amplitude.api.d d3 = Z;
                Object[] arrobject = new Object[]{string, var17_27.toString()};
                String string3 = String.format((String)"JSON Serialization of event type %s failed, skipping: %s", (Object[])arrobject);
                d3.b(string2, string3);
                com.amplitude.api.i.c().a(String.format((String)"Failed to JSON serialize event type %s", (Object[])new Object[]{string}), (Throwable)var17_27);
                return -1L;
            }
            String string4 = O;
        }
        if (this.m.r() && this.v.a() != null) {
            jSONObject7.put("androidADID", (Object)this.v.a());
        }
        jSONObject7.put("limit_ad_tracking", this.v.n());
        jSONObject7.put("gps_enabled", this.v.m());
        jSONObject6.put("api_properties", (Object)jSONObject7);
        JSONObject jSONObject10 = jSONObject == null ? new JSONObject() : this.b(jSONObject);
        jSONObject6.put("event_properties", (Object)jSONObject10);
        JSONObject jSONObject11 = jSONObject3 == null ? new JSONObject() : this.b(jSONObject3);
        jSONObject6.put("user_properties", (Object)jSONObject11);
        JSONObject jSONObject12 = jSONObject4 == null ? new JSONObject() : this.b(jSONObject4);
        jSONObject6.put("groups", (Object)jSONObject12);
        JSONObject jSONObject13 = jSONObject5 == null ? new JSONObject() : this.b(jSONObject5);
        jSONObject6.put("group_properties", (Object)jSONObject13);
        return this.c(string, jSONObject6);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected Pair<Pair<Long, Long>, JSONArray> a(List<JSONObject> list, List<JSONObject> list2, long l2) throws JSONException {
        long l3;
        JSONArray jSONArray = new JSONArray();
        long l4 = l3 = -1L;
        while ((long)jSONArray.length() < l2) {
            long l5;
            block6 : {
                block9 : {
                    long l6;
                    block8 : {
                        block7 : {
                            boolean bl;
                            block5 : {
                                bl = list.isEmpty();
                                boolean bl2 = list2.isEmpty();
                                if (bl && bl2) {
                                    com.amplitude.api.d d2 = Z;
                                    Object[] arrobject = new Object[]{l2 - (long)jSONArray.length()};
                                    d2.e(O, String.format((String)"mergeEventsAndIdentifys: number of events and identifys less than expected by %d", (Object[])arrobject));
                                    return new Pair((Object)new Pair((Object)l3, (Object)l4), (Object)jSONArray);
                                }
                                if (!bl2) break block5;
                                JSONObject jSONObject = (JSONObject)list.remove(0);
                                l5 = jSONObject.getLong("event_id");
                                jSONArray.put((Object)jSONObject);
                                break block6;
                            }
                            if (!bl) break block7;
                            JSONObject jSONObject = (JSONObject)list2.remove(0);
                            l6 = jSONObject.getLong("event_id");
                            jSONArray.put((Object)jSONObject);
                            break block8;
                        }
                        if (!((JSONObject)list.get(0)).has(U) || ((JSONObject)list.get(0)).getLong(U) < ((JSONObject)list2.get(0)).getLong(U)) break block9;
                        JSONObject jSONObject = (JSONObject)list2.remove(0);
                        l6 = jSONObject.getLong("event_id");
                        jSONArray.put((Object)jSONObject);
                    }
                    l4 = l6;
                    continue;
                }
                JSONObject jSONObject = (JSONObject)list.remove(0);
                l5 = jSONObject.getLong("event_id");
                jSONArray.put((Object)jSONObject);
            }
            l3 = l5;
        }
        return new Pair((Object)new Pair((Object)l3, (Object)l4), (Object)jSONArray);
    }

    public c a(int n2) {
        com.amplitude.api.i.c().a(n2);
        return this;
    }

    public c a(Application application) {
        if (!this.E) {
            if (!this.a("enableForegroundTracking()")) {
                return this;
            }
            if (Build.VERSION.SDK_INT >= 14) {
                application.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new com.amplitude.api.b(this));
            }
        }
        return this;
    }

    public c a(Context context, String string) {
        return this.a(context, string, null);
    }

    public c a(Context context, String string, String string2) {
        return this.a(context, string, string2, null, false);
    }

    public c a(final Context context, final String string, final String string2, String string3, final boolean bl) {
        c c2 = this;
        synchronized (c2) {
            block8 : {
                Context context2;
                block7 : {
                    if (context == null) {
                        Z.b(O, "Argument context cannot be null in initialize()");
                        return this;
                    }
                    if (!com.amplitude.api.n.a(string)) break block7;
                    Z.b(O, "Argument apiKey cannot be null or blank in initialize()");
                    return this;
                }
                this.a = context2 = context.getApplicationContext();
                this.d = string;
                this.c = com.amplitude.api.f.a(context2, this.e);
                if (!com.amplitude.api.n.a(string3)) break block8;
                string3 = "Android";
            }
            this.o = string3;
            Runnable runnable = new Runnable(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    c c2;
                    boolean bl2;
                    c c3 = c.this;
                    if (!c3.j) {
                        try {
                            if (c3.e.equals((Object)"$default_instance")) {
                                c.a(context);
                                c.b(context);
                            }
                            c.this.b = new z();
                            c.this.v = new com.amplitude.api.h(context);
                            c.this.g = c.this.v();
                            if (bl) {
                                com.amplitude.api.i.c().a(c.this.b, string, c.this.g);
                            }
                            c.this.v.p();
                            String string3 = string2;
                            if (string3 != null) {
                                this.f = string2;
                                c.this.c.c(c.S, string2);
                            } else {
                                this.f = c.this.c.d(c.S);
                            }
                            Long l2 = c.this.c.c(c.T);
                            c2 = c.this;
                            bl2 = l2 != null && l2 == 1L;
                        }
                        catch (CursorWindowAllocationException cursorWindowAllocationException) {
                            com.amplitude.api.d d2 = Z;
                            Object[] arrobject = new Object[]{cursorWindowAllocationException.getMessage()};
                            d2.b(c.O, String.format((String)"Failed to initialize Amplitude SDK due to: %s", (Object[])arrobject));
                            com.amplitude.api.i.c().a("Failed to initialize Amplitude SDK", (Throwable)cursorWindowAllocationException);
                            this.d = null;
                        }
                    }
                    return;
                    c2.k = bl2;
                    c.this.u = c.this.a(c.Y, -1L);
                    if (c.this.u >= 0L) {
                        c.this.p = c.this.u;
                    }
                    c.this.q = c.this.a(c.U, 0L);
                    c.this.r = c.this.a(c.W, -1L);
                    c.this.s = c.this.a(c.X, -1L);
                    c.this.t = c.this.a(c.V, -1L);
                    c.this.c.a((com.amplitude.api.g)new a(this));
                    c.this.j = true;
                }
            };
            this.a(runnable);
            return this;
        }
    }

    public c a(com.amplitude.api.m m2) {
        this.m = m2;
        this.n = m2.q();
        return this;
    }

    public c a(final String string, final boolean bl) {
        if (!this.a("setUserId()")) {
            return this;
        }
        this.a(new Runnable(){

            public void run() {
                String string2;
                if (com.amplitude.api.n.a(this.d)) {
                    return;
                }
                if (bl && c.this.F) {
                    c.this.h(c.Q);
                }
                c c2 = this;
                c2.f = string2 = string;
                c.this.c.c(c.S, string2);
                if (bl) {
                    long l2 = c.this.f();
                    c.this.l(l2);
                    c.this.c(l2);
                    if (c.this.F) {
                        c.this.h(c.P);
                    }
                }
            }
        });
        return this;
    }

    public c a(boolean bl) {
        Z.a(bl);
        return this;
    }

    protected Object a(Object object) {
        if (object == null) {
            object = JSONObject.NULL;
        }
        return object;
    }

    protected String a(byte[] arrby) {
        char[] arrc = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
        char[] arrc2 = new char[2 * arrby.length];
        for (int i2 = 0; i2 < arrby.length; ++i2) {
            int n2 = 255 & arrby[i2];
            int n3 = i2 * 2;
            arrc2[n3] = arrc[n2 >>> 4];
            arrc2[n3 + 1] = arrc[n2 & 15];
        }
        return new String(arrc2);
    }

    public JSONArray a(JSONArray jSONArray) throws JSONException {
        if (jSONArray == null) {
            return new JSONArray();
        }
        for (int i2 = 0; i2 < jSONArray.length(); ++i2) {
            Object object = jSONArray.get(i2);
            if (object.getClass().equals(String.class)) {
                jSONArray.put(i2, (Object)c.i((String)object));
                continue;
            }
            if (object.getClass().equals(JSONObject.class)) {
                jSONArray.put(i2, (Object)this.b((JSONObject)object));
                continue;
            }
            if (!object.getClass().equals(JSONArray.class)) continue;
            jSONArray.put(i2, (Object)this.a((JSONArray)object));
        }
        return jSONArray;
    }

    public void a() {
        this.a(new com.amplitude.api.j().a());
    }

    public void a(double d2) {
        this.a(null, 1, d2);
    }

    void a(final long l2) {
        this.a(new Runnable(){

            public void run() {
                if (com.amplitude.api.n.a(c.this.d)) {
                    return;
                }
                c.this.j(l2);
                c.this.G = true;
            }
        });
    }

    public void a(com.amplitude.api.j j2) {
        this.a(j2, false);
    }

    public void a(com.amplitude.api.j j2, boolean bl) {
        if (j2 != null && j2.a.length() != 0) {
            if (!this.a("identify()")) {
                return;
            }
            this.b("$identify", null, null, j2.a, null, null, this.f(), bl);
        }
    }

    public void a(com.amplitude.api.l l2) {
        if (this.a("logRevenueV2()") && l2 != null) {
            if (!l2.a()) {
                return;
            }
            this.a("revenue_amount", l2.b());
        }
    }

    protected void a(Runnable runnable) {
        com.amplitude.api.o o2;
        Thread thread = Thread.currentThread();
        if (thread != (o2 = this.M)) {
            o2.a(runnable);
            return;
        }
        runnable.run();
    }

    public void a(String string, int n2, double d2) {
        this.a(string, n2, d2, null, null);
    }

    public void a(String string, int n2, double d2, String string2, String string3) {
        if (!this.a("logRevenue()")) {
            return;
        }
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("special", (Object)"revenue_amount");
            jSONObject.put("productId", (Object)string);
            jSONObject.put("quantity", n2);
            jSONObject.put("price", d2);
            jSONObject.put("receipt", (Object)string2);
            jSONObject.put("receiptSig", (Object)string3);
        }
        catch (JSONException jSONException) {
            com.amplitude.api.i.c().a("Failed to generate API Properties JSON for revenue event", jSONException);
        }
        this.b("revenue_amount", null, jSONObject, null, null, null, this.f(), false);
    }

    public void a(String string, Object object) {
        if (this.a("setGroup()")) {
            JSONObject jSONObject;
            if (com.amplitude.api.n.a(string)) {
                return;
            }
            try {
                JSONObject jSONObject2;
                jSONObject = jSONObject2 = new JSONObject().put(string, object);
            }
            catch (JSONException jSONException) {
                Z.b(O, jSONException.toString());
                com.amplitude.api.i.c().a(String.format((String)"Failed to generate Group JSON for groupType: %s", (Object[])new Object[]{string}), jSONException);
                jSONObject = null;
            }
            this.b("$identify", null, null, new com.amplitude.api.j().c((String)string, (Object)object).a, jSONObject, null, this.f(), false);
        }
    }

    public void a(String string, Object object, com.amplitude.api.j j2) {
        this.a(string, object, j2, false);
    }

    public void a(String string, Object object, com.amplitude.api.j j2, boolean bl) {
        if (j2 != null && j2.a.length() != 0 && this.a("groupIdentify()")) {
            JSONObject jSONObject;
            if (com.amplitude.api.n.a(string)) {
                return;
            }
            try {
                JSONObject jSONObject2;
                jSONObject = jSONObject2 = new JSONObject().put(string, object);
            }
            catch (JSONException jSONException) {
                Z.b(O, jSONException.toString());
                com.amplitude.api.i.c().a(String.format((String)"Failed to generate Group Identify JSON Object for groupType %s", (Object[])new Object[]{string}), jSONException);
                jSONObject = null;
            }
            this.b("$groupidentify", null, null, null, jSONObject, j2.a, this.f(), bl);
            return;
        }
    }

    public void a(String string, JSONObject jSONObject) {
        this.a(string, jSONObject, false);
    }

    public void a(String string, JSONObject jSONObject, JSONObject jSONObject2) {
        this.a(string, jSONObject, jSONObject2, false);
    }

    public void a(String string, JSONObject jSONObject, JSONObject jSONObject2, long l2, boolean bl) {
        if (this.g(string)) {
            this.b(string, jSONObject, null, null, jSONObject2, null, l2, bl);
        }
    }

    public void a(String string, JSONObject jSONObject, JSONObject jSONObject2, boolean bl) {
        this.a(string, jSONObject, jSONObject2, this.f(), bl);
    }

    public void a(String string, JSONObject jSONObject, boolean bl) {
        this.a(string, jSONObject, null, bl);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected void a(z var1_1, String var2_2, final long var3_3, final long var5_4) {
        block25 : {
            block30 : {
                block29 : {
                    block28 : {
                        block27 : {
                            block26 : {
                                block31 : {
                                    block24 : {
                                        var7_5 = new StringBuilder();
                                        var8_6 = "";
                                        var7_5.append(var8_6);
                                        var7_5.append(this.f());
                                        var11_7 = var7_5.toString();
                                        try {
                                            var12_8 = new StringBuilder();
                                            var12_8.append("2");
                                            var12_8.append(this.d);
                                            var12_8.append(var2_2);
                                            var12_8.append(var11_7);
                                            var60_9 = var12_8.toString();
                                            var8_6 = this.a(new c.a.a.a().digest(var60_9.getBytes("UTF-8")));
                                        }
                                        catch (UnsupportedEncodingException var13_10) {
                                            c.Z.b("com.amplitude.api.AmplitudeClient", var13_10.toString());
                                            com.amplitude.api.i.c().a("Failed to compute checksum for upload request", var13_10);
                                        }
                                        var16_11 = new s.a().a("v", "2").a("client", this.d).a("e", var2_2).a("upload_time", var11_7).a("checksum", var8_6).a();
                                        try {
                                            var20_12 = new c0.a().b(this.L).c((d0)var16_11).a();
                                            var21_13 = 1;
                                        }
                                        catch (IllegalArgumentException var17_39) {
                                            c.Z.b("com.amplitude.api.AmplitudeClient", var17_39.toString());
                                            this.J.set(false);
                                            com.amplitude.api.i.c().a("Failed to build upload request", var17_39);
                                            return;
                                        }
                                        var35_14 = var1_1.a(var20_12).execute();
                                        var36_15 = var35_14.a().h();
                                        var37_16 = var36_15.equals((Object)"success");
                                        if (!var37_16) break block24;
                                        try {
                                            var54_17 = this.M;
                                            var55_18 = new Runnable(){

                                                public void run() {
                                                    long l2;
                                                    long l3 = var3_3;
                                                    if (l3 >= 0L) {
                                                        c.this.c.d(l3);
                                                    }
                                                    if ((l2 = var5_4) >= 0L) {
                                                        c.this.c.f(l2);
                                                    }
                                                    c.this.J.set(false);
                                                    if (c.this.c.d() > (long)c.this.w) {
                                                        c.this.M.a(new Runnable(){

                                                            public void run() {
                                                                c c2 = c.this;
                                                                c2.g(c2.C);
                                                            }
                                                        });
                                                        return;
                                                    }
                                                    c.this.C = false;
                                                    c c2 = c.this;
                                                    c2.D = c2.x;
                                                }

                                            };
                                            var54_17.a(var55_18);
                                            break block25;
                                        }
                                        catch (Exception var32_19) {
                                            break block26;
                                        }
                                        catch (AssertionError var29_22) {
                                            break block27;
                                        }
                                        catch (IOException var26_25) {
                                            break block28;
                                        }
                                        catch (UnknownHostException var24_28) {
                                            break block29;
                                        }
                                        catch (ConnectException var22_31) {
                                            break block30;
                                        }
                                    }
                                    if (var36_15.equals((Object)"invalid_api_key")) {
                                        c.Z.b("com.amplitude.api.AmplitudeClient", "Invalid API key, make sure your API key is correct in initialize()");
                                        break block31;
                                    }
                                    if (var36_15.equals((Object)"bad_checksum")) {
                                        c.Z.e("com.amplitude.api.AmplitudeClient", "Bad checksum, post request was mangled in transit, will attempt to reupload later");
                                        break block31;
                                    }
                                    if (var36_15.equals((Object)"request_db_write_failed")) {
                                        c.Z.e("com.amplitude.api.AmplitudeClient", "Couldn't write to request database on server, will attempt to reupload later");
                                        break block31;
                                    }
                                    if (var35_14.e() != 413) ** GOTO lbl74
                                    if (this.C && this.D == var21_13) {
                                        if (var3_3 >= 0L) {
                                            this.c.c(var3_3);
                                        }
                                        if (var5_4 >= 0L) {
                                            this.c.e(var5_4);
                                        }
                                    }
                                    this.C = var21_13;
                                    var44_34 = Math.min((int)((int)this.c.b()), (int)this.D);
                                    var45_35 = var44_34;
                                    Double.isNaN((double)var45_35);
                                    var48_36 = var45_35 / 2.0;
                                    try {
                                        this.D = (int)Math.ceil((double)var48_36);
                                        c.Z.e("com.amplitude.api.AmplitudeClient", "Request too large, will decrease size and attempt to reupload");
                                        this.M.a(new Runnable(){

                                            public void run() {
                                                c.this.J.set(false);
                                                c.this.g(true);
                                            }
                                        });
                                        break block31;
lbl74: // 1 sources:
                                        var38_37 = c.Z;
                                        var39_38 = new StringBuilder();
                                        var39_38.append("Upload failed, ");
                                        var39_38.append(var36_15);
                                        var39_38.append(", will attempt to reupload later");
                                        var38_37.e("com.amplitude.api.AmplitudeClient", var39_38.toString());
                                    }
                                    catch (Exception var32_20) {
                                        var21_13 = 0;
                                    }
                                }
                                var21_13 = 0;
                                break block25;
                            }
                            c.Z.b("com.amplitude.api.AmplitudeClient", "Exception:", (Throwable)var32_21);
                            this.K = var32_21;
                            com.amplitude.api.i.c().a("Failed to post upload request", (Throwable)var32_21);
                            break block25;
                            catch (AssertionError var29_23) {
                                var21_13 = 0;
                            }
                        }
                        c.Z.b("com.amplitude.api.AmplitudeClient", "Exception:", (Throwable)var29_24);
                        this.K = var29_24;
                        com.amplitude.api.i.c().a("Failed to post upload request", (Throwable)var29_24);
                        break block25;
                        catch (IOException var26_26) {
                            var21_13 = 0;
                        }
                    }
                    c.Z.b("com.amplitude.api.AmplitudeClient", var26_27.toString());
                    this.K = var26_27;
                    com.amplitude.api.i.c().a("Failed to post upload request", (Throwable)var26_27);
                    break block25;
                    catch (UnknownHostException var24_29) {
                        var21_13 = 0;
                    }
                }
                this.K = var24_30;
                com.amplitude.api.i.c().a("Failed to post upload request", (Throwable)var24_30);
                break block25;
                catch (ConnectException var22_32) {
                    var21_13 = 0;
                }
            }
            this.K = var22_33;
            com.amplitude.api.i.c().a("Failed to post upload request", (Throwable)var22_33);
        }
        if (var21_13 != 0) return;
        this.J.set(false);
    }

    public void a(JSONObject jSONObject) {
        if (jSONObject != null && jSONObject.length() != 0) {
            if (!this.a("setUserProperties")) {
                return;
            }
            JSONObject jSONObject2 = this.b(jSONObject);
            if (jSONObject2.length() == 0) {
                return;
            }
            com.amplitude.api.j j2 = new com.amplitude.api.j();
            Iterator iterator = jSONObject2.keys();
            while (iterator.hasNext()) {
                String string = (String)iterator.next();
                try {
                    j2.c(string, jSONObject2.get(string));
                }
                catch (JSONException jSONException) {
                    Z.b(O, jSONException.toString());
                    com.amplitude.api.i.c().a(String.format((String)"Failed to set user property %s", (Object[])new Object[]{string}), jSONException);
                }
            }
            this.a(j2);
        }
    }

    public void a(JSONObject jSONObject, boolean bl) {
        this.a(jSONObject);
    }

    protected boolean a(String string) {
        c c2 = this;
        synchronized (c2) {
            if (this.a == null) {
                com.amplitude.api.d d2 = Z;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("context cannot be null, set context with initialize() before calling ");
                stringBuilder.append(string);
                d2.b(O, stringBuilder.toString());
                return false;
            }
            if (com.amplitude.api.n.a(this.d)) {
                com.amplitude.api.d d3 = Z;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("apiKey cannot be null or empty, set apiKey with initialize() before calling ");
                stringBuilder.append(string);
                d3.b(O, stringBuilder.toString());
                return false;
            }
            return true;
        }
    }

    public c b() {
        com.amplitude.api.i.c().a();
        return this;
    }

    public c b(int n2) {
        this.y = n2;
        return this;
    }

    public c b(boolean bl) {
        this.h = bl;
        return this;
    }

    public JSONObject b(JSONObject jSONObject) {
        if (jSONObject == null) {
            return new JSONObject();
        }
        if (jSONObject.length() > 1000) {
            Z.e(O, "Warning: too many properties (more than 1000), ignoring");
            return new JSONObject();
        }
        Iterator iterator = jSONObject.keys();
        while (iterator.hasNext()) {
            String string = (String)iterator.next();
            try {
                Object object = jSONObject.get(string);
                if (!string.equals((Object)"$receipt") && !string.equals((Object)"$receiptSig")) {
                    if (object.getClass().equals(String.class)) {
                        jSONObject.put(string, (Object)c.i((String)object));
                        continue;
                    }
                    if (object.getClass().equals(JSONObject.class)) {
                        jSONObject.put(string, (Object)this.b((JSONObject)object));
                        continue;
                    }
                    if (!object.getClass().equals(JSONArray.class)) continue;
                    jSONObject.put(string, (Object)this.a((JSONArray)object));
                    continue;
                }
                jSONObject.put(string, object);
            }
            catch (JSONException jSONException) {
                Z.b(O, jSONException.toString());
            }
        }
        return jSONObject;
    }

    void b(final long l2) {
        this.a(new Runnable(){

            public void run() {
                if (com.amplitude.api.n.a(c.this.d)) {
                    return;
                }
                c.this.c(l2);
                c.this.G = false;
                if (c.this.H) {
                    c.this.o();
                }
                c c2 = c.this;
                c2.c.c(c.R, c2.g);
                c c3 = c.this;
                c3.c.c(c.S, c3.f);
                c c4 = c.this;
                com.amplitude.api.f f2 = c4.c;
                long l22 = c4.k ? 1L : 0L;
                f2.a(c.T, (Long)l22);
                c c5 = c.this;
                c5.c.a(c.Y, (Long)c5.p);
                c c6 = c.this;
                c6.c.a(c.V, (Long)c6.t);
            }
        });
    }

    public void b(String string) {
        this.a(string, null);
    }

    public void b(String string, JSONObject jSONObject) {
        this.b(string, jSONObject, false);
    }

    public void b(String string, JSONObject jSONObject, JSONObject jSONObject2) {
        this.b(string, jSONObject, jSONObject2, false);
    }

    public void b(String string, JSONObject jSONObject, JSONObject jSONObject2, long l2, boolean bl) {
        if (this.g(string)) {
            this.a(string, jSONObject, null, null, jSONObject2, null, l2, bl);
        }
    }

    protected void b(final String string, JSONObject jSONObject, JSONObject jSONObject2, JSONObject jSONObject3, JSONObject jSONObject4, JSONObject jSONObject5, final long l2, final boolean bl) {
        final JSONObject jSONObject6 = jSONObject != null ? com.amplitude.api.n.a(jSONObject) : jSONObject;
        final JSONObject jSONObject7 = jSONObject2 != null ? com.amplitude.api.n.a(jSONObject2) : jSONObject2;
        final JSONObject jSONObject8 = jSONObject3 != null ? com.amplitude.api.n.a(jSONObject3) : jSONObject3;
        final JSONObject jSONObject9 = jSONObject4 != null ? com.amplitude.api.n.a(jSONObject4) : jSONObject4;
        final JSONObject jSONObject10 = jSONObject5 != null ? com.amplitude.api.n.a(jSONObject5) : jSONObject5;
        Runnable runnable = new Runnable(){

            public void run() {
                if (com.amplitude.api.n.a(c.this.d)) {
                    return;
                }
                c.this.a(string, jSONObject6, jSONObject7, jSONObject8, jSONObject9, jSONObject10, l2, bl);
            }
        };
        this.a(runnable);
    }

    public void b(String string, JSONObject jSONObject, JSONObject jSONObject2, boolean bl) {
        this.b(string, jSONObject, jSONObject2, this.f(), bl);
    }

    public void b(String string, JSONObject jSONObject, boolean bl) {
        this.b(string, jSONObject, null, bl);
    }

    protected long c(String string, JSONObject jSONObject) {
        long l2;
        int n2;
        String string2 = jSONObject.toString();
        if (com.amplitude.api.n.a(string2)) {
            Z.b(O, String.format((String)"Detected empty event string for event type %s, skipping", (Object[])new Object[]{string}));
            return -1L;
        }
        if (!string.equals((Object)"$identify") && !string.equals((Object)"$groupidentify")) {
            long l3;
            this.r = l3 = this.c.a(string2);
            this.d(l3);
        } else {
            long l4;
            this.s = l4 = this.c.b(string2);
            this.f(l4);
        }
        int n3 = Math.min((int)Math.max((int)1, (int)(this.y / 10)), (int)20);
        if (this.c.b() > (long)this.y) {
            com.amplitude.api.f f2 = this.c;
            f2.d(f2.a(n3));
        }
        if (this.c.c() > (long)this.y) {
            com.amplitude.api.f f3 = this.c;
            f3.f(f3.b(n3));
        }
        if ((l2 = this.c.d()) % (long)(n2 = this.w) == 0L && l2 >= (long)n2) {
            this.o();
        } else {
            this.n(this.z);
        }
        if (!string.equals((Object)"$identify") && !string.equals((Object)"$groupidentify")) {
            return this.r;
        }
        return this.s;
    }

    public c c() {
        this.a(new Runnable(){

            public void run() {
                if (c.this.v != null) {
                    c.this.v.a(false);
                    return;
                }
                throw new IllegalStateException("Must initialize before acting on location listening.");
            }
        });
        return this;
    }

    public c c(int n2) {
        this.x = n2;
        this.D = n2;
        return this;
    }

    public c c(boolean bl) {
        this.H = bl;
        return this;
    }

    void c(long l2) {
        if (!this.u()) {
            return;
        }
        this.e(l2);
    }

    public void c(String string) {
        this.b(string, null);
    }

    public c d() {
        if (!this.a("enableDiagnosticLogging")) {
            return this;
        }
        com.amplitude.api.i.c().a(this.b, this.d, this.g);
        return this;
    }

    public c d(int n2) {
        this.z = n2;
        return this;
    }

    public c d(final String string) {
        Set<String> set = this.t();
        if (this.a("setDeviceId()") && !com.amplitude.api.n.a(string)) {
            if (set.contains((Object)string)) {
                return this;
            }
            this.a(new Runnable(){

                public void run() {
                    String string2;
                    if (com.amplitude.api.n.a(this.d)) {
                        return;
                    }
                    c c2 = this;
                    c2.g = string2 = string;
                    c.this.c.c(c.R, string2);
                }
            });
        }
        return this;
    }

    public c d(boolean bl) {
        this.l = bl;
        if (!bl) {
            this.p();
        }
        return this;
    }

    void d(long l2) {
        this.r = l2;
        this.c.a(W, (Long)l2);
    }

    public c e() {
        this.a(new Runnable(){

            public void run() {
                if (c.this.v != null) {
                    c.this.v.a(true);
                    return;
                }
                throw new IllegalStateException("Must initialize before acting on location listening.");
            }
        });
        return this;
    }

    public c e(int n2) {
        this.w = n2;
        return this;
    }

    public c e(String string) {
        if (!com.amplitude.api.n.a(string)) {
            this.L = string;
        }
        return this;
    }

    public c e(final boolean bl) {
        if (!this.a("setOptOut()")) {
            return this;
        }
        this.a(new Runnable(){

            public void run() {
                if (com.amplitude.api.n.a(c.this.d)) {
                    return;
                }
                this.k = bl;
                com.amplitude.api.f f2 = c.this.c;
                long l2 = bl ? 1L : 0L;
                f2.a(c.T, (Long)l2);
            }
        });
        return this;
    }

    void e(long l2) {
        this.t = l2;
        this.c.a(V, (Long)l2);
    }

    protected long f() {
        return System.currentTimeMillis();
    }

    public c f(int n2) {
        Z.a(n2);
        return this;
    }

    public c f(String string) {
        return this.a(string, false);
    }

    public c f(boolean bl) {
        this.F = bl;
        return this;
    }

    void f(long l2) {
        this.s = l2;
        this.c.a(X, (Long)l2);
    }

    public c g(long l2) {
        this.A = l2;
        return this;
    }

    public String g() {
        return this.g;
    }

    protected void g(boolean bl) {
        if (!this.k) {
            if (this.l) {
                return;
            }
            if (!this.J.getAndSet(true)) {
                long l2;
                int n2 = bl ? this.D : this.x;
                long l3 = Math.min((long)n2, (long)(l2 = this.c.d()));
                if (l3 <= 0L) {
                    this.J.set(false);
                    return;
                }
                try {
                    Pair<Pair<Long, Long>, JSONArray> pair = this.a(this.c.a(this.r, l3), this.c.b(this.s, l3), l3);
                    if (((JSONArray)pair.second).length() == 0) {
                        this.J.set(false);
                        return;
                    }
                    final long l4 = (Long)((Pair)pair.first).first;
                    final long l5 = (Long)((Pair)pair.first).second;
                    final String string = ((JSONArray)pair.second).toString();
                    com.amplitude.api.o o2 = this.N;
                    Runnable runnable = new Runnable(){

                        public void run() {
                            c c2 = c.this;
                            c2.a(c2.b, string, l4, l5);
                        }
                    };
                    o2.a(runnable);
                    return;
                }
                catch (CursorWindowAllocationException cursorWindowAllocationException) {
                    this.J.set(false);
                    com.amplitude.api.d d2 = Z;
                    Object[] arrobject = new Object[]{cursorWindowAllocationException.getMessage()};
                    d2.b(O, String.format((String)"Caught Cursor window exception during event upload, deferring upload: %s", (Object[])arrobject));
                    com.amplitude.api.i.c().a("Failed to update server", (Throwable)cursorWindowAllocationException);
                    return;
                }
                catch (JSONException jSONException) {
                    this.J.set(false);
                    Z.b(O, jSONException.toString());
                    com.amplitude.api.i.c().a("Failed to update server", jSONException);
                }
            }
        }
    }

    protected boolean g(String string) {
        if (com.amplitude.api.n.a(string)) {
            Z.b(O, "Argument eventType cannot be null or blank in logEvent()");
            return false;
        }
        return this.a("logEvent()");
    }

    long h() {
        long l2;
        this.q = l2 = 1L + this.q;
        this.c.a(U, (Long)l2);
        return this.q;
    }

    void h(long l2) {
        this.u = l2;
        this.c.a(Y, (Long)l2);
    }

    public long i() {
        return this.p;
    }

    public c i(long l2) {
        this.B = l2;
        return this;
    }

    public String j() {
        return this.f;
    }

    boolean j(long l2) {
        if (this.u()) {
            if (this.k(l2)) {
                this.c(l2);
                return false;
            }
            this.m(l2);
            return true;
        }
        if (this.k(l2)) {
            long l3 = this.u;
            if (l3 == -1L) {
                this.m(l2);
                return true;
            }
            this.l(l3);
            this.c(l2);
            return false;
        }
        this.m(l2);
        return true;
    }

    boolean k() {
        return this.G;
    }

    public boolean l() {
        return this.k;
    }

    boolean m() {
        return this.E;
    }

    public c n() {
        if (!this.a("regenerateDeviceId()")) {
            return this;
        }
        this.a(new Runnable(){

            public void run() {
                if (com.amplitude.api.n.a(this.d)) {
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(com.amplitude.api.h.q());
                stringBuilder.append("R");
                String string = stringBuilder.toString();
                c.this.d(string);
            }
        });
        return this;
    }

    protected void o() {
        this.g(false);
        com.amplitude.api.i.c().b();
    }

    public void p() {
        if (!this.a("uploadEvents()")) {
            return;
        }
        this.M.a(new Runnable(){

            public void run() {
                if (com.amplitude.api.n.a(c.this.d)) {
                    return;
                }
                c.this.o();
            }
        });
    }

    public c q() {
        this.i = true;
        return this;
    }

    void r() {
        this.E = true;
    }

}

