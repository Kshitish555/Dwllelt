/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.j.q.e
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 */
package l.a.j.q.i.d;

import l.a.h.k.c;
import l.a.j.q.e;
import l.a.j.q.i.a;
import l.a.j.q.i.b;

public final class a
extends Enum<a>
implements l.a.j.q.i.a {
    public static final /* enum */ a c;
    private static final /* synthetic */ a[] d;

    static {
        a a2;
        c = a2 = new a();
        d = new a[]{a2};
    }

    public static a valueOf(String string) {
        return (a)Enum.valueOf(a.class, (String)string);
    }

    public static a[] values() {
        return (a[])d.clone();
    }

    public e a(c.f f2, c.f f3, a.d d2) {
        if (!f2.isPrimitive() && !f3.isPrimitive()) {
            if (f2.y0().b(f3.y0())) {
                return e.d.c;
            }
            if (d2.c()) {
                return b.a((l.a.h.k.b)f3);
            }
            return e.b.c;
        }
        if (f2.equals((Object)f3)) {
            return e.d.c;
        }
        return e.b.c;
    }
}

