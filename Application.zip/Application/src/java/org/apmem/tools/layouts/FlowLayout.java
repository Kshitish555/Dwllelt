/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.util.AttributeSet
 *  android.view.Gravity
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewDebug
 *  android.view.ViewDebug$ExportedProperty
 *  android.view.ViewDebug$IntToString
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.List
 */
package org.apmem.tools.layouts;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.apmem.tools.layouts.LayoutConfiguration;
import org.apmem.tools.layouts.b;
import org.apmem.tools.layouts.c;

public class FlowLayout
extends ViewGroup {
    public static final int f = 0;
    public static final int h = 1;
    public static final int o = 0;
    public static final int s = 1;
    private final LayoutConfiguration c;
    List<b> d = new ArrayList();

    public FlowLayout(Context context) {
        super(context);
        this.c = new LayoutConfiguration(context, null);
    }

    public FlowLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.c = new LayoutConfiguration(context, attributeSet);
    }

    public FlowLayout(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.c = new LayoutConfiguration(context, attributeSet);
    }

    private int a(int n2, int n3, int n4) {
        if (n2 != Integer.MIN_VALUE) {
            if (n2 != 1073741824) {
                return n4;
            }
        } else {
            n3 = Math.min((int)n4, (int)n3);
        }
        return n3;
    }

    private int a(LayoutParams layoutParams) {
        int n2 = this.c.a();
        int n3 = layoutParams != null && layoutParams.k() ? layoutParams.a() : n2;
        int n4 = this.b(n3);
        int n5 = this.b(n2);
        if ((n4 & 7) == 0) {
            n4 |= n5 & 7;
        }
        if ((n4 & 112) == 0) {
            n4 |= n5 & 112;
        }
        if ((n4 & 7) == 0) {
            n4 |= 3;
        }
        if ((n4 & 112) == 0) {
            n4 |= 48;
        }
        return n4;
    }

    private Paint a(int n2) {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(n2);
        paint.setStrokeWidth(2.0f);
        return paint;
    }

    private void a(Canvas canvas, View view) {
        if (!this.a()) {
            return;
        }
        Paint paint = this.a(-256);
        Paint paint2 = this.a(-65536);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.rightMargin > 0) {
            float f2 = view.getRight();
            float f3 = (float)view.getTop() + (float)view.getHeight() / 2.0f;
            canvas.drawLine(f2, f3, f2 + (float)layoutParams.rightMargin, f3, paint);
            int n2 = layoutParams.rightMargin;
            canvas.drawLine(f2 + (float)n2 - 4.0f, f3 - 4.0f, f2 + (float)n2, f3, paint);
            int n3 = layoutParams.rightMargin;
            canvas.drawLine(f2 + (float)n3 - 4.0f, f3 + 4.0f, f2 + (float)n3, f3, paint);
        }
        if (layoutParams.leftMargin > 0) {
            float f4 = view.getLeft();
            float f5 = (float)view.getTop() + (float)view.getHeight() / 2.0f;
            canvas.drawLine(f4, f5, f4 - (float)layoutParams.leftMargin, f5, paint);
            int n4 = layoutParams.leftMargin;
            canvas.drawLine(4.0f + (f4 - (float)n4), f5 - 4.0f, f4 - (float)n4, f5, paint);
            int n5 = layoutParams.leftMargin;
            canvas.drawLine(4.0f + (f4 - (float)n5), f5 + 4.0f, f4 - (float)n5, f5, paint);
        }
        if (layoutParams.bottomMargin > 0) {
            float f6 = (float)view.getLeft() + (float)view.getWidth() / 2.0f;
            float f7 = view.getBottom();
            canvas.drawLine(f6, f7, f6, f7 + (float)layoutParams.bottomMargin, paint);
            float f8 = f6 - 4.0f;
            int n6 = layoutParams.bottomMargin;
            canvas.drawLine(f8, f7 + (float)n6 - 4.0f, f6, f7 + (float)n6, paint);
            float f9 = f6 + 4.0f;
            int n7 = layoutParams.bottomMargin;
            canvas.drawLine(f9, f7 + (float)n7 - 4.0f, f6, f7 + (float)n7, paint);
        }
        if (layoutParams.topMargin > 0) {
            float f10 = (float)view.getLeft() + (float)view.getWidth() / 2.0f;
            float f11 = view.getTop();
            canvas.drawLine(f10, f11, f10, f11 - (float)layoutParams.topMargin, paint);
            float f12 = f10 - 4.0f;
            int n8 = layoutParams.topMargin;
            canvas.drawLine(f12, 4.0f + (f11 - (float)n8), f10, f11 - (float)n8, paint);
            float f13 = f10 + 4.0f;
            int n9 = layoutParams.topMargin;
            canvas.drawLine(f13, 4.0f + (f11 - (float)n9), f10, f11 - (float)n9, paint);
        }
        if (layoutParams.l()) {
            if (this.c.c() == 0) {
                float f14 = view.getLeft();
                float f15 = (float)view.getTop() + (float)view.getHeight() / 2.0f;
                canvas.drawLine(f14, f15 - 6.0f, f14, f15 + 6.0f, paint2);
                return;
            }
            float f16 = (float)view.getLeft() + (float)view.getWidth() / 2.0f;
            float f17 = view.getTop();
            canvas.drawLine(f16 - 6.0f, f17, f16 + 6.0f, f17, paint2);
        }
    }

    private void a(List<b> list) {
        int n2 = list.size();
        int n3 = 0;
        for (int i2 = 0; i2 < n2; ++i2) {
            b b2 = (b)list.get(i2);
            b2.c(n3);
            n3 += b2.d();
            List<View> list2 = b2.e();
            int n4 = list2.size();
            int n5 = 0;
            for (int i3 = 0; i3 < n4; ++i3) {
                LayoutParams layoutParams = (LayoutParams)((View)list2.get(i3)).getLayoutParams();
                layoutParams.b(n5);
                n5 += layoutParams.d() + layoutParams.e();
            }
        }
    }

    private void a(List<b> list, int n2, int n3) {
        int n4 = list.size();
        if (n4 <= 0) {
            return;
        }
        b b2 = (b)list.get(n4 - 1);
        int n5 = n3 - (b2.d() + b2.c());
        if (n5 < 0) {
            n5 = 0;
        }
        int n6 = 0;
        for (int i2 = 0; i2 < n4; ++i2) {
            b b3 = (b)list.get(i2);
            int n7 = this.a((LayoutParams)null);
            int n8 = Math.round((float)(n5 * 1 / n4));
            int n9 = b3.a();
            int n10 = b3.d();
            Rect rect = new Rect();
            rect.top = n6;
            rect.left = 0;
            rect.right = n2;
            rect.bottom = n6 + (n10 + n8);
            Rect rect2 = new Rect();
            Gravity.apply((int)n7, (int)n9, (int)n10, (Rect)rect, (Rect)rect2);
            n6 += n8;
            b3.b(b3.b() + rect2.left);
            b3.c(b3.c() + rect2.top);
            b3.a(rect2.width());
            b3.d(rect2.height());
        }
    }

    private void a(b b2) {
        List<View> list = b2.e();
        int n2 = list.size();
        if (n2 <= 0) {
            return;
        }
        float f2 = 0.0f;
        for (int i2 = 0; i2 < n2; ++i2) {
            f2 += this.b((LayoutParams)((View)list.get(i2)).getLayoutParams());
        }
        LayoutParams layoutParams = (LayoutParams)((View)list.get(n2 - 1)).getLayoutParams();
        int n3 = b2.a() - (layoutParams.d() + layoutParams.e() + layoutParams.b());
        int n4 = 0;
        for (int i3 = 0; i3 < n2; ++i3) {
            LayoutParams layoutParams2 = (LayoutParams)((View)list.get(i3)).getLayoutParams();
            float f3 = this.b(layoutParams2);
            int n5 = this.a(layoutParams2);
            int n6 = f2 == 0.0f ? n3 / n2 : Math.round((float)(f3 * (float)n3 / f2));
            int n7 = layoutParams2.d() + layoutParams2.e();
            int n8 = layoutParams2.g() + layoutParams2.f();
            Rect rect = new Rect();
            rect.top = 0;
            rect.left = n4;
            rect.right = n4 + (n7 + n6);
            rect.bottom = b2.d();
            Rect rect2 = new Rect();
            Gravity.apply((int)n5, (int)n7, (int)n8, (Rect)rect, (Rect)rect2);
            n4 += n6;
            layoutParams2.b(rect2.left + layoutParams2.b());
            layoutParams2.c(rect2.top);
            layoutParams2.d(rect2.width() - layoutParams2.e());
            layoutParams2.e(rect2.height() - layoutParams2.f());
        }
    }

    private float b(LayoutParams layoutParams) {
        if (layoutParams.m()) {
            return layoutParams.h();
        }
        return this.c.d();
    }

    private int b(int n2) {
        if (this.c.c() == 1 && (n2 & 8388608) == 0) {
            n2 = 0 | (n2 & 7) >> 0 << 4 | (n2 & 112) >> 4 << 0;
        }
        if (this.c.b() == 1 && (n2 & 8388608) != 0) {
            int n3 = (n2 & 3) == 3 ? 5 : 0;
            int n4 = n3 | 0;
            int n5 = n2 & 5;
            int n6 = 0;
            if (n5 == 5) {
                n6 = 3;
            }
            n2 = n4 | n6;
        }
        return n2;
    }

    private void b(b b2) {
        List<View> list = b2.e();
        int n2 = list.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            View view = (View)list.get(i2);
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            if (this.c.c() == 0) {
                layoutParams.a(this.getPaddingLeft() + b2.b() + layoutParams.b(), this.getPaddingTop() + b2.c() + layoutParams.c());
                view.measure(View.MeasureSpec.makeMeasureSpec((int)layoutParams.d(), (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)layoutParams.g(), (int)1073741824));
                continue;
            }
            layoutParams.a(this.getPaddingLeft() + b2.c() + layoutParams.c(), this.getPaddingTop() + b2.b() + layoutParams.b());
            view.measure(View.MeasureSpec.makeMeasureSpec((int)layoutParams.g(), (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)layoutParams.d(), (int)1073741824));
        }
    }

    private boolean b() {
        boolean bl;
        bl = false;
        try {
            Method method = ViewGroup.class.getDeclaredMethod("debugDraw", null);
            method.setAccessible(true);
            bl = (Boolean)method.invoke((Object)this, new Object[]{null});
        }
        catch (Exception exception) {}
        return bl;
    }

    public boolean a() {
        return this.c.e() || this.b();
        {
        }
    }

    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    protected boolean drawChild(Canvas canvas, View view, long l2) {
        boolean bl = super.drawChild(canvas, view, l2);
        this.a(canvas, view);
        return bl;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(this.getContext(), attributeSet);
    }

    protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public int getGravity() {
        return this.c.a();
    }

    public int getLayoutDirection() {
        LayoutConfiguration layoutConfiguration = this.c;
        if (layoutConfiguration == null) {
            return 0;
        }
        return layoutConfiguration.b();
    }

    public int getOrientation() {
        return this.c.c();
    }

    public float getWeightDefault() {
        return this.c.d();
    }

    protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
        int n6 = this.getChildCount();
        for (int i2 = 0; i2 < n6; ++i2) {
            View view = this.getChildAt(i2);
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            view.layout(layoutParams.h + layoutParams.leftMargin, layoutParams.i + layoutParams.topMargin, layoutParams.h + layoutParams.leftMargin + view.getMeasuredWidth(), layoutParams.i + layoutParams.topMargin + view.getMeasuredHeight());
        }
    }

    protected void onMeasure(int n2, int n3) {
        int n4;
        int n5;
        int n6 = View.MeasureSpec.getSize((int)n2) - this.getPaddingRight() - this.getPaddingLeft();
        int n7 = View.MeasureSpec.getSize((int)n3) - this.getPaddingTop() - this.getPaddingBottom();
        int n8 = View.MeasureSpec.getMode((int)n2);
        int n9 = View.MeasureSpec.getMode((int)n3);
        int n10 = this.c.c() == 0 ? n6 : n7;
        if (this.c.c() == 0) {
            n6 = n7;
        }
        if (this.c.c() != 0) {
            n8 = n9;
        }
        this.c.c();
        this.d.clear();
        b b2 = new b(n10);
        this.d.add((Object)b2);
        int n11 = this.getChildCount();
        int n12 = 0;
        for (int i2 = 0; i2 < n11; ++i2) {
            View view = this.getChildAt(i2);
            if (view.getVisibility() == 8) continue;
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            view.measure(ViewGroup.getChildMeasureSpec((int)n2, (int)(this.getPaddingLeft() + this.getPaddingRight()), (int)layoutParams.width), ViewGroup.getChildMeasureSpec((int)n3, (int)(this.getPaddingTop() + this.getPaddingBottom()), (int)layoutParams.height));
            layoutParams.j = this.c.c();
            if (this.c.c() == 0) {
                layoutParams.d(view.getMeasuredWidth());
                layoutParams.e(view.getMeasuredHeight());
            } else {
                layoutParams.d(view.getMeasuredHeight());
                layoutParams.e(view.getMeasuredWidth());
            }
            boolean bl = layoutParams.l() || n8 != 0 && !b2.b(view);
            if (bl) {
                b2 = new b(n10);
                if (this.c.c() == 1 && this.c.b() == 1) {
                    this.d.add(0, (Object)b2);
                } else {
                    this.d.add((Object)b2);
                }
            }
            if (this.c.c() == 0 && this.c.b() == 1) {
                b2.a(0, view);
                continue;
            }
            b2.a(view);
        }
        this.a(this.d);
        int n13 = this.d.size();
        int n14 = 0;
        for (int i3 = 0; i3 < n13; ++i3) {
            n14 = Math.max((int)n14, (int)((b)this.d.get(i3)).a());
        }
        int n15 = b2.c() + b2.d();
        int n16 = this.a(n8, n10, n14);
        int n17 = this.a(n9, n6, n15);
        this.a(this.d, n16, n17);
        while (n12 < n13) {
            b b3 = (b)this.d.get(n12);
            this.a(b3);
            this.b(b3);
            ++n12;
        }
        int n18 = this.getPaddingLeft() + this.getPaddingRight();
        int n19 = this.getPaddingBottom() + this.getPaddingTop();
        if (this.c.c() == 0) {
            n5 = n18 + n14;
            n4 = n19 + n15;
        } else {
            n5 = n18 + n15;
            n4 = n19 + n14;
        }
        this.setMeasuredDimension(ViewGroup.resolveSize((int)n5, (int)n2), ViewGroup.resolveSize((int)n4, (int)n3));
    }

    public void setDebugDraw(boolean bl) {
        this.c.a(bl);
        this.invalidate();
    }

    public void setGravity(int n2) {
        this.c.a(n2);
        this.requestLayout();
    }

    public void setLayoutDirection(int n2) {
        this.c.b(n2);
        this.requestLayout();
    }

    public void setOrientation(int n2) {
        this.c.c(n2);
        this.requestLayout();
    }

    public void setWeightDefault(float f2) {
        this.c.a(f2);
        this.requestLayout();
    }

    public static class LayoutParams
    extends ViewGroup.MarginLayoutParams {
        @ViewDebug.ExportedProperty(mapping={@ViewDebug.IntToString(from=0, to="NONE"), @ViewDebug.IntToString(from=48, to="TOP"), @ViewDebug.IntToString(from=80, to="BOTTOM"), @ViewDebug.IntToString(from=3, to="LEFT"), @ViewDebug.IntToString(from=5, to="RIGHT"), @ViewDebug.IntToString(from=16, to="CENTER_VERTICAL"), @ViewDebug.IntToString(from=112, to="FILL_VERTICAL"), @ViewDebug.IntToString(from=1, to="CENTER_HORIZONTAL"), @ViewDebug.IntToString(from=7, to="FILL_HORIZONTAL"), @ViewDebug.IntToString(from=17, to="CENTER"), @ViewDebug.IntToString(from=119, to="FILL")})
        private boolean a = false;
        private int b = 0;
        private float c = -1.0f;
        private int d;
        private int e;
        private int f;
        private int g;
        private int h;
        private int i;
        private int j;

        public LayoutParams(int n2, int n3) {
            super(n2, n3);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.a(context, attributeSet);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        private void a(Context context, AttributeSet attributeSet) {
            TypedArray typedArray = context.obtainStyledAttributes(attributeSet, c.c.FlowLayout_LayoutParams);
            try {
                this.a = typedArray.getBoolean(c.c.FlowLayout_LayoutParams_layout_newLine, false);
                this.b = typedArray.getInt(c.c.FlowLayout_LayoutParams_android_layout_gravity, 0);
                this.c = typedArray.getFloat(c.c.FlowLayout_LayoutParams_layout_weight, -1.0f);
                return;
            }
            finally {
                typedArray.recycle();
            }
        }

        public int a() {
            return this.b;
        }

        public void a(float f2) {
            this.c = f2;
        }

        public void a(int n2) {
            this.b = n2;
        }

        void a(int n2, int n3) {
            this.h = n2;
            this.i = n3;
        }

        public void a(boolean bl) {
            this.a = bl;
        }

        int b() {
            return this.d;
        }

        void b(int n2) {
            this.d = n2;
        }

        int c() {
            return this.g;
        }

        void c(int n2) {
            this.g = n2;
        }

        int d() {
            return this.e;
        }

        void d(int n2) {
            this.e = n2;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        int e() {
            int n2;
            int n3;
            if (this.j == 0) {
                n2 = this.leftMargin;
                n3 = this.rightMargin;
                do {
                    return n2 + n3;
                    break;
                } while (true);
            }
            n2 = this.topMargin;
            n3 = this.bottomMargin;
            return n2 + n3;
        }

        void e(int n2) {
            this.f = n2;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        int f() {
            int n2;
            int n3;
            if (this.j == 0) {
                n2 = this.topMargin;
                n3 = this.bottomMargin;
                do {
                    return n2 + n3;
                    break;
                } while (true);
            }
            n2 = this.leftMargin;
            n3 = this.rightMargin;
            return n2 + n3;
        }

        int g() {
            return this.f;
        }

        public float h() {
            return this.c;
        }

        public int i() {
            return this.h;
        }

        public int j() {
            return this.i;
        }

        public boolean k() {
            return this.b != 0;
        }

        public boolean l() {
            return this.a;
        }

        public boolean m() {
            return this.c >= 0.0f;
        }
    }

}

