/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.text.TextUtils
 *  java.io.BufferedReader
 *  java.io.FileReader
 *  java.io.IOException
 *  java.io.Reader
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Locale
 */
package com.adjust.sdk;

import android.content.Context;
import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Locale;

public class MacAddressUtil {
    public static String getMacAddress(Context context) {
        String string = MacAddressUtil.getRawMacAddress(context);
        if (string == null) {
            return null;
        }
        return MacAddressUtil.removeSpaceString(string.toUpperCase(Locale.US));
    }

    /*
     * Exception decompiling
     */
    private static String getRawMacAddress(Context var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl26.1 : ACONST_NULL : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static String loadAddress(String string) {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("/sys/class/net/");
            stringBuilder.append(string);
            stringBuilder.append("/address");
            String string2 = stringBuilder.toString();
            StringBuilder stringBuilder2 = new StringBuilder(1000);
            BufferedReader bufferedReader = new BufferedReader((Reader)new FileReader(string2), 1024);
            char[] arrc = new char[1024];
            do {
                int n2;
                if ((n2 = bufferedReader.read(arrc)) == -1) {
                    bufferedReader.close();
                    return stringBuilder2.toString();
                }
                stringBuilder2.append(String.valueOf((char[])arrc, (int)0, (int)n2));
            } while (true);
        }
        catch (IOException iOException) {
            return null;
        }
    }

    private static String removeSpaceString(String string) {
        if (string == null) {
            return null;
        }
        String string2 = string.replaceAll("\\s", "");
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return null;
        }
        return string2;
    }
}

