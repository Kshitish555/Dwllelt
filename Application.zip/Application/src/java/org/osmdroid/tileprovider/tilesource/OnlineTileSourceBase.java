/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.util.Random
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.tileprovider.MapTile
 */
package org.osmdroid.tileprovider.tilesource;

import java.util.Random;
import org.osmdroid.ResourceProxy;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase;

public abstract class OnlineTileSourceBase
extends BitmapTileSourceBase {
    private final String[] mBaseUrls;

    public /* varargs */ OnlineTileSourceBase(String string2, ResourceProxy.string string3, int n2, int n3, int n4, String string4, String ... arrstring) {
        super(string2, string3, n2, n3, n4, string4);
        this.mBaseUrls = arrstring;
    }

    protected String getBaseUrl() {
        String[] arrstring = this.mBaseUrls;
        return arrstring[this.random.nextInt(arrstring.length)];
    }

    public abstract String getTileURLString(MapTile var1);
}

