/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Environment
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.tileprovider.IRegisterReceiver
 *  org.osmdroid.tileprovider.modules.MapTileFileStorageProviderBase$1
 *  org.osmdroid.tileprovider.modules.MapTileFileStorageProviderBase$MyBroadcastReceiver
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Environment;
import org.osmdroid.tileprovider.IRegisterReceiver;
import org.osmdroid.tileprovider.modules.MapTileFileStorageProviderBase;
import org.osmdroid.tileprovider.modules.MapTileModuleProviderBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Exception performing whole class analysis.
 */
public abstract class MapTileFileStorageProviderBase
extends MapTileModuleProviderBase {
    private static final Logger logger;
    private MyBroadcastReceiver mBroadcastReceiver;
    private final IRegisterReceiver mRegisterReceiver;
    private boolean mSdCardAvailable;

    static {
        logger = LoggerFactory.getLogger(MapTileFileStorageProviderBase.class);
    }

    public MapTileFileStorageProviderBase(IRegisterReceiver iRegisterReceiver, int n2, int n3) {
        super(n2, n3);
        this.mSdCardAvailable = true;
        this.checkSdCard();
        this.mRegisterReceiver = iRegisterReceiver;
        this.mBroadcastReceiver = new /* Unavailable Anonymous Inner Class!! */;
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.MEDIA_MOUNTED");
        intentFilter.addAction("android.intent.action.MEDIA_UNMOUNTED");
        intentFilter.addDataScheme("file");
        iRegisterReceiver.registerReceiver((BroadcastReceiver)this.mBroadcastReceiver, intentFilter);
    }

    static /* synthetic */ void access$100(MapTileFileStorageProviderBase mapTileFileStorageProviderBase) {
        mapTileFileStorageProviderBase.checkSdCard();
    }

    private void checkSdCard() {
        String string2 = Environment.getExternalStorageState();
        Logger logger = MapTileFileStorageProviderBase.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("sdcard state: ");
        stringBuilder.append(string2);
        logger.info(stringBuilder.toString());
        this.mSdCardAvailable = "mounted".equals((Object)string2);
    }

    @Override
    public void detach() {
        MyBroadcastReceiver myBroadcastReceiver = this.mBroadcastReceiver;
        if (myBroadcastReceiver != null) {
            this.mRegisterReceiver.unregisterReceiver((BroadcastReceiver)myBroadcastReceiver);
            this.mBroadcastReceiver = null;
        }
        super.detach();
    }

    protected boolean getSdCardAvailable() {
        return this.mSdCardAvailable;
    }

    protected void onMediaMounted() {
    }

    protected void onMediaUnmounted() {
    }
}

