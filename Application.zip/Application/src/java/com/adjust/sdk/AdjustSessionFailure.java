/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import com.adjust.sdk.Util;
import org.json.JSONObject;

public class AdjustSessionFailure {
    public String adid;
    public JSONObject jsonResponse;
    public String message;
    public String timestamp;
    public boolean willRetry;

    public String toString() {
        Object[] arrobject = new Object[]{this.message, this.timestamp, this.adid, this.willRetry, this.jsonResponse};
        return Util.formatString("Session Failure msg:%s time:%s adid:%s retry:%b json:%s", arrobject);
    }
}

