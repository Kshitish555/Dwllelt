/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.j.q.e
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 *  l.a.j.q.i.c.a
 *  l.a.j.q.i.c.d
 */
package l.a.j.q.i.c;

import l.a.h.k.c;
import l.a.j.q.e;
import l.a.j.q.i.a;
import l.a.j.q.i.c.a;
import l.a.j.q.i.c.c;
import l.a.j.q.i.c.d;

public class b
implements l.a.j.q.i.a {
    private final l.a.j.q.i.a c;

    public b(l.a.j.q.i.a a2) {
        this.c = a2;
    }

    public e a(c.f f2, c.f f3, a.d d2) {
        if (f2.isPrimitive() && f3.isPrimitive()) {
            return d.b((l.a.h.k.b)f2).a((l.a.h.k.b)f3);
        }
        if (f2.isPrimitive()) {
            return a.a((l.a.h.k.b)f2).a(f3, this.c, d2);
        }
        if (f3.isPrimitive()) {
            return c.a((l.a.h.k.b)f2).a(f3, this.c, d2);
        }
        return this.c.a(f2, f3, d2);
    }

    protected boolean a(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (!b2.a(this)) {
            return false;
        }
        l.a.j.q.i.a a2 = this.c;
        l.a.j.q.i.a a3 = b2.c;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public int hashCode() {
        l.a.j.q.i.a a2 = this.c;
        int n2 = a2 == null ? 43 : a2.hashCode();
        return 59 + n2;
    }
}

