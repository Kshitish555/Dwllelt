/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public final class h
extends Enum<h>
implements e {
    public static final /* enum */ h d;
    public static final /* enum */ h f;
    private static final e.c h;
    private static final /* synthetic */ h[] o;
    private final int c;

    static {
        h h2;
        d = new h(9);
        f = h2 = new h(10);
        h[] arrh = new h[]{d, h2};
        o = arrh;
        h = f.h.f();
    }

    private h(int n3) {
        this.c = n3;
    }

    public static e a(long l2) {
        if (l2 == 0L) {
            return d;
        }
        if (l2 == 1L) {
            return f;
        }
        return new a(l2);
    }

    public static h valueOf(String string) {
        return (h)Enum.valueOf(h.class, (String)string);
    }

    public static h[] values() {
        return (h[])o.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.c);
        return h;
    }

    public boolean x() {
        return true;
    }

    protected static class a
    implements e {
        private final long c;

        protected a(long l2) {
            this.c = l2;
        }

        public e.c a(r r2, e.d d2) {
            r2.a((Object)this.c);
            return h;
        }

        protected boolean b(Object object) {
            return object instanceof a;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof a)) {
                return false;
            }
            a a2 = (a)object;
            if (!a2.b(this)) {
                return false;
            }
            return this.c == a2.c;
        }

        public int hashCode() {
            long l2 = this.c;
            return 59 + (int)(l2 ^ l2 >>> 32);
        }

        public boolean x() {
            return true;
        }
    }

}

