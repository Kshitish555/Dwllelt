/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Point
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$bitmap
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IProjection
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IProjection;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

public class SimpleLocationOverlay
extends Overlay {
    protected final Point PERSON_HOTSPOT = new Point(24, 39);
    protected final Bitmap PERSON_ICON = this.mResourceProxy.getBitmap(ResourceProxy.bitmap.person);
    protected GeoPoint mLocation;
    protected final Paint mPaint = new Paint();
    private final Point screenCoords = new Point();

    public SimpleLocationOverlay(Context context) {
        this(context, new DefaultResourceProxyImpl(context));
    }

    public SimpleLocationOverlay(Context context, ResourceProxy resourceProxy) {
        super(resourceProxy);
    }

    @Override
    public void draw(Canvas canvas, MapView mapView, boolean bl) {
        if (!bl && this.mLocation != null) {
            mapView.getProjection().toMapPixels(this.mLocation, this.screenCoords);
            Bitmap bitmap2 = this.PERSON_ICON;
            Point point = this.screenCoords;
            int n2 = point.x;
            Point point2 = this.PERSON_HOTSPOT;
            canvas.drawBitmap(bitmap2, (float)(n2 - point2.x), (float)(point.y - point2.y), this.mPaint);
        }
    }

    public GeoPoint getMyLocation() {
        return this.mLocation;
    }

    public void setLocation(GeoPoint geoPoint) {
        this.mLocation = geoPoint;
    }
}

