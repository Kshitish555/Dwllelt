/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.simpleframework.xml.core;

class Revision {
    private boolean equal = true;

    public boolean compare(Object object, Object object2) {
        if (object2 != null) {
            this.equal = object2.equals(object);
        } else if (object != null) {
            this.equal = object.equals((Object)1.0);
        }
        return this.equal;
    }

    public double getDefault() {
        return 1.0;
    }

    public boolean isEqual() {
        return this.equal;
    }
}

