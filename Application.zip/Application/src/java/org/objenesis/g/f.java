/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  org.objenesis.f.a
 *  org.objenesis.f.c.a
 *  org.objenesis.f.c.b
 *  org.objenesis.f.c.c
 *  org.objenesis.f.e.a
 *  org.objenesis.f.e.g
 *  org.objenesis.f.f.a
 *  org.objenesis.f.g.a
 *  org.objenesis.f.h.c
 *  org.objenesis.f.h.e
 *  org.objenesis.g.a
 *  org.objenesis.g.c
 */
package org.objenesis.g;

import java.io.Serializable;
import org.objenesis.f.c.b;
import org.objenesis.f.e.g;
import org.objenesis.f.h.e;
import org.objenesis.g.a;
import org.objenesis.g.c;

public class f
extends a {
    public <T> org.objenesis.f.a<T> a(Class<T> class_) {
        if (!c.a((String)"Java HotSpot") && !c.a((String)"OpenJDK")) {
            if (c.a((String)"Dalvik")) {
                if (c.f()) {
                    return new e(class_);
                }
                int n2 = c.n;
                if (n2 <= 10) {
                    return new org.objenesis.f.c.a(class_);
                }
                if (n2 <= 17) {
                    return new b(class_);
                }
                return new org.objenesis.f.c.c(class_);
            }
            if (c.a((String)"BEA")) {
                return new org.objenesis.f.h.c(class_);
            }
            if (c.a((String)"GNU libgcj")) {
                return new org.objenesis.f.f.a(class_);
            }
            if (c.a((String)"PERC")) {
                return new org.objenesis.f.g.a(class_);
            }
            return new e(class_);
        }
        if (c.g()) {
            if (Serializable.class.isAssignableFrom(class_)) {
                return new g(class_);
            }
            return new org.objenesis.f.e.a(class_);
        }
        return new org.objenesis.f.h.c(class_);
    }
}

