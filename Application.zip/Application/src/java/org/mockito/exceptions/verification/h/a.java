/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.Throwable
 *  junit.framework.ComparisonFailure
 */
package org.mockito.exceptions.verification.h;

import junit.framework.ComparisonFailure;
import o.e.y.s.l;

public class a
extends ComparisonFailure {
    private static final long f = 1L;
    private final String c;
    private final StackTraceElement[] d;

    public a(String string2, String string3, String string4) {
        super(string2, string3, string4);
        this.c = string2;
        this.d = this.getStackTrace();
        new org.mockito.internal.exceptions.d.a().a((Throwable)this);
    }

    public StackTraceElement[] a() {
        return this.d;
    }

    public String getMessage() {
        return this.c;
    }

    public String toString() {
        return l.c(super.toString());
    }
}

