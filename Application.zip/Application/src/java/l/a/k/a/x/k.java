/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  l.a.k.a.a
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.t
 *  l.a.k.a.u
 *  l.a.k.a.v
 */
package l.a.k.a.x;

import l.a.k.a.a;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.t;
import l.a.k.a.u;
import l.a.k.a.v;

public class k
extends r {
    private static final u t;
    static /* synthetic */ Class w;
    private int[] f = new int[40];
    private Object[] h = new Object[20];
    protected final int o;
    protected int s;

    static {
        k.e();
        t = u.d((String)"java/lang/Object");
    }

    protected k(int n2, int n3, String string, r r2) {
        super(n2, r2);
        u[] arru = u.a((String)string);
        int n4 = n3 & 8;
        int n5 = n4 == 0 ? 1 : 0;
        this.s = n5;
        for (int i2 = 0; i2 < arru.length; ++i2) {
            this.s += arru[i2].i();
        }
        this.o = this.s;
    }

    public k(int n2, String string, r r2) {
        this(327680, n2, string, r2);
        if (this.getClass() == w) {
            return;
        }
        throw new IllegalStateException();
    }

    static /* synthetic */ Class a(String string) {
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new NoClassDefFoundError(classNotFoundException.getMessage());
        }
    }

    private void a(int n2, Object object) {
        int n3 = this.h.length;
        if (n2 >= n3) {
            Object[] arrobject = new Object[Math.max((int)(n3 * 2), (int)(n2 + 1))];
            System.arraycopy((Object)this.h, (int)0, (Object)arrobject, (int)0, (int)n3);
            this.h = arrobject;
        }
        this.h[n2] = object;
    }

    private int b(int n2, u u2) {
        int n3;
        int n4;
        if (n2 + u2.i() <= this.o) {
            return n2;
        }
        int n5 = -1 + (n2 * 2 + u2.i());
        if (n5 >= (n3 = this.f.length)) {
            int[] arrn = new int[Math.max((int)(n3 * 2), (int)(n5 + 1))];
            System.arraycopy((Object)this.f, (int)0, (Object)arrn, (int)0, (int)n3);
            this.f = arrn;
        }
        if ((n4 = this.f[n5]) == 0) {
            int n6 = this.b(u2);
            this.a(n6, u2);
            this.f[n5] = n6 + 1;
            return n6;
        }
        return n4 - 1;
    }

    private static void e() {
        w = k.a("net.bytebuddy.jar.asm.commons.LocalVariablesSorter");
    }

    public int a(u u2) {
        Object object;
        switch (u2.j()) {
            default: {
                object = u2.g();
                break;
            }
            case 9: {
                object = u2.d();
                break;
            }
            case 8: {
                object = t.C1;
                break;
            }
            case 7: {
                object = t.D1;
                break;
            }
            case 6: {
                object = t.B1;
                break;
            }
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: {
                object = t.A1;
            }
        }
        int n2 = this.b(u2);
        this.a(n2, u2);
        this.a(n2, object);
        return n2;
    }

    public a a(int n2, v v2, q[] arrq, q[] arrq2, int[] arrn, String string, boolean bl) {
        u u2 = u.f((String)string);
        int n3 = arrn.length;
        int[] arrn2 = new int[n3];
        for (int i2 = 0; i2 < n3; ++i2) {
            arrn2[i2] = this.b(arrn[i2], u2);
        }
        return this.d.a(n2, v2, arrq, arrq2, arrn2, string, bl);
    }

    public void a(int n2, int n3) {
        this.d.a(this.b(n2, u.v), n3);
    }

    public void a(int n2, int n3, Object[] arrobject, int n4, Object[] arrobject2) {
        IllegalStateException illegalStateException;
        if (n2 == -1) {
            Object[] arrobject3;
            Object[] arrobject4 = this.h;
            int n5 = arrobject4.length;
            Object[] arrobject5 = new Object[n5];
            int n6 = 0;
            System.arraycopy((Object)arrobject4, (int)0, (Object)arrobject5, (int)0, (int)n5);
            this.a(this.h);
            int n7 = 0;
            for (int i2 = 0; i2 < n3; ++i2) {
                Object object = arrobject[i2];
                int n8 = object != t.D1 && object != t.C1 ? 1 : 2;
                if (object != t.z1) {
                    u u2 = t;
                    if (object == t.A1) {
                        u2 = u.v;
                    } else if (object == t.B1) {
                        u2 = u.w;
                    } else if (object == t.D1) {
                        u2 = u.x;
                    } else if (object == t.C1) {
                        u2 = u.y;
                    } else if (object instanceof String) {
                        u2 = u.d((String)((String)object));
                    }
                    this.a(this.b(n7, u2), object);
                }
                n7 += n8;
            }
            int n9 = 0;
            int n10 = 0;
            while (n6 < (arrobject3 = this.h).length) {
                int n11 = n6 + 1;
                Object object = arrobject3[n6];
                if (object != null && object != t.z1) {
                    arrobject3[n9] = object;
                    int n12 = n9 + 1;
                    if (object == t.D1 || object == t.C1) {
                        // empty if block
                    }
                    n6 = ++n11;
                    n10 = n12;
                } else {
                    this.h[n9] = t.z1;
                    n6 = n11;
                }
                ++n9;
            }
            this.d.a(n2, n10, arrobject3, n4, arrobject2);
            this.h = arrobject5;
            return;
        }
        illegalStateException = new IllegalStateException("ClassReader.accept() should be called with EXPAND_FRAMES flag");
        throw illegalStateException;
    }

    protected void a(int n2, u u2) {
    }

    public void a(String string, String string2, String string3, q q2, q q3, int n2) {
        int n3 = this.b(n2, u.f((String)string2));
        this.d.a(string, string2, string3, q2, q3, n3);
    }

    protected void a(Object[] arrobject) {
    }

    protected int b(u u2) {
        int n2 = this.s;
        this.s = n2 + u2.i();
        return n2;
    }

    public void c(int n2, int n3) {
        this.d.c(n2, this.s);
    }

    /*
     * Exception decompiling
     */
    public void d(int var1_1, int var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:478)
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:328)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:462)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }
}

