/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.PersistenceException
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import org.simpleframework.xml.core.CollectionFactory;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Repeater;
import org.simpleframework.xml.core.Traverser;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;

class CompositeInlineList
implements Repeater {
    private final Type entry;
    private final CollectionFactory factory;
    private final String name;
    private final Traverser root;
    private final Type type;

    public CompositeInlineList(Context context, Type type, Type type2, String string2) {
        this.factory = new CollectionFactory(context, type);
        this.root = new Traverser(context);
        this.entry = type2;
        this.type = type;
        this.name = string2;
    }

    private Object read(InputNode inputNode, Class class_) throws Exception {
        Object object = this.root.read(inputNode, class_);
        Class class_2 = object.getClass();
        if (this.entry.getType().isAssignableFrom(class_2)) {
            return object;
        }
        Object[] arrobject = new Object[]{class_2, this.entry, this.type};
        throw new PersistenceException("Entry %s does not match %s for %s", arrobject);
    }

    private Object read(InputNode inputNode, Collection collection) throws Exception {
        InputNode inputNode2 = inputNode.getParent();
        String string2 = inputNode.getName();
        while (inputNode != null) {
            Object object = this.read(inputNode, this.entry.getType());
            if (object != null) {
                collection.add(object);
            }
            inputNode = inputNode2.getNext(string2);
        }
        return collection;
    }

    public Object read(InputNode inputNode) throws Exception {
        Collection collection = (Collection)this.factory.getInstance();
        if (collection != null) {
            return this.read(inputNode, collection);
        }
        return null;
    }

    @Override
    public Object read(InputNode inputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        if (collection != null) {
            return this.read(inputNode, collection);
        }
        return this.read(inputNode);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        InputNode inputNode2 = inputNode.getParent();
        Class class_ = this.entry.getType();
        String string2 = inputNode.getName();
        while (inputNode != null) {
            if (!this.root.validate(inputNode, class_)) {
                return false;
            }
            inputNode = inputNode2.getNext(string2);
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        OutputNode outputNode2 = outputNode.getParent();
        if (!outputNode.isCommitted()) {
            outputNode.remove();
        }
        this.write(outputNode2, collection);
    }

    public void write(OutputNode outputNode, Collection collection) throws Exception {
        for (Object object : collection) {
            Class class_;
            if (object == null) continue;
            Class class_2 = this.entry.getType();
            if (class_2.isAssignableFrom(class_ = object.getClass())) {
                this.root.write(outputNode, object, class_2, this.name);
                continue;
            }
            Object[] arrobject = new Object[]{class_, class_2, this.type};
            throw new PersistenceException("Entry %s does not match %s for %s", arrobject);
        }
    }
}

