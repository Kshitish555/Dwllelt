/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 */
package org.osmdroid.tileprovider.tilesource;

import android.graphics.drawable.Drawable;
import java.io.InputStream;
import org.osmdroid.ResourceProxy;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase;

public interface ITileSource {
    public Drawable getDrawable(InputStream var1) throws BitmapTileSourceBase.LowMemoryException;

    public Drawable getDrawable(String var1) throws BitmapTileSourceBase.LowMemoryException;

    public int getMaximumZoomLevel();

    public int getMinimumZoomLevel();

    public String getTileRelativeFilenameString(MapTile var1);

    public int getTileSizePixels();

    public String localizedName(ResourceProxy var1);

    public String name();

    public int ordinal();
}

