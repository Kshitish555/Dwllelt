/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  l.a.h.k.b
 *  l.a.j.q.c$a
 *  l.a.j.q.c$b
 *  l.a.j.q.c$c
 *  l.a.j.q.c$d
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q;

import l.a.j.e;
import l.a.j.q.c;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public abstract class c
extends Enum<c>
implements l.a.j.q.e {
    public static final /* enum */ c f = new a("ZERO", 0, f.d, 0);
    public static final /* enum */ c h = new b("SINGLE", 1, f.f, 89);
    public static final /* enum */ c o;
    private static final /* synthetic */ c[] s;
    protected final e.c c;
    private final int d;

    static {
        c c2 = new c("DOUBLE", 2, f.h, 92);
        o = c2;
        c[] arrc = new c[]{f, h, c2};
        s = arrc;
    }

    private c(f f2, int n3) {
        this.c = f2.f();
        this.d = n3;
    }

    public static c b(l.a.h.k.b b2) {
        int n2 = d.a[b2.l().ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 == 3) {
                    return f;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected type: ");
                stringBuilder.append((Object)b2);
                throw new AssertionError((Object)stringBuilder.toString());
            }
            return o;
        }
        return h;
    }

    public static c valueOf(String string) {
        return (c)Enum.valueOf(c.class, (String)string);
    }

    public static c[] values() {
        return (c[])s.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.d);
        return this.c;
    }

    public abstract l.a.j.q.e a(l.a.h.k.b var1);

    public boolean x() {
        return true;
    }

    protected static final class e
    extends Enum<e>
    implements l.a.j.q.e {
        public static final /* enum */ e f;
        public static final /* enum */ e h;
        public static final /* enum */ e o;
        public static final /* enum */ e s;
        private static final /* synthetic */ e[] t;
        private final int c;
        private final f d;

        static {
            e e2;
            f = new e(90, f.f);
            h = new e(91, f.f);
            o = new e(93, f.h);
            s = e2 = new e(94, f.h);
            e[] arre = new e[]{f, h, o, e2};
            t = arre;
        }

        private e(int n3, f f2) {
            this.c = n3;
            this.d = f2;
        }

        public static e valueOf(String string) {
            return (e)Enum.valueOf(e.class, (String)string);
        }

        public static e[] values() {
            return (e[])t.clone();
        }

        public e.c a(r r2, e.d d2) {
            r2.a(this.c);
            return this.d.f();
        }

        public boolean x() {
            return true;
        }
    }

}

