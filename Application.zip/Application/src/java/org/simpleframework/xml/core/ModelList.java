/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package org.simpleframework.xml.core;

import java.util.ArrayList;
import java.util.Iterator;
import org.simpleframework.xml.core.Model;

class ModelList
extends ArrayList<Model> {
    public ModelList build() {
        ModelList modelList = new ModelList();
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            modelList.register((Model)iterator.next());
        }
        return modelList;
    }

    public boolean isEmpty() {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            Model model = (Model)iterator.next();
            if (model == null || model.isEmpty()) continue;
            return false;
        }
        return true;
    }

    public Model lookup(int n2) {
        if (n2 <= this.size()) {
            return (Model)this.get(n2 - 1);
        }
        return null;
    }

    public void register(Model model) {
        int n2 = model.getIndex();
        int n3 = this.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            int n4;
            if (i2 >= n3) {
                this.add(null);
            }
            if (i2 != (n4 = n2 - 1)) continue;
            this.set(n4, (Object)model);
        }
    }

    public Model take() {
        while (!this.isEmpty()) {
            Model model = (Model)this.remove(0);
            if (model.isEmpty()) continue;
            return model;
        }
        return null;
    }
}

