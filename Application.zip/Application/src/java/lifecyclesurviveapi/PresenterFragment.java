/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  androidx.annotation.i0
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  java.lang.Object
 *  lifecyclesurviveapi.PresenterFragment$a
 *  lifecyclesurviveapi.h
 *  lifecyclesurviveapi.i
 *  lifecyclesurviveapi.j
 *  lifecyclesurviveapi.k
 *  lifecyclesurviveapi.l
 *  lifecyclesurviveapi.m
 *  lifecyclesurviveapi.p
 */
package lifecyclesurviveapi;

import android.os.Bundle;
import androidx.annotation.i0;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import lifecyclesurviveapi.PresenterFragment;
import lifecyclesurviveapi.h;
import lifecyclesurviveapi.i;
import lifecyclesurviveapi.j;
import lifecyclesurviveapi.k;
import lifecyclesurviveapi.l;
import lifecyclesurviveapi.m;
import lifecyclesurviveapi.p;

public abstract class PresenterFragment<C extends l<P>, P extends m>
extends Fragment
implements h {
    private j<C> c = new j();
    private p<P> d = new p();
    private i f = new i();
    private k<C> h = new a(this);

    public long C0() {
        return this.f.a();
    }

    public void a(long l2, Object object) {
        this.f.a(l2, object);
    }

    public final <C> C d(long l2) {
        return (C)this.f.a(l2);
    }

    public C getComponent() {
        return (C)((l)this.c.a());
    }

    public P getPresenter() {
        return (P)this.d.a();
    }

    public void onCreate(@i0 Bundle bundle) {
        super.onCreate(bundle);
        i i2 = this.f;
        i2.a(bundle, i2.b());
        this.c.a((h)this, bundle, this.h);
        this.d.a(this.getComponent().q0(), bundle);
        this.setRetainInstance(true);
    }

    protected abstract C onCreateNonConfigurationComponent();

    public void onDestroyView() {
        super.onDestroyView();
        this.d.a(this.getActivity().isFinishing());
        this.c.b();
    }

    public void onResume() {
        super.onResume();
        this.c.c();
        this.d.c();
        this.d.a((Object)((Object)this));
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.c.a(bundle);
        this.d.a(bundle);
    }

    public void onStop() {
        super.onStop();
        this.d.b();
    }
}

