/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.util.DisplayMetrics
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  java.lang.Class
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicInteger
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.views.util.constants.OverlayConstants
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import java.util.concurrent.atomic.AtomicInteger;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.views.MapView;
import org.osmdroid.views.util.constants.OverlayConstants;

public abstract class Overlay
implements OverlayConstants {
    protected static final float SHADOW_X_SKEW = -0.9f;
    protected static final float SHADOW_Y_SCALE = 0.5f;
    private static final Rect mRect;
    private static AtomicInteger sOrdinal;
    private boolean mEnabled = true;
    protected final ResourceProxy mResourceProxy;
    protected final float mScale;

    static {
        sOrdinal = new AtomicInteger();
        mRect = new Rect();
    }

    public Overlay(Context context) {
        this.mResourceProxy = new DefaultResourceProxyImpl(context);
        this.mScale = context.getResources().getDisplayMetrics().density;
    }

    public Overlay(ResourceProxy resourceProxy) {
        this.mResourceProxy = resourceProxy;
        this.mScale = resourceProxy.getDisplayMetricsDensity();
    }

    protected static void drawAt(Canvas canvas, Drawable drawable, int n, int n2, boolean bl) {
        Class<Overlay> class_ = Overlay.class;
        synchronized (Overlay.class) {
            drawable.copyBounds(mRect);
            drawable.setBounds(n + Overlay.mRect.left, n2 + Overlay.mRect.top, n + Overlay.mRect.right, n2 + Overlay.mRect.bottom);
            drawable.draw(canvas);
            drawable.setBounds(mRect);
            // ** MonitorExit[var6_5] (shouldn't be in output)
            return;
        }
    }

    protected static final int getSafeMenuId() {
        return sOrdinal.getAndIncrement();
    }

    protected static final int getSafeMenuIdSequence(int n) {
        return sOrdinal.getAndAdd(n);
    }

    protected abstract void draw(Canvas var1, MapView var2, boolean var3);

    public boolean isEnabled() {
        return this.mEnabled;
    }

    public void onDetach(MapView mapView) {
    }

    public boolean onDoubleTap(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public boolean onDoubleTapEvent(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public boolean onDown(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2, MapView mapView) {
        return false;
    }

    public boolean onKeyDown(int n, KeyEvent keyEvent, MapView mapView) {
        return false;
    }

    public boolean onKeyUp(int n, KeyEvent keyEvent, MapView mapView) {
        return false;
    }

    public boolean onLongPress(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2, MapView mapView) {
        return false;
    }

    public void onShowPress(MotionEvent motionEvent, MapView mapView) {
    }

    public boolean onSingleTapConfirmed(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public boolean onSingleTapUp(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public boolean onTouchEvent(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public boolean onTrackballEvent(MotionEvent motionEvent, MapView mapView) {
        return false;
    }

    public void setEnabled(boolean bl) {
        this.mEnabled = bl;
    }
}

