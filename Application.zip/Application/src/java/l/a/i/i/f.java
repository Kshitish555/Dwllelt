/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  l.a.i.i.h
 *  l.a.i.i.h$c
 *  l.a.i.i.h$c$a
 *  l.a.j.q.b
 */
package l.a.i.i;

import l.a.i.i.h;
import l.a.j.q.b;

public interface f
extends b {
    public h.c.a a(h.c.a var1);

    public f b(b var1);

    public boolean c();
}

