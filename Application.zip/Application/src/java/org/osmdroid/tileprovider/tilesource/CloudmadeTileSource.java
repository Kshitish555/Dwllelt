/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase
 *  org.osmdroid.tileprovider.tilesource.IStyledTileSource
 *  org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
 *  org.osmdroid.tileprovider.util.CloudmadeUtil
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.tilesource;

import org.osmdroid.ResourceProxy;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase;
import org.osmdroid.tileprovider.tilesource.IStyledTileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.util.CloudmadeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CloudmadeTileSource
extends OnlineTileSourceBase
implements IStyledTileSource<Integer> {
    private static final Logger logger = LoggerFactory.getLogger(CloudmadeTileSource.class);
    private Integer mStyle = 1;

    public /* varargs */ CloudmadeTileSource(String string2, ResourceProxy.string string3, int n2, int n3, int n4, String string4, String ... arrstring) {
        super(string2, string3, n2, n3, n4, string4, arrstring);
    }

    public Integer getStyle() {
        return this.mStyle;
    }

    public String getTileURLString(MapTile mapTile) {
        String string2 = CloudmadeUtil.getCloudmadeKey();
        if (string2.length() == 0) {
            logger.error("CloudMade key is not set. You should enter it in the manifest and call CloudmadeUtil.retrieveCloudmadeKey()");
        }
        String string3 = CloudmadeUtil.getCloudmadeToken();
        String string4 = this.getBaseUrl();
        Object[] arrobject = new Object[]{string2, this.mStyle, this.getTileSizePixels(), mapTile.getZoomLevel(), mapTile.getX(), mapTile.getY(), ((BitmapTileSourceBase)this).mImageFilenameEnding, string3};
        return String.format((String)string4, (Object[])arrobject);
    }

    public String pathBase() {
        Integer n2 = this.mStyle;
        if (n2 != null && n2 > 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(((BitmapTileSourceBase)this).mName);
            stringBuilder.append((Object)this.mStyle);
            return stringBuilder.toString();
        }
        return ((BitmapTileSourceBase)this).mName;
    }

    public void setStyle(Integer n2) {
        this.mStyle = n2;
    }

    public void setStyle(String string2) {
        try {
            this.mStyle = Integer.parseInt((String)string2);
            return;
        }
        catch (NumberFormatException numberFormatException) {
            Logger logger = CloudmadeTileSource.logger;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error setting integer style: ");
            stringBuilder.append(string2);
            logger.warn(stringBuilder.toString());
            return;
        }
    }
}

