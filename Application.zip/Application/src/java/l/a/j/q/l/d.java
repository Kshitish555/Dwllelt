/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.lang.reflect.Type
 *  l.a.h.k.b
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.l;

import java.lang.reflect.Type;
import l.a.h.k.b;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public final class d
extends Enum<d>
implements e {
    private static final /* synthetic */ d[] P4;
    public static final /* enum */ d f;
    public static final /* enum */ d h;
    public static final /* enum */ d o;
    public static final /* enum */ d s;
    public static final /* enum */ d t;
    public static final /* enum */ d w;
    private final int c;
    private final e.c d;

    static {
        d d2;
        f = new d(172, f.f);
        h = new d(175, f.h);
        o = new d(174, f.f);
        s = new d(173, f.h);
        t = new d(177, f.d);
        w = d2 = new d(176, f.f);
        d[] arrd = new d[]{f, h, o, s, t, d2};
        P4 = arrd;
    }

    private d(int n3, f f2) {
        this.c = n3;
        this.d = f2.e();
    }

    public static e a(b b2) {
        if (b2.isPrimitive()) {
            if (b2.a((Type)Long.TYPE)) {
                return s;
            }
            if (b2.a((Type)Double.TYPE)) {
                return h;
            }
            if (b2.a((Type)Float.TYPE)) {
                return o;
            }
            if (b2.a((Type)Void.TYPE)) {
                return t;
            }
            return f;
        }
        return w;
    }

    public static d valueOf(String string) {
        return (d)Enum.valueOf(d.class, (String)string);
    }

    public static d[] values() {
        return (d[])P4.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.c);
        return this.d;
    }

    public boolean x() {
        return true;
    }
}

