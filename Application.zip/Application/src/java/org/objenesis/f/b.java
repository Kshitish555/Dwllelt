/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Error
 *  java.lang.Object
 *  java.lang.String
 */
package org.objenesis.f;

import java.io.Serializable;

public class b {
    public static <T> Class<? super T> a(Class<T> class_) {
        while (Serializable.class.isAssignableFrom(class_)) {
            if ((class_ = class_.getSuperclass()) != null) continue;
            throw new Error("Bad class hierarchy: No non-serializable parents");
        }
        return class_;
    }
}

