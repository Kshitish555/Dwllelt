/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.lang.annotation.ElementType
 *  java.lang.reflect.Type
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  l.a.h.a
 *  l.a.h.a$a
 *  l.a.h.f.a
 *  l.a.h.f.b
 *  l.a.h.f.b$c
 *  l.a.h.f.d
 *  l.a.h.h.a
 *  l.a.h.h.a$c
 *  l.a.h.h.a$f
 *  l.a.h.h.b
 *  l.a.h.i.a
 *  l.a.h.i.a$d
 *  l.a.h.i.a$g
 *  l.a.h.i.a$h
 *  l.a.h.i.b
 *  l.a.h.i.c
 *  l.a.h.i.c$c
 *  l.a.h.i.d
 *  l.a.h.k.a
 *  l.a.h.k.b
 *  l.a.h.k.b$a
 *  l.a.h.k.c
 *  l.a.h.k.c$b
 *  l.a.h.k.c$f
 *  l.a.h.k.c$f$d
 *  l.a.h.k.c$f$d$h
 *  l.a.h.k.c$f$j
 *  l.a.h.k.c$f$j$h
 *  l.a.h.k.c$f$j$h$a
 *  l.a.h.k.c$f$j$h$b
 *  l.a.h.k.d
 *  l.a.h.k.d$d
 *  l.a.h.k.d$f
 *  l.a.h.k.d$f$d$b
 *  l.a.h.k.e
 *  l.a.i.f
 *  l.a.i.i.f$b
 *  l.a.j.h
 *  l.a.j.q.b
 *  l.a.l.r
 *  l.a.n.a
 */
package l.a.i.i;

import java.lang.annotation.ElementType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import l.a.h.a;
import l.a.h.f.b;
import l.a.h.h.a;
import l.a.h.h.b;
import l.a.h.i.a;
import l.a.h.i.b;
import l.a.h.i.c;
import l.a.h.k.a;
import l.a.h.k.b;
import l.a.h.k.c;
import l.a.h.k.d;
import l.a.h.k.e;
import l.a.i.i.f;
import l.a.j.h;
import l.a.l.r;

public interface c
extends l.a.h.k.c {
    public l.a.h.k.c R0();

    public c a(List<? extends l.a.h.f.a> var1);

    public c a(a.g var1);

    public c a(a.h var1);

    public c a(d.f var1);

    public c a(e var1);

    public c a(h var1);

    public c a(l.a.j.q.b var1);

    public c m(int var1);

    public h p();

    public l.a.i.i.f w();

    public static class b
    extends c.b.a
    implements f {
        private static final Set<String> Y4 = new HashSet((Collection)Arrays.asList((Object[])new String[]{"abstract", "continue", "for", "new", "switch", "assert", "default", "goto", "package", "synchronized", "boolean", "do", "if", "private", "this", "break", "double", "implements", "protected", "throw", "byte", "else", "import", "public", "throws", "case", "enum", "instanceof", "return", "transient", "catch", "extends", "int", "short", "try", "char", "final", "interface", "static", "void", "class", "finally", "long", "strictfp", "volatile", "const", "float", "native", "super", "while"}));
        private final l.a.i.i.f P4;
        private final h Q4;
        private final l.a.h.k.c R4;
        private final a S4;
        private final l.a.h.k.c T4;
        private final List<? extends l.a.h.k.c> U4;
        private final boolean V4;
        private final boolean W4;
        private final boolean X4;
        private final String c;
        private final int d;
        private final c.f f;
        private final List<? extends e> h;
        private final List<? extends c.f> o;
        private final List<? extends a.g> s;
        private final List<? extends a.h> t;
        private final List<? extends l.a.h.f.a> w;

        protected b(String string, int n, c.f f2, List<? extends e> list, List<? extends c.f> list2, List<? extends a.g> list3, List<? extends a.h> list4, List<? extends l.a.h.f.a> list5, l.a.i.i.f f3, h h2, l.a.h.k.c c2, a a2, l.a.h.k.c c3, List<? extends l.a.h.k.c> list6, boolean bl, boolean bl2, boolean bl3) {
            this.c = string;
            this.d = n;
            this.h = list;
            this.f = f2;
            this.o = list2;
            this.s = list3;
            this.t = list4;
            this.w = list5;
            this.P4 = f3;
            this.Q4 = h2;
            this.R4 = c2;
            this.S4 = a2;
            this.T4 = c3;
            this.U4 = list6;
            this.V4 = bl;
            this.W4 = bl2;
            this.X4 = bl3;
        }

        private static boolean a(String[] arrstring) {
            if (arrstring.length == 0) {
                return false;
            }
            int n = arrstring.length;
            for (int i2 = 0; i2 < n; ++i2) {
                if (b.c(arrstring[i2])) continue;
                return false;
            }
            return true;
        }

        private static boolean c(String string) {
            if (!Y4.contains((Object)string) && !string.isEmpty()) {
                if (!Character.isJavaIdentifierStart((char)string.charAt(0))) {
                    return false;
                }
                if (string.equals((Object)"package-info")) {
                    return true;
                }
                for (int i2 = 1; i2 < string.length(); ++i2) {
                    if (Character.isJavaIdentifierPart((char)string.charAt(i2))) continue;
                    return false;
                }
                return true;
            }
            return false;
        }

        public d.f A0() {
            return new d.f.d.b(this.o, (c.f.j)c.f.j.h.a.a((l.a.h.k.c)this));
        }

        public boolean B() {
            return this.V4;
        }

        public boolean K1() {
            return this.W4;
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public l.a.h.k.c R0() {
            a.d d2;
            c.f f2;
            block84 : {
                String string;
                String string2;
                String string3;
                String string4;
                String string5;
                String string6;
                String string7;
                String string8;
                String string9;
                String string10;
                String string11;
                if (!b.a(this.getName().split("\\."))) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Illegal type name: ");
                    stringBuilder.append(this.getName());
                    stringBuilder.append(" for ");
                    stringBuilder.append((Object)this);
                    IllegalStateException illegalStateException = new IllegalStateException(stringBuilder.toString());
                    throw illegalStateException;
                }
                int n = -161312 & this.getModifiers();
                String string12 = "Illegal modifiers ";
                if (n != 0) {
                    String string13 = string12;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string13);
                    stringBuilder.append(this.getModifiers());
                    stringBuilder.append(" for ");
                    stringBuilder.append((Object)this);
                    throw new IllegalStateException(stringBuilder.toString());
                }
                if (this.J1() && this.getModifiers() != 5632) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string12);
                    stringBuilder.append(this.getModifiers());
                    stringBuilder.append(" for package ");
                    stringBuilder.append((Object)this);
                    throw new IllegalStateException(stringBuilder.toString());
                }
                c.f f3 = this.a0();
                if (f3 != null) {
                    if (!((Boolean)f3.a((c.f.j)c.f.j.j.o)).booleanValue()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Illegal super class ");
                        stringBuilder.append((Object)f3);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!((Boolean)f3.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Illegal type annotations on super class ");
                        stringBuilder.append((Object)f3);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!f3.y0().e((l.a.h.k.c)this)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Invisible super type ");
                        stringBuilder.append((Object)f3);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                }
                HashSet hashSet = new HashSet();
                for (c.f f4 : this.A0()) {
                    if (!((Boolean)f4.a((c.f.j)c.f.j.j.s)).booleanValue()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Illegal interface ");
                        stringBuilder.append((Object)f4);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!((Boolean)f4.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Illegal type annotations on interface ");
                        stringBuilder.append((Object)f4);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!hashSet.add((Object)f4.y0())) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Already implemented interface ");
                        stringBuilder.append((Object)f4);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (f4.y0().e((l.a.h.k.c)this)) continue;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Invisible interface type ");
                    stringBuilder.append((Object)f4);
                    stringBuilder.append(" for ");
                    stringBuilder.append((Object)this);
                    throw new IllegalStateException(stringBuilder.toString());
                }
                d.f f5 = this.U();
                if (!f5.isEmpty() && this.c(Throwable.class)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Cannot define throwable ");
                    stringBuilder.append((Object)this);
                    stringBuilder.append(" to be generic");
                    throw new IllegalStateException(stringBuilder.toString());
                }
                HashSet hashSet2 = new HashSet();
                Iterator iterator = f5.iterator();
                do {
                    boolean bl = iterator.hasNext();
                    string7 = "Illegal interface bound ";
                    string11 = "Duplicate bound ";
                    string4 = "Illegal type variable bound ";
                    string2 = "Illegal type annotation on '";
                    string = "Illegal type variable name '";
                    string10 = "Duplicate type variable symbol '";
                    string8 = "' for ";
                    if (!bl) break;
                    c.f f6 = (c.f)iterator.next();
                    Iterator iterator2 = iterator;
                    String string14 = f6.z1();
                    if (!hashSet2.add((Object)string14)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(string10);
                        stringBuilder.append((Object)f6);
                        stringBuilder.append(string8);
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!b.c(string14)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(string);
                        stringBuilder.append((Object)f6);
                        stringBuilder.append(string8);
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!c.f.j.j.d.g(f6)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(string2);
                        stringBuilder.append((Object)f6);
                        stringBuilder.append(string8);
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    HashSet hashSet3 = new HashSet();
                    Iterator iterator3 = f6.getUpperBounds().iterator();
                    boolean bl2 = false;
                    while (iterator3.hasNext()) {
                        c.f f7 = (c.f)iterator3.next();
                        if (!((Boolean)f7.a((c.f.j)c.f.j.j.t)).booleanValue()) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(string4);
                            stringBuilder.append((Object)f7);
                            stringBuilder.append(" of ");
                            stringBuilder.append((Object)f6);
                            stringBuilder.append(" for ");
                            stringBuilder.append((Object)this);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        if (!((Boolean)f7.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Illegal type annotations on type variable ");
                            stringBuilder.append((Object)f7);
                            stringBuilder.append(" for ");
                            stringBuilder.append((Object)this);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        if (!hashSet3.add((Object)f7)) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(string11);
                            stringBuilder.append((Object)f7);
                            stringBuilder.append(" of ");
                            stringBuilder.append((Object)f6);
                            stringBuilder.append(" for ");
                            stringBuilder.append((Object)this);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        if (bl2 && (f7.k().h() || !f7.isInterface())) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(string7);
                            stringBuilder.append((Object)f7);
                            stringBuilder.append(" of ");
                            stringBuilder.append((Object)f6);
                            stringBuilder.append(" for ");
                            stringBuilder.append((Object)this);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        bl2 = true;
                    }
                    if (!bl2) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Type variable ");
                        stringBuilder.append((Object)f6);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        stringBuilder.append(" does not define at least one bound");
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    iterator = iterator2;
                } while (true);
                HashSet hashSet4 = new HashSet();
                Iterator iterator4 = this.getDeclaredAnnotations().iterator();
                do {
                    boolean bl = iterator4.hasNext();
                    string5 = string12;
                    string3 = string10;
                    string9 = string;
                    if (!bl) break;
                    l.a.h.f.a a2 = (l.a.h.f.a)iterator4.next();
                    Iterator iterator5 = iterator4;
                    Set set = a2.c();
                    String string15 = string8;
                    if (!(set.contains((Object)ElementType.TYPE) || this.X0() && a2.c().contains((Object)ElementType.ANNOTATION_TYPE) || this.J1() && a2.c().contains((Object)ElementType.PACKAGE))) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Cannot add ");
                        stringBuilder.append((Object)a2);
                        stringBuilder.append(" on ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!hashSet4.add((Object)a2.d())) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Duplicate annotation ");
                        stringBuilder.append((Object)a2);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    string12 = string5;
                    string10 = string3;
                    string = string9;
                    iterator4 = iterator5;
                    string8 = string15;
                } while (true);
                String string16 = string8;
                HashSet hashSet5 = new HashSet();
                Iterator iterator6 = this.q().iterator();
                do {
                    boolean bl = iterator6.hasNext();
                    string6 = "Illegal type annotations on ";
                    if (!bl) break;
                    a.c c2 = (a.c)iterator6.next();
                    String string17 = c2.getName();
                    Iterator iterator7 = iterator6;
                    if (!hashSet5.add((Object)c2.h())) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Duplicate field definition for ");
                        stringBuilder.append((Object)c2);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!b.c(string17)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Illegal field name for ");
                        stringBuilder.append((Object)c2);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if ((-151776 & c2.getModifiers()) != 0) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Illegal field modifiers ");
                        stringBuilder.append(c2.getModifiers());
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)c2);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    c.f f8 = c2.getType();
                    HashSet hashSet6 = hashSet5;
                    if (!((Boolean)f8.a((c.f.j)c.f.j.j.w)).booleanValue()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Illegal field type ");
                        stringBuilder.append((Object)f8);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)c2);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!((Boolean)f8.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(string6);
                        stringBuilder.append((Object)f8);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    if (!c2.t() && !f8.y0().e((l.a.h.k.c)this)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Invisible field type ");
                        stringBuilder.append((Object)c2.getType());
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)c2);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    HashSet hashSet7 = new HashSet();
                    Iterator iterator8 = c2.getDeclaredAnnotations().iterator();
                    while (iterator8.hasNext()) {
                        l.a.h.f.a a3 = (l.a.h.f.a)iterator8.next();
                        Iterator iterator9 = iterator8;
                        Set set = a3.c();
                        String string18 = string2;
                        if (!set.contains((Object)ElementType.FIELD)) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Cannot add ");
                            stringBuilder.append((Object)a3);
                            stringBuilder.append(" on ");
                            stringBuilder.append((Object)c2);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        if (!hashSet7.add((Object)a3.d())) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Duplicate annotation ");
                            stringBuilder.append((Object)a3);
                            stringBuilder.append(" for ");
                            stringBuilder.append((Object)c2);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        iterator8 = iterator9;
                        string2 = string18;
                    }
                    hashSet5 = hashSet6;
                    iterator6 = iterator7;
                } while (true);
                String string19 = string2;
                HashSet hashSet8 = new HashSet();
                Iterator iterator10 = this.u().iterator();
                while (iterator10.hasNext()) {
                    Iterator iterator11;
                    String string20;
                    String string21;
                    String string22;
                    String string23;
                    HashSet hashSet9;
                    String string24;
                    String string25;
                    block86 : {
                        block87 : {
                            block88 : {
                                block85 : {
                                    String string26;
                                    HashSet hashSet10;
                                    Iterator iterator12;
                                    d2 = (a.d)iterator10.next();
                                    if (!hashSet8.add((Object)d2.h())) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Duplicate method signature for ");
                                        stringBuilder.append((Object)d2);
                                        throw new IllegalStateException(stringBuilder.toString());
                                    }
                                    if ((-7680 & d2.getModifiers()) != 0) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append(string5);
                                        stringBuilder.append(d2.getModifiers());
                                        stringBuilder.append(" for ");
                                        stringBuilder.append((Object)d2);
                                        throw new IllegalStateException(stringBuilder.toString());
                                    }
                                    HashSet hashSet11 = new HashSet();
                                    Iterator iterator13 = d2.U().iterator();
                                    do {
                                        if (!iterator13.hasNext()) {
                                            hashSet9 = hashSet8;
                                            iterator11 = iterator10;
                                            string25 = string6;
                                            string20 = string9;
                                            string26 = string16;
                                            String string27 = string19;
                                            c.f f9 = d2.getReturnType();
                                            if (d2.N0()) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Illegal explicit declaration of a type initializer by ");
                                                stringBuilder.append((Object)this);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            boolean bl = d2.p1();
                                            string19 = string27;
                                            if (bl) {
                                                string24 = string7;
                                                if (!f9.a((Type)Void.TYPE)) {
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    stringBuilder.append("A constructor must return void ");
                                                    stringBuilder.append((Object)d2);
                                                    throw new IllegalStateException(stringBuilder.toString());
                                                }
                                                if (!f9.getDeclaredAnnotations().isEmpty()) {
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    stringBuilder.append("The void non-type must not be annotated for ");
                                                    stringBuilder.append((Object)d2);
                                                    throw new IllegalStateException(stringBuilder.toString());
                                                }
                                            } else {
                                                string24 = string7;
                                                if (!b.c(d2.d())) {
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    stringBuilder.append("Illegal method name ");
                                                    stringBuilder.append((Object)f9);
                                                    stringBuilder.append(" for ");
                                                    stringBuilder.append((Object)d2);
                                                    throw new IllegalStateException(stringBuilder.toString());
                                                }
                                                if (!((Boolean)f9.a((c.f.j)c.f.j.j.P4)).booleanValue()) {
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    stringBuilder.append("Illegal return type ");
                                                    stringBuilder.append((Object)f9);
                                                    stringBuilder.append(" for ");
                                                    stringBuilder.append((Object)d2);
                                                    throw new IllegalStateException(stringBuilder.toString());
                                                }
                                                if (!((Boolean)f9.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    stringBuilder.append("Illegal type annotations return type ");
                                                    stringBuilder.append((Object)f9);
                                                    stringBuilder.append(" for ");
                                                    stringBuilder.append((Object)d2);
                                                    throw new IllegalStateException(stringBuilder.toString());
                                                }
                                                if (!d2.t() && !d2.getReturnType().y0().e((l.a.h.k.c)this)) {
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    stringBuilder.append("Invisible return type ");
                                                    stringBuilder.append((Object)d2.getReturnType());
                                                    stringBuilder.append(" for ");
                                                    stringBuilder.append((Object)d2);
                                                    throw new IllegalStateException(stringBuilder.toString());
                                                }
                                            }
                                            hashSet10 = new HashSet();
                                            iterator12 = d2.getParameters().iterator();
                                            break;
                                        }
                                        Object object = iterator13.next();
                                        HashSet hashSet12 = hashSet8;
                                        c.f f10 = (c.f)object;
                                        Iterator iterator14 = iterator10;
                                        String string28 = f10.z1();
                                        if (!hashSet11.add((Object)string28)) {
                                            String string29 = string16;
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append(string3);
                                            stringBuilder.append((Object)f10);
                                            stringBuilder.append(string29);
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (!b.c(string28)) {
                                            String string30 = string16;
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append(string9);
                                            stringBuilder.append((Object)f10);
                                            stringBuilder.append(string30);
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (!c.f.j.j.d.g(f10)) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append(string19);
                                            stringBuilder.append((Object)f10);
                                            stringBuilder.append(string16);
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        HashSet hashSet13 = new HashSet();
                                        Iterator iterator15 = f10.getUpperBounds().iterator();
                                        boolean bl = false;
                                        while (iterator15.hasNext()) {
                                            Object object2 = iterator15.next();
                                            HashSet hashSet14 = hashSet11;
                                            c.f f11 = (c.f)object2;
                                            String string31 = string6;
                                            if (!((Boolean)f11.a((c.f.j)c.f.j.j.t)).booleanValue()) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append(string4);
                                                stringBuilder.append((Object)f11);
                                                stringBuilder.append(" of ");
                                                stringBuilder.append((Object)f10);
                                                stringBuilder.append(" for ");
                                                stringBuilder.append((Object)d2);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            if (!((Boolean)f11.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Illegal type annotations on bound ");
                                                stringBuilder.append((Object)f11);
                                                stringBuilder.append(" of ");
                                                stringBuilder.append((Object)f10);
                                                stringBuilder.append(" for ");
                                                stringBuilder.append((Object)this);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            if (!hashSet13.add((Object)f11)) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append(string11);
                                                stringBuilder.append((Object)f11);
                                                stringBuilder.append(" of ");
                                                stringBuilder.append((Object)f10);
                                                stringBuilder.append(" for ");
                                                stringBuilder.append((Object)d2);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            if (bl && (f11.k().h() || !f11.isInterface())) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append(string7);
                                                stringBuilder.append((Object)f11);
                                                stringBuilder.append(" of ");
                                                stringBuilder.append((Object)f10);
                                                stringBuilder.append(" for ");
                                                stringBuilder.append((Object)d2);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            string6 = string31;
                                            hashSet11 = hashSet14;
                                            bl = true;
                                        }
                                        String string32 = string6;
                                        HashSet hashSet15 = hashSet11;
                                        if (!bl) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Type variable ");
                                            stringBuilder.append((Object)f10);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            stringBuilder.append(" does not define at least one bound");
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        iterator10 = iterator14;
                                        hashSet8 = hashSet12;
                                        string6 = string32;
                                        hashSet11 = hashSet15;
                                    } while (true);
                                    while (iterator12.hasNext()) {
                                        Object object = iterator12.next();
                                        Iterator iterator16 = iterator12;
                                        c.c c3 = (c.c)object;
                                        String string33 = string26;
                                        c.f f12 = c3.getType();
                                        String string34 = string11;
                                        if (!((Boolean)f12.a((c.f.j)c.f.j.j.Q4)).booleanValue()) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Illegal parameter type of ");
                                            stringBuilder.append((Object)c3);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (!((Boolean)f12.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Illegal type annotations return type ");
                                            stringBuilder.append((Object)f12);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (!d2.t() && !f12.y0().e((l.a.h.k.c)this)) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Invisible parameter type of ");
                                            stringBuilder.append((Object)c3);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (c3.W()) {
                                            String string35 = c3.getName();
                                            if (!hashSet10.add((Object)string35)) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Duplicate parameter name of ");
                                                stringBuilder.append((Object)c3);
                                                stringBuilder.append(" for ");
                                                stringBuilder.append((Object)d2);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            if (!b.c(string35)) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Illegal parameter name of ");
                                                stringBuilder.append((Object)c3);
                                                stringBuilder.append(" for ");
                                                stringBuilder.append((Object)d2);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                        }
                                        if (c3.g0() && (-36881 & c3.getModifiers()) != 0) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Illegal modifiers of ");
                                            stringBuilder.append((Object)c3);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        HashSet hashSet16 = new HashSet();
                                        Iterator iterator17 = c3.getDeclaredAnnotations().iterator();
                                        while (iterator17.hasNext()) {
                                            Object object3 = iterator17.next();
                                            HashSet hashSet17 = hashSet10;
                                            l.a.h.f.a a4 = (l.a.h.f.a)object3;
                                            Iterator iterator18 = iterator17;
                                            Set set = a4.c();
                                            String string36 = string4;
                                            if (!set.contains((Object)ElementType.PARAMETER)) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Cannot add ");
                                                stringBuilder.append((Object)a4);
                                                stringBuilder.append(" on ");
                                                stringBuilder.append((Object)c3);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            if (!hashSet16.add((Object)a4.d())) {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Duplicate annotation ");
                                                stringBuilder.append((Object)a4);
                                                stringBuilder.append(" of ");
                                                stringBuilder.append((Object)c3);
                                                stringBuilder.append(" for ");
                                                stringBuilder.append((Object)d2);
                                                throw new IllegalStateException(stringBuilder.toString());
                                            }
                                            iterator17 = iterator18;
                                            hashSet10 = hashSet17;
                                            string4 = string36;
                                        }
                                        string26 = string33;
                                        iterator12 = iterator16;
                                        string11 = string34;
                                    }
                                    string23 = string26;
                                    string22 = string11;
                                    string21 = string4;
                                    HashSet hashSet18 = new HashSet();
                                    for (c.f f13 : d2.o()) {
                                        if (!hashSet18.add((Object)f13)) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Duplicate exception type ");
                                            stringBuilder.append((Object)f13);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (!((Boolean)f13.a((c.f.j)c.f.j.j.R4)).booleanValue()) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Illegal exception type ");
                                            stringBuilder.append((Object)f13);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (!((Boolean)f13.a((c.f.j)c.f.j.j.d.f)).booleanValue()) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append(string25);
                                            stringBuilder.append((Object)f13);
                                            stringBuilder.append(" for ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (d2.t() || f13.y0().e((l.a.h.k.c)this)) continue;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Invisible exception type ");
                                        stringBuilder.append((Object)f13);
                                        stringBuilder.append(" for ");
                                        stringBuilder.append((Object)d2);
                                        throw new IllegalStateException(stringBuilder.toString());
                                    }
                                    HashSet hashSet19 = new HashSet();
                                    for (l.a.h.f.a a5 : d2.getDeclaredAnnotations()) {
                                        ElementType elementType;
                                        Set set = a5.c();
                                        if (!set.contains((Object)(elementType = d2.Y0() ? ElementType.METHOD : ElementType.CONSTRUCTOR))) {
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Cannot add ");
                                            stringBuilder.append((Object)a5);
                                            stringBuilder.append(" on ");
                                            stringBuilder.append((Object)d2);
                                            throw new IllegalStateException(stringBuilder.toString());
                                        }
                                        if (hashSet19.add((Object)a5.d())) continue;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Duplicate annotation ");
                                        stringBuilder.append((Object)a5);
                                        stringBuilder.append(" for ");
                                        stringBuilder.append((Object)d2);
                                        throw new IllegalStateException(stringBuilder.toString());
                                    }
                                    l.a.h.f.d d3 = d2.K0();
                                    if (d3 != null && !d2.a(d3)) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Illegal default value ");
                                        stringBuilder.append((Object)d3);
                                        stringBuilder.append("for ");
                                        stringBuilder.append((Object)d2);
                                        throw new IllegalStateException(stringBuilder.toString());
                                    }
                                    f2 = d2.A();
                                    if (f2 != null && !((Boolean)f2.a((c.f.j)c.f.j.j.S4)).booleanValue()) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Illegal receiver type ");
                                        stringBuilder.append((Object)f2);
                                        stringBuilder.append(" for ");
                                        stringBuilder.append((Object)d2);
                                        throw new IllegalStateException(stringBuilder.toString());
                                    }
                                    if (!d2.isStatic()) break block85;
                                    if (f2 != null) {
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Static method ");
                                        stringBuilder.append((Object)d2);
                                        stringBuilder.append(" defines a non-null receiver ");
                                        stringBuilder.append((Object)f2);
                                        throw new IllegalStateException(stringBuilder.toString());
                                    }
                                    break block86;
                                }
                                if (!d2.p1()) break block87;
                                l.a.h.k.c c4 = this.n1();
                                if (f2 == null) break block88;
                                l.a.h.k.c c5 = f2.y0();
                                if (c4 == null) {
                                    c4 = this;
                                }
                                if (c5.equals((Object)c4)) break block86;
                            }
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Constructor ");
                            stringBuilder.append((Object)d2);
                            stringBuilder.append(" defines an illegal receiver ");
                            stringBuilder.append((Object)f2);
                            throw new IllegalStateException(stringBuilder.toString());
                        }
                        if (f2 == null || !this.equals((Object)f2.y0())) break block84;
                    }
                    string6 = string25;
                    string7 = string24;
                    string16 = string23;
                    iterator10 = iterator11;
                    hashSet8 = hashSet9;
                    string11 = string22;
                    string4 = string21;
                    string9 = string20;
                }
                return this;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Method ");
            stringBuilder.append((Object)d2);
            stringBuilder.append(" defines an illegal receiver ");
            stringBuilder.append((Object)f2);
            throw new IllegalStateException(stringBuilder.toString());
        }

        public d.f U() {
            return d.f.d.a(this, this.h);
        }

        public l.a.h.k.a Z0() {
            int n = this.c.lastIndexOf(46);
            if (n == -1) {
                return l.a.h.k.a.Z;
            }
            return new a.c(this.c.substring(0, n));
        }

        @Override
        public f a(List<? extends l.a.h.f.a> list) {
            b b2 = new b(this.c, this.d, this.f, this.h, this.o, this.s, this.t, (List<? extends l.a.h.f.a>)l.a.n.a.a(this.w, list), this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        @Override
        public f a(a.g g2) {
            b b2 = new b(this.c, this.d, this.f, this.h, this.o, (List<? extends a.g>)l.a.n.a.a(this.s, (Object)g2.a(c.f.j.h.b.a((l.a.h.k.b)this))), this.t, this.w, this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        @Override
        public f a(a.h h2) {
            b b2 = new b(this.c, this.d, this.f, this.h, this.o, this.s, (List<? extends a.h>)l.a.n.a.a(this.t, (Object)h2.a(c.f.j.h.b.a((l.a.h.k.b)this))), this.w, this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        @Override
        public f a(d.f f2) {
            b b2 = new b(this.c, this.d, this.f, this.h, (List<? extends c.f>)l.a.n.a.a(this.o, (List)f2.a(c.f.j.h.b.a((l.a.h.k.b)this))), this.s, this.t, this.w, this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        @Override
        public f a(e e2) {
            b b2 = new b(this.c, this.d, this.f, (List<? extends e>)l.a.n.a.a(this.h, (Object)e2.a(c.f.j.h.b.a((l.a.h.k.b)this))), this.o, this.s, this.t, this.w, this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        @Override
        public f a(h h2) {
            String string = this.c;
            int n = this.d;
            c.f f2 = this.f;
            List<? extends e> list = this.h;
            List<? extends c.f> list2 = this.o;
            List<? extends a.g> list3 = this.s;
            List<? extends a.h> list4 = this.t;
            List<? extends l.a.h.f.a> list5 = this.w;
            l.a.i.i.f f3 = this.P4;
            h[] arrh = new h[]{this.Q4, h2};
            b b2 = new b(string, n, f2, list, list2, list3, list4, list5, f3, new h.a(arrh), this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        @Override
        public f a(l.a.j.q.b b2) {
            b b3 = new b(this.c, this.d, this.f, this.h, this.o, this.s, this.t, this.w, this.P4.b(b2), this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b3;
        }

        @Override
        public f a(r<? super c.f> r2, l.a.i.f<e> f2) {
            ArrayList arrayList = new ArrayList(this.h.size());
            Iterator iterator = this.h.iterator();
            int n = 0;
            while (iterator.hasNext()) {
                e e2 = (e)iterator.next();
                d.f f3 = this.U();
                int n2 = n + 1;
                if (r2.a(f3.get(n))) {
                    e2 = (e)f2.a((l.a.h.k.c)this, (Object)e2);
                }
                arrayList.add((Object)e2);
                n = n2;
            }
            b b2 = new b(this.c, this.d, this.f, (List<? extends e>)arrayList, this.o, this.s, this.t, this.w, this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        public c.f a0() {
            if (this.f == null) {
                return c.f.e0;
            }
            return new c.f.d.h(this.f, (c.f.j)c.f.j.h.a.a((l.a.h.k.c)this));
        }

        public l.a.h.k.d a1() {
            return new d.d(this.U4);
        }

        @Override
        public f d(String string) {
            b b2 = new b(string, this.d, this.f, this.h, this.o, this.s, this.t, this.w, this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        public l.a.h.k.c e() {
            return this.R4;
        }

        public l.a.h.f.b getDeclaredAnnotations() {
            return new b.c(this.w);
        }

        public int getModifiers() {
            return this.d;
        }

        public String getName() {
            return this.c;
        }

        public boolean h1() {
            return this.X4;
        }

        @Override
        public f m(int n) {
            b b2 = new b(this.c, n, this.f, this.h, this.o, this.s, this.t, this.w, this.P4, this.Q4, this.R4, this.S4, this.T4, this.U4, this.V4, this.W4, this.X4);
            return b2;
        }

        public l.a.h.k.c n1() {
            return this.T4;
        }

        @Override
        public h p() {
            return this.Q4;
        }

        public l.a.h.h.b<a.c> q() {
            return new b.e((l.a.h.k.c)this, this.s);
        }

        public l.a.h.i.b<a.d> u() {
            return new b.e((l.a.h.k.c)this, this.t);
        }

        public a v1() {
            return this.S4;
        }

        @Override
        public l.a.i.i.f w() {
            return this.P4;
        }
    }

    public static class d
    extends c.b.a
    implements f {
        private final l.a.h.k.c c;
        private final h d;

        protected d(l.a.h.k.c c2, h h2) {
            this.c = c2;
            this.d = h2;
        }

        public d.f A0() {
            return this.c.A0();
        }

        public boolean B() {
            return this.c.B();
        }

        public boolean K1() {
            return this.c.K1();
        }

        @Override
        public l.a.h.k.c R0() {
            return this.c;
        }

        public d.f U() {
            return this.c.U();
        }

        public l.a.h.k.a Z0() {
            return this.c.Z0();
        }

        public int a(boolean bl) {
            return this.c.a(bl);
        }

        @Override
        public f a(List<? extends l.a.h.f.a> list) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot add annotation to frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public f a(a.g g2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot define field for frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public f a(a.h h2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot define method for frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public f a(d.f f2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot add interfaces for frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public f a(e e2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot define type variable for frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public f a(h h2) {
            l.a.h.k.c c2 = this.c;
            h[] arrh = new h[]{this.d, h2};
            return new d(c2, new h.a(arrh));
        }

        @Override
        public f a(l.a.j.q.b b2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot add initializer to frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public f a(r<? super c.f> r2, l.a.i.f<e> f2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot add type variables of frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        public c.f a0() {
            return this.c.a0();
        }

        public l.a.h.k.d a1() {
            return this.c.a1();
        }

        @Override
        public f d(String string) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot change name of frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        public l.a.h.k.c e() {
            return this.c.e();
        }

        public l.a.h.f.b getDeclaredAnnotations() {
            return this.c.getDeclaredAnnotations();
        }

        public int getModifiers() {
            return this.c.getModifiers();
        }

        public String getName() {
            return this.c.getName();
        }

        public boolean h1() {
            return this.c.h1();
        }

        public String i1() {
            return this.c.i1();
        }

        @Override
        public f m(int n) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot change modifiers for frozen type: ");
            stringBuilder.append((Object)this.c);
            throw new IllegalStateException(stringBuilder.toString());
        }

        public l.a.h.k.c n1() {
            return this.c.n1();
        }

        @Override
        public h p() {
            return this.d;
        }

        public l.a.h.h.b<a.c> q() {
            return this.c.q();
        }

        public l.a.h.i.b<a.d> u() {
            return this.c.u();
        }

        public a v1() {
            return this.c.v1();
        }

        @Override
        public l.a.i.i.f w() {
            return f.b.c;
        }
    }

    public static interface f
    extends c {
        @Override
        public f a(List<? extends l.a.h.f.a> var1);

        @Override
        public f a(a.g var1);

        @Override
        public f a(a.h var1);

        @Override
        public f a(d.f var1);

        @Override
        public f a(e var1);

        @Override
        public f a(h var1);

        @Override
        public f a(l.a.j.q.b var1);

        public f a(r<? super c.f> var1, l.a.i.f<e> var2);

        public f d(String var1);

        @Override
        public f m(int var1);
    }

}

