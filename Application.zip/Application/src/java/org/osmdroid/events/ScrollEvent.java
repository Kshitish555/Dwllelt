/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.events.MapEvent
 */
package org.osmdroid.events;

import org.osmdroid.events.MapEvent;
import org.osmdroid.views.MapView;

public class ScrollEvent
implements MapEvent {
    protected MapView source;
    protected int x;
    protected int y;

    public ScrollEvent(MapView mapView, int n, int n2) {
        this.source = mapView;
        this.x = n;
        this.y = n2;
    }

    public MapView getSource() {
        return this.source;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ScrollEvent [source=");
        stringBuilder.append((Object)this.source);
        stringBuilder.append(", x=");
        stringBuilder.append(this.x);
        stringBuilder.append(", y=");
        stringBuilder.append(this.y);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

