/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedOutputStream
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Comparator
 *  java.util.List
 *  java.util.NoSuchElementException
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.osmdroid.tileprovider.modules.IFilesystemCache
 *  org.osmdroid.tileprovider.modules.TileWriter$1
 *  org.osmdroid.tileprovider.modules.TileWriter$2
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.tileprovider.util.StreamUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.osmdroid.tileprovider.modules.IFilesystemCache;
import org.osmdroid.tileprovider.modules.TileWriter;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.util.StreamUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TileWriter
implements IFilesystemCache,
OpenStreetMapTileProviderConstants {
    private static final Logger logger = LoggerFactory.getLogger(TileWriter.class);
    private static long mUsedCacheSpace;

    public TileWriter() {
        1 var1_1 = new 1(this);
        var1_1.setPriority(1);
        var1_1.start();
    }

    static /* synthetic */ long access$000() {
        return mUsedCacheSpace;
    }

    static /* synthetic */ long access$002(long l) {
        mUsedCacheSpace = l;
        return l;
    }

    static /* synthetic */ void access$100(TileWriter tileWriter, File file) {
        tileWriter.calculateDirectorySize(file);
    }

    static /* synthetic */ void access$200(TileWriter tileWriter) {
        tileWriter.cutCurrentCache();
    }

    private void calculateDirectorySize(File file) {
        File[] arrfile = file.listFiles();
        if (arrfile != null) {
            for (File file2 : arrfile) {
                if (file2.isFile()) {
                    mUsedCacheSpace += file2.length();
                }
                if (!file2.isDirectory() || this.isSymbolicDirectoryLink(file, file2)) continue;
                this.calculateDirectorySize(file2);
            }
        }
    }

    /*
     * Exception decompiling
     */
    private boolean createFolderAndCheckIfExists(File var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl9.1 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private void cutCurrentCache() {
        var16_2 = var1_1 = OpenStreetMapTileProviderConstants.TILE_PATH_BASE;
        // MONITORENTER : var16_2
        if (TileWriter.mUsedCacheSpace > 524288000L) {
            var3_3 = TileWriter.logger;
            var4_4 = new StringBuilder();
            var4_4.append("Trimming tile cache from ");
            var4_4.append(TileWriter.mUsedCacheSpace);
            var4_4.append(" to ");
            var4_4.append(524288000L);
            var3_3.info(var4_4.toString());
            var9_5 = this.getDirectoryFileList(OpenStreetMapTileProviderConstants.TILE_PATH_BASE);
            var10_6 = 0;
            var11_7 = (File[])var9_5.toArray((Object[])new File[0]);
            Arrays.sort((Object[])var11_7, (Comparator)new 2(this));
            var12_8 = var11_7.length;
        }
        ** GOTO lbl31
        do {
            if (var10_6 >= var12_8) ** GOTO lbl-1000
            var13_9 = var11_7[var10_6];
            if (TileWriter.mUsedCacheSpace > 524288000L) {
                var14_10 = var13_9.length();
                if (var13_9.delete()) {
                    TileWriter.mUsedCacheSpace -= var14_10;
                }
            } else lbl-1000: // 2 sources:
            {
                TileWriter.logger.info("Finished trimming tile cache");
lbl31: // 2 sources:
                // MONITOREXIT : var16_2
                return;
            }
            ++var10_6;
        } while (true);
    }

    private List<File> getDirectoryFileList(File file) {
        ArrayList arrayList = new ArrayList();
        File[] arrfile = file.listFiles();
        if (arrfile != null) {
            for (File file2 : arrfile) {
                if (file2.isFile()) {
                    arrayList.add((Object)file2);
                }
                if (!file2.isDirectory()) continue;
                arrayList.addAll(this.getDirectoryFileList(file2));
            }
        }
        return arrayList;
    }

    public static long getUsedCacheSpace() {
        return mUsedCacheSpace;
    }

    private boolean isSymbolicDirectoryLink(File file, File file2) {
        boolean bl;
        try {
            bl = file.getCanonicalPath().equals((Object)file2.getCanonicalFile().getParent());
        }
        catch (IOException | NoSuchElementException throwable) {
            return true;
        }
        return bl ^ true;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public boolean saveFile(ITileSource iTileSource, MapTile mapTile, InputStream inputStream) {
        BufferedOutputStream bufferedOutputStream;
        block9 : {
            Throwable throwable;
            BufferedOutputStream bufferedOutputStream2;
            IOException iOException2;
            block8 : {
                block7 : {
                    File file = OpenStreetMapTileProviderConstants.TILE_PATH_BASE;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(iTileSource.getTileRelativeFilenameString(mapTile));
                    stringBuilder.append(".tile");
                    File file2 = new File(file, stringBuilder.toString());
                    File file3 = file2.getParentFile();
                    if (!file3.exists() && !this.createFolderAndCheckIfExists(file3)) {
                        return false;
                    }
                    bufferedOutputStream = null;
                    bufferedOutputStream2 = new BufferedOutputStream((OutputStream)new FileOutputStream(file2.getPath()), 8192);
                    try {
                        long l;
                        mUsedCacheSpace = l = StreamUtils.copy((InputStream)inputStream, (OutputStream)bufferedOutputStream2) + mUsedCacheSpace;
                        if (l <= 629145600L) break block7;
                        this.cutCurrentCache();
                    }
                    catch (Throwable throwable2) {
                        break block8;
                    }
                    catch (IOException iOException2) {
                        bufferedOutputStream = bufferedOutputStream2;
                        break block9;
                    }
                }
                StreamUtils.closeStream((Closeable)bufferedOutputStream2);
                return true;
                catch (Throwable throwable3) {
                    bufferedOutputStream2 = null;
                    throwable = throwable3;
                }
            }
            if (bufferedOutputStream2 == null) throw throwable;
            StreamUtils.closeStream((Closeable)bufferedOutputStream2);
            throw throwable;
            catch (IOException iOException2) {
                // empty catch block
            }
        }
        if (bufferedOutputStream == null) return false;
        StreamUtils.closeStream(bufferedOutputStream);
        return false;
    }
}

