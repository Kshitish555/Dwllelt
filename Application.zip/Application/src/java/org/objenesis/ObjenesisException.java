/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package org.objenesis;

public class ObjenesisException
extends RuntimeException {
    private static final long c = -2677230016262426968L;

    public ObjenesisException(String string2) {
        super(string2);
    }

    public ObjenesisException(String string2, Throwable throwable) {
        super(string2, throwable);
    }

    public ObjenesisException(Throwable throwable) {
        super(throwable);
    }
}

