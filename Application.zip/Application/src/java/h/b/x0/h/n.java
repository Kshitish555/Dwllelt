/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.q
 *  h.b.u0.c
 *  h.b.x0.c.n
 *  h.b.x0.h.q
 *  h.b.x0.h.r
 *  h.b.x0.h.s
 *  h.b.x0.i.j
 *  h.b.x0.j.d
 *  h.b.x0.j.u
 *  h.b.x0.j.v
 *  io.reactivex.exceptions.MissingBackpressureException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicInteger
 *  java.util.concurrent.atomic.AtomicLong
 *  o.f.c
 */
package h.b.x0.h;

import h.b.q;
import h.b.x0.h.r;
import h.b.x0.h.s;
import h.b.x0.i.j;
import h.b.x0.j.d;
import h.b.x0.j.u;
import h.b.x0.j.v;
import io.reactivex.exceptions.MissingBackpressureException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import o.f.c;

public abstract class n<T, U, V>
extends r
implements q<T>,
u<U, V> {
    protected final c<? super V> C5;
    protected final h.b.x0.c.n<U> D5;
    protected volatile boolean E5;
    protected volatile boolean F5;
    protected Throwable G5;

    public n(c<? super V> c2, h.b.x0.c.n<U> n2) {
        this.C5 = c2;
        this.D5 = n2;
    }

    public final int a(int n2) {
        return ((s)this).W4.addAndGet(n2);
    }

    public final long a(long l) {
        return ((h.b.x0.h.q)this).m5.addAndGet(-l);
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void a(U u2, boolean bl, h.b.u0.c c2) {
        c<? super V> c3 = this.C5;
        h.b.x0.c.n<U> n2 = this.D5;
        if (this.e()) {
            long l = ((h.b.x0.h.q)this).m5.get();
            if (l == 0L) {
                c2.dispose();
                c3.onError((Throwable)new MissingBackpressureException("Could not emit buffer due to lack of requests"));
                return;
            }
            if (this.a(c3, u2) && l != Long.MAX_VALUE) {
                this.a(1L);
            }
            if (this.a(-1) == 0) {
                return;
            }
        } else {
            n2.offer(u2);
            if (!this.a()) {
                return;
            }
        }
        v.a(n2, c3, (boolean)bl, (h.b.u0.c)c2, (u)this);
    }

    public final boolean a() {
        return ((s)this).W4.getAndIncrement() == 0;
    }

    public boolean a(c<? super V> c2, U u2) {
        return false;
    }

    public final void b(long l) {
        if (j.b((long)l)) {
            d.a((AtomicLong)((h.b.x0.h.q)this).m5, (long)l);
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    protected final void b(U u2, boolean bl, h.b.u0.c c2) {
        c<? super V> c3 = this.C5;
        h.b.x0.c.n<U> n2 = this.D5;
        if (this.e()) {
            long l = ((h.b.x0.h.q)this).m5.get();
            if (l == 0L) {
                this.E5 = true;
                c2.dispose();
                c3.onError((Throwable)new MissingBackpressureException("Could not emit buffer due to lack of requests"));
                return;
            }
            if (n2.isEmpty()) {
                if (this.a(c3, u2) && l != Long.MAX_VALUE) {
                    this.a(1L);
                }
                if (this.a(-1) == 0) {
                    return;
                }
            } else {
                n2.offer(u2);
            }
        } else {
            n2.offer(u2);
            if (!this.a()) {
                return;
            }
        }
        v.a(n2, c3, (boolean)bl, (h.b.u0.c)c2, (u)this);
    }

    public final boolean b() {
        return this.F5;
    }

    public final boolean d() {
        return this.E5;
    }

    public final boolean e() {
        return ((s)this).W4.get() == 0 && ((s)this).W4.compareAndSet(0, 1);
    }

    public final Throwable error() {
        return this.G5;
    }

    public final long requested() {
        return ((h.b.x0.h.q)this).m5.get();
    }
}

