/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import org.simpleframework.xml.core.Contact;

class ContactMap
extends LinkedHashMap<Object, Contact>
implements Iterable<Contact> {
    ContactMap() {
    }

    public Iterator<Contact> iterator() {
        return this.values().iterator();
    }
}

