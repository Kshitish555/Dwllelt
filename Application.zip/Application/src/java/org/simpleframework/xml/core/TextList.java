/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import org.simpleframework.xml.core.ClassType;
import org.simpleframework.xml.core.CollectionFactory;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.Primitive;
import org.simpleframework.xml.core.Repeater;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;

class TextList
implements Repeater {
    private final CollectionFactory factory;
    private final Primitive primitive;
    private final Type type = new ClassType(String.class);

    public TextList(Context context, Type type, Label label) {
        this.factory = new CollectionFactory(context, type);
        this.primitive = new Primitive(context, this.type);
    }

    public Object read(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        Object object = instance.getInstance();
        if (instance.isReference()) {
            return instance.getInstance();
        }
        return this.read(inputNode, object);
    }

    @Override
    public Object read(InputNode inputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        Object object2 = this.primitive.read(inputNode);
        if (object2 != null) {
            collection.add(object2);
        }
        return object;
    }

    public boolean validate(InputNode inputNode) throws Exception {
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        OutputNode outputNode2 = outputNode.getParent();
        for (Object object2 : collection) {
            this.primitive.write(outputNode2, object2);
        }
    }
}

