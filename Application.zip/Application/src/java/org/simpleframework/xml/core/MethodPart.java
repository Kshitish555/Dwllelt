/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import org.simpleframework.xml.core.MethodType;

interface MethodPart {
    public Annotation getAnnotation();

    public <T extends Annotation> T getAnnotation(Class<T> var1);

    public Class getDeclaringClass();

    public Class getDependent();

    public Class[] getDependents();

    public Method getMethod();

    public MethodType getMethodType();

    public String getName();

    public Class getType();

    public String toString();
}

