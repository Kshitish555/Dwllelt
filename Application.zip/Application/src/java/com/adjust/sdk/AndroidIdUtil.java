/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings;

public class AndroidIdUtil {
    public static String getAndroidId(Context context) {
        return Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"android_id");
    }
}

