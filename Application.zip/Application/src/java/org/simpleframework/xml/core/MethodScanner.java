/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 *  java.util.Iterator
 *  java.util.List
 *  org.simpleframework.xml.Attribute
 *  org.simpleframework.xml.DefaultType
 *  org.simpleframework.xml.Element
 *  org.simpleframework.xml.ElementArray
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementListUnion
 *  org.simpleframework.xml.ElementMap
 *  org.simpleframework.xml.ElementMapUnion
 *  org.simpleframework.xml.ElementUnion
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.Transient
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.ContactList
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.MethodContact
 *  org.simpleframework.xml.core.MethodDetail
 *  org.simpleframework.xml.core.MethodPart
 *  org.simpleframework.xml.core.MethodPartFactory
 *  org.simpleframework.xml.core.MethodScanner$1
 *  org.simpleframework.xml.core.MethodScanner$PartMap
 *  org.simpleframework.xml.core.MethodType
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementArray;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementListUnion;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.ElementMapUnion;
import org.simpleframework.xml.ElementUnion;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.Transient;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.ContactList;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.MethodContact;
import org.simpleframework.xml.core.MethodDetail;
import org.simpleframework.xml.core.MethodException;
import org.simpleframework.xml.core.MethodPart;
import org.simpleframework.xml.core.MethodPartFactory;
import org.simpleframework.xml.core.MethodScanner;
import org.simpleframework.xml.core.MethodType;
import org.simpleframework.xml.core.Support;

/*
 * Exception performing whole class analysis.
 */
class MethodScanner
extends ContactList {
    private final Detail detail;
    private final MethodPartFactory factory;
    private final PartMap read;
    private final Support support;
    private final PartMap write;

    public MethodScanner(Detail detail, Support support) throws Exception {
        this.factory = new MethodPartFactory(detail, support);
        this.write = new /* Unavailable Anonymous Inner Class!! */;
        this.read = new /* Unavailable Anonymous Inner Class!! */;
        this.support = support;
        this.detail = detail;
        this.scan(detail);
    }

    private void build() throws Exception {
        for (String string2 : this.read) {
            MethodPart methodPart = (MethodPart)this.read.get((Object)string2);
            if (methodPart == null) continue;
            this.build(methodPart, string2);
        }
    }

    private void build(MethodPart methodPart) throws Exception {
        this.add((Object)new MethodContact(methodPart));
    }

    private void build(MethodPart methodPart, String string2) throws Exception {
        MethodPart methodPart2 = this.write.take(string2);
        if (methodPart2 != null) {
            this.build(methodPart, methodPart2);
            return;
        }
        this.build(methodPart);
    }

    private void build(MethodPart methodPart, MethodPart methodPart2) throws Exception {
        Annotation annotation = methodPart.getAnnotation();
        String string2 = methodPart.getName();
        if (methodPart2.getAnnotation().equals((Object)annotation)) {
            Class class_ = methodPart.getType();
            if (class_ == methodPart2.getType()) {
                this.add((Object)new MethodContact(methodPart, methodPart2));
                return;
            }
            throw new MethodException("Method types do not match for %s in %s", new Object[]{string2, class_});
        }
        Object[] arrobject = new Object[]{string2, this.detail};
        throw new MethodException("Annotations do not match for '%s' in %s", arrobject);
    }

    private void extend(Class class_, DefaultType defaultType) throws Exception {
        Iterator iterator = this.support.getMethods(class_, defaultType).iterator();
        while (iterator.hasNext()) {
            this.process((MethodContact)((Contact)iterator.next()));
        }
    }

    private void extract(Detail detail) throws Exception {
        for (MethodDetail methodDetail : detail.getMethods()) {
            Annotation[] arrannotation = methodDetail.getAnnotations();
            Method method = methodDetail.getMethod();
            int n = arrannotation.length;
            for (int i = 0; i < n; ++i) {
                this.scan(method, arrannotation[i], arrannotation);
            }
        }
    }

    private void extract(Detail detail, DefaultType defaultType) throws Exception {
        List list = detail.getMethods();
        if (defaultType == DefaultType.PROPERTY) {
            for (MethodDetail methodDetail : list) {
                Annotation[] arrannotation = methodDetail.getAnnotations();
                Method method = methodDetail.getMethod();
                if (this.factory.getType(method) == null) continue;
                this.process(method, arrannotation);
            }
        }
    }

    private void insert(MethodPart methodPart, PartMap partMap) {
        String string2 = methodPart.getName();
        MethodPart methodPart2 = (MethodPart)partMap.remove((Object)string2);
        if (methodPart2 != null && this.isText(methodPart)) {
            methodPart = methodPart2;
        }
        partMap.put((Object)string2, (Object)methodPart);
    }

    private boolean isText(MethodPart methodPart) {
        return methodPart.getAnnotation() instanceof Text;
    }

    private void process(Method method, Annotation annotation, Annotation[] arrannotation) throws Exception {
        MethodPart methodPart = this.factory.getInstance(method, annotation, arrannotation);
        MethodType methodType = methodPart.getMethodType();
        if (methodType == MethodType.GET) {
            this.process(methodPart, this.read);
        }
        if (methodType == MethodType.IS) {
            this.process(methodPart, this.read);
        }
        if (methodType == MethodType.SET) {
            this.process(methodPart, this.write);
        }
    }

    private void process(Method method, Annotation[] arrannotation) throws Exception {
        MethodPart methodPart = this.factory.getInstance(method, arrannotation);
        MethodType methodType = methodPart.getMethodType();
        if (methodType == MethodType.GET) {
            this.process(methodPart, this.read);
        }
        if (methodType == MethodType.IS) {
            this.process(methodPart, this.read);
        }
        if (methodType == MethodType.SET) {
            this.process(methodPart, this.write);
        }
    }

    private void process(MethodContact methodContact) {
        MethodPart methodPart = methodContact.getRead();
        MethodPart methodPart2 = methodContact.getWrite();
        if (methodPart2 != null) {
            this.insert(methodPart2, this.write);
        }
        this.insert(methodPart, this.read);
    }

    private void process(MethodPart methodPart, PartMap partMap) {
        String string2 = methodPart.getName();
        if (string2 != null) {
            partMap.put((Object)string2, (Object)methodPart);
        }
    }

    private void remove(Method method, Annotation annotation, Annotation[] arrannotation) throws Exception {
        MethodPart methodPart = this.factory.getInstance(method, annotation, arrannotation);
        MethodType methodType = methodPart.getMethodType();
        if (methodType == MethodType.GET) {
            this.remove(methodPart, this.read);
        }
        if (methodType == MethodType.IS) {
            this.remove(methodPart, this.read);
        }
        if (methodType == MethodType.SET) {
            this.remove(methodPart, this.write);
        }
    }

    private void remove(MethodPart methodPart, PartMap partMap) throws Exception {
        String string2 = methodPart.getName();
        if (string2 != null) {
            partMap.remove((Object)string2);
        }
    }

    private void scan(Method method, Annotation annotation, Annotation[] arrannotation) throws Exception {
        if (annotation instanceof Attribute) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof ElementUnion) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof ElementListUnion) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof ElementMapUnion) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof ElementList) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof ElementArray) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof ElementMap) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof Element) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof Version) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof Text) {
            this.process(method, annotation, arrannotation);
        }
        if (annotation instanceof Transient) {
            this.remove(method, annotation, arrannotation);
        }
    }

    private void scan(Detail detail) throws Exception {
        DefaultType defaultType = detail.getOverride();
        DefaultType defaultType2 = detail.getAccess();
        Class class_ = detail.getSuper();
        if (class_ != null) {
            this.extend(class_, defaultType);
        }
        this.extract(detail, defaultType2);
        this.extract(detail);
        this.build();
        this.validate();
    }

    private void validate() throws Exception {
        for (String string2 : this.write) {
            MethodPart methodPart = (MethodPart)this.write.get((Object)string2);
            if (methodPart == null) continue;
            this.validate(methodPart, string2);
        }
    }

    private void validate(MethodPart methodPart, String string2) throws Exception {
        MethodPart methodPart2 = this.read.take(string2);
        Method method = methodPart.getMethod();
        if (methodPart2 != null) {
            return;
        }
        Object[] arrobject = new Object[]{method, this.detail};
        throw new MethodException("No matching get method for %s in %s", arrobject);
    }
}

