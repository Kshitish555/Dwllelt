/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  l.a.k.a.a
 *  l.a.k.a.k
 *  l.a.k.a.v
 *  l.a.k.a.x.n
 */
package l.a.k.a.x;

import l.a.k.a.a;
import l.a.k.a.k;
import l.a.k.a.v;
import l.a.k.a.x.n;
import l.a.k.a.x.o;

public class q
extends k {
    private final n c;

    protected q(int n2, k k2, n n3) {
        super(n2, k2);
        this.c = n3;
    }

    public q(k k2, n n2) {
        this(327680, k2, n2);
    }

    public a a(int n2, v v2, String string, boolean bl) {
        a a2 = super.a(n2, v2, this.c.b(string), bl);
        if (a2 == null) {
            return null;
        }
        return new o(a2, this.c);
    }

    public a a(String string, boolean bl) {
        a a2 = this.b.a(this.c.b(string), bl);
        if (a2 == null) {
            return null;
        }
        return new o(a2, this.c);
    }
}

