/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Message
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.annotation.c0
 *  androidx.annotation.h0
 *  androidx.annotation.i0
 *  androidx.annotation.w0
 *  androidx.core.util.Pools
 *  androidx.core.util.Pools$SynchronizedPool
 *  java.lang.ClassNotFoundException
 *  java.lang.InterruptedException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.concurrent.ArrayBlockingQueue
 */
package b.c.b;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.c0;
import androidx.annotation.h0;
import androidx.annotation.i0;
import androidx.annotation.w0;
import androidx.core.util.Pools;
import java.util.concurrent.ArrayBlockingQueue;

public final class a {
    private static final String e = "AsyncLayoutInflater";
    LayoutInflater a;
    Handler b;
    d c;
    private Handler.Callback d = new Handler.Callback(){

        public boolean handleMessage(Message message) {
            c c2 = (c)message.obj;
            if (c2.d == null) {
                c2.d = a.this.a.inflate(c2.c, c2.b, false);
            }
            c2.e.a(c2.d, c2.c, c2.b);
            a.this.c.b(c2);
            return true;
        }
    };

    public a(@h0 Context context) {
        this.a = new b(context);
        this.b = new Handler(this.d);
        this.c = d.c();
    }

    @w0
    public void a(@c0 int n2, @i0 ViewGroup viewGroup, @h0 e e2) {
        if (e2 != null) {
            c c2 = this.c.a();
            c2.a = this;
            c2.c = n2;
            c2.b = viewGroup;
            c2.e = e2;
            this.c.a(c2);
            return;
        }
        throw new NullPointerException("callback argument may not be null!");
    }

    private static class b
    extends LayoutInflater {
        private static final String[] a = new String[]{"android.widget.", "android.webkit.", "android.app."};

        b(Context context) {
            super(context);
        }

        public LayoutInflater cloneInContext(Context context) {
            return new b(context);
        }

        /*
         * Exception decompiling
         */
        protected View onCreateView(String var1, AttributeSet var2) throws ClassNotFoundException {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl25.1 : IINC : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
            // java.lang.Thread.run(Thread.java:764)
            throw new IllegalStateException("Decompilation failed");
        }
    }

    private static class c {
        a a;
        ViewGroup b;
        int c;
        View d;
        e e;

        c() {
        }
    }

    private static class d
    extends Thread {
        private static final d f;
        private ArrayBlockingQueue<c> c = new ArrayBlockingQueue(10);
        private Pools.SynchronizedPool<c> d = new Pools.SynchronizedPool(10);

        static {
            d d2;
            f = d2 = new d();
            d2.start();
        }

        private d() {
        }

        public static d c() {
            return f;
        }

        public c a() {
            c c2 = (c)this.d.c();
            if (c2 == null) {
                c2 = new c();
            }
            return c2;
        }

        public void a(c c2) {
            try {
                this.c.put((Object)c2);
                return;
            }
            catch (InterruptedException interruptedException) {
                throw new RuntimeException("Failed to enqueue async inflate request", (Throwable)interruptedException);
            }
        }

        public void b() {
            c c2;
            try {
                c2 = (c)this.c.take();
            }
            catch (InterruptedException interruptedException) {
                Log.w((String)a.e, (Throwable)interruptedException);
                return;
            }
            try {
                c2.d = c2.a.a.inflate(c2.c, c2.b, false);
            }
            catch (RuntimeException runtimeException) {
                Log.w((String)a.e, (String)"Failed to inflate resource in the background! Retrying on the UI thread", (Throwable)runtimeException);
            }
            Message.obtain((Handler)c2.a.b, (int)0, (Object)c2).sendToTarget();
        }

        public void b(c c2) {
            c2.e = null;
            c2.a = null;
            c2.b = null;
            c2.c = 0;
            c2.d = null;
            this.d.a((Object)c2);
        }

        public void run() {
            do {
                this.b();
            } while (true);
        }
    }

    public static interface e {
        public void a(@h0 View var1, @c0 int var2, @i0 ViewGroup var3);
    }

}

