/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.util.List
 *  org.simpleframework.xml.Attribute
 *  org.simpleframework.xml.Element
 *  org.simpleframework.xml.ElementArray
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementListUnion
 *  org.simpleframework.xml.ElementMap
 *  org.simpleframework.xml.ElementMapUnion
 *  org.simpleframework.xml.ElementUnion
 *  org.simpleframework.xml.Order
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.ExpressionBuilder
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.InstantiatorBuilder
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 *  org.simpleframework.xml.core.Model
 *  org.simpleframework.xml.core.ModelAssembler
 *  org.simpleframework.xml.core.PersistenceException
 *  org.simpleframework.xml.core.Policy
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementArray;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementListUnion;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.ElementMapUnion;
import org.simpleframework.xml.ElementUnion;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.AttributeException;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.ExpressionBuilder;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.InstantiatorBuilder;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.Model;
import org.simpleframework.xml.core.ModelAssembler;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Policy;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.Structure;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.core.TextException;
import org.simpleframework.xml.core.TreeModel;
import org.simpleframework.xml.core.UnionException;
import org.simpleframework.xml.strategy.Type;

class StructureBuilder {
    private ModelAssembler assembler;
    private LabelMap attributes;
    private ExpressionBuilder builder;
    private LabelMap elements;
    private Instantiator factory;
    private boolean primitive;
    private InstantiatorBuilder resolver;
    private Model root;
    private Scanner scanner;
    private Support support;
    private Label text;
    private LabelMap texts;
    private Label version;

    public StructureBuilder(Scanner scanner, Detail detail, Support support) throws Exception {
        ExpressionBuilder expressionBuilder;
        this.builder = expressionBuilder = new ExpressionBuilder(detail, support);
        this.assembler = new ModelAssembler(expressionBuilder, detail, support);
        this.resolver = new InstantiatorBuilder(scanner, detail);
        this.root = new TreeModel(scanner, detail);
        this.attributes = new LabelMap((Policy)scanner);
        this.elements = new LabelMap((Policy)scanner);
        this.texts = new LabelMap((Policy)scanner);
        this.scanner = scanner;
        this.support = support;
    }

    private Model create(Expression expression) throws Exception {
        Model model = this.root;
        while (model != null) {
            String string = expression.getPrefix();
            String string2 = expression.getFirst();
            int n = expression.getIndex();
            if (string2 != null) {
                model = model.register(string2, string, n);
            }
            if (!expression.isPath()) {
                return model;
            }
            expression = expression.getPath(1);
        }
        return model;
    }

    private boolean isAttribute(String string) throws Exception {
        Expression expression = this.builder.build(string);
        Model model = this.lookup(expression);
        if (model != null) {
            String string2 = expression.getLast();
            if (!expression.isPath()) {
                return model.isAttribute(string);
            }
            return model.isAttribute(string2);
        }
        return false;
    }

    private boolean isElement(String string) throws Exception {
        Expression expression = this.builder.build(string);
        Model model = this.lookup(expression);
        if (model != null) {
            String string2 = expression.getLast();
            int n = expression.getIndex();
            if (model.isElement(string2)) {
                return true;
            }
            if (model.isModel(string2)) {
                return !model.lookup(string2, n).isEmpty();
            }
        }
        return false;
    }

    private boolean isEmpty() {
        if (this.text != null) {
            return false;
        }
        return this.root.isEmpty();
    }

    private Model lookup(Expression expression) throws Exception {
        Expression expression2 = expression.getPath(0, 1);
        if (expression.isPath()) {
            return this.root.lookup(expression2);
        }
        return this.root;
    }

    private void process(Contact contact, Annotation annotation, LabelMap labelMap) throws Exception {
        Label label = this.support.getLabel(contact, annotation);
        String string = label.getPath();
        String string2 = label.getName();
        if (labelMap.get((Object)string) == null) {
            this.process(contact, label, labelMap);
            return;
        }
        throw new PersistenceException("Duplicate annotation of name '%s' on %s", new Object[]{string2, contact});
    }

    private void process(Contact contact, Label label, LabelMap labelMap) throws Exception {
        Expression expression = label.getExpression();
        String string = label.getPath();
        Model model = this.root;
        if (!expression.isEmpty()) {
            model = this.register(expression);
        }
        this.resolver.register(label);
        model.register(label);
        labelMap.put((Object)string, (Object)label);
    }

    private Model register(Expression expression) throws Exception {
        Model model = this.root.lookup(expression);
        if (model != null) {
            return model;
        }
        return this.create(expression);
    }

    private void text(Contact contact, Annotation annotation) throws Exception {
        Label label = this.support.getLabel(contact, annotation);
        Expression expression = label.getExpression();
        String string = label.getPath();
        Model model = this.root;
        if (!expression.isEmpty()) {
            model = this.register(expression);
        }
        if (this.texts.get((Object)string) == null) {
            this.resolver.register(label);
            model.register(label);
            this.texts.put((Object)string, (Object)label);
            return;
        }
        throw new TextException("Multiple text annotations in %s", new Object[]{annotation});
    }

    private void union(Contact contact, Annotation annotation, LabelMap labelMap) throws Exception {
        for (Label label : this.support.getLabels(contact, annotation)) {
            String string = label.getPath();
            String string2 = label.getName();
            if (labelMap.get((Object)string) == null) {
                this.process(contact, label, labelMap);
                continue;
            }
            throw new PersistenceException("Duplicate annotation of name '%s' on %s", new Object[]{string2, label});
        }
    }

    private void validateAttributes(Class class_, Order order) throws Exception {
        if (order != null) {
            for (String string : order.attributes()) {
                if (this.isAttribute(string)) {
                    continue;
                }
                throw new AttributeException("Ordered attribute '%s' missing in %s", new Object[]{string, class_});
            }
        }
    }

    private void validateElements(Class class_, Order order) throws Exception {
        if (order != null) {
            for (String string : order.elements()) {
                if (this.isElement(string)) {
                    continue;
                }
                throw new ElementException("Ordered element '%s' missing for %s", new Object[]{string, class_});
            }
        }
    }

    private void validateModel(Class class_) throws Exception {
        if (!this.root.isEmpty()) {
            this.root.validate(class_);
        }
    }

    private void validateText(Class class_) throws Exception {
        Label label = this.root.getText();
        if (label != null) {
            if (!label.isTextList()) {
                if (this.elements.isEmpty()) {
                    if (!this.root.isComposite()) {
                        return;
                    }
                    throw new TextException("Paths used with %s in %s", new Object[]{label, class_});
                }
                throw new TextException("Elements used with %s in %s", new Object[]{label, class_});
            }
        } else if (this.scanner.isEmpty()) {
            this.primitive = this.isEmpty();
        }
    }

    private void validateTextList(Class class_) throws Exception {
        Label label = this.root.getText();
        if (label != null && label.isTextList()) {
            Object object = label.getKey();
            for (Label label2 : this.elements) {
                if (label2.getKey().equals(object)) {
                    Class class_2 = label2.getDependent().getType();
                    if (class_2 != String.class) continue;
                    throw new TextException("Illegal entry of %s with text annotations on %s in %s", new Object[]{class_2, label, class_});
                }
                throw new TextException("Elements used with %s in %s", new Object[]{label, class_});
            }
            if (!this.root.isComposite()) {
                return;
            }
            throw new TextException("Paths used with %s in %s", new Object[]{label, class_});
        }
    }

    private void validateUnions(Class class_) throws Exception {
        for (Label label : this.elements) {
            String[] arrstring = label.getPaths();
            Contact contact = label.getContact();
            for (String string : arrstring) {
                Annotation annotation = contact.getAnnotation();
                Label label2 = (Label)this.elements.get((Object)string);
                if (label.isInline() == label2.isInline()) {
                    if (label.isRequired() == label2.isRequired()) {
                        continue;
                    }
                    throw new UnionException("Required must be consistent in %s for %s", new Object[]{annotation, contact});
                }
                throw new UnionException("Inline must be consistent in %s for %s", new Object[]{annotation, contact});
            }
        }
    }

    private void version(Contact contact, Annotation annotation) throws Exception {
        Label label = this.support.getLabel(contact, annotation);
        if (this.version == null) {
            this.version = label;
            return;
        }
        throw new AttributeException("Multiple version annotations in %s", new Object[]{annotation});
    }

    public void assemble(Class class_) throws Exception {
        Order order = this.scanner.getOrder();
        if (order != null) {
            this.assembler.assemble(this.root, order);
        }
    }

    public Structure build(Class class_) throws Exception {
        Structure structure = new Structure(this.factory, this.root, this.version, this.text, this.primitive);
        return structure;
    }

    public void commit(Class class_) throws Exception {
        if (this.factory == null) {
            this.factory = this.resolver.build();
        }
    }

    public void process(Contact contact, Annotation annotation) throws Exception {
        if (annotation instanceof Attribute) {
            this.process(contact, annotation, this.attributes);
        }
        if (annotation instanceof ElementUnion) {
            this.union(contact, annotation, this.elements);
        }
        if (annotation instanceof ElementListUnion) {
            this.union(contact, annotation, this.elements);
        }
        if (annotation instanceof ElementMapUnion) {
            this.union(contact, annotation, this.elements);
        }
        if (annotation instanceof ElementList) {
            this.process(contact, annotation, this.elements);
        }
        if (annotation instanceof ElementArray) {
            this.process(contact, annotation, this.elements);
        }
        if (annotation instanceof ElementMap) {
            this.process(contact, annotation, this.elements);
        }
        if (annotation instanceof Element) {
            this.process(contact, annotation, this.elements);
        }
        if (annotation instanceof Version) {
            this.version(contact, annotation);
        }
        if (annotation instanceof Text) {
            this.text(contact, annotation);
        }
    }

    public void validate(Class class_) throws Exception {
        Order order = this.scanner.getOrder();
        this.validateUnions(class_);
        this.validateElements(class_, order);
        this.validateAttributes(class_, order);
        this.validateModel(class_);
        this.validateText(class_);
        this.validateTextList(class_);
    }
}

