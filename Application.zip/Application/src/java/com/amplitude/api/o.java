/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.amplitude.api;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;

public class o
extends HandlerThread {
    private Handler c;

    public o(String string) {
        super(string);
    }

    private void b() {
        o o2 = this;
        synchronized (o2) {
            if (this.c == null) {
                this.c = new Handler(this.getLooper());
            }
            return;
        }
    }

    Handler a() {
        return this.c;
    }

    void a(Runnable runnable) {
        this.b();
        this.c.post(runnable);
    }

    void a(Runnable runnable, long l2) {
        this.b();
        this.c.postDelayed(runnable, l2);
    }

    void b(Runnable runnable) {
        this.b();
        this.c.removeCallbacks(runnable);
    }
}

