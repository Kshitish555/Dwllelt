/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteException
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import android.database.sqlite.SQLiteException;
import java.io.File;
import java.io.IOException;
import org.osmdroid.tileprovider.modules.DatabaseFileArchive;
import org.osmdroid.tileprovider.modules.GEMFFileArchive;
import org.osmdroid.tileprovider.modules.IArchiveFile;
import org.osmdroid.tileprovider.modules.MBTilesFileArchive;
import org.osmdroid.tileprovider.modules.ZipFileArchive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ArchiveFileFactory {
    private static final Logger logger = LoggerFactory.getLogger(ArchiveFileFactory.class);

    public static IArchiveFile getArchiveFile(File file) {
        if (file.getName().endsWith(".zip")) {
            try {
                ZipFileArchive zipFileArchive = ZipFileArchive.getZipFileArchive(file);
                return zipFileArchive;
            }
            catch (IOException iOException) {
                logger.error("Error opening ZIP file", (Throwable)iOException);
            }
        }
        if (file.getName().endsWith(".sqlite")) {
            try {
                DatabaseFileArchive databaseFileArchive = DatabaseFileArchive.getDatabaseFileArchive(file);
                return databaseFileArchive;
            }
            catch (SQLiteException sQLiteException) {
                logger.error("Error opening SQL file", (Throwable)sQLiteException);
            }
        }
        if (file.getName().endsWith(".mbtiles")) {
            try {
                MBTilesFileArchive mBTilesFileArchive = MBTilesFileArchive.getDatabaseFileArchive(file);
                return mBTilesFileArchive;
            }
            catch (SQLiteException sQLiteException) {
                logger.error("Error opening MBTiles SQLite file", (Throwable)sQLiteException);
            }
        }
        if (file.getName().endsWith(".gemf")) {
            try {
                GEMFFileArchive gEMFFileArchive = GEMFFileArchive.getGEMFFileArchive(file);
                return gEMFFileArchive;
            }
            catch (IOException iOException) {
                logger.error("Error opening GEMF file", (Throwable)iOException);
            }
        }
        return null;
    }
}

