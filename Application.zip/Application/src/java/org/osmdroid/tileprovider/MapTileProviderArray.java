/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.ConcurrentHashMap
 *  org.osmdroid.tileprovider.ExpirableBitmapDrawable
 *  org.osmdroid.tileprovider.IMapTileProviderCallback
 *  org.osmdroid.tileprovider.IRegisterReceiver
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.MapTileRequestState
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider;

import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import org.osmdroid.tileprovider.ExpirableBitmapDrawable;
import org.osmdroid.tileprovider.IMapTileProviderCallback;
import org.osmdroid.tileprovider.IRegisterReceiver;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.MapTileCache;
import org.osmdroid.tileprovider.MapTileProviderBase;
import org.osmdroid.tileprovider.MapTileRequestState;
import org.osmdroid.tileprovider.modules.MapTileModuleProviderBase;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MapTileProviderArray
extends MapTileProviderBase {
    private static final Logger logger = LoggerFactory.getLogger(MapTileProviderArray.class);
    protected final List<MapTileModuleProviderBase> mTileProviderList;
    private final ConcurrentHashMap<MapTileRequestState, MapTile> mWorking = new ConcurrentHashMap();

    protected MapTileProviderArray(ITileSource iTileSource, IRegisterReceiver iRegisterReceiver) {
        this(iTileSource, iRegisterReceiver, new MapTileModuleProviderBase[0]);
    }

    public MapTileProviderArray(ITileSource iTileSource, IRegisterReceiver iRegisterReceiver, MapTileModuleProviderBase[] arrmapTileModuleProviderBase) {
        ArrayList arrayList;
        super(iTileSource);
        this.mTileProviderList = arrayList = new ArrayList();
        Collections.addAll((Collection)arrayList, (Object[])arrmapTileModuleProviderBase);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void detach() {
        List<MapTileModuleProviderBase> list;
        List<MapTileModuleProviderBase> list2 = list = this.mTileProviderList;
        synchronized (list2) {
            Iterator iterator = this.mTileProviderList.iterator();
            while (iterator.hasNext()) {
                ((MapTileModuleProviderBase)iterator.next()).detach();
            }
            return;
        }
    }

    protected MapTileModuleProviderBase findNextAppropriateProvider(MapTileRequestState mapTileRequestState) {
        MapTileModuleProviderBase mapTileModuleProviderBase;
        while ((mapTileModuleProviderBase = mapTileRequestState.getNextProvider()) != null && (!this.getProviderExists(mapTileModuleProviderBase) || !this.useDataConnection() && mapTileModuleProviderBase.getUsesDataConnection())) {
        }
        return mapTileModuleProviderBase;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public Drawable getMapTile(MapTile mapTile) {
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap;
        List<MapTileModuleProviderBase> list;
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap2;
        Drawable drawable = this.mTileCache.getMapTile(mapTile);
        if (drawable != null && !ExpirableBitmapDrawable.isDrawableExpired((Drawable)drawable)) {
            return drawable;
        }
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap3 = concurrentHashMap2 = this.mWorking;
        // MONITORENTER : concurrentHashMap3
        boolean bl = this.mWorking.containsValue((Object)mapTile);
        // MONITOREXIT : concurrentHashMap3
        if (bl) return drawable;
        List<MapTileModuleProviderBase> list2 = list = this.mTileProviderList;
        // MONITORENTER : list2
        Object[] arrobject = new MapTileModuleProviderBase[this.mTileProviderList.size()];
        MapTileRequestState mapTileRequestState = new MapTileRequestState(mapTile, (MapTileModuleProviderBase[])this.mTileProviderList.toArray(arrobject), (IMapTileProviderCallback)this);
        // MONITOREXIT : list2
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap4 = concurrentHashMap = this.mWorking;
        // MONITORENTER : concurrentHashMap4
        if (this.mWorking.containsValue((Object)mapTile)) {
            // MONITOREXIT : concurrentHashMap4
            return null;
        }
        this.mWorking.put((Object)mapTileRequestState, (Object)mapTile);
        // MONITOREXIT : concurrentHashMap4
        MapTileModuleProviderBase mapTileModuleProviderBase = this.findNextAppropriateProvider(mapTileRequestState);
        if (mapTileModuleProviderBase != null) {
            mapTileModuleProviderBase.loadMapTileAsync(mapTileRequestState);
            return drawable;
        }
        this.mapTileRequestFailed(mapTileRequestState);
        return drawable;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getMaximumZoomLevel() {
        List<MapTileModuleProviderBase> list;
        List<MapTileModuleProviderBase> list2 = list = this.mTileProviderList;
        synchronized (list2) {
            Iterator iterator = this.mTileProviderList.iterator();
            int n2 = 0;
            while (iterator.hasNext()) {
                MapTileModuleProviderBase mapTileModuleProviderBase = (MapTileModuleProviderBase)iterator.next();
                if (mapTileModuleProviderBase.getMaximumZoomLevel() <= n2) continue;
                n2 = mapTileModuleProviderBase.getMaximumZoomLevel();
            }
            return n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public int getMinimumZoomLevel() {
        List<MapTileModuleProviderBase> list;
        List<MapTileModuleProviderBase> list2 = list = this.mTileProviderList;
        synchronized (list2) {
            Iterator iterator = this.mTileProviderList.iterator();
            int n2 = 22;
            while (iterator.hasNext()) {
                MapTileModuleProviderBase mapTileModuleProviderBase = (MapTileModuleProviderBase)iterator.next();
                if (mapTileModuleProviderBase.getMinimumZoomLevel() >= n2) continue;
                n2 = mapTileModuleProviderBase.getMinimumZoomLevel();
            }
            return n2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean getProviderExists(MapTileModuleProviderBase mapTileModuleProviderBase) {
        List<MapTileModuleProviderBase> list;
        List<MapTileModuleProviderBase> list2 = list = this.mTileProviderList;
        synchronized (list2) {
            return this.mTileProviderList.contains((Object)mapTileModuleProviderBase);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void mapTileRequestCompleted(MapTileRequestState mapTileRequestState, Drawable drawable) {
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap;
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap2 = concurrentHashMap = this.mWorking;
        synchronized (concurrentHashMap2) {
            this.mWorking.remove((Object)mapTileRequestState);
        }
        super.mapTileRequestCompleted(mapTileRequestState, drawable);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void mapTileRequestFailed(MapTileRequestState mapTileRequestState) {
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap;
        MapTileModuleProviderBase mapTileModuleProviderBase = this.findNextAppropriateProvider(mapTileRequestState);
        if (mapTileModuleProviderBase != null) {
            mapTileModuleProviderBase.loadMapTileAsync(mapTileRequestState);
            return;
        }
        ConcurrentHashMap<MapTileRequestState, MapTile> concurrentHashMap2 = concurrentHashMap = this.mWorking;
        synchronized (concurrentHashMap2) {
            this.mWorking.remove((Object)mapTileRequestState);
        }
        super.mapTileRequestFailed(mapTileRequestState);
    }

    @Override
    public void setTileSource(ITileSource iTileSource) {
        super.setTileSource(iTileSource);
        Iterator iterator = this.mTileProviderList.iterator();
        while (iterator.hasNext()) {
            ((MapTileModuleProviderBase)iterator.next()).setTileSource(iTileSource);
            this.clearTileCache();
        }
    }
}

