/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Arrays
 *  java.util.List
 */
package org.simpleframework.xml.core;

import java.util.Arrays;
import java.util.List;
import org.simpleframework.xml.core.Label;

class LabelGroup {
    private final List<Label> list;
    private final int size;

    public LabelGroup(List<Label> list) {
        this.size = list.size();
        this.list = list;
    }

    public LabelGroup(Label label) {
        this((List<Label>)Arrays.asList((Object[])new Label[]{label}));
    }

    public List<Label> getList() {
        return this.list;
    }

    public Label getPrimary() {
        if (this.size > 0) {
            return (Label)this.list.get(0);
        }
        return null;
    }
}

