/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Field
 *  java.lang.reflect.Modifier
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  org.simpleframework.xml.Attribute
 *  org.simpleframework.xml.DefaultType
 *  org.simpleframework.xml.Element
 *  org.simpleframework.xml.ElementArray
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementListUnion
 *  org.simpleframework.xml.ElementMap
 *  org.simpleframework.xml.ElementMapUnion
 *  org.simpleframework.xml.ElementUnion
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.Transient
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.AnnotationFactory
 *  org.simpleframework.xml.core.ContactList
 *  org.simpleframework.xml.core.ContactMap
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.FieldContact
 *  org.simpleframework.xml.core.FieldDetail
 *  org.simpleframework.xml.core.FieldScanner$FieldKey
 *  org.simpleframework.xml.core.Reflector
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementArray;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementListUnion;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.ElementMapUnion;
import org.simpleframework.xml.ElementUnion;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.Transient;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.AnnotationFactory;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.ContactList;
import org.simpleframework.xml.core.ContactMap;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.FieldContact;
import org.simpleframework.xml.core.FieldDetail;
import org.simpleframework.xml.core.FieldScanner;
import org.simpleframework.xml.core.Reflector;
import org.simpleframework.xml.core.Support;

/*
 * Exception performing whole class analysis.
 */
class FieldScanner
extends ContactList {
    private final ContactMap done;
    private final AnnotationFactory factory;
    private final Support support;

    public FieldScanner(Detail detail, Support support) throws Exception {
        this.factory = new AnnotationFactory(detail, support);
        this.done = new ContactMap();
        this.support = support;
        this.scan(detail);
    }

    private void build() {
        Iterator iterator = this.done.iterator();
        while (iterator.hasNext()) {
            this.add((Object)((Contact)iterator.next()));
        }
    }

    private void extend(Class class_, DefaultType defaultType) throws Exception {
        ContactList contactList = this.support.getFields(class_, defaultType);
        if (contactList != null) {
            this.addAll((Collection)contactList);
        }
    }

    private void extract(Detail detail) {
        for (FieldDetail fieldDetail : detail.getFields()) {
            Annotation[] arrannotation = fieldDetail.getAnnotations();
            Field field = fieldDetail.getField();
            int n = arrannotation.length;
            for (int i = 0; i < n; ++i) {
                this.scan(field, arrannotation[i], arrannotation);
            }
        }
    }

    private void extract(Detail detail, DefaultType defaultType) throws Exception {
        List list = detail.getFields();
        if (defaultType == DefaultType.FIELD) {
            for (FieldDetail fieldDetail : list) {
                Annotation[] arrannotation = fieldDetail.getAnnotations();
                Field field = fieldDetail.getField();
                Class class_ = field.getType();
                if (this.isStatic(field) || this.isTransient(field)) continue;
                this.process(field, class_, arrannotation);
            }
        }
    }

    private void insert(Object object, Contact contact) {
        Contact contact2 = (Contact)this.done.remove(object);
        if (contact2 != null && this.isText(contact)) {
            contact = contact2;
        }
        this.done.put(object, (Object)contact);
    }

    private boolean isStatic(Field field) {
        return Modifier.isStatic((int)field.getModifiers());
    }

    private boolean isText(Contact contact) {
        return contact.getAnnotation() instanceof Text;
    }

    private boolean isTransient(Field field) {
        return Modifier.isTransient((int)field.getModifiers());
    }

    private void process(Field field, Class class_, Annotation[] arrannotation) throws Exception {
        Class[] arrclass = Reflector.getDependents((Field)field);
        Annotation annotation = this.factory.getInstance(class_, arrclass);
        if (annotation != null) {
            this.process(field, annotation, arrannotation);
        }
    }

    private void process(Field field, Annotation annotation, Annotation[] arrannotation) {
        FieldContact fieldContact = new FieldContact(field, annotation, arrannotation);
        FieldKey fieldKey = new /* Unavailable Anonymous Inner Class!! */;
        if (!field.isAccessible()) {
            field.setAccessible(true);
        }
        this.insert((Object)fieldKey, (Contact)fieldContact);
    }

    private void remove(Field field, Annotation annotation) {
        this.done.remove((Object)new /* Unavailable Anonymous Inner Class!! */);
    }

    private void scan(Field field, Annotation annotation, Annotation[] arrannotation) {
        if (annotation instanceof Attribute) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof ElementUnion) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof ElementListUnion) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof ElementMapUnion) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof ElementList) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof ElementArray) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof ElementMap) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof Element) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof Version) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof Text) {
            this.process(field, annotation, arrannotation);
        }
        if (annotation instanceof Transient) {
            this.remove(field, annotation);
        }
    }

    private void scan(Detail detail) throws Exception {
        DefaultType defaultType = detail.getOverride();
        DefaultType defaultType2 = detail.getAccess();
        Class class_ = detail.getSuper();
        if (class_ != null) {
            this.extend(class_, defaultType);
        }
        this.extract(detail, defaultType2);
        this.extract(detail);
        this.build();
    }
}

