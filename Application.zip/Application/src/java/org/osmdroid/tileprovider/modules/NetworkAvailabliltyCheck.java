/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  java.lang.Object
 *  java.lang.String
 *  org.osmdroid.tileprovider.modules.INetworkAvailablityCheck
 */
package org.osmdroid.tileprovider.modules;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import org.osmdroid.tileprovider.modules.INetworkAvailablityCheck;

public class NetworkAvailabliltyCheck
implements INetworkAvailablityCheck {
    private final ConnectivityManager mConnectionManager;

    public NetworkAvailabliltyCheck(Context context) {
        this.mConnectionManager = (ConnectivityManager)context.getSystemService("connectivity");
    }

    public boolean getCellularDataNetworkAvailable() {
        NetworkInfo networkInfo = this.mConnectionManager.getNetworkInfo(0);
        boolean bl = false;
        if (networkInfo != null) {
            boolean bl2 = networkInfo.isAvailable();
            bl = false;
            if (bl2) {
                bl = true;
            }
        }
        return bl;
    }

    public boolean getNetworkAvailable() {
        NetworkInfo networkInfo = this.mConnectionManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isAvailable();
    }

    public boolean getRouteToPathExists(int n) {
        ConnectivityManager connectivityManager = this.mConnectionManager;
        boolean bl = true;
        if (!connectivityManager.requestRouteToHost((int)bl, n)) {
            if (this.mConnectionManager.requestRouteToHost(0, n)) {
                return bl;
            }
            bl = false;
        }
        return bl;
    }

    public boolean getWiFiNetworkAvailable() {
        NetworkInfo networkInfo = this.mConnectionManager.getNetworkInfo(1);
        return networkInfo != null && networkInfo.isAvailable();
    }
}

