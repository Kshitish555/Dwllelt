/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.i;

import l.a.h.k.c;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public class b
implements e {
    private final c c;

    protected b(c c2) {
        this.c = c2;
    }

    public static e a(l.a.h.k.b b2) {
        if (!b2.isPrimitive()) {
            return new b(b2.y0());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot cast to primitive type: ");
        stringBuilder.append((Object)b2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public e.c a(r r2, e.d d2) {
        r2.a(192, this.c.d());
        return f.d.f();
    }

    protected boolean b(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (!b2.b(this)) {
            return false;
        }
        c c2 = this.c;
        c c3 = b2.c;
        return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
    }

    public int hashCode() {
        c c2 = this.c;
        int n2 = c2 == null ? 43 : c2.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }
}

