/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.modules.IArchiveFile
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.util.GEMFFile
 */
package org.osmdroid.tileprovider.modules;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.modules.IArchiveFile;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.util.GEMFFile;

public class GEMFFileArchive
implements IArchiveFile {
    private final GEMFFile mFile;

    private GEMFFileArchive(File file) throws FileNotFoundException, IOException {
        this.mFile = new GEMFFile(file);
    }

    public static GEMFFileArchive getGEMFFileArchive(File file) throws FileNotFoundException, IOException {
        return new GEMFFileArchive(file);
    }

    public InputStream getInputStream(ITileSource iTileSource, MapTile mapTile) {
        return this.mFile.getInputStream(mapTile.getX(), mapTile.getY(), mapTile.getZoomLevel());
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("GEMFFileArchive [mGEMFFile=");
        stringBuilder.append(this.mFile.getName());
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

