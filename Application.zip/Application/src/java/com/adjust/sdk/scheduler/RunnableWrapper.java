/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;

public class RunnableWrapper
implements Runnable {
    private Runnable runnable;

    RunnableWrapper(Runnable runnable) {
        this.runnable = runnable;
    }

    public void run() {
        try {
            this.runnable.run();
            return;
        }
        catch (Throwable throwable) {
            ILogger iLogger = AdjustFactory.getLogger();
            Object[] arrobject = new Object[]{throwable.getMessage(), throwable.getClass().getCanonicalName()};
            iLogger.error("Runnable error [%s] of type [%s]", arrobject);
            return;
        }
    }
}

