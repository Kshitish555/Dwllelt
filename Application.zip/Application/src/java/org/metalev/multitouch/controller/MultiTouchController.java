/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  android.view.MotionEvent
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 */
package org.metalev.multitouch.controller;

import android.util.Log;
import android.view.MotionEvent;
import java.lang.reflect.Method;

public class MultiTouchController<T> {
    private static int ACTION_POINTER_INDEX_SHIFT = 8;
    private static int ACTION_POINTER_UP = 6;
    public static final boolean DEBUG = false;
    private static final long EVENT_SETTLE_TIME_INTERVAL = 20L;
    private static final float MAX_MULTITOUCH_DIM_JUMP_SIZE = 40.0f;
    private static final float MAX_MULTITOUCH_POS_JUMP_SIZE = 30.0f;
    public static final int MAX_TOUCH_POINTS = 20;
    private static final float MIN_MULTITOUCH_SEPARATION = 30.0f;
    private static final int MODE_DRAG = 1;
    private static final int MODE_NOTHING = 0;
    private static final int MODE_PINCH = 2;
    private static Method m_getHistoricalPressure;
    private static Method m_getHistoricalX;
    private static Method m_getHistoricalY;
    private static Method m_getPointerCount;
    private static Method m_getPointerId;
    private static Method m_getPressure;
    private static Method m_getX;
    private static Method m_getY;
    public static final boolean multiTouchSupported;
    private static final int[] pointerIds;
    private static final float[] pressureVals;
    private static final float[] xVals;
    private static final float[] yVals;
    private boolean handleSingleTouchEvents;
    private PointInfo mCurrPt = new PointInfo();
    private float mCurrPtAng;
    private float mCurrPtDiam;
    private float mCurrPtHeight;
    private float mCurrPtWidth;
    private float mCurrPtX;
    private float mCurrPtY;
    private PositionAndScale mCurrXform = new PositionAndScale();
    private int mMode = 0;
    private PointInfo mPrevPt = new PointInfo();
    private long mSettleEndTime;
    private long mSettleStartTime;
    MultiTouchObjectCanvas<T> objectCanvas;
    private T selectedObject = null;
    private float startAngleMinusPinchAngle;
    private float startPosX;
    private float startPosY;
    private float startScaleOverPinchDiam;
    private float startScaleXOverPinchWidth;
    private float startScaleYOverPinchHeight;

    /*
     * Exception decompiling
     */
    static {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public MultiTouchController(MultiTouchObjectCanvas<T> multiTouchObjectCanvas) {
        this(multiTouchObjectCanvas, true);
    }

    public MultiTouchController(MultiTouchObjectCanvas<T> multiTouchObjectCanvas, boolean bl) {
        this.handleSingleTouchEvents = bl;
        this.objectCanvas = multiTouchObjectCanvas;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void anchorAtThisPositionAndScale() {
        T t2 = this.selectedObject;
        if (t2 == null) {
            return;
        }
        this.objectCanvas.getPositionAndScale(t2, this.mCurrXform);
        float f2 = !this.mCurrXform.updateScale || this.mCurrXform.scale == 0.0f ? 1.0f : this.mCurrXform.scale;
        float f3 = 1.0f / f2;
        this.extractCurrPtInfo();
        this.startPosX = f3 * (this.mCurrPtX - this.mCurrXform.xOff);
        this.startPosY = f3 * (this.mCurrPtY - this.mCurrXform.yOff);
        this.startScaleOverPinchDiam = this.mCurrXform.scale / this.mCurrPtDiam;
        this.startScaleXOverPinchWidth = this.mCurrXform.scaleX / this.mCurrPtWidth;
        this.startScaleYOverPinchHeight = this.mCurrXform.scaleY / this.mCurrPtHeight;
        this.startAngleMinusPinchAngle = this.mCurrXform.angle - this.mCurrPtAng;
    }

    private void decodeTouchEvent(int n2, float[] arrf, float[] arrf2, float[] arrf3, int[] arrn, int n3, boolean bl, long l2) {
        PointInfo pointInfo = this.mPrevPt;
        this.mPrevPt = this.mCurrPt;
        this.mCurrPt = pointInfo;
        pointInfo.set(n2, arrf, arrf2, arrf3, arrn, n3, bl, l2);
        this.multiTouchController();
    }

    private void extractCurrPtInfo() {
        this.mCurrPtX = this.mCurrPt.getX();
        this.mCurrPtY = this.mCurrPt.getY();
        float f2 = !this.mCurrXform.updateScale ? 0.0f : this.mCurrPt.getMultiTouchDiameter();
        this.mCurrPtDiam = Math.max((float)21.3f, (float)f2);
        float f3 = !this.mCurrXform.updateScaleXY ? 0.0f : this.mCurrPt.getMultiTouchWidth();
        this.mCurrPtWidth = Math.max((float)30.0f, (float)f3);
        float f4 = !this.mCurrXform.updateScaleXY ? 0.0f : this.mCurrPt.getMultiTouchHeight();
        this.mCurrPtHeight = Math.max((float)30.0f, (float)f4);
        float f5 = !this.mCurrXform.updateAngle ? 0.0f : this.mCurrPt.getMultiTouchAngle();
        this.mCurrPtAng = f5;
    }

    private void multiTouchController() {
        int n2 = this.mMode;
        if (n2 != 0) {
            if (n2 != 1) {
                long l2;
                if (n2 != 2) {
                    return;
                }
                if (this.mCurrPt.isMultiTouch() && this.mCurrPt.isDown()) {
                    long l3;
                    if (!(Math.abs((float)(this.mCurrPt.getX() - this.mPrevPt.getX())) > 30.0f || Math.abs((float)(this.mCurrPt.getY() - this.mPrevPt.getY())) > 30.0f || 0.5f * Math.abs((float)(this.mCurrPt.getMultiTouchWidth() - this.mPrevPt.getMultiTouchWidth())) > 40.0f || 0.5f * Math.abs((float)(this.mCurrPt.getMultiTouchHeight() - this.mPrevPt.getMultiTouchHeight())) > 40.0f)) {
                        if (this.mCurrPt.eventTime < this.mSettleEndTime) {
                            this.anchorAtThisPositionAndScale();
                            return;
                        }
                        this.performDragOrPinch();
                        return;
                    }
                    this.anchorAtThisPositionAndScale();
                    this.mSettleStartTime = l3 = this.mCurrPt.getEventTime();
                    this.mSettleEndTime = l3 + 20L;
                    return;
                }
                if (!this.mCurrPt.isDown()) {
                    this.mMode = 0;
                    MultiTouchObjectCanvas<Object> multiTouchObjectCanvas = this.objectCanvas;
                    this.selectedObject = null;
                    multiTouchObjectCanvas.selectObject(null, this.mCurrPt);
                    return;
                }
                this.mMode = 1;
                this.anchorAtThisPositionAndScale();
                this.mSettleStartTime = l2 = this.mCurrPt.getEventTime();
                this.mSettleEndTime = l2 + 20L;
                return;
            }
            if (!this.mCurrPt.isDown()) {
                this.mMode = 0;
                MultiTouchObjectCanvas<Object> multiTouchObjectCanvas = this.objectCanvas;
                this.selectedObject = null;
                multiTouchObjectCanvas.selectObject(null, this.mCurrPt);
                return;
            }
            if (this.mCurrPt.isMultiTouch()) {
                long l4;
                this.mMode = 2;
                this.anchorAtThisPositionAndScale();
                this.mSettleStartTime = l4 = this.mCurrPt.getEventTime();
                this.mSettleEndTime = l4 + 20L;
                return;
            }
            if (this.mCurrPt.getEventTime() < this.mSettleEndTime) {
                this.anchorAtThisPositionAndScale();
                return;
            }
            this.performDragOrPinch();
            return;
        }
        if (this.mCurrPt.isDown()) {
            T t2 = this.objectCanvas.getDraggableObjectAtPoint(this.mCurrPt);
            this.selectedObject = t2;
            if (t2 != null) {
                long l5;
                this.mMode = 1;
                this.objectCanvas.selectObject(t2, this.mCurrPt);
                this.anchorAtThisPositionAndScale();
                this.mSettleEndTime = l5 = this.mCurrPt.getEventTime();
                this.mSettleStartTime = l5;
            }
        }
    }

    private void performDragOrPinch() {
        if (this.selectedObject == null) {
            return;
        }
        boolean bl = this.mCurrXform.updateScale;
        float f2 = 1.0f;
        if (bl && this.mCurrXform.scale != 0.0f) {
            f2 = this.mCurrXform.scale;
        }
        this.extractCurrPtInfo();
        float f3 = this.mCurrPtX - f2 * this.startPosX;
        float f4 = this.mCurrPtY - f2 * this.startPosY;
        float f5 = this.startScaleOverPinchDiam * this.mCurrPtDiam;
        float f6 = this.startScaleXOverPinchWidth * this.mCurrPtWidth;
        float f7 = this.startScaleYOverPinchHeight * this.mCurrPtHeight;
        float f8 = this.startAngleMinusPinchAngle + this.mCurrPtAng;
        this.mCurrXform.set(f3, f4, f5, f6, f7, f8);
        this.objectCanvas.setPositionAndScale(this.selectedObject, this.mCurrXform, this.mCurrPt);
    }

    protected boolean getHandleSingleTouchEvents() {
        return this.handleSingleTouchEvents;
    }

    public boolean isPinching() {
        return this.mMode == 2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public boolean onTouchEvent(MotionEvent var1_1) {
        block15 : {
            block16 : {
                block14 : {
                    try {
                        var4_2 = MultiTouchController.multiTouchSupported != false ? (Integer)MultiTouchController.m_getPointerCount.invoke((Object)var1_1, new Object[0]) : 1;
                        if (this.mMode == 0 && !this.handleSingleTouchEvents && var4_2 == 1) {
                            return false;
                        }
                        var5_3 = var1_1.getAction();
                        var6_4 = var1_1.getHistorySize() / var4_2;
                        var7_5 = 0;
                        break block14;
lbl9: // 2 sources:
                        do {
                            if (MultiTouchController.multiTouchSupported && var4_2 != 1) {
                                var9_7 = Math.min((int)var4_2, (int)20);
                                var10_8 = 0;
                                break block15;
                            }
                            var47_43 = MultiTouchController.xVals;
                            var48_44 = var8_6 != false ? var1_1.getHistoricalX(var7_5) : var1_1.getX();
                            var47_43[0] = var48_44;
                            var49_45 = MultiTouchController.yVals;
                            var50_46 = var8_6 != false ? var1_1.getHistoricalY(var7_5) : var1_1.getY();
                            var49_45[0] = var50_46;
                            var51_47 = MultiTouchController.pressureVals;
                            var52_48 = var8_6 != false ? var1_1.getHistoricalPressure(var7_5) : var1_1.getPressure();
                            var51_47[0] = var52_48;
                            do {
                                var32_30 = MultiTouchController.xVals;
                                var33_31 = MultiTouchController.yVals;
                                var34_32 = MultiTouchController.pressureVals;
                                var35_33 = MultiTouchController.pointerIds;
                                var36_34 = var8_6 != false ? 2 : var5_3;
                                break;
                            } while (true);
                            break;
                        } while (true);
                    }
                    catch (Exception var2_49) {
                        Log.e((String)"MultiTouchController", (String)"onTouchEvent() failed", (Throwable)var2_49);
                        return false;
                    }
                    var37_35 = var8_6 != false || var5_3 != 1 && (var5_3 & (1 << MultiTouchController.ACTION_POINTER_INDEX_SHIFT) - 1) != MultiTouchController.ACTION_POINTER_UP && var5_3 != 3;
                    var38_36 = var8_6 != false ? var1_1.getHistoricalEventTime(var7_5) : var1_1.getEventTime();
                    var40_37 = var38_36;
                    var42_38 = var4_2;
                    var43_39 = var36_34;
                    var44_40 = var37_35;
                    var45_41 = var6_4;
                    var46_42 = var7_5;
                    this.decodeTouchEvent(var42_38, var32_30, var33_31, var34_32, var35_33, var43_39, var44_40, var40_37);
                    var7_5 = var46_42 + 1;
                    var6_4 = var45_41;
                }
                if (var7_5 > var6_4) return true;
                if (var7_5 >= var6_4) break block16;
                var8_6 = true;
                ** GOTO lbl9
            }
            var8_6 = false;
            ** while (true)
        }
        do {
            if (var10_8 >= var9_7) ** continue;
            var11_9 = MultiTouchController.m_getPointerId;
            var12_10 = new Object[]{var10_8};
            MultiTouchController.pointerIds[var10_8] = var13_11 = ((Integer)var11_9.invoke((Object)var1_1, var12_10)).intValue();
            var14_12 = MultiTouchController.xVals;
            if (var8_6) {
                var15_13 = MultiTouchController.m_getHistoricalX;
                var16_14 = new Object[]{var10_8, var7_5};
                var17_15 = var15_13.invoke((Object)var1_1, var16_14);
            } else {
                var30_28 = MultiTouchController.m_getX;
                var31_29 = new Object[]{var10_8};
                var17_15 = var30_28.invoke((Object)var1_1, var31_29);
            }
            var14_12[var10_8] = ((Float)var17_15).floatValue();
            var18_16 = MultiTouchController.yVals;
            if (var8_6) {
                var19_17 = MultiTouchController.m_getHistoricalY;
                var20_18 = new Object[]{var10_8, var7_5};
                var21_19 = var19_17.invoke((Object)var1_1, var20_18);
            } else {
                var28_26 = MultiTouchController.m_getY;
                var29_27 = new Object[]{var10_8};
                var21_19 = var28_26.invoke((Object)var1_1, var29_27);
            }
            var18_16[var10_8] = ((Float)var21_19).floatValue();
            var22_20 = MultiTouchController.pressureVals;
            if (var8_6) {
                var23_21 = MultiTouchController.m_getHistoricalPressure;
                var24_22 = new Object[]{var10_8, var7_5};
                var25_23 = var23_21.invoke((Object)var1_1, var24_22);
            } else {
                var26_24 = MultiTouchController.m_getPressure;
                var27_25 = new Object[]{var10_8};
                var25_23 = var26_24.invoke((Object)var1_1, var27_25);
            }
            var22_20[var10_8] = ((Float)var25_23).floatValue();
            ++var10_8;
        } while (true);
    }

    protected void setHandleSingleTouchEvents(boolean bl) {
        this.handleSingleTouchEvents = bl;
    }

    public static interface MultiTouchObjectCanvas<T> {
        public T getDraggableObjectAtPoint(PointInfo var1);

        public void getPositionAndScale(T var1, PositionAndScale var2);

        public void selectObject(T var1, PointInfo var2);

        public boolean setPositionAndScale(T var1, PositionAndScale var2, PointInfo var3);
    }

    public static class PointInfo {
        private int action;
        private float angle;
        private boolean angleIsCalculated;
        private float diameter;
        private boolean diameterIsCalculated;
        private float diameterSq;
        private boolean diameterSqIsCalculated;
        private float dx;
        private float dy;
        private long eventTime;
        private boolean isDown;
        private boolean isMultiTouch;
        private int numPoints;
        private int[] pointerIds = new int[20];
        private float pressureMid;
        private float[] pressures = new float[20];
        private float xMid;
        private float[] xs = new float[20];
        private float yMid;
        private float[] ys = new float[20];

        private int julery_isqrt(int n2) {
            int n3 = 0;
            int n4 = 32768;
            int n5 = 15;
            do {
                int n6 = n4 + (n3 << 1);
                int n7 = n5 - 1;
                int n8 = n6 << n5;
                if (n2 >= n8) {
                    n3 += n4;
                    n2 -= n8;
                }
                if ((n4 >>= 1) <= 0) {
                    return n3;
                }
                n5 = n7;
            } while (true);
        }

        private void set(int n2, float[] arrf, float[] arrf2, float[] arrf3, int[] arrn, int n3, boolean bl, long l2) {
            this.eventTime = l2;
            this.action = n3;
            this.numPoints = n2;
            for (int i2 = 0; i2 < n2; ++i2) {
                this.xs[i2] = arrf[i2];
                this.ys[i2] = arrf2[i2];
                this.pressures[i2] = arrf3[i2];
                this.pointerIds[i2] = arrn[i2];
            }
            this.isDown = bl;
            boolean bl2 = n2 >= 2;
            this.isMultiTouch = bl2;
            if (bl2) {
                this.xMid = 0.5f * (arrf[0] + arrf[1]);
                this.yMid = 0.5f * (arrf2[0] + arrf2[1]);
                this.pressureMid = 0.5f * (arrf3[0] + arrf3[1]);
                this.dx = Math.abs((float)(arrf[1] - arrf[0]));
                this.dy = Math.abs((float)(arrf2[1] - arrf2[0]));
            } else {
                this.xMid = arrf[0];
                this.yMid = arrf2[0];
                this.pressureMid = arrf3[0];
                this.dy = 0.0f;
                this.dx = 0.0f;
            }
            this.angleIsCalculated = false;
            this.diameterIsCalculated = false;
            this.diameterSqIsCalculated = false;
        }

        public int getAction() {
            return this.action;
        }

        public long getEventTime() {
            return this.eventTime;
        }

        public float getMultiTouchAngle() {
            if (!this.angleIsCalculated) {
                if (!this.isMultiTouch) {
                    this.angle = 0.0f;
                } else {
                    float[] arrf = this.ys;
                    double d2 = arrf[1] - arrf[0];
                    float[] arrf2 = this.xs;
                    this.angle = (float)Math.atan2((double)d2, (double)(arrf2[1] - arrf2[0]));
                }
                this.angleIsCalculated = true;
            }
            return this.angle;
        }

        public float getMultiTouchDiameter() {
            if (!this.diameterIsCalculated) {
                if (!this.isMultiTouch) {
                    this.diameter = 0.0f;
                } else {
                    float f2;
                    float f3;
                    float f4 = this.getMultiTouchDiameterSq();
                    float f5 = f4 == 0.0f ? 0.0f : (float)this.julery_isqrt((int)(f4 * 256.0f)) / 16.0f;
                    this.diameter = f5;
                    float f6 = this.dx;
                    if (f5 < f6) {
                        this.diameter = f6;
                    }
                    if ((f2 = this.diameter) < (f3 = this.dy)) {
                        this.diameter = f3;
                    }
                }
                this.diameterIsCalculated = true;
            }
            return this.diameter;
        }

        public float getMultiTouchDiameterSq() {
            if (!this.diameterSqIsCalculated) {
                float f2;
                if (this.isMultiTouch) {
                    float f3 = this.dx;
                    float f4 = f3 * f3;
                    float f5 = this.dy;
                    f2 = f4 + f5 * f5;
                } else {
                    f2 = 0.0f;
                }
                this.diameterSq = f2;
                this.diameterSqIsCalculated = true;
            }
            return this.diameterSq;
        }

        public float getMultiTouchHeight() {
            if (this.isMultiTouch) {
                return this.dy;
            }
            return 0.0f;
        }

        public float getMultiTouchWidth() {
            if (this.isMultiTouch) {
                return this.dx;
            }
            return 0.0f;
        }

        public int getNumTouchPoints() {
            return this.numPoints;
        }

        public int[] getPointerIds() {
            return this.pointerIds;
        }

        public float getPressure() {
            return this.pressureMid;
        }

        public float[] getPressures() {
            return this.pressures;
        }

        public float getX() {
            return this.xMid;
        }

        public float[] getXs() {
            return this.xs;
        }

        public float getY() {
            return this.yMid;
        }

        public float[] getYs() {
            return this.ys;
        }

        public boolean isDown() {
            return this.isDown;
        }

        public boolean isMultiTouch() {
            return this.isMultiTouch;
        }

        public void set(PointInfo pointInfo) {
            this.numPoints = pointInfo.numPoints;
            for (int i2 = 0; i2 < this.numPoints; ++i2) {
                this.xs[i2] = pointInfo.xs[i2];
                this.ys[i2] = pointInfo.ys[i2];
                this.pressures[i2] = pointInfo.pressures[i2];
                this.pointerIds[i2] = pointInfo.pointerIds[i2];
            }
            this.xMid = pointInfo.xMid;
            this.yMid = pointInfo.yMid;
            this.pressureMid = pointInfo.pressureMid;
            this.dx = pointInfo.dx;
            this.dy = pointInfo.dy;
            this.diameter = pointInfo.diameter;
            this.diameterSq = pointInfo.diameterSq;
            this.angle = pointInfo.angle;
            this.isDown = pointInfo.isDown;
            this.action = pointInfo.action;
            this.isMultiTouch = pointInfo.isMultiTouch;
            this.diameterIsCalculated = pointInfo.diameterIsCalculated;
            this.diameterSqIsCalculated = pointInfo.diameterSqIsCalculated;
            this.angleIsCalculated = pointInfo.angleIsCalculated;
            this.eventTime = pointInfo.eventTime;
        }
    }

    public static class PositionAndScale {
        private float angle;
        private float scale;
        private float scaleX;
        private float scaleY;
        private boolean updateAngle;
        private boolean updateScale;
        private boolean updateScaleXY;
        private float xOff;
        private float yOff;

        public float getAngle() {
            if (!this.updateAngle) {
                return 0.0f;
            }
            return this.angle;
        }

        public float getScale() {
            if (!this.updateScale) {
                return 1.0f;
            }
            return this.scale;
        }

        public float getScaleX() {
            if (!this.updateScaleXY) {
                return 1.0f;
            }
            return this.scaleX;
        }

        public float getScaleY() {
            if (!this.updateScaleXY) {
                return 1.0f;
            }
            return this.scaleY;
        }

        public float getXOff() {
            return this.xOff;
        }

        public float getYOff() {
            return this.yOff;
        }

        protected void set(float f2, float f3, float f4, float f5, float f6, float f7) {
            this.xOff = f2;
            this.yOff = f3;
            if (f4 == 0.0f) {
                f4 = 1.0f;
            }
            this.scale = f4;
            if (f5 == 0.0f) {
                f5 = 1.0f;
            }
            this.scaleX = f5;
            if (f6 == 0.0f) {
                f6 = 1.0f;
            }
            this.scaleY = f6;
            this.angle = f7;
        }

        public void set(float f2, float f3, boolean bl, float f4, boolean bl2, float f5, float f6, boolean bl3, float f7) {
            this.xOff = f2;
            this.yOff = f3;
            this.updateScale = bl;
            if (f4 == 0.0f) {
                f4 = 1.0f;
            }
            this.scale = f4;
            this.updateScaleXY = bl2;
            if (f5 == 0.0f) {
                f5 = 1.0f;
            }
            this.scaleX = f5;
            if (f6 == 0.0f) {
                f6 = 1.0f;
            }
            this.scaleY = f6;
            this.updateAngle = bl3;
            this.angle = f7;
        }
    }

}

