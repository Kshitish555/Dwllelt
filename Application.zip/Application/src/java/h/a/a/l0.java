/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.github.classgraph.utils.p
 *  io.github.classgraph.utils.y
 *  io.github.classgraph.utils.y$a
 *  io.github.classgraph.utils.y$b
 *  io.github.classgraph.utils.y$c
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Field
 *  java.util.ArrayList
 *  java.util.List
 */
package h.a.a;

import h.a.a.h;
import h.a.a.m;
import h.a.a.r0.b;
import io.github.classgraph.utils.p;
import io.github.classgraph.utils.y;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class l0 {
    public boolean A = false;
    public transient List<ClassLoader> B;
    public transient List<ClassLoader> C;
    public transient List<Object> D;
    public transient List<Object> E;
    public String F;
    public transient List<h.a> G;
    public final transient ArrayList<b.a> H = new ArrayList();
    public transient boolean I = false;
    public transient boolean J = false;
    public transient boolean K = false;
    public transient boolean L = false;
    public transient boolean M = false;
    public y.c a = new y.c();
    public y.b b = new y.b();
    public y.c c = new y.c();
    public y.b d = new y.b();
    public y.c e = new y.c();
    public y.c f = new y.c();
    public y.c g = new y.c();
    public y.c h = new y.c();
    public y.c i = new y.c();
    public y.a j = new y.a();
    public y.a k = new y.a();
    public boolean l = true;
    public boolean m = true;
    public boolean n = true;
    public boolean o = true;
    public boolean p = true;
    public boolean q = false;
    public boolean r = false;
    public boolean s = false;
    public boolean t = false;
    public boolean u = false;
    public boolean v = false;
    public boolean w = true;
    public boolean x;
    public boolean y = false;
    public boolean z = false;

    l0() {
    }

    private static boolean b(Object object) {
        IllegalArgumentException illegalArgumentException;
        if (object != null) {
            for (Class class_ = object.getClass(); class_ != null; class_ = class_.getSuperclass()) {
                if (!class_.getName().equals((Object)"java.lang.ModuleLayer")) continue;
                return true;
            }
            return false;
        }
        illegalArgumentException = new IllegalArgumentException("ModuleLayer references must not be null");
        throw illegalArgumentException;
    }

    /*
     * Exception decompiling
     */
    void a() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public void a(h.a a2) {
        if (this.G == null) {
            this.G = new ArrayList(2);
        }
        this.G.add((Object)a2);
    }

    void a(p p2) {
        if (p2 != null) {
            p p3 = p2.a("ScanSpec:");
            for (Field field : l0.class.getDeclaredFields()) {
                try {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(field.getName());
                    stringBuilder.append(": ");
                    stringBuilder.append(field.get((Object)this));
                    p3.a(stringBuilder.toString());
                }
                catch (Exception exception) {}
            }
        }
    }

    public void a(Class<? extends m> class_) {
        this.H.add((Object)new b.a(class_));
    }

    public void a(ClassLoader classLoader) {
        if (this.B == null) {
            this.B = new ArrayList();
        }
        if (classLoader != null) {
            this.B.add((Object)classLoader);
        }
    }

    public void a(Object object) {
        if (l0.b(object)) {
            if (this.D == null) {
                this.D = new ArrayList();
            }
            if (object != null) {
                this.D.add(object);
            }
            return;
        }
        throw new IllegalArgumentException("moduleLayer must be of type java.lang.ModuleLayer");
    }

    public /* varargs */ void a(ClassLoader ... arrclassLoader) {
        IllegalArgumentException illegalArgumentException;
        if (arrclassLoader.length != 0) {
            this.B = null;
            this.C = new ArrayList();
            for (ClassLoader classLoader : arrclassLoader) {
                if (classLoader == null) continue;
                this.C.add((Object)classLoader);
            }
            return;
        }
        illegalArgumentException = new IllegalArgumentException("At least one override ClassLoader must be provided");
        throw illegalArgumentException;
    }

    public /* varargs */ void a(Object ... arrobject) {
        IllegalArgumentException illegalArgumentException;
        if (arrobject != null) {
            if (arrobject.length != 0) {
                int n2 = arrobject.length;
                int n3 = 0;
                for (int i2 = 0; i2 < n2; ++i2) {
                    if (l0.b(arrobject[i2])) {
                        continue;
                    }
                    throw new IllegalArgumentException("moduleLayer must be of type java.lang.ModuleLayer");
                }
                this.D = null;
                this.E = new ArrayList();
                int n4 = arrobject.length;
                while (n3 < n4) {
                    Object object = arrobject[n3];
                    this.E.add(object);
                    ++n3;
                }
                return;
            }
            throw new IllegalArgumentException("At least one override ModuleLayer must be provided");
        }
        illegalArgumentException = new IllegalArgumentException("overrideModuleLayers cannot be null");
        throw illegalArgumentException;
    }

    boolean a(String string) {
        return this.e.c(string) || this.b.c(string);
        {
        }
    }

    a b(String string) {
        if (this.c.c(string)) {
            return a.c;
        }
        if (this.d.c(string)) {
            return a.c;
        }
        if (this.c.b() && this.h.b()) {
            return a.f;
        }
        if (this.c.e(string)) {
            return a.f;
        }
        if (this.h.e(string)) {
            return a.o;
        }
        if (string.equals((Object)"/")) {
            return a.h;
        }
        if (this.c.h(string)) {
            return a.h;
        }
        if (this.f.h(string)) {
            return a.h;
        }
        if (this.d.d(string)) {
            return a.d;
        }
        return a.s;
    }

    boolean c(String string) {
        return this.f.e(string);
    }

    public void d(String string) {
        this.F = string;
    }

    static final class a
    extends Enum<a> {
        public static final /* enum */ a c;
        public static final /* enum */ a d;
        public static final /* enum */ a f;
        public static final /* enum */ a h;
        public static final /* enum */ a o;
        public static final /* enum */ a s;
        private static final /* synthetic */ a[] t;

        static {
            a a2;
            c = new a();
            d = new a();
            f = new a();
            h = new a();
            o = new a();
            s = a2 = new a();
            a[] arra = new a[]{c, d, f, h, o, a2};
            t = arra;
        }

        public static a valueOf(String string) {
            return (a)Enum.valueOf(a.class, (String)string);
        }

        public static a[] values() {
            return (a[])t.clone();
        }
    }

}

