/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 */
package h.a.a.s0;

import h.a.a.s0.i;
import h.a.a.s0.j;
import h.a.a.s0.k;
import h.a.a.s0.m;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class e {
    List<Object> a;

    public e() {
        this.a = new ArrayList();
    }

    public e(List<Object> list) {
        this.a = list;
    }

    void a(Map<m<i>, CharSequence> map, boolean bl, int n2, int n3, StringBuilder stringBuilder) {
        boolean bl2 = n3 > 0;
        int n4 = this.a.size();
        if (n4 == 0) {
            stringBuilder.append("[]");
            return;
        }
        stringBuilder.append('[');
        if (bl2) {
            stringBuilder.append('\n');
        }
        for (int i2 = 0; i2 < n4; ++i2) {
            Object object = this.a.get(i2);
            if (bl2) {
                k.a(n2 + 1, n3, stringBuilder);
            }
            j.a(object, map, bl, n2 + 1, n3, stringBuilder);
            if (i2 < n4 - 1) {
                stringBuilder.append(',');
            }
            if (!bl2) continue;
            stringBuilder.append('\n');
        }
        if (bl2) {
            k.a(n2, n3, stringBuilder);
        }
        stringBuilder.append(']');
    }
}

