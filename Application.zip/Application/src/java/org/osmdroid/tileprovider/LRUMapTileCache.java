/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LRUMapTileCache
extends LinkedHashMap<MapTile, Drawable>
implements OpenStreetMapTileProviderConstants {
    private static final Logger logger = LoggerFactory.getLogger(LRUMapTileCache.class);
    private static final long serialVersionUID = -541142277575493335L;
    private int mCapacity;

    public LRUMapTileCache(int n) {
        super(n + 2, 0.1f, true);
        this.mCapacity = n;
    }

    public void clear() {
        while (!this.isEmpty()) {
            this.remove(this.keySet().iterator().next());
        }
        super.clear();
    }

    public void ensureCapacity(int n) {
        if (n > this.mCapacity) {
            Logger logger = LRUMapTileCache.logger;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Tile cache increased from ");
            stringBuilder.append(this.mCapacity);
            stringBuilder.append(" to ");
            stringBuilder.append(n);
            logger.info(stringBuilder.toString());
            this.mCapacity = n;
        }
    }

    public Drawable remove(Object object) {
        Bitmap bitmap2;
        Drawable drawable = (Drawable)super.remove(object);
        if (drawable instanceof BitmapDrawable && (bitmap2 = ((BitmapDrawable)drawable).getBitmap()) != null) {
            bitmap2.recycle();
        }
        return drawable;
    }

    protected boolean removeEldestEntry(Map.Entry<MapTile, Drawable> entry) {
        if (this.size() > this.mCapacity) {
            this.remove((Object)((MapTile)entry.getKey()));
        }
        return false;
    }
}

