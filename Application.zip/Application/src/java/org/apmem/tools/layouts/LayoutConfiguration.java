/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.util.AttributeSet
 *  java.lang.Math
 *  java.lang.Object
 */
package org.apmem.tools.layouts;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import org.apmem.tools.layouts.c;

class LayoutConfiguration {
    private int a = 0;
    private boolean b = false;
    private float c = 0.0f;
    private int d = 51;
    private int e = 0;

    public LayoutConfiguration(Context context, AttributeSet attributeSet) {
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, c.c.FlowLayout);
        try {
            this.c(typedArray.getInteger(c.c.FlowLayout_android_orientation, 0));
            this.a(typedArray.getBoolean(c.c.FlowLayout_debugDraw, false));
            this.a(typedArray.getFloat(c.c.FlowLayout_weightDefault, 0.0f));
            this.a(typedArray.getInteger(c.c.FlowLayout_android_gravity, 0));
            this.b(typedArray.getInteger(c.c.FlowLayout_layoutDirection, 0));
            return;
        }
        finally {
            typedArray.recycle();
        }
    }

    public int a() {
        return this.d;
    }

    public void a(float f2) {
        this.c = Math.max((float)0.0f, (float)f2);
    }

    public void a(int n2) {
        this.d = n2;
    }

    public void a(boolean bl) {
        this.b = bl;
    }

    public int b() {
        return this.e;
    }

    public void b(int n2) {
        if (n2 == 1) {
            this.e = n2;
            return;
        }
        this.e = 0;
    }

    public int c() {
        return this.a;
    }

    public void c(int n2) {
        if (n2 == 1) {
            this.a = n2;
            return;
        }
        this.a = 0;
    }

    public float d() {
        return this.c;
    }

    public boolean e() {
        return this.b;
    }
}

