/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.protobuf.m
 *  com.google.protobuf.p
 *  com.google.protobuf.p$l
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 */
package e.a.a;

import com.google.protobuf.m;
import com.google.protobuf.p;

public final class a {
    private a() {
    }

    public static void a(m m2) {
    }

}

