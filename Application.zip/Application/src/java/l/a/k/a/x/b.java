/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.t
 *  l.a.k.a.u
 */
package l.a.k.a.x;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import l.a.k.a.n;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.t;
import l.a.k.a.u;

public class b
extends r {
    static /* synthetic */ Class Q4;
    private String P4;
    public List f;
    public List h;
    private List o;
    public Map s;
    private int t;
    private int w;

    static {
        Q4 = b.a("net.bytebuddy.jar.asm.commons.AnalyzerAdapter");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected b(int var1_1, String var2_2, int var3_3, String var4_4, String var5_5, r var6_6) {
        super(var1_1, var6_6);
        this.P4 = var2_2;
        this.f = new ArrayList();
        this.h = new ArrayList();
        this.s = new HashMap();
        if ((var3_3 & 8) == 0) {
            if ("<init>".equals((Object)var4_4)) {
                var15_7 = this.f;
                var2_2 = t.F1;
            } else {
                var15_7 = this.f;
            }
            var15_7.add((Object)var2_2);
        }
        var7_8 = u.a((String)var5_5);
        var8_9 = 0;
        do {
            block12 : {
                if (var8_9 >= var7_8.length) {
                    this.w = this.f.size();
                    return;
                }
                switch (var7_8[var8_9].j()) {
                    default: {
                        var9_10 = this.f;
                        var10_12 = var7_8[var8_9].g();
                        break block12;
                    }
                    case 9: {
                        var9_10 = this.f;
                        var10_13 = var7_8[var8_9].d();
                        break block12;
                    }
                    case 8: {
                        var12_17 = this.f;
                        var13_18 = t.C1;
                        ** GOTO lbl35
                    }
                    case 7: {
                        var12_17 = this.f;
                        var13_18 = t.D1;
lbl35: // 2 sources:
                        var12_17.add((Object)var13_18);
                        var9_10 = this.f;
                        var10_14 = t.z1;
                        break block12;
                    }
                    case 6: {
                        var9_10 = this.f;
                        var10_15 = t.B1;
                        break block12;
                    }
                    case 1: 
                    case 2: 
                    case 3: 
                    case 4: 
                    case 5: 
                }
                var9_10 = this.f;
                var10_16 = t.A1;
            }
            var9_10.add((Object)var10_11);
            ++var8_9;
        } while (true);
    }

    public b(String string, int n2, String string2, String string3, r r2) {
        this(327680, string, n2, string2, string3, r2);
        if (b.class == Q4) {
            return;
        }
        throw new IllegalStateException();
    }

    static /* synthetic */ Class a(String string) {
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new NoClassDefFoundError(classNotFoundException.getMessage());
        }
    }

    /*
     * Exception decompiling
     */
    private void a(int var1_1, int var2_2, String var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [22[CASE]], but top level block is 53[SWITCH]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private void a(int n2, Object object) {
        this.w = Math.max((int)this.w, (int)(n2 + 1));
        while (n2 >= this.f.size()) {
            this.f.add((Object)t.z1);
        }
        this.f.set(n2, object);
    }

    private static void a(int n2, Object[] arrobject, List list) {
        for (int i2 = 0; i2 < n2; ++i2) {
            Object object = arrobject[i2];
            list.add(object);
            if (object != t.D1 && object != t.C1) continue;
            list.add((Object)t.z1);
        }
    }

    private Object b(int n2) {
        this.w = Math.max((int)this.w, (int)(n2 + 1));
        if (n2 < this.f.size()) {
            return this.f.get(n2);
        }
        return t.z1;
    }

    private void b(int n2, String string, String string2, String string3, boolean bl) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, string, string2, string3, bl);
        }
        if (this.f == null) {
            this.o = null;
            return;
        }
        this.b(string3);
        if (n2 != 184) {
            Object object = this.e();
            if (n2 == 183 && string2.charAt(0) == '<') {
                Object object2 = object == t.F1 ? this.P4 : this.s.get(object);
                int n3 = 0;
                do {
                    int n4 = this.f.size();
                    if (n3 >= n4) break;
                    if (this.f.get(n3) == object) {
                        this.f.set(n3, object2);
                    }
                    ++n3;
                } while (true);
                for (int i2 = 0; i2 < this.h.size(); ++i2) {
                    if (this.h.get(i2) != object) continue;
                    this.h.set(i2, object2);
                }
            }
        }
        this.c(string3);
        this.o = null;
    }

    private void b(Object object) {
        this.h.add(object);
        this.t = Math.max((int)this.t, (int)this.h.size());
    }

    private void b(String string) {
        char c2 = string.charAt(0);
        if (c2 == '(') {
            u[] arru = u.a((String)string);
            int n2 = 0;
            for (int i2 = 0; i2 < arru.length; ++i2) {
                n2 += arru[i2].i();
            }
            this.c(n2);
            return;
        }
        int n3 = c2 != 'J' && c2 != 'D' ? 1 : 2;
        this.c(n3);
    }

    private void c(int n2) {
        int n3 = this.h.size();
        int n4 = n3 - n2;
        for (int i2 = n3 - 1; i2 >= n4; --i2) {
            this.h.remove(i2);
        }
    }

    /*
     * Exception decompiling
     */
    private void c(String var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:478)
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:61)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:372)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private Object e() {
        List list = this.h;
        return list.remove(-1 + list.size());
    }

    public void a(int n2) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2);
        }
        this.a(n2, 0, null);
        if (n2 >= 172 && n2 <= 177 || n2 == 191) {
            this.f = null;
            this.h = null;
        }
    }

    public void a(int n2, int n3) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, n3);
        }
        this.a(132, n2, null);
    }

    public /* varargs */ void a(int n2, int n3, q q2, q ... arrq) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, n3, q2, arrq);
        }
        this.a(170, 0, null);
        this.f = null;
        this.h = null;
    }

    public void a(int n2, int n3, Object[] arrobject, int n4, Object[] arrobject2) {
        if (n2 == -1) {
            List list;
            r r2 = this.d;
            if (r2 != null) {
                r2.a(n2, n3, arrobject, n4, arrobject2);
            }
            if ((list = this.f) != null) {
                list.clear();
                this.h.clear();
            } else {
                this.f = new ArrayList();
                this.h = new ArrayList();
            }
            b.a(n3, arrobject, this.f);
            b.a(n4, arrobject2, this.h);
            this.t = Math.max((int)this.t, (int)this.h.size());
            return;
        }
        throw new IllegalStateException("ClassReader.accept() should be called with EXPAND_FRAMES flag");
    }

    public void a(int n2, String string) {
        r r2;
        if (n2 == 187) {
            if (this.o == null) {
                q q2 = new q();
                ArrayList arrayList = new ArrayList(3);
                this.o = arrayList;
                arrayList.add((Object)q2);
                r r3 = this.d;
                if (r3 != null) {
                    r3.a(q2);
                }
            }
            for (int i2 = 0; i2 < this.o.size(); ++i2) {
                this.s.put(this.o.get(i2), (Object)string);
            }
        }
        if ((r2 = this.d) != null) {
            r2.a(n2, string);
        }
        this.a(n2, 0, string);
    }

    public void a(int n2, String string, String string2, String string3) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, string, string2, string3);
        }
        this.a(n2, 0, string3);
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            super.a(n2, string, string2, string3, bl);
            return;
        }
        this.b(n2, string, string2, string3, bl);
    }

    public void a(int n2, q q2) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, q2);
        }
        this.a(n2, 0, null);
        if (n2 == 167) {
            this.f = null;
            this.h = null;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(Object var1_1) {
        block14 : {
            block15 : {
                block13 : {
                    var2_2 = this.d;
                    if (var2_2 != null) {
                        var2_2.a(var1_1);
                    }
                    if (this.f == null) {
                        this.o = null;
                        return;
                    }
                    if (!(var1_1 instanceof Integer)) break block13;
                    var4_3 = t.A1;
                    break block14;
                }
                if (!(var1_1 instanceof Long)) break block15;
                var6_11 = t.D1;
                ** GOTO lbl20
            }
            if (var1_1 instanceof Float) {
                var4_6 = t.B1;
            } else if (var1_1 instanceof Double) {
                var6_11 = t.C1;
lbl20: // 2 sources:
                this.b((Object)var6_11);
                var4_5 = t.z1;
            } else if (var1_1 instanceof String) {
                var4_7 = "java/lang/String";
            } else if (var1_1 instanceof u) {
                var5_12 = ((u)var1_1).j();
                if (var5_12 != 10 && var5_12 != 9) {
                    if (var5_12 != 11) throw new IllegalArgumentException();
                    var4_8 = "java/lang/invoke/MethodType";
                } else {
                    var4_9 = "java/lang/Class";
                }
            } else {
                if (!(var1_1 instanceof n)) {
                    var3_13 = new IllegalArgumentException();
                    throw var3_13;
                }
                var4_10 = "java/lang/invoke/MethodHandle";
            }
        }
        this.b(var4_4);
        this.o = null;
    }

    public void a(String string, int n2) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(string, n2);
        }
        this.a(197, n2, string);
    }

    public /* varargs */ void a(String string, String string2, n n2, Object ... arrobject) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(string, string2, n2, arrobject);
        }
        if (this.f == null) {
            this.o = null;
            return;
        }
        this.b(string2);
        this.c(string2);
        this.o = null;
    }

    public void a(q q2) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(q2);
        }
        if (this.o == null) {
            this.o = new ArrayList(3);
        }
        this.o.add((Object)q2);
    }

    public void a(q q2, int[] arrn, q[] arrq) {
        r r2 = this.d;
        if (r2 != null) {
            r2.a(q2, arrn, arrq);
        }
        this.a(171, 0, null);
        this.f = null;
        this.h = null;
    }

    public void b(int n2, int n3) {
        r r2 = this.d;
        if (r2 != null) {
            r2.b(n2, n3);
        }
        this.a(n2, n3, null);
    }

    public void b(int n2, String string, String string2, String string3) {
        if (this.c >= 327680) {
            super.b(n2, string, string2, string3);
            return;
        }
        boolean bl = n2 == 185;
        this.b(n2, string, string2, string3, bl);
    }

    public void c(int n2, int n3) {
        if (this.d != null) {
            int n4;
            this.t = Math.max((int)this.t, (int)n2);
            this.w = n4 = Math.max((int)this.w, (int)n3);
            this.d.c(this.t, n4);
        }
    }

    public void d(int n2, int n3) {
        r r2 = this.d;
        if (r2 != null) {
            r2.d(n2, n3);
        }
        this.a(n2, n3, null);
    }
}

