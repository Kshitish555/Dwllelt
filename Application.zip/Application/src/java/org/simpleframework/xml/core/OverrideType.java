/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.strategy.Type
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.strategy.Type;

class OverrideType
implements Type {
    private final Class override;
    private final Type type;

    public OverrideType(Type type, Class class_) {
        this.override = class_;
        this.type = type;
    }

    public <T extends Annotation> T getAnnotation(Class<T> class_) {
        return (T)this.type.getAnnotation(class_);
    }

    public Class getType() {
        return this.override;
    }

    public String toString() {
        return this.type.toString();
    }
}

