/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.core.Expression;

interface Parameter {
    public Annotation getAnnotation();

    public Expression getExpression();

    public int getIndex();

    public Object getKey();

    public String getName();

    public String getPath();

    public Class getType();

    public boolean isAttribute();

    public boolean isPrimitive();

    public boolean isRequired();

    public boolean isText();

    public String toString();
}

