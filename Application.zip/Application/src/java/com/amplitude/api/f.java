/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  android.database.sqlite.SQLiteException
 *  android.database.sqlite.SQLiteOpenHelper
 *  java.io.File
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.StackOverflowError
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amplitude.api;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import com.amplitude.api.CursorWindowAllocationException;
import com.amplitude.api.d;
import com.amplitude.api.g;
import com.amplitude.api.i;
import com.amplitude.api.n;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

class f
extends SQLiteOpenHelper {
    static final Map<String, f> e = new HashMap();
    private static final String f = "com.amplitude.api.DatabaseHelper";
    protected static final String g = "store";
    protected static final String h = "long_store";
    private static final String i = "key";
    private static final String j = "value";
    protected static final String k = "events";
    protected static final String l = "identifys";
    private static final String m = "id";
    private static final String n = "event";
    private static final String o = "CREATE TABLE IF NOT EXISTS store (key TEXT PRIMARY KEY NOT NULL, value TEXT);";
    private static final String p = "CREATE TABLE IF NOT EXISTS long_store (key TEXT PRIMARY KEY NOT NULL, value INTEGER);";
    private static final String q = "CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT);";
    private static final String r = "CREATE TABLE IF NOT EXISTS identifys (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT);";
    private static final d s = d.a();
    File a;
    private String b;
    private boolean c = true;
    private g d;

    protected f(Context context) {
        this(context, null);
    }

    protected f(Context context, String string) {
        super(context, f.e(string), null, 3);
        this.a = context.getDatabasePath(f.e(string));
        this.b = n.b(string);
    }

    /*
     * Exception decompiling
     */
    private long a(String var1_1, long var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    @Deprecated
    static f a(Context context) {
        return f.a(context, null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static f a(Context context, String string) {
        Class<f> class_ = f.class;
        synchronized (f.class) {
            String string2 = n.b(string);
            f f2 = (f)((Object)e.get((Object)string2));
            if (f2 == null) {
                f2 = new f(context.getApplicationContext(), string2);
                e.put((Object)string2, (Object)f2);
            }
            // ** MonitorExit[var6_2] (shouldn't be in output)
            return f2;
        }
    }

    private void a(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS store");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS long_store");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS events");
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS identifys");
        this.onCreate(sQLiteDatabase);
    }

    private static void a(RuntimeException runtimeException) {
        String string = runtimeException.getMessage();
        if (!n.a(string) && string.startsWith("Cursor window allocation of")) {
            throw new CursorWindowAllocationException(string);
        }
        throw runtimeException;
    }

    /*
     * Exception decompiling
     */
    private void b(String var1_1, long var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CATCHBLOCK]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private void c(String var1_1, long var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CATCHBLOCK]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    private long d(String string, String string2) {
        long l2;
        block13 : {
            SQLiteException sQLiteException;
            block15 : {
                f f2 = this;
                // MONITORENTER : f2
                try {
                    StackOverflowError stackOverflowError;
                    block14 : {
                        SQLiteDatabase sQLiteDatabase = this.getWritableDatabase();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(n, string2);
                        l2 = this.a(sQLiteDatabase, string, contentValues);
                        if (l2 != -1L) break block13;
                        try {
                            s.e(f, String.format((String)"Insert into %s failed", (Object[])new Object[]{string}));
                            break block13;
                        }
                        catch (StackOverflowError stackOverflowError2) {
                            break block14;
                        }
                        catch (SQLiteException sQLiteException2) {
                            break block15;
                        }
                        catch (StackOverflowError stackOverflowError3) {
                            stackOverflowError = stackOverflowError3;
                            l2 = -1L;
                        }
                    }
                    s.b(f, String.format((String)"addEvent to %s failed", (Object[])new Object[]{string}), stackOverflowError);
                    i.c().a(String.format((String)"DB: Failed to addEvent: %s", (Object[])new Object[]{string2}), stackOverflowError);
                    this.e();
                    break block13;
                }
                catch (Throwable throwable) {}
                this.close();
                throw throwable;
                catch (SQLiteException sQLiteException3) {
                    sQLiteException = sQLiteException3;
                    l2 = -1L;
                }
            }
            s.b(f, String.format((String)"addEvent to %s failed", (Object[])new Object[]{string}), sQLiteException);
            i.c().a(String.format((String)"DB: Failed to addEvent: %s", (Object[])new Object[]{string2}), sQLiteException);
            this.e();
        }
        this.close();
        return l2;
    }

    private static String e(String string) {
        if (!n.a(string) && !string.equals((Object)"$default_instance")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("com.amplitude.api_");
            stringBuilder.append(string);
            return stringBuilder.toString();
        }
        return "com.amplitude.api";
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void e() {
        var1_1 = null;
        this.close();
        this.a.delete();
        if (this.d == null) return;
        if (this.c == false) return;
        this.c = false;
        var1_1 = this.getWritableDatabase();
        this.d.a(var1_1);
        this.c = true;
        if (var1_1 == null) return;
        if (var1_1.isOpen() == false) return;
lbl14: // 4 sources:
        do {
            this.close();
            return;
            break;
        } while (true);
        {
            catch (Throwable var18_2) {
            }
            catch (SQLiteException var15_3) {}
            {
                f.s.b("com.amplitude.api.DatabaseHelper", String.format((String)"databaseReset callback failed during delete", (Object[])new Object[0]), var15_3);
                i.c().a(String.format((String)"DB: Failed to run databaseReset callback in delete", (Object[])new Object[0]), var15_3);
            }
            this.c = true;
            if (var1_1 == null) return;
            if (var1_1.isOpen() == false) return;
            ** GOTO lbl14
        }
        this.c = true;
        if (var1_1 == null) throw var18_2;
        if (var1_1.isOpen() == false) throw var18_2;
        this.close();
        throw var18_2;
        {
            block19 : {
                block18 : {
                    catch (Throwable var9_4) {
                        break block18;
                    }
                    catch (SecurityException var2_5) {}
                    {
                        f.s.b("com.amplitude.api.DatabaseHelper", "delete failed", var2_5);
                        i.c().a("DB: Failed to delete database");
                        if (this.d == null) return;
                        if (this.c == false) return;
                    }
                    this.c = false;
                    var1_1 = this.getWritableDatabase();
                    this.d.a(var1_1);
                    this.c = true;
                    if (var1_1 == null) return;
                    if (var1_1.isOpen() == false) return;
                    ** GOTO lbl14
                }
                if (this.d == null) throw var9_4;
                if (this.c == false) throw var9_4;
                this.c = false;
                var1_1 = this.getWritableDatabase();
                this.d.a(var1_1);
                this.c = true;
                if (var1_1 == null) throw var9_4;
                if (var1_1.isOpen() == false) throw var9_4;
                {
                    catch (Throwable var8_6) {
                        break block19;
                    }
                    catch (SQLiteException var5_7) {}
                    {
                        f.s.b("com.amplitude.api.DatabaseHelper", String.format((String)"databaseReset callback failed during delete", (Object[])new Object[0]), var5_7);
                        i.c().a(String.format((String)"DB: Failed to run databaseReset callback in delete", (Object[])new Object[0]), var5_7);
                    }
                    this.c = true;
                    if (var1_1 == null) return;
                    if (var1_1.isOpen() == false) return;
                    ** continue;
                }
            }
            this.c = true;
            if (var1_1 == null) throw var8_6;
            if (var1_1.isOpen() == false) throw var8_6;
            this.close();
            throw var8_6;
        }
lbl72: // 2 sources:
        do {
            this.close();
            throw var9_4;
            break;
        } while (true);
        {
            catch (Throwable var13_8) {
            }
            catch (SQLiteException var10_9) {}
            {
                f.s.b("com.amplitude.api.DatabaseHelper", String.format((String)"databaseReset callback failed during delete", (Object[])new Object[0]), var10_9);
                i.c().a(String.format((String)"DB: Failed to run databaseReset callback in delete", (Object[])new Object[0]), var10_9);
            }
            this.c = true;
            if (var1_1 == null) throw var9_4;
            if (var1_1.isOpen() == false) throw var9_4;
            ** continue;
        }
        this.c = true;
        if (var1_1 == null) throw var13_8;
        if (var1_1.isOpen() == false) throw var13_8;
        this.close();
        throw var13_8;
    }

    /*
     * Exception decompiling
     */
    private long f(String var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    long a(long l2) {
        f f2 = this;
        synchronized (f2) {
            long l3 = this.a(k, l2);
            return l3;
        }
    }

    long a(SQLiteDatabase sQLiteDatabase, String string, ContentValues contentValues) throws SQLiteException, StackOverflowError {
        f f2 = this;
        synchronized (f2) {
            long l2 = sQLiteDatabase.insert(string, null, contentValues);
            return l2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    long a(SQLiteDatabase sQLiteDatabase, String string, String string2, Object object) throws SQLiteException, StackOverflowError {
        f f2 = this;
        synchronized (f2) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(i, string2);
            if (object instanceof Long) {
                contentValues.put(j, (Long)object);
            } else {
                contentValues.put(j, (String)object);
            }
            long l2 = this.b(sQLiteDatabase, string, contentValues);
            if (l2 == -1L) {
                s.e(f, "Insert failed");
            }
            return l2;
        }
    }

    long a(String string) {
        f f2 = this;
        synchronized (f2) {
            long l2 = this.d(k, string);
            return l2;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    long a(String string, Long l2) {
        f f2 = this;
        synchronized (f2) {
            if (l2 != null) return this.a(h, string, (Object)l2);
            return this.a(h, string);
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    long a(String string, String string2) {
        f f2 = this;
        // MONITORENTER : f2
        int n2 = this.getWritableDatabase().delete(string, "key=?", new String[]{string2});
        long l2 = n2;
        this.close();
        return l2;
        {
            Throwable throwable32;
            block12 : {
                block13 : {
                    catch (Throwable throwable2) {
                        throw throwable2;
                    }
                    {
                        catch (Throwable throwable32) {
                            break block12;
                        }
                        catch (StackOverflowError stackOverflowError) {}
                        {
                            s.b(f, String.format((String)"deleteKey from %s failed", (Object[])new Object[]{string}), stackOverflowError);
                            i.c().a(String.format((String)"DB: Failed to deleteKey: %s", (Object[])new Object[]{string2}), stackOverflowError);
                            this.e();
                            break block13;
                        }
                        catch (SQLiteException sQLiteException) {}
                        {
                            s.b(f, String.format((String)"deleteKey from %s failed", (Object[])new Object[]{string}), sQLiteException);
                            i.c().a(String.format((String)"DB: Failed to deleteKey: %s", (Object[])new Object[]{string2}), sQLiteException);
                            this.e();
                        }
                    }
                }
                this.close();
                l2 = -1L;
                return l2;
            }
            this.close();
            throw throwable32;
        }
    }

    /*
     * Exception decompiling
     */
    long a(String var1_1, String var2_2, Object var3_3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    Cursor a(SQLiteDatabase sQLiteDatabase, String string, String[] arrstring, String string2, String[] arrstring2, String string3, String string4, String string5, String string6) {
        return sQLiteDatabase.query(string, arrstring, string2, arrstring2, string3, string4, string5, string6);
    }

    List<JSONObject> a(long l2, long l3) throws JSONException {
        f f2 = this;
        synchronized (f2) {
            List<JSONObject> list = this.a(k, l2, l3);
            return list;
        }
    }

    /*
     * Exception decompiling
     */
    protected List<JSONObject> a(String var1_1, long var2_2, long var4_3) throws JSONException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 3 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    void a(g g2) {
        this.d = g2;
    }

    boolean a() {
        return this.a.exists();
    }

    long b() {
        f f2 = this;
        synchronized (f2) {
            long l2 = this.f(k);
            return l2;
        }
    }

    long b(long l2) {
        f f2 = this;
        synchronized (f2) {
            long l3 = this.a(l, l2);
            return l3;
        }
    }

    long b(SQLiteDatabase sQLiteDatabase, String string, ContentValues contentValues) throws SQLiteException, StackOverflowError {
        f f2 = this;
        synchronized (f2) {
            long l2 = sQLiteDatabase.insertWithOnConflict(string, null, contentValues, 5);
            return l2;
        }
    }

    long b(String string) {
        f f2 = this;
        synchronized (f2) {
            long l2 = this.d(l, string);
            return l2;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    protected Object b(String var1_1, String var2_2) {
        block27 : {
            var18_3 = this;
            // MONITORENTER : var18_3
            var4_4 = this.a(this.getReadableDatabase(), var1_1, new String[]{"key", "value"}, "key = ?", new String[]{var2_2}, null, null, null, null);
            try {
                var16_5 = var4_4.moveToFirst();
                var10_6 = null;
                if (var16_5) {
                    var17_7 = var1_1.equals((Object)"store") != false ? var4_4.getString(1) : Long.valueOf((long)var4_4.getLong(1));
                    var10_6 = var17_7;
                }
                ** if (var4_4 == null) goto lbl14
            }
            catch (Throwable var5_18) {
                var6_20 = var4_4;
            }
lbl-1000: // 1 sources:
            {
                var4_4.close();
            }
lbl14: // 2 sources:
            ** GOTO lbl61
            {
                block28 : {
                    block26 : {
                        block25 : {
                            block24 : {
                                catch (RuntimeException var14_8) {
                                    break block24;
                                }
                                catch (StackOverflowError var11_11) {
                                    break block25;
                                }
                                catch (SQLiteException var3_14) {
                                    break block26;
                                }
                                catch (Throwable var5_17) {
                                    var6_20 = null;
                                    break block27;
                                }
                                catch (RuntimeException var14_9) {
                                    var4_4 = null;
                                }
                            }
                            i.c().a(String.format((String)"DB: Failed to getValue: %s", (Object[])new Object[]{var2_2}), (Throwable)var14_10);
                            f.a((RuntimeException)var14_10);
                            var10_6 = null;
                            ** if (var4_4 == null) goto lbl-1000
lbl-1000: // 1 sources:
                            {
                                var4_4.close();
                                var10_6 = null;
                            }
lbl-1000: // 2 sources:
                            {
                                break block28;
                            }
                            catch (StackOverflowError var11_12) {
                                var4_4 = null;
                            }
                        }
                        f.s.b("com.amplitude.api.DatabaseHelper", String.format((String)"getValue from %s failed", (Object[])new Object[]{var1_1}), (Throwable)var11_13);
                        i.c().a(String.format((String)"DB: Failed to getValue: %s", (Object[])new Object[]{var2_2}), (Throwable)var11_13);
                        this.e();
                        var10_6 = null;
                        ** if (var4_4 == null) goto lbl-1000
lbl-1000: // 1 sources:
                        {
                            var4_4.close();
                            var10_6 = null;
                        }
lbl-1000: // 2 sources:
                        {
                            break block28;
                        }
                        catch (SQLiteException var3_15) {
                            var4_4 = null;
                        }
                    }
                    f.s.b("com.amplitude.api.DatabaseHelper", String.format((String)"getValue from %s failed", (Object[])new Object[]{var1_1}), (Throwable)var3_16);
                    i.c().a(String.format((String)"DB: Failed to getValue: %s", (Object[])new Object[]{var2_2}), (Throwable)var3_16);
                    this.e();
                    var10_6 = null;
                    if (var4_4 == null) break block28;
                    var4_4.close();
                    var10_6 = null;
                }
                this.close();
                return var10_6;
            }
        }
        if (var6_20 == null) ** GOTO lbl70
        var6_20.close();
lbl70: // 2 sources:
        this.close();
        throw var5_19;
    }

    List<JSONObject> b(long l2, long l3) throws JSONException {
        f f2 = this;
        synchronized (f2) {
            List<JSONObject> list = this.a(l, l2, l3);
            return list;
        }
    }

    long c() {
        f f2 = this;
        synchronized (f2) {
            long l2 = this.f(l);
            return l2;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    long c(String string, String string2) {
        f f2 = this;
        synchronized (f2) {
            if (string2 != null) return this.a(g, string, string2);
            return this.a(g, string);
        }
    }

    Long c(String string) {
        f f2 = this;
        synchronized (f2) {
            Long l2 = (Long)this.b(h, string);
            return l2;
        }
    }

    void c(long l2) {
        f f2 = this;
        synchronized (f2) {
            this.b(k, l2);
            return;
        }
    }

    long d() {
        f f2 = this;
        synchronized (f2) {
            long l2 = this.b();
            long l3 = this.c();
            long l4 = l2 + l3;
            return l4;
        }
    }

    String d(String string) {
        f f2 = this;
        synchronized (f2) {
            String string2 = (String)this.b(g, string);
            return string2;
        }
    }

    void d(long l2) {
        f f2 = this;
        synchronized (f2) {
            this.c(k, l2);
            return;
        }
    }

    void e(long l2) {
        f f2 = this;
        synchronized (f2) {
            this.b(l, l2);
            return;
        }
    }

    void f(long l2) {
        f f2 = this;
        synchronized (f2) {
            this.c(l, l2);
            return;
        }
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void onCreate(SQLiteDatabase var1_1) {
        var1_1.execSQL("CREATE TABLE IF NOT EXISTS store (key TEXT PRIMARY KEY NOT NULL, value TEXT);");
        var1_1.execSQL("CREATE TABLE IF NOT EXISTS long_store (key TEXT PRIMARY KEY NOT NULL, value INTEGER);");
        var1_1.execSQL("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT);");
        var1_1.execSQL("CREATE TABLE IF NOT EXISTS identifys (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT);");
        var2_2 = this.d;
        if (var2_2 == null) return;
        if (this.c == false) return;
        this.c = false;
        var2_2.a(var1_1);
lbl11: // 2 sources:
        do {
            this.c = true;
            return;
            break;
        } while (true);
        {
            catch (Throwable var6_3) {
            }
            catch (SQLiteException var3_4) {}
            {
                f.s.b("com.amplitude.api.DatabaseHelper", String.format((String)"databaseReset callback failed during onCreate", (Object[])new Object[0]), var3_4);
                i.c().a(String.format((String)"DB: Failed to run databaseReset callback during onCreate", (Object[])new Object[0]), var3_4);
                ** continue;
            }
        }
        this.c = true;
        throw var6_3;
    }

    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int n2, int n3) {
        block6 : {
            block5 : {
                block4 : {
                    if (n2 > n3) {
                        s.b(f, "onUpgrade() with invalid oldVersion and newVersion");
                        this.a(sQLiteDatabase);
                        return;
                    }
                    if (n3 <= 1) {
                        return;
                    }
                    if (n2 == 1) break block4;
                    if (n2 == 2) break block5;
                    if (n2 != 3) {
                        d d2 = s;
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("onUpgrade() with unknown oldVersion ");
                        stringBuilder.append(n2);
                        d2.b(f, stringBuilder.toString());
                        this.a(sQLiteDatabase);
                        return;
                    }
                    break block6;
                }
                sQLiteDatabase.execSQL(o);
                if (n3 <= 2) {
                    return;
                }
            }
            sQLiteDatabase.execSQL(r);
            sQLiteDatabase.execSQL(p);
        }
    }
}

