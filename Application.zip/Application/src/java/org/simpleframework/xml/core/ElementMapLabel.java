/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.ElementMap
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Entry
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Introspector
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.core.ClassType;
import org.simpleframework.xml.core.CompositeInlineMap;
import org.simpleframework.xml.core.CompositeMap;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Entry;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Introspector;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.MapFactory;
import org.simpleframework.xml.core.Qualifier;
import org.simpleframework.xml.core.TemplateLabel;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.Format;
import org.simpleframework.xml.stream.Style;

class ElementMapLabel
extends TemplateLabel {
    private Expression cache;
    private boolean data;
    private Decorator decorator;
    private Introspector detail;
    private Entry entry;
    private Format format;
    private boolean inline;
    private Class[] items;
    private ElementMap label;
    private String name;
    private String override;
    private String parent;
    private String path;
    private boolean required;
    private Class type;

    public ElementMapLabel(Contact contact, ElementMap elementMap, Format format) {
        this.detail = new Introspector(contact, (Label)this, format);
        this.decorator = new Qualifier(contact);
        this.entry = new Entry(contact, elementMap);
        this.required = elementMap.required();
        this.type = contact.getType();
        this.inline = elementMap.inline();
        this.override = elementMap.name();
        this.data = elementMap.data();
        this.format = format;
        this.label = elementMap;
    }

    private Type getMap() {
        return new ClassType(this.type);
    }

    public Annotation getAnnotation() {
        return this.label;
    }

    public Contact getContact() {
        return this.detail.getContact();
    }

    public Converter getConverter(Context context) throws Exception {
        Type type = this.getMap();
        if (!this.label.inline()) {
            return new CompositeMap(context, this.entry, type);
        }
        return new CompositeInlineMap(context, this.entry, type);
    }

    public Decorator getDecorator() throws Exception {
        return this.decorator;
    }

    @Override
    public Type getDependent() throws Exception {
        Class[] arrclass;
        Contact contact = this.getContact();
        if (this.items == null) {
            this.items = contact.getDependents();
        }
        if ((arrclass = this.items) != null) {
            if (arrclass.length == 0) {
                return new ClassType(Object.class);
            }
            return new ClassType(arrclass[0]);
        }
        throw new ElementException("Unable to determine type for %s", contact);
    }

    public Object getEmpty(Context context) throws Exception {
        MapFactory mapFactory = new MapFactory(context, new ClassType(this.type));
        if (!this.label.empty()) {
            return mapFactory.getInstance();
        }
        return null;
    }

    @Override
    public String getEntry() throws Exception {
        Style style = this.format.getStyle();
        if (this.detail.isEmpty(this.parent)) {
            this.parent = this.detail.getEntry();
        }
        return style.getElement(this.parent);
    }

    public Expression getExpression() throws Exception {
        if (this.cache == null) {
            this.cache = this.detail.getExpression();
        }
        return this.cache;
    }

    public String getName() throws Exception {
        if (this.name == null) {
            Style style = this.format.getStyle();
            String string2 = this.entry.getEntry();
            if (!this.label.inline()) {
                string2 = this.detail.getName();
            }
            this.name = style.getElement(string2);
        }
        return this.name;
    }

    public String getOverride() {
        return this.override;
    }

    public String getPath() throws Exception {
        if (this.path == null) {
            this.path = this.getExpression().getElement(this.getName());
        }
        return this.path;
    }

    public Class getType() {
        return this.type;
    }

    @Override
    public boolean isCollection() {
        return true;
    }

    public boolean isData() {
        return this.data;
    }

    @Override
    public boolean isInline() {
        return this.inline;
    }

    public boolean isRequired() {
        return this.required;
    }

    public String toString() {
        return this.detail.toString();
    }
}

