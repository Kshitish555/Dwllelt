/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.util.Collections
 *  java.util.List
 *  org.simpleframework.xml.Attribute
 *  org.simpleframework.xml.Element
 *  org.simpleframework.xml.ElementArray
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementListUnion
 *  org.simpleframework.xml.ElementMap
 *  org.simpleframework.xml.ElementMapUnion
 *  org.simpleframework.xml.ElementUnion
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.core.Parameter
 *  org.simpleframework.xml.core.ParameterFactory
 *  org.simpleframework.xml.core.ParameterMap
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementArray;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementListUnion;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.ElementMapUnion;
import org.simpleframework.xml.ElementUnion;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.core.ConstructorException;
import org.simpleframework.xml.core.Parameter;
import org.simpleframework.xml.core.ParameterFactory;
import org.simpleframework.xml.core.ParameterMap;
import org.simpleframework.xml.core.Signature;
import org.simpleframework.xml.core.SignatureBuilder;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.core.UnionException;

class SignatureScanner {
    private final SignatureBuilder builder;
    private final Constructor constructor;
    private final ParameterFactory factory;
    private final ParameterMap registry;
    private final Class type;

    public SignatureScanner(Constructor constructor, ParameterMap parameterMap, Support support) throws Exception {
        Class class_;
        this.builder = new SignatureBuilder(constructor);
        this.factory = new ParameterFactory(support);
        this.type = class_ = constructor.getDeclaringClass();
        this.constructor = constructor;
        this.registry = parameterMap;
        this.scan(class_);
    }

    private List<Parameter> create(Annotation annotation, int n) throws Exception {
        Parameter parameter = this.factory.getInstance(this.constructor, annotation, n);
        if (parameter != null) {
            this.register(parameter);
        }
        return Collections.singletonList((Object)parameter);
    }

    private Annotation[] extract(Annotation annotation) throws Exception {
        Method[] arrmethod = annotation.annotationType().getDeclaredMethods();
        if (arrmethod.length == 1) {
            return (Annotation[])arrmethod[0].invoke((Object)annotation, new Object[0]);
        }
        Object[] arrobject = new Object[]{annotation, this.type};
        throw new UnionException("Annotation '%s' is not a valid union for %s", arrobject);
    }

    private List<Parameter> process(Annotation annotation, int n) throws Exception {
        if (annotation instanceof Attribute) {
            return this.create(annotation, n);
        }
        if (annotation instanceof Element) {
            return this.create(annotation, n);
        }
        if (annotation instanceof ElementList) {
            return this.create(annotation, n);
        }
        if (annotation instanceof ElementArray) {
            return this.create(annotation, n);
        }
        if (annotation instanceof ElementMap) {
            return this.create(annotation, n);
        }
        if (annotation instanceof ElementListUnion) {
            return this.union(annotation, n);
        }
        if (annotation instanceof ElementMapUnion) {
            return this.union(annotation, n);
        }
        if (annotation instanceof ElementUnion) {
            return this.union(annotation, n);
        }
        if (annotation instanceof Text) {
            return this.create(annotation, n);
        }
        return Collections.emptyList();
    }

    private void register(Parameter parameter) throws Exception {
        String string = parameter.getPath();
        Object object = parameter.getKey();
        if (this.registry.containsKey(object)) {
            this.validate(parameter, object);
        }
        if (this.registry.containsKey((Object)string)) {
            this.validate(parameter, string);
        }
        this.registry.put((Object)string, (Object)parameter);
        this.registry.put(object, (Object)parameter);
    }

    private void scan(Class class_) throws Exception {
        Class[] arrclass = this.constructor.getParameterTypes();
        for (int i = 0; i < arrclass.length; ++i) {
            this.scan(arrclass[i], i);
        }
    }

    private void scan(Class class_, int n) throws Exception {
        Annotation[][] arrannotation = this.constructor.getParameterAnnotations();
        for (int i = 0; i < arrannotation[n].length; ++i) {
            for (Parameter parameter : this.process(arrannotation[n][i], n)) {
                this.builder.insert(parameter, n);
            }
        }
    }

    private List<Parameter> union(Annotation annotation, int n) throws Exception {
        Signature signature = new Signature(this.constructor);
        for (Annotation annotation2 : this.extract(annotation)) {
            Parameter parameter = this.factory.getInstance(this.constructor, annotation, annotation2, n);
            String string = parameter.getPath();
            if (!signature.contains(string)) {
                signature.set(string, parameter);
                this.register(parameter);
                continue;
            }
            Object[] arrobject = new Object[]{string, annotation, this.type};
            throw new UnionException("Annotation name '%s' used more than once in %s for %s", arrobject);
        }
        return signature.getAll();
    }

    private void validate(Parameter parameter, Object object) throws Exception {
        Parameter parameter2 = (Parameter)this.registry.get(object);
        if (parameter.isText() != parameter2.isText()) {
            Annotation annotation = parameter.getAnnotation();
            Annotation annotation2 = parameter2.getAnnotation();
            String string = parameter.getPath();
            if (annotation.equals((Object)annotation2)) {
                if (parameter2.getType() == parameter.getType()) {
                    return;
                }
                Object[] arrobject = new Object[]{string, this.type};
                throw new ConstructorException("Parameter types do not match for '%s' in %s", arrobject);
            }
            Object[] arrobject = new Object[]{string, this.type};
            throw new ConstructorException("Annotations do not match for '%s' in %s", arrobject);
        }
    }

    public List<Signature> getSignatures() throws Exception {
        return this.builder.build();
    }

    public boolean isValid() {
        return this.builder.isValid();
    }
}

