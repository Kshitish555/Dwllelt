/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.zip.ZipEntry
 *  java.util.zip.ZipException
 *  java.util.zip.ZipFile
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.modules.IArchiveFile
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.modules.IArchiveFile;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZipFileArchive
implements IArchiveFile {
    private static final Logger logger = LoggerFactory.getLogger(ZipFileArchive.class);
    private final ZipFile mZipFile;

    private ZipFileArchive(ZipFile zipFile) {
        this.mZipFile = zipFile;
    }

    public static ZipFileArchive getZipFileArchive(File file) throws ZipException, IOException {
        return new ZipFileArchive(new ZipFile(file));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public InputStream getInputStream(ITileSource iTileSource, MapTile mapTile) {
        String string2 = iTileSource.getTileRelativeFilenameString(mapTile);
        ZipEntry zipEntry = this.mZipFile.getEntry(string2);
        if (zipEntry == null) return null;
        try {
            return this.mZipFile.getInputStream(zipEntry);
        }
        catch (IOException iOException) {
            Logger logger = ZipFileArchive.logger;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error getting zip stream: ");
            stringBuilder.append((Object)mapTile);
            logger.warn(stringBuilder.toString(), (Throwable)iOException);
        }
        return null;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("ZipFileArchive [mZipFile=");
        stringBuilder.append(this.mZipFile.getName());
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

