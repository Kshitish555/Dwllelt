/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.LocaleList
 *  android.os.Looper
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.telephony.TelephonyManager
 *  android.text.TextUtils
 *  java.io.ObjectInputStream
 *  java.io.ObjectInputStream$GetField
 *  java.io.PrintWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.math.BigInteger
 *  java.security.MessageDigest
 *  java.text.DecimalFormat
 *  java.text.DecimalFormatSymbols
 *  java.text.SimpleDateFormat
 *  java.util.HashMap
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Random
 *  java.util.Set
 *  java.util.UUID
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package com.adjust.sdk;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.LocaleList;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.AndroidIdUtil;
import com.adjust.sdk.BackoffStrategy;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.MacAddressUtil;
import com.adjust.sdk.OnDeviceIdsRead;
import com.adjust.sdk.Reflection;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {
    private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'Z";
    public static final DecimalFormat SecondsDisplayFormat = Util.newLocalDecimalFormat();
    public static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'Z", Locale.US);
    private static final String fieldReadErrorMessage = "Unable to read '%s' field in migration device with message (%s)";

    public static boolean checkPermission(Context context, String string) {
        try {
            int n2 = context.checkCallingOrSelfPermission(string);
            return n2 == 0;
        }
        catch (Exception exception) {
            ILogger iLogger = Util.getLogger();
            Object[] arrobject = new Object[]{string, exception.getMessage()};
            iLogger.debug("Unable to check permission '%s' with message (%s)", arrobject);
            return false;
        }
    }

    public static String convertToHex(byte[] arrby) {
        BigInteger bigInteger = new BigInteger(1, arrby);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("%0");
        stringBuilder.append(arrby.length << 1);
        stringBuilder.append("x");
        return Util.formatString(stringBuilder.toString(), new Object[]{bigInteger});
    }

    protected static String createUuid() {
        return UUID.randomUUID().toString();
    }

    public static boolean equalBoolean(Boolean bl, Boolean bl2) {
        return Util.equalObject((Object)bl, (Object)bl2);
    }

    public static boolean equalEnum(Enum enum_, Enum enum_2) {
        return Util.equalObject(enum_, enum_2);
    }

    public static boolean equalInt(Integer n2, Integer n3) {
        return Util.equalObject((Object)n2, (Object)n3);
    }

    public static boolean equalLong(Long l2, Long l3) {
        return Util.equalObject((Object)l2, (Object)l3);
    }

    public static boolean equalObject(Object object, Object object2) {
        if (object != null && object2 != null) {
            return object.equals(object2);
        }
        return object == null && object2 == null;
    }

    public static boolean equalString(String string, String string2) {
        return Util.equalObject(string, string2);
    }

    public static boolean equalsDouble(Double d2, Double d3) {
        if (d2 != null && d3 != null) {
            return Double.doubleToLongBits((double)d2) == Double.doubleToLongBits((double)d3);
        }
        return d2 == null && d3 == null;
    }

    public static /* varargs */ String formatString(String string, Object ... arrobject) {
        return String.format((Locale)Locale.US, (String)string, (Object[])arrobject);
    }

    public static String getAndroidId(Context context) {
        return AndroidIdUtil.getAndroidId(context);
    }

    public static int getConnectivityType(Context context) {
        try {
            int n2 = ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo().getType();
            return n2;
        }
        catch (Exception exception) {
            ILogger iLogger = Util.getLogger();
            Object[] arrobject = new Object[]{exception.getMessage()};
            iLogger.warn("Couldn't read connectivity type (%s)", arrobject);
            return -1;
        }
    }

    public static String getCpuAbi() {
        if (Build.VERSION.SDK_INT < 21) {
            return Build.CPU_ABI;
        }
        return null;
    }

    public static String getFireAdvertisingId(ContentResolver contentResolver) {
        if (contentResolver == null) {
            return null;
        }
        try {
            String string = Settings.Secure.getString((ContentResolver)contentResolver, (String)"advertising_id");
            return string;
        }
        catch (Exception exception) {
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Boolean getFireTrackingEnabled(ContentResolver contentResolver) {
        try {
            boolean bl = Settings.Secure.getInt((ContentResolver)contentResolver, (String)"limit_ad_tracking") == 0;
            return bl;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public static void getGoogleAdId(Context context, final OnDeviceIdsRead onDeviceIdsRead) {
        ILogger iLogger = AdjustFactory.getLogger();
        if (Looper.myLooper() != Looper.getMainLooper()) {
            iLogger.debug("GoogleAdId being read in the background", new Object[0]);
            String string = Util.getPlayAdId(context);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("GoogleAdId read ");
            stringBuilder.append(string);
            iLogger.debug(stringBuilder.toString(), new Object[0]);
            onDeviceIdsRead.onGoogleAdIdRead(string);
            return;
        }
        iLogger.debug("GoogleAdId being read in the foreground", new Object[0]);
        new AsyncTask<Context, Void, String>(){

            protected /* varargs */ String a(Context ... arrcontext) {
                ILogger iLogger = AdjustFactory.getLogger();
                String string = Util.getPlayAdId(arrcontext[0]);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("GoogleAdId read ");
                stringBuilder.append(string);
                iLogger.debug(stringBuilder.toString(), new Object[0]);
                return string;
            }

            protected void a(String string) {
                AdjustFactory.getLogger();
                onDeviceIdsRead.onGoogleAdIdRead(string);
            }
        }.execute((Object[])new Context[]{context});
    }

    public static Locale getLocale(Configuration configuration) {
        LocaleList localeList;
        if (Build.VERSION.SDK_INT >= 24 && (localeList = configuration.getLocales()) != null && !localeList.isEmpty()) {
            return localeList.get(0);
        }
        if (Build.VERSION.SDK_INT < 24) {
            return configuration.locale;
        }
        return null;
    }

    private static ILogger getLogger() {
        return AdjustFactory.getLogger();
    }

    public static String getMacAddress(Context context) {
        return MacAddressUtil.getMacAddress(context);
    }

    public static String getMcc(Context context) {
        String string;
        block3 : {
            try {
                string = ((TelephonyManager)context.getSystemService("phone")).getNetworkOperator();
                if (!TextUtils.isEmpty((CharSequence)string)) break block3;
                AdjustFactory.getLogger().warn("Couldn't receive networkOperator string to read MCC", new Object[0]);
                return null;
            }
            catch (Exception exception) {
                AdjustFactory.getLogger().warn("Couldn't return mcc", new Object[0]);
                return null;
            }
        }
        String string2 = string.substring(0, 3);
        return string2;
    }

    public static String getMnc(Context context) {
        String string;
        block3 : {
            try {
                string = ((TelephonyManager)context.getSystemService("phone")).getNetworkOperator();
                if (!TextUtils.isEmpty((CharSequence)string)) break block3;
                AdjustFactory.getLogger().warn("Couldn't receive networkOperator string to read MNC", new Object[0]);
                return null;
            }
            catch (Exception exception) {
                AdjustFactory.getLogger().warn("Couldn't return mnc", new Object[0]);
                return null;
            }
        }
        String string2 = string.substring(3);
        return string2;
    }

    public static int getNetworkType(Context context) {
        try {
            int n2 = ((TelephonyManager)context.getSystemService("phone")).getNetworkType();
            return n2;
        }
        catch (Exception exception) {
            ILogger iLogger = Util.getLogger();
            Object[] arrobject = new Object[]{exception.getMessage()};
            iLogger.warn("Couldn't read network type (%s)", arrobject);
            return -1;
        }
    }

    public static String getPlayAdId(Context context) {
        return Reflection.getPlayAdId(context);
    }

    public static String getReasonString(String string, Throwable throwable) {
        if (throwable != null) {
            return Util.formatString("%s: %s", new Object[]{string, throwable});
        }
        return Util.formatString("%s", string);
    }

    public static String getRootCause(Exception exception) {
        if (!Util.hasRootCause(exception)) {
            return null;
        }
        StringWriter stringWriter = new StringWriter();
        exception.printStackTrace(new PrintWriter((Writer)stringWriter));
        String string = stringWriter.toString();
        int n2 = string.indexOf("Caused by:");
        return string.substring(n2, string.indexOf("\n", n2));
    }

    private static String getSdkPrefix(String string) {
        if (string == null) {
            return null;
        }
        if (!string.contains((CharSequence)"@")) {
            return null;
        }
        String[] arrstring = string.split("@");
        if (arrstring == null) {
            return null;
        }
        if (arrstring.length != 2) {
            return null;
        }
        return arrstring[0];
    }

    public static String getSdkPrefixPlatform(String string) {
        String string2 = Util.getSdkPrefix(string);
        if (string2 == null) {
            return null;
        }
        String[] arrstring = string2.split("\\d+", 2);
        if (arrstring == null) {
            return null;
        }
        if (arrstring.length == 0) {
            return null;
        }
        return arrstring[0];
    }

    public static String getSdkVersion() {
        return "android4.17.0";
    }

    public static String[] getSupportedAbis() {
        if (Build.VERSION.SDK_INT >= 21) {
            return Build.SUPPORTED_ABIS;
        }
        return null;
    }

    public static long getWaitingTime(int n2, BackoffStrategy backoffStrategy) {
        int n3 = backoffStrategy.minRetries;
        if (n2 < n3) {
            return 0L;
        }
        long l2 = Math.min((long)((long)Math.pow((double)2.0, (double)(n2 - n3)) * backoffStrategy.milliSecondMultiplier), (long)backoffStrategy.maxWait);
        double d2 = Util.randomInRange(backoffStrategy.minRange, backoffStrategy.maxRange);
        double d3 = l2;
        Double.isNaN((double)d3);
        return (long)(d3 * d2);
    }

    public static boolean hasRootCause(Exception exception) {
        StringWriter stringWriter = new StringWriter();
        exception.printStackTrace(new PrintWriter((Writer)stringWriter));
        return stringWriter.toString().contains((CharSequence)"Caused by:");
    }

    public static String hash(String string, String string2) {
        try {
            byte[] arrby = string.getBytes("UTF-8");
            MessageDigest messageDigest = MessageDigest.getInstance((String)string2);
            messageDigest.update(arrby, 0, arrby.length);
            String string3 = Util.convertToHex(messageDigest.digest());
            return string3;
        }
        catch (Exception exception) {
            return null;
        }
    }

    public static int hashBoolean(Boolean bl) {
        if (bl == null) {
            return 0;
        }
        return bl.hashCode();
    }

    public static int hashEnum(Enum enum_) {
        if (enum_ == null) {
            return 0;
        }
        return enum_.hashCode();
    }

    public static int hashLong(Long l2) {
        if (l2 == null) {
            return 0;
        }
        return l2.hashCode();
    }

    public static int hashObject(Object object) {
        if (object == null) {
            return 0;
        }
        return object.hashCode();
    }

    public static int hashString(String string) {
        if (string == null) {
            return 0;
        }
        return string.hashCode();
    }

    public static Boolean isPlayTrackingEnabled(Context context) {
        return Reflection.isPlayTrackingEnabled(context);
    }

    public static boolean isUrlFilteredOut(Uri uri) {
        if (uri == null) {
            return true;
        }
        String string = uri.toString();
        if (string != null) {
            if (string.length() == 0) {
                return true;
            }
            return string.matches("^(fb|vk)[0-9]{5,}[^:]*://authorize.*access_token=.*");
        }
        return true;
    }

    public static boolean isValidParameter(String string, String string2, String string3) {
        if (string == null) {
            Util.getLogger().error("%s parameter %s is missing", string3, string2);
            return false;
        }
        if (string.equals((Object)"")) {
            Util.getLogger().error("%s parameter %s is empty", string3, string2);
            return false;
        }
        return true;
    }

    public static String md5(String string) {
        return Util.hash(string, "MD5");
    }

    public static Map<String, String> mergeParameters(Map<String, String> map, Map<String, String> map2, String string) {
        if (map == null) {
            return map2;
        }
        if (map2 == null) {
            return map;
        }
        HashMap hashMap = new HashMap(map);
        ILogger iLogger = Util.getLogger();
        for (Map.Entry entry : map2.entrySet()) {
            String string2 = (String)hashMap.put(entry.getKey(), entry.getValue());
            if (string2 == null) continue;
            Object[] arrobject = new Object[]{entry.getKey(), string2, string, entry.getValue()};
            iLogger.warn("Key %s with value %s from %s parameter was replaced by value %s", arrobject);
        }
        return hashMap;
    }

    private static DecimalFormat newLocalDecimalFormat() {
        return new DecimalFormat("0.0", new DecimalFormatSymbols(Locale.US));
    }

    public static String quote(String string) {
        if (string == null) {
            return null;
        }
        if (!Pattern.compile((String)"\\s").matcher((CharSequence)string).find()) {
            return string;
        }
        return Util.formatString("'%s'", string);
    }

    private static double randomInRange(double d2, double d3) {
        Random random = new Random();
        return d2 + (d3 - d2) * random.nextDouble();
    }

    public static boolean readBooleanField(ObjectInputStream.GetField getField, String string, boolean bl) {
        try {
            boolean bl2 = getField.get(string, bl);
            return bl2;
        }
        catch (Exception exception) {
            ILogger iLogger = Util.getLogger();
            Object[] arrobject = new Object[]{string, exception.getMessage()};
            iLogger.debug(fieldReadErrorMessage, arrobject);
            return bl;
        }
    }

    public static int readIntField(ObjectInputStream.GetField getField, String string, int n2) {
        try {
            int n3 = getField.get(string, n2);
            return n3;
        }
        catch (Exception exception) {
            ILogger iLogger = Util.getLogger();
            Object[] arrobject = new Object[]{string, exception.getMessage()};
            iLogger.debug(fieldReadErrorMessage, arrobject);
            return n2;
        }
    }

    public static long readLongField(ObjectInputStream.GetField getField, String string, long l2) {
        try {
            long l3 = getField.get(string, l2);
            return l3;
        }
        catch (Exception exception) {
            ILogger iLogger = Util.getLogger();
            Object[] arrobject = new Object[]{string, exception.getMessage()};
            iLogger.debug(fieldReadErrorMessage, arrobject);
            return l2;
        }
    }

    /*
     * Exception decompiling
     */
    public static <T> T readObject(Context var0, String var1, String var2, Class<T> var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl152 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public static <T> T readObjectField(ObjectInputStream.GetField getField, String string, T t2) {
        Object object;
        try {
            object = getField.get(string, t2);
        }
        catch (Exception exception) {
            ILogger iLogger = Util.getLogger();
            Object[] arrobject = new Object[]{string, exception.getMessage()};
            iLogger.debug(fieldReadErrorMessage, arrobject);
            return t2;
        }
        return (T)object;
    }

    public static String readStringField(ObjectInputStream.GetField getField, String string, String string2) {
        return Util.readObjectField(getField, string, string2);
    }

    public static void runInBackground(Runnable runnable) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runnable.run();
            return;
        }
        new AsyncTask<Object, Void, Void>(){

            protected /* varargs */ Void doInBackground(Object ... arrobject) {
                ((Runnable)arrobject[0]).run();
                return null;
            }
        }.execute(new Object[]{runnable});
    }

    public static String sha1(String string) {
        return Util.hash(string, "SHA-1");
    }

    public static String sha256(String string) {
        return Util.hash(string, "SHA-256");
    }

    /*
     * Exception decompiling
     */
    public static <T> void writeObject(T var0, Context var1, String var2, String var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl65 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

}

