/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.osmdroid.api.IGeoPoint
 */
package org.osmdroid.api;

import org.osmdroid.api.IGeoPoint;

public interface IMapController {
    public void animateTo(IGeoPoint var1);

    public void setCenter(IGeoPoint var1);

    public int setZoom(int var1);

    public boolean zoomIn();

    public boolean zoomInFixing(int var1, int var2);

    public boolean zoomOut();

    public boolean zoomOutFixing(int var1, int var2);

    public void zoomToSpan(int var1, int var2);
}

