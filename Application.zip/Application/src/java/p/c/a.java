/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package p.c;

import profile.dto.IdentificationLevels;

public final class a {
    public static final /* synthetic */ int[] a;

    static /* synthetic */ {
        int[] arrn = new int[IdentificationLevels.values().length];
        a = arrn;
        arrn[IdentificationLevels.ANONYMOUS.ordinal()] = 1;
        a.a[IdentificationLevels.SIMPLE.ordinal()] = 2;
        a.a[IdentificationLevels.VERIFIED.ordinal()] = 3;
        a.a[IdentificationLevels.FULL.ordinal()] = 4;
    }
}

