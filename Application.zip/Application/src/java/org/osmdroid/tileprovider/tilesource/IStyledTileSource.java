/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.osmdroid.tileprovider.tilesource;

public interface IStyledTileSource<T> {
    public T getStyle();

    public void setStyle(T var1);

    public void setStyle(String var1);
}

