/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amplitude.api;

import com.amplitude.api.d;
import com.amplitude.api.n;
import org.json.JSONException;
import org.json.JSONObject;

public class l {
    public static final String h = "com.amplitude.api.Revenue";
    private static d i = d.a();
    protected String a = null;
    protected int b = 1;
    protected Double c = null;
    protected String d = null;
    protected String e = null;
    protected String f = null;
    protected JSONObject g = null;

    public l a(double d2) {
        this.c = d2;
        return this;
    }

    public l a(int n2) {
        this.b = n2;
        return this;
    }

    public l a(String string) {
        if (n.a(string)) {
            i.e(h, "Invalid empty productId");
            return this;
        }
        this.a = string;
        return this;
    }

    public l a(String string, String string2) {
        this.e = string;
        this.f = string2;
        return this;
    }

    public l a(JSONObject jSONObject) {
        this.g = n.a(jSONObject);
        return this;
    }

    protected boolean a() {
        if (this.c == null) {
            i.e(h, "Invalid revenue, need to set price");
            return false;
        }
        return true;
    }

    public l b(String string) {
        this.d = string;
        return this;
    }

    public l b(JSONObject jSONObject) {
        i.e(h, "setRevenueProperties is deprecated, please use setEventProperties instead");
        return this.a(jSONObject);
    }

    protected JSONObject b() {
        JSONObject jSONObject = this.g;
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        try {
            jSONObject.put("$productId", (Object)this.a);
            jSONObject.put("$quantity", this.b);
            jSONObject.put("$price", (Object)this.c);
            jSONObject.put("$revenueType", (Object)this.d);
            jSONObject.put("$receipt", (Object)this.e);
            jSONObject.put("$receiptSig", (Object)this.f);
            return jSONObject;
        }
        catch (JSONException jSONException) {
            d d2 = i;
            Object[] arrobject = new Object[]{jSONException.toString()};
            d2.b(h, String.format((String)"Failed to convert revenue object to JSON: %s", (Object[])arrobject));
            return jSONObject;
        }
    }

    public boolean equals(Object object) {
        block9 : {
            boolean bl;
            block11 : {
                block12 : {
                    JSONObject jSONObject;
                    block10 : {
                        bl = true;
                        if (this == object) {
                            return bl;
                        }
                        if (object == null) break block9;
                        if (l.class != object.getClass()) {
                            return false;
                        }
                        l l2 = (l)object;
                        if (this.b != l2.b) {
                            return false;
                        }
                        String string = this.a;
                        if (string != null ? !string.equals((Object)l2.a) : l2.a != null) {
                            return false;
                        }
                        Double d2 = this.c;
                        if (d2 != null ? !d2.equals((Object)l2.c) : l2.c != null) {
                            return false;
                        }
                        String string2 = this.d;
                        if (string2 != null ? !string2.equals((Object)l2.d) : l2.d != null) {
                            return false;
                        }
                        String string3 = this.e;
                        if (string3 != null ? !string3.equals((Object)l2.e) : l2.e != null) {
                            return false;
                        }
                        String string4 = this.f;
                        if (string4 != null ? !string4.equals((Object)l2.f) : l2.f != null) {
                            return false;
                        }
                        JSONObject jSONObject2 = this.g;
                        jSONObject = l2.g;
                        if (jSONObject2 == null) break block10;
                        if (n.a(jSONObject2, jSONObject)) break block11;
                        break block12;
                    }
                    if (jSONObject == null) {
                        return bl;
                    }
                }
                bl = false;
            }
            return bl;
        }
        return false;
    }

    public int hashCode() {
        String string = this.a;
        int n2 = string != null ? string.hashCode() : 0;
        int n3 = 31 * (n2 * 31 + this.b);
        Double d2 = this.c;
        int n4 = d2 != null ? d2.hashCode() : 0;
        int n5 = 31 * (n3 + n4);
        String string2 = this.d;
        int n6 = string2 != null ? string2.hashCode() : 0;
        int n7 = 31 * (n5 + n6);
        String string3 = this.e;
        int n8 = string3 != null ? string3.hashCode() : 0;
        int n9 = 31 * (n7 + n8);
        String string4 = this.f;
        int n10 = string4 != null ? string4.hashCode() : 0;
        int n11 = 31 * (n9 + n10);
        JSONObject jSONObject = this.g;
        int n12 = 0;
        if (jSONObject != null) {
            n12 = jSONObject.hashCode();
        }
        return n11 + n12;
    }
}

