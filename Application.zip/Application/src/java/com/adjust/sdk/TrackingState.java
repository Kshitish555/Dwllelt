/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

public final class TrackingState
extends Enum<TrackingState> {
    private static final /* synthetic */ TrackingState[] $VALUES;
    public static final /* enum */ TrackingState OPTED_OUT;
    private int value;

    static {
        TrackingState trackingState;
        OPTED_OUT = trackingState = new TrackingState(1);
        $VALUES = new TrackingState[]{trackingState};
    }

    private TrackingState(int n3) {
        this.value = n3;
    }

    public static TrackingState valueOf(String string) {
        return (TrackingState)Enum.valueOf(TrackingState.class, (String)string);
    }

    public static TrackingState[] values() {
        return (TrackingState[])$VALUES.clone();
    }

    public int getValue() {
        return this.value;
    }
}

