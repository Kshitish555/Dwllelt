/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.amplitude.api;

import android.content.Context;
import com.amplitude.api.c;
import com.amplitude.api.n;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class a {
    static final Map<String, c> a = new HashMap();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static c a(String string) {
        Class<a> class_ = a.class;
        synchronized (a.class) {
            String string2 = n.b(string);
            c c2 = (c)a.get((Object)string2);
            if (c2 == null) {
                c2 = new c(string2);
                a.put((Object)string2, (Object)c2);
            }
            // ** MonitorExit[var5_1] (shouldn't be in output)
            return c2;
        }
    }

    @Deprecated
    public static void a() {
        a.e().c();
    }

    @Deprecated
    public static void a(double d2) {
        a.e().a(d2);
    }

    @Deprecated
    public static void a(long l2) {
        a.e().i(l2);
    }

    @Deprecated
    public static void a(Context context, String string) {
        a.e().a(context, string);
    }

    @Deprecated
    public static void a(Context context, String string, String string2) {
        a.e().a(context, string, string2);
    }

    @Deprecated
    public static void a(String string, int n2, double d2) {
        a.e().a(string, n2, d2);
    }

    @Deprecated
    public static void a(String string, int n2, double d2, String string2, String string3) {
        a.e().a(string, n2, d2, string2, string3);
    }

    @Deprecated
    public static void a(String string, JSONObject jSONObject) {
        a.e().a(string, jSONObject);
    }

    @Deprecated
    public static void a(JSONObject jSONObject) {
        a.e().a(jSONObject);
    }

    @Deprecated
    public static void a(JSONObject jSONObject, boolean bl) {
        a.e().a(jSONObject, bl);
    }

    @Deprecated
    public static void a(boolean bl) {
        a.e().b(bl);
    }

    @Deprecated
    public static void b() {
        a.e().e();
    }

    @Deprecated
    public static void b(String string) {
        a.e().b(string);
    }

    @Deprecated
    public static void b(boolean bl) {
        a.e().e(bl);
    }

    @Deprecated
    public static void c() {
    }

    @Deprecated
    public static void c(String string) {
        a.e().f(string);
    }

    @Deprecated
    public static String d() {
        return a.e().g();
    }

    public static c e() {
        return a.a(null);
    }

    @Deprecated
    public static void f() {
    }

    @Deprecated
    public static void g() {
        a.e().p();
    }

    @Deprecated
    public static void h() {
        a.e().q();
    }
}

