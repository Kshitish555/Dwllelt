/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  l.a.k.a.f
 *  l.a.k.a.r
 */
package l.a.k.a.x;

import l.a.k.a.f;
import l.a.k.a.r;

public class x
extends f {
    private String f;
    private r h;
    private final String o;
    private int s;

    protected x(int n2, String string, f f2) {
        super(n2, f2);
        this.o = string;
    }

    public x(String string, f f2) {
        this(327680, string, f2);
    }

    public r a(int n2, String string, String string2, String string3, String[] arrstring) {
        if ("<clinit>".equals((Object)string)) {
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(this.o);
            int n3 = this.s;
            this.s = n3 + 1;
            stringBuffer.append(n3);
            String string4 = stringBuffer.toString();
            r r2 = this.d.a(10, string4, string2, string3, arrstring);
            if (this.h == null) {
                this.h = this.d.a(10, string, string2, null, null);
            }
            this.h.a(184, this.f, string4, string2, false);
            return r2;
        }
        return this.d.a(n2, string, string2, string3, arrstring);
    }

    public void a() {
        r r2 = this.h;
        if (r2 != null) {
            r2.a(177);
            this.h.c(0, 0);
        }
        this.d.a();
    }

    public void a(int n2, int n3, String string, String string2, String string3, String[] arrstring) {
        this.d.a(n2, n3, string, string2, string3, arrstring);
        this.f = string;
    }
}

