/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.NotSerializableException
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.objenesis.ObjenesisException
 *  org.objenesis.f.a
 *  org.objenesis.f.c.d
 *  org.objenesis.f.e.g
 *  org.objenesis.f.e.h
 *  org.objenesis.f.f.c
 *  org.objenesis.f.g.b
 *  org.objenesis.f.h.d
 *  org.objenesis.g.a
 *  org.objenesis.g.c
 */
package org.objenesis.g;

import java.io.NotSerializableException;
import java.io.Serializable;
import org.objenesis.ObjenesisException;
import org.objenesis.f.e.g;
import org.objenesis.f.e.h;
import org.objenesis.f.g.b;
import org.objenesis.g.a;
import org.objenesis.g.c;

public class d
extends a {
    public <T> org.objenesis.f.a<T> a(Class<T> class_) {
        if (Serializable.class.isAssignableFrom(class_)) {
            if (!c.m.startsWith("Java HotSpot") && !c.a((String)"OpenJDK")) {
                if (c.m.startsWith("Dalvik")) {
                    if (c.f()) {
                        return new h(class_);
                    }
                    return new org.objenesis.f.c.d(class_);
                }
                if (c.m.startsWith("GNU libgcj")) {
                    return new org.objenesis.f.f.c(class_);
                }
                if (c.m.startsWith("PERC")) {
                    return new b(class_);
                }
                return new h(class_);
            }
            if (c.g()) {
                return new g(class_);
            }
            if (c.h.equals((Object)"9")) {
                return new org.objenesis.f.h.d(class_);
            }
            return new h(class_);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(class_);
        stringBuilder.append(" not serializable");
        throw new ObjenesisException((Throwable)new NotSerializableException(stringBuilder.toString()));
    }
}

