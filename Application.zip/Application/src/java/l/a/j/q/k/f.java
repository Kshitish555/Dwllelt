/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import l.a.j.e;
import l.a.j.q.e;
import l.a.k.a.r;

public final class f
extends Enum<f>
implements e {
    private static final e.c P4;
    private static final /* synthetic */ f[] Q4;
    public static final /* enum */ f d;
    public static final /* enum */ f f;
    public static final /* enum */ f h;
    public static final /* enum */ f o;
    public static final /* enum */ f s;
    public static final /* enum */ f t;
    public static final /* enum */ f w;
    private final int c;

    static {
        f f2;
        d = new f(2);
        f = new f(3);
        h = new f(4);
        o = new f(5);
        s = new f(6);
        t = new f(7);
        w = f2 = new f(8);
        f[] arrf = new f[]{d, f, h, o, s, t, f2};
        Q4 = arrf;
        P4 = l.a.j.q.f.f.f();
    }

    private f(int n3) {
        this.c = n3;
    }

    public static e a(int n2) {
        switch (n2) {
            default: {
                if (n2 < -128 || n2 > 127) break;
                return new b((byte)n2);
            }
            case 5: {
                return w;
            }
            case 4: {
                return t;
            }
            case 3: {
                return s;
            }
            case 2: {
                return o;
            }
            case 1: {
                return h;
            }
            case 0: {
                return f;
            }
            case -1: {
                return d;
            }
        }
        if (n2 >= -32768 && n2 <= 32767) {
            return new c((short)n2);
        }
        return new a(n2);
    }

    public static e a(boolean bl) {
        if (bl) {
            return h;
        }
        return f;
    }

    public static f valueOf(String string) {
        return (f)Enum.valueOf(f.class, (String)string);
    }

    public static f[] values() {
        return (f[])Q4.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.c);
        return P4;
    }

    public boolean x() {
        return true;
    }

    protected static class a
    implements e {
        private final int c;

        protected a(int n2) {
            this.c = n2;
        }

        public e.c a(r r2, e.d d2) {
            r2.a((Object)this.c);
            return P4;
        }

        protected boolean b(Object object) {
            return object instanceof a;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof a)) {
                return false;
            }
            a a2 = (a)object;
            if (!a2.b(this)) {
                return false;
            }
            return this.c == a2.c;
        }

        public int hashCode() {
            return 59 + this.c;
        }

        public boolean x() {
            return true;
        }
    }

    protected static class b
    implements e {
        private final byte c;

        protected b(byte by) {
            this.c = by;
        }

        public e.c a(r r2, e.d d2) {
            r2.b(16, (int)this.c);
            return P4;
        }

        protected boolean b(Object object) {
            return object instanceof b;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof b)) {
                return false;
            }
            b b2 = (b)object;
            if (!b2.b(this)) {
                return false;
            }
            return this.c == b2.c;
        }

        public int hashCode() {
            return 59 + this.c;
        }

        public boolean x() {
            return true;
        }
    }

    protected static class c
    implements e {
        private final short c;

        protected c(short s2) {
            this.c = s2;
        }

        public e.c a(r r2, e.d d2) {
            r2.b(17, (int)this.c);
            return P4;
        }

        protected boolean b(Object object) {
            return object instanceof c;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof c)) {
                return false;
            }
            c c2 = (c)object;
            if (!c2.b(this)) {
                return false;
            }
            return this.c == c2.c;
        }

        public int hashCode() {
            return 59 + this.c;
        }

        public boolean x() {
            return true;
        }
    }

}

