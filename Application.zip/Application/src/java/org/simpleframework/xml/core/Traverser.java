/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Decorator
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.ClassType;
import org.simpleframework.xml.core.Composite;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.RootException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Style;

class Traverser {
    private final Context context;
    private final Style style;

    public Traverser(Context context) {
        this.style = context.getStyle();
        this.context = context;
    }

    private Composite getComposite(Class class_) throws Exception {
        Type type = this.getType(class_);
        if (class_ != null) {
            return new Composite(this.context, type);
        }
        throw new RootException("Can not instantiate null class", new Object[0]);
    }

    private Decorator getDecorator(Class class_) throws Exception {
        return this.context.getDecorator(class_);
    }

    private Type getType(Class class_) {
        return new ClassType(class_);
    }

    private Object read(InputNode inputNode, Class class_, Object object) throws Exception {
        if (this.getName(class_) != null) {
            return object;
        }
        throw new RootException("Root annotation required for %s", new Object[]{class_});
    }

    protected String getName(Class class_) throws Exception {
        String string = this.context.getName(class_);
        return this.style.getElement(string);
    }

    public Object read(InputNode inputNode, Class class_) throws Exception {
        Object object = this.getComposite(class_).read(inputNode);
        if (object != null) {
            return this.read(inputNode, object.getClass(), object);
        }
        return null;
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Class class_ = object.getClass();
        return this.read(inputNode, class_, this.getComposite(class_).read(inputNode, object));
    }

    public boolean validate(InputNode inputNode, Class class_) throws Exception {
        Composite composite = this.getComposite(class_);
        if (this.getName(class_) != null) {
            return composite.validate(inputNode);
        }
        throw new RootException("Root annotation required for %s", new Object[]{class_});
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        this.write(outputNode, object, object.getClass());
    }

    public void write(OutputNode outputNode, Object object, Class class_) throws Exception {
        Class class_2 = object.getClass();
        String string = this.getName(class_2);
        if (string != null) {
            this.write(outputNode, object, class_, string);
            return;
        }
        throw new RootException("Root annotation required for %s", new Object[]{class_2});
    }

    public void write(OutputNode outputNode, Object object, Class class_, String string) throws Exception {
        OutputNode outputNode2 = outputNode.getChild(string);
        Type type = this.getType(class_);
        if (object != null) {
            Class class_2 = object.getClass();
            Decorator decorator = this.getDecorator(class_2);
            if (decorator != null) {
                decorator.decorate(outputNode2);
            }
            if (!this.context.setOverride(type, object, outputNode2)) {
                this.getComposite(class_2).write(outputNode2, object);
            }
        }
        outputNode2.commit();
    }
}

