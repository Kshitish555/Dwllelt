/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Introspector
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Introspector;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.Primitive;
import org.simpleframework.xml.core.TemplateLabel;
import org.simpleframework.xml.core.TextException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.Format;

class TextLabel
extends TemplateLabel {
    private Contact contact;
    private boolean data;
    private Introspector detail;
    private String empty;
    private Text label;
    private Expression path;
    private boolean required;
    private Class type;

    public TextLabel(Contact contact, Text text, Format format) {
        this.detail = new Introspector(contact, (Label)this, format);
        this.required = text.required();
        this.type = contact.getType();
        this.empty = text.empty();
        this.data = text.data();
        this.contact = contact;
        this.label = text;
    }

    public Annotation getAnnotation() {
        return this.label;
    }

    public Contact getContact() {
        return this.contact;
    }

    public Converter getConverter(Context context) throws Exception {
        Object object = this.getEmpty(context);
        Contact contact = this.getContact();
        if (context.isPrimitive((Type)contact)) {
            return new Primitive(context, contact, (String)object);
        }
        Object[] arrobject = new Object[]{contact, this.label};
        throw new TextException("Cannot use %s to represent %s", arrobject);
    }

    public Decorator getDecorator() throws Exception {
        return null;
    }

    public String getEmpty(Context context) {
        if (this.detail.isEmpty(this.empty)) {
            return null;
        }
        return this.empty;
    }

    public Expression getExpression() throws Exception {
        if (this.path == null) {
            this.path = this.detail.getExpression();
        }
        return this.path;
    }

    public String getName() {
        return "";
    }

    public String getOverride() {
        return this.contact.toString();
    }

    public String getPath() throws Exception {
        return this.getExpression().getPath();
    }

    public Class getType() {
        return this.type;
    }

    public boolean isData() {
        return this.data;
    }

    @Override
    public boolean isInline() {
        return true;
    }

    public boolean isRequired() {
        return this.required;
    }

    @Override
    public boolean isText() {
        return true;
    }

    public String toString() {
        return this.detail.toString();
    }
}

