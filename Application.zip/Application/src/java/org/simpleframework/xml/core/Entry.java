/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  org.simpleframework.xml.ElementMap
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.core.ClassType;
import org.simpleframework.xml.core.CompositeKey;
import org.simpleframework.xml.core.CompositeValue;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.PrimitiveKey;
import org.simpleframework.xml.core.PrimitiveValue;
import org.simpleframework.xml.strategy.Type;

class Entry {
    private static final String DEFAULT_NAME = "entry";
    private boolean attribute;
    private Contact contact;
    private String entry;
    private String key;
    private Class keyType;
    private ElementMap label;
    private String value;
    private Class valueType;

    public Entry(Contact contact, ElementMap elementMap) {
        this.attribute = elementMap.attribute();
        this.entry = elementMap.entry();
        this.value = elementMap.value();
        this.key = elementMap.key();
        this.contact = contact;
        this.label = elementMap;
    }

    private Class getDependent(int n2) throws Exception {
        Class[] arrclass = this.contact.getDependents();
        if (arrclass.length < n2) {
            return Object.class;
        }
        if (arrclass.length == 0) {
            return Object.class;
        }
        return arrclass[n2];
    }

    private boolean isEmpty(String string2) {
        return string2.length() == 0;
    }

    public Contact getContact() {
        return this.contact;
    }

    public String getEntry() throws Exception {
        String string2 = this.entry;
        if (string2 == null) {
            return string2;
        }
        if (this.isEmpty(string2)) {
            this.entry = DEFAULT_NAME;
        }
        return this.entry;
    }

    public String getKey() throws Exception {
        String string2 = this.key;
        if (string2 == null) {
            return string2;
        }
        if (this.isEmpty(string2)) {
            this.key = null;
        }
        return this.key;
    }

    public Converter getKey(Context context) throws Exception {
        Type type = this.getKeyType();
        if (context.isPrimitive(type)) {
            return new PrimitiveKey(context, this, type);
        }
        return new CompositeKey(context, this, type);
    }

    protected Type getKeyType() throws Exception {
        if (this.keyType == null) {
            Class class_;
            this.keyType = class_ = this.label.keyType();
            if (class_ == Void.TYPE) {
                this.keyType = this.getDependent(0);
            }
        }
        return new ClassType(this.keyType);
    }

    public String getValue() throws Exception {
        String string2 = this.value;
        if (string2 == null) {
            return string2;
        }
        if (this.isEmpty(string2)) {
            this.value = null;
        }
        return this.value;
    }

    public Converter getValue(Context context) throws Exception {
        Type type = this.getValueType();
        if (context.isPrimitive(type)) {
            return new PrimitiveValue(context, this, type);
        }
        return new CompositeValue(context, this, type);
    }

    protected Type getValueType() throws Exception {
        if (this.valueType == null) {
            Class class_;
            this.valueType = class_ = this.label.valueType();
            if (class_ == Void.TYPE) {
                this.valueType = this.getDependent(1);
            }
        }
        return new ClassType(this.valueType);
    }

    public boolean isAttribute() {
        return this.attribute;
    }

    public boolean isInline() throws Exception {
        return this.isAttribute();
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.label, this.contact};
        return String.format((String)"%s on %s", (Object[])arrobject);
    }
}

