/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.github.classgraph.utils.h
 *  io.github.classgraph.utils.p
 *  java.lang.ClassLoader
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package h.a.a;

import h.a.a.l0;
import io.github.classgraph.utils.h;
import io.github.classgraph.utils.p;

public interface m {
    public a a(ClassLoader var1);

    public void a(l0 var1, ClassLoader var2, h var3, p var4) throws Exception;

    public String[] a();

    public ClassLoader b(ClassLoader var1);

    public static final class a
    extends Enum<a> {
        public static final /* enum */ a c;
        public static final /* enum */ a d;
        private static final /* synthetic */ a[] f;

        static {
            a a2;
            c = new a();
            d = a2 = new a();
            a[] arra = new a[]{c, a2};
            f = arra;
        }

        public static a valueOf(String string) {
            return (a)Enum.valueOf(a.class, (String)string);
        }

        public static a[] values() {
            return (a[])f.clone();
        }
    }

}

