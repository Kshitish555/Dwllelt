/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.github.classgraph.utils.j
 *  io.github.classgraph.utils.k
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Comparable
 *  java.lang.Object
 *  java.lang.String
 *  java.net.URL
 *  java.nio.ByteBuffer
 */
package h.a.a;

import h.a.a.e0;
import io.github.classgraph.utils.j;
import io.github.classgraph.utils.k;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.ByteBuffer;

public abstract class h0
implements Closeable,
Comparable<h0> {
    protected InputStream c;
    protected ByteBuffer d;
    protected long f = -1L;
    private String h;

    public int a(h0 h02) {
        return this.toString().compareTo(h02.toString());
    }

    protected byte[] c() {
        if (this.d.hasArray()) {
            return this.d.array();
        }
        byte[] arrby = new byte[this.d.remaining()];
        this.d.get(arrby);
        return arrby;
    }

    public abstract void close();

    protected InputStream e() {
        InputStream inputStream = this.c;
        if (inputStream == null) {
            this.c = inputStream = j.a((ByteBuffer)this.d);
        }
        return inputStream;
    }

    public boolean equals(Object object) {
        if (!(object instanceof h0)) {
            return false;
        }
        return this.toString().equals((Object)object.toString());
    }

    public abstract File g();

    public abstract String getPath();

    public abstract URL h();

    public int hashCode() {
        return this.toString().hashCode();
    }

    public long i() {
        return this.f;
    }

    public abstract e0 k();

    public abstract String l();

    public abstract URL m();

    protected byte[] n() throws IOException {
        return j.b((InputStream)this.c, (long)this.f, null);
    }

    protected ByteBuffer o() throws IOException {
        ByteBuffer byteBuffer = this.d;
        if (byteBuffer == null) {
            this.d = byteBuffer = ByteBuffer.wrap((byte[])this.n());
        }
        return byteBuffer;
    }

    public abstract byte[] p() throws IOException;

    public abstract InputStream q() throws IOException;

    public abstract ByteBuffer read() throws IOException;

    abstract k s() throws IOException;

    public String toString() {
        String string;
        String string2 = this.h;
        if (string2 != null) {
            return string2;
        }
        this.h = string = this.u();
        return string;
    }

    protected abstract String u();

    protected class a
    extends InputStream {
        private InputStream c;
        private h0 d;

        protected a(h0 h03, InputStream inputStream) throws IOException {
            if (inputStream != null) {
                this.c = inputStream;
                this.d = h03;
                return;
            }
            throw new IOException("InputStream cannot be null");
        }

        public int available() throws IOException {
            InputStream inputStream = this.c;
            if (inputStream != null) {
                return inputStream.available();
            }
            throw new IOException("InputStream is not open");
        }

        public void close() throws IOException {
            InputStream inputStream = this.c;
            if (inputStream != null) {
                inputStream.close();
                this.c = null;
                this.d.close();
                this.d = null;
                return;
            }
            throw new IOException("InputStream is not open");
        }

        public void mark(int n2) {
            a a2 = this;
            synchronized (a2) {
                this.c.mark(n2);
                return;
            }
        }

        public boolean markSupported() {
            return this.c.markSupported();
        }

        public int read() throws IOException {
            InputStream inputStream = this.c;
            if (inputStream != null) {
                return inputStream.read();
            }
            throw new IOException("InputStream is not open");
        }

        public int read(byte[] arrby) throws IOException {
            InputStream inputStream = this.c;
            if (inputStream != null) {
                return inputStream.read(arrby);
            }
            throw new IOException("InputStream is not open");
        }

        public int read(byte[] arrby, int n2, int n3) throws IOException {
            InputStream inputStream = this.c;
            if (inputStream != null) {
                return inputStream.read(arrby, n2, n3);
            }
            throw new IOException("InputStream is not open");
        }

        public void reset() throws IOException {
            a a2 = this;
            synchronized (a2) {
                if (this.c != null) {
                    this.c.reset();
                    return;
                }
                throw new IOException("InputStream is not open");
            }
        }

        public long skip(long l2) throws IOException {
            InputStream inputStream = this.c;
            if (inputStream != null) {
                return inputStream.skip(l2);
            }
            throw new IOException("InputStream is not open");
        }
    }

}

