/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.InvocationHandler
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  l.a.h.a
 *  l.a.h.a$b
 *  l.a.h.h.a
 *  l.a.h.h.b
 *  l.a.h.i.a
 *  l.a.h.i.a$d
 *  l.a.h.i.b
 *  l.a.h.i.d
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.h.k.c$f$f
 *  l.a.h.k.c$f$f$b
 *  l.a.h.k.d
 *  l.a.h.k.d$f
 *  l.a.i.i.a
 *  l.a.i.i.a$b
 *  l.a.i.i.a$g
 *  l.a.j.e$g
 *  l.a.j.h
 *  l.a.j.q.b
 *  l.a.j.q.b$c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 *  l.a.j.q.l.a
 *  l.a.j.q.l.c
 *  l.a.j.q.l.e
 *  l.a.k.a.r
 *  l.a.l.r
 *  l.a.l.r$a
 *  l.a.l.s
 *  l.a.l.x
 *  l.a.n.e
 */
package l.a.j;

import java.lang.reflect.InvocationHandler;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import l.a.h.a;
import l.a.h.h.a;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.h.k.d;
import l.a.i.i.a;
import l.a.j.e;
import l.a.j.h;
import l.a.j.q.b;
import l.a.j.q.e;
import l.a.j.q.i.a;
import l.a.j.q.k.i;
import l.a.j.q.l.d;
import l.a.l.r;
import l.a.l.s;
import l.a.l.x;

public abstract class f
implements l.a.j.e {
    private static final c.f h = new c.f.f.b(InvocationHandler.class);
    private static final boolean o = false;
    protected static final boolean s = true;
    protected final String c;
    protected final l.a.j.q.i.a d;
    protected final boolean f;

    protected f(String string, boolean bl, l.a.j.q.i.a a2) {
        this.c = string;
        this.f = bl;
        this.d = a2;
    }

    private List<e> a(l.a.h.i.a a2) {
        d.f f2 = a2.getParameters().E();
        ArrayList arrayList = new ArrayList(f2.size());
        Iterator iterator = f2.iterator();
        int n2 = 1;
        while (iterator.hasNext()) {
            c.f f3 = (c.f)iterator.next();
            e[] arre = new e[]{l.a.j.q.l.e.a((l.a.h.k.b)f3).a(n2), this.d.a(f3, c.f.b0, a.d.d)};
            arrayList.add((Object)new e.a(arre));
            n2 += f3.l().c();
        }
        return arrayList;
    }

    public static f a(String string) {
        return f.a(string, a.c.a.c);
    }

    public static f a(String string, a.b b2) {
        return new a(string, true, l.a.j.q.i.a.w0, b2){
            private final a.b t;
            {
                this.t = b2;
            }

            public l.a.i.i.c a(l.a.i.i.c c2) {
                return c2;
            }

            @Override
            public l.a.j.e a(l.a.j.q.i.a a2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public a a() {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public l.a.j.q.b a(e.g g2) {
                a.g g3 = this.t.a(g2.c()).a(this.c);
                if (g3.c()) {
                    if (g3.e().getType().y0().c(InvocationHandler.class)) {
                        return new l.a.j.q.b(g2.c(), g3.e()){
                            private final l.a.h.k.c c;
                            private final l.a.h.h.a d;
                            {
                                this.c = c2;
                                this.d = a2;
                            }

                            private f a() {
                                return b.this;
                            }

                            public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                                b b2 = b.this;
                                e.d d3 = this.d.isStatic() ? e.d.c : l.a.j.q.l.e.c();
                                return b2.a(r2, d2, a2, d3, this.d);
                            }

                            public boolean equals(Object object) {
                                block2 : {
                                    block3 : {
                                        if (this == object) break block2;
                                        if (object == null || a.class != object.getClass()) break block3;
                                        l.a.h.k.c c2 = this.c;
                                        a a2 = object;
                                        if (c2.equals((Object)a2.c) && this.d.equals((Object)a2.d) && b.this.equals(a2.a())) break block2;
                                    }
                                    return false;
                                }
                                return true;
                            }

                            public int hashCode() {
                                return 31 * (31 * b.this.hashCode() + this.c.hashCode()) + this.d.hashCode();
                            }
                        };
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Field ");
                    stringBuilder.append((Object)g3.e());
                    stringBuilder.append(" does not declare a type that is assignable to invocation handler");
                    throw new IllegalStateException(stringBuilder.toString());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Could not find a field named '");
                stringBuilder.append(this.c);
                stringBuilder.append("' for ");
                stringBuilder.append((Object)g2.c());
                throw new IllegalStateException(stringBuilder.toString());
            }

            @Override
            protected boolean a(Object object) {
                return object instanceof b;
            }

            @Override
            public boolean equals(Object object) {
                if (object == this) {
                    return true;
                }
                if (!(object instanceof b)) {
                    return false;
                }
                b b2 = object;
                if (!b2.a(this)) {
                    return false;
                }
                if (!super.equals(object)) {
                    return false;
                }
                a.b b3 = this.t;
                a.b b4 = b2.t;
                return !(b3 == null ? b4 != null : !b3.equals((Object)b4));
            }

            @Override
            public int hashCode() {
                int n2 = 59 + super.hashCode();
                a.b b2 = this.t;
                int n3 = n2 * 59;
                int n4 = b2 == null ? 43 : b2.hashCode();
                return n3 + n4;
            }

        };
    }

    public static f a(InvocationHandler invocationHandler) {
        Object[] arrobject = new Object[]{"invocationHandler", l.a.n.e.a((int)invocationHandler.hashCode())};
        return f.a(invocationHandler, String.format((String)"%s$%s", (Object[])arrobject));
    }

    public static f a(InvocationHandler invocationHandler, String string) {
        return new a(string, true, l.a.j.q.i.a.w0, invocationHandler){
            private static final String w = "invocationHandler";
            protected final InvocationHandler t;
            {
                this.t = invocationHandler;
            }

            public l.a.i.i.c a(l.a.i.i.c c2) {
                return c2.a(new a.g(this.c, 4105, h)).a(new h.b(this.c, (Object)this.t));
            }

            @Override
            public l.a.j.e a(l.a.j.q.i.a a2) {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public a a() {
                return new /* invalid duplicate definition of identical inner class */;
            }

            @Override
            public l.a.j.q.b a(e.g g2) {
                return new l.a.j.q.b(g2.c()){
                    private final l.a.h.k.c c;
                    {
                        this.c = c3;
                    }

                    private f a() {
                        return c.this;
                    }

                    public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                        return c.this.a(r2, d2, a2, e.d.c, (l.a.h.h.a)((l.a.h.h.b)this.c.q().b((r)s.m((String)c.this.c).a((r)s.b((c.f)h)))).b1());
                    }

                    public boolean equals(Object object) {
                        block2 : {
                            block3 : {
                                if (this == object) break block2;
                                if (object == null || a.class != object.getClass()) break block3;
                                l.a.h.k.c c2 = this.c;
                                a a2 = object;
                                if (c2.equals((Object)a2.c) && c.this.equals(a2.a())) break block2;
                            }
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return 31 * c.this.hashCode() + this.c.hashCode();
                    }
                };
            }

            @Override
            protected boolean a(Object object) {
                return object instanceof c;
            }

            @Override
            public boolean equals(Object object) {
                if (object == this) {
                    return true;
                }
                if (!(object instanceof c)) {
                    return false;
                }
                c c2 = object;
                if (!c2.a(this)) {
                    return false;
                }
                if (!super.equals(object)) {
                    return false;
                }
                InvocationHandler invocationHandler = this.t;
                InvocationHandler invocationHandler2 = c2.t;
                return !(invocationHandler == null ? invocationHandler2 != null : !invocationHandler.equals((Object)invocationHandler2));
            }

            @Override
            public int hashCode() {
                int n2 = 59 + super.hashCode();
                InvocationHandler invocationHandler = this.t;
                int n3 = n2 * 59;
                int n4 = invocationHandler == null ? 43 : invocationHandler.hashCode();
                return n3 + n4;
            }

        };
    }

    public abstract a a();

    protected b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2, e e2, l.a.h.h.a a3) {
        if (!a2.isStatic()) {
            e[] arre = new e[8];
            arre[0] = e2;
            arre[1] = l.a.j.q.l.a.a((l.a.h.h.a)a3).read();
            arre[2] = l.a.j.q.l.e.c();
            i.c c2 = this.f ? i.a((a.d)a2.i()).cached() : i.a((a.d)a2.i());
            arre[3] = c2;
            arre[4] = l.a.j.q.j.b.a(c.f.b0).a(this.a(a2));
            arre[5] = l.a.j.q.l.c.a((l.a.h.i.a)((l.a.h.i.a)h.u().b1()));
            arre[6] = this.d.a(c.f.b0, a2.getReturnType(), a.d.f);
            arre[7] = d.a((l.a.h.k.b)a2.getReturnType());
            return new b.c(new e.a(arre).a(r2, d2).a(), a2.l());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("It is not possible to apply an invocation handler onto the static method ");
        stringBuilder.append((Object)a2);
        throw new IllegalStateException(stringBuilder.toString());
    }

    protected boolean a(Object object) {
        return object instanceof f;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof f)) {
            return false;
        }
        f f2 = (f)object;
        if (!f2.a(this)) {
            return false;
        }
        String string = this.c;
        String string2 = f2.c;
        if (string == null ? string2 != null : !string.equals((Object)string2)) {
            return false;
        }
        l.a.j.q.i.a a2 = this.d;
        l.a.j.q.i.a a3 = f2.d;
        if (a2 == null ? a3 != null : !a2.equals((Object)a3)) {
            return false;
        }
        return this.f == f2.f;
    }

    public int hashCode() {
        String string = this.c;
        int n2 = 43;
        int n3 = string == null ? 43 : string.hashCode();
        int n4 = n3 + 59;
        l.a.j.q.i.a a2 = this.d;
        int n5 = n4 * 59;
        if (a2 != null) {
            n2 = a2.hashCode();
        }
        int n6 = 59 * (n5 + n2);
        int n7 = this.f ? 79 : 97;
        return n6 + n7;
    }

    protected static interface a
    extends l.a.j.e {
        public l.a.j.e a(l.a.j.q.i.a var1);
    }

}

