/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 */
package org.osmdroid.tileprovider;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

public class ExpirableBitmapDrawable
extends BitmapDrawable {
    public static final int EXPIRED = -1;
    private int[] mState = new int[0];

    public ExpirableBitmapDrawable(Bitmap bitmap2) {
        super(bitmap2);
    }

    public static boolean isDrawableExpired(Drawable drawable) {
        if (!drawable.isStateful()) {
            return false;
        }
        int[] arrn = drawable.getState();
        for (int i2 = 0; i2 < arrn.length; ++i2) {
            if (arrn[i2] != -1) continue;
            return true;
        }
        return false;
    }

    public int[] getState() {
        return this.mState;
    }

    public boolean isStateful() {
        return this.mState.length > 0;
    }

    public boolean setState(int[] arrn) {
        this.mState = arrn;
        return true;
    }
}

