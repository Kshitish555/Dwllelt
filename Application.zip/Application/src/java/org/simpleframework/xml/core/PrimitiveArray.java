/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Array
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.Position
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Array;
import org.simpleframework.xml.core.ArrayFactory;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.Primitive;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Position;

class PrimitiveArray
implements Converter {
    private final Type entry;
    private final ArrayFactory factory;
    private final String parent;
    private final Primitive root;
    private final Type type;

    public PrimitiveArray(Context context, Type type, Type type2, String string2) {
        this.factory = new ArrayFactory(context, type);
        this.root = new Primitive(context, type2);
        this.parent = string2;
        this.entry = type2;
        this.type = type;
    }

    private boolean isOverridden(OutputNode outputNode, Object object) throws Exception {
        return this.factory.setOverride(this.entry, object, outputNode);
    }

    private boolean validate(InputNode inputNode, Class class_) throws Exception {
        InputNode inputNode2;
        while ((inputNode2 = inputNode.getNext()) != null) {
            this.root.validate(inputNode2);
        }
        return true;
    }

    private void write(OutputNode outputNode, Object object, int n) throws Exception {
        Object object2 = Array.get((Object)object, (int)n);
        if (object2 != null && !this.isOverridden(outputNode, object2)) {
            this.root.write(outputNode, object2);
        }
    }

    public Object read(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        Object object = instance.getInstance();
        if (!instance.isReference()) {
            return this.read(inputNode, object);
        }
        return object;
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        ElementException elementException;
        Position position;
        int n = Array.getLength((Object)object);
        int n2 = 0;
        do {
            position = inputNode.getPosition();
            InputNode inputNode2 = inputNode.getNext();
            if (inputNode2 == null) {
                return object;
            }
            if (n2 >= n) break;
            Array.set((Object)object, (int)n2, (Object)this.root.read(inputNode2));
            ++n2;
        } while (true);
        Object[] arrobject = new Object[]{this.type, position};
        elementException = new ElementException("Array length missing or incorrect for %s at %s", arrobject);
        throw elementException;
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            instance.setInstance(null);
            return this.validate(inputNode, instance.getType());
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        int n = Array.getLength((Object)object);
        for (int i = 0; i < n; ++i) {
            OutputNode outputNode2 = outputNode.getChild(this.parent);
            if (outputNode2 == null) {
                return;
            }
            this.write(outputNode2, object, i);
        }
    }
}

