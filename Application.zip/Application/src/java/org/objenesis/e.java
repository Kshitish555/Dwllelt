/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  org.objenesis.b
 *  org.objenesis.g.b
 */
package org.objenesis;

import org.objenesis.g.b;
import org.objenesis.g.f;

public class e
extends org.objenesis.b {
    public e() {
        super((b)new f());
    }

    public e(boolean bl) {
        super((b)new f(), bl);
    }
}

