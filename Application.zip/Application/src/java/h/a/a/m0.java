/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.m0$g
 *  io.github.classgraph.utils.g
 *  io.github.classgraph.utils.l
 *  io.github.classgraph.utils.p
 *  io.github.classgraph.utils.q
 *  java.lang.Exception
 *  java.lang.InterruptedException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.AbstractMap
 *  java.util.AbstractMap$SimpleEntry
 *  java.util.ArrayList
 *  java.util.Comparator
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ExecutionException
 *  java.util.concurrent.ExecutorService
 */
package h.a.a;

import h.a.a.h;
import h.a.a.j0;
import h.a.a.l0;
import h.a.a.m0;
import h.a.a.r;
import io.github.classgraph.utils.l;
import io.github.classgraph.utils.p;
import io.github.classgraph.utils.q;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;

class m0
implements Callable<j0> {
    private static final int P4 = 32;
    private final l0 c;
    private final ExecutorService d;
    private final int f;
    private final l h = new l();
    private final h.c o;
    private final h.b s;
    private final p t;
    private q w;

    m0(l0 l02, ExecutorService executorService, int n2, h.c c2, h.b b2, p p2) {
        this.c = l02;
        l02.a();
        this.d = executorService;
        this.f = n2;
        this.o = c2;
        this.s = b2;
        this.t = p2;
        l02.a(p2);
    }

    static /* synthetic */ l a(m0 m02) {
        return m02.h;
    }

    private static List<f> a(List<r> list) {
        LinkedList linkedList = new LinkedList();
        for (r r2 : list) {
            LinkedList linkedList2 = new LinkedList();
            int n2 = r2.e();
            if (n2 > 0) {
                float f2 = n2;
                int n3 = (int)Math.ceil((double)(f2 / 32.0f));
                float f3 = f2 / (float)n3;
                for (int i2 = 0; i2 < n3; ++i2) {
                    int n4;
                    int n5 = i2 < n3 - 1 ? (int)(f3 * (float)(i2 + 1)) : n2;
                    if (n5 <= (n4 = (int)(f3 * (float)i2))) continue;
                    linkedList2.add((Object)new f(r2, n4, n5));
                }
            }
            linkedList.add((Object)linkedList2);
        }
        ArrayList arrayList = new ArrayList();
        while (!linkedList.isEmpty()) {
            LinkedList linkedList3 = new LinkedList();
            for (LinkedList linkedList4 : linkedList) {
                if (linkedList4.isEmpty()) continue;
                arrayList.add((Object)((f)linkedList4.remove()));
                if (linkedList4.isEmpty()) continue;
                linkedList3.add((Object)linkedList4);
            }
            linkedList = linkedList3;
        }
        return arrayList;
    }

    private static List<r> a(List<io.github.classgraph.utils.g> list, g g2) throws InterruptedException {
        HashSet hashSet = new HashSet();
        ArrayList arrayList = new ArrayList();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            r r2 = (r)g2.a((Object)((io.github.classgraph.utils.g)iterator.next()));
            if (r2 == null) continue;
            m0.a(r2, g2, (HashSet<r>)hashSet, (ArrayList<r>)arrayList);
        }
        return arrayList;
    }

    private static void a(r r2, g g2, HashSet<r> hashSet, ArrayList<r> arrayList) throws InterruptedException {
        if (hashSet.add((Object)r2)) {
            List<io.github.classgraph.utils.g> list;
            if (!r2.c) {
                arrayList.add((Object)r2);
            }
            if ((list = r2.d) != null) {
                Iterator iterator = list.iterator();
                while (iterator.hasNext()) {
                    r r3 = (r)g2.a((Object)((io.github.classgraph.utils.g)iterator.next()));
                    if (r3 == null) continue;
                    m0.a(r3, g2, hashSet, arrayList);
                }
            }
            if (r2.c) {
                r2.a();
            }
        }
    }

    /*
     * Exception decompiling
     */
    public j0 call() throws InterruptedException, ExecutionException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [19[UNCONDITIONALDOLOOP]], but top level block is 2[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private static class f {
        private final r a;
        private final int b;
        private final int c;

        public f(r r2, int n2, int n3) {
            this.a = r2;
            this.b = n2;
            this.c = n3;
        }

        static /* synthetic */ int a(f f2) {
            return f2.b;
        }

        static /* synthetic */ int b(f f2) {
            return f2.c;
        }

        static /* synthetic */ r c(f f2) {
            return f2.a;
        }
    }

}

