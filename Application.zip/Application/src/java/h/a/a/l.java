/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.c
 *  h.a.a.e
 *  h.a.a.j
 *  h.a.a.p
 *  h.a.a.v
 *  h.a.a.z
 *  io.github.classgraph.utils.Parser
 *  io.github.classgraph.utils.Parser$ParseException
 *  io.github.classgraph.utils.o
 *  io.github.classgraph.utils.p
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.AbstractMap
 *  java.util.AbstractMap$SimpleEntry
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 */
package h.a.a;

import h.a.a.a0;
import h.a.a.c;
import h.a.a.d;
import h.a.a.e;
import h.a.a.j;
import h.a.a.l0;
import h.a.a.p;
import h.a.a.r;
import h.a.a.v;
import h.a.a.w;
import h.a.a.z;
import io.github.classgraph.utils.Parser;
import io.github.classgraph.utils.o;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

class l {
    private final String a;
    private final int b;
    private final boolean c;
    private final boolean d;
    private String e;
    private List<String> f;
    private d g;
    private String h;
    private List<AbstractMap.SimpleEntry<String, String>> i;
    private List<e> j;
    final r k;
    private w l;
    private a0 m;
    private String n;

    l(String string, int n2, boolean bl, boolean bl2, r r2) {
        this.a = string;
        this.b = n2;
        this.c = bl;
        this.d = bl2;
        this.k = r2;
    }

    void a(c c2) {
        if (this.g == null) {
            this.g = new d();
        }
        this.g.add((Object)c2);
    }

    void a(l0 l02, Map<String, j> map, io.github.classgraph.utils.p p2) {
        a0 a02;
        List<AbstractMap.SimpleEntry<String, String>> list;
        w w2;
        d d2;
        List<e> list2;
        List<String> list3;
        String string;
        String string2;
        j j2 = j.a((String)this.a, (int)this.b, (boolean)this.c, (boolean)this.d, map, (r)this.k, (l0)l02, (io.github.classgraph.utils.p)p2);
        String string3 = this.e;
        if (string3 != null) {
            j2.b(string3, map);
        }
        if ((list3 = this.f) != null) {
            Iterator iterator = list3.iterator();
            while (iterator.hasNext()) {
                j2.a((String)iterator.next(), map);
            }
        }
        if ((d2 = this.g) != null) {
            Iterator iterator = d2.iterator();
            while (iterator.hasNext()) {
                j2.a((c)iterator.next(), map);
            }
        }
        if ((list = this.i) != null) {
            j.a(list, map);
        }
        if ((list2 = this.j) != null) {
            j2.a(list2);
        }
        if ((string = this.h) != null) {
            j2.a(string);
        }
        if ((w2 = this.l) != null) {
            j2.a(w2, map);
        }
        if ((a02 = this.m) != null) {
            j2.a(a02, map);
        }
        if ((string2 = this.n) != null) {
            j2.b(string2);
        }
    }

    void a(v v2) {
        if (this.l == null) {
            this.l = new w();
        }
        this.l.add((Object)v2);
    }

    void a(z z2) {
        if (this.m == null) {
            this.m = new a0();
        }
        this.m.add((Object)z2);
    }

    void a(io.github.classgraph.utils.p p2) {
        if (p2 != null) {
            a0 a02;
            List<e> list;
            w w2;
            String string;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Found ");
            boolean bl = this.d;
            String string2 = "class";
            String string3 = bl ? "annotation class" : (this.c ? "interface class" : string2);
            stringBuilder.append(string3);
            stringBuilder.append(" ");
            stringBuilder.append(this.a);
            io.github.classgraph.utils.p p3 = p2.a(stringBuilder.toString());
            if (this.e != null) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("Super");
                if (this.c && !this.d) {
                    string2 = "interface";
                }
                stringBuilder2.append(string2);
                stringBuilder2.append(": ");
                stringBuilder2.append(this.e);
                p3.a(stringBuilder2.toString());
            }
            if (this.f != null) {
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("Interfaces: ");
                stringBuilder3.append(o.a((String)", ", this.f));
                p3.a(stringBuilder3.toString());
            }
            if (this.g != null) {
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("Class annotations: ");
                stringBuilder4.append(o.a((String)", ", (Iterable)this.g));
                p3.a(stringBuilder4.toString());
            }
            if ((list = this.j) != null) {
                for (e e2 : list) {
                    StringBuilder stringBuilder5 = new StringBuilder();
                    stringBuilder5.append("Annotation default param value: ");
                    stringBuilder5.append((Object)e2);
                    p3.a(stringBuilder5.toString());
                }
            }
            if ((w2 = this.l) != null) {
                Iterator iterator = w2.iterator();
                while (iterator.hasNext()) {
                    v v2 = (v)iterator.next();
                    StringBuilder stringBuilder6 = new StringBuilder();
                    stringBuilder6.append("Field: ");
                    stringBuilder6.append((Object)v2);
                    p3.a(stringBuilder6.toString());
                }
            }
            if ((a02 = this.m) != null) {
                Iterator iterator = a02.iterator();
                while (iterator.hasNext()) {
                    z z2 = (z)iterator.next();
                    StringBuilder stringBuilder7 = new StringBuilder();
                    stringBuilder7.append("Method: ");
                    stringBuilder7.append((Object)z2);
                    p3.a(stringBuilder7.toString());
                }
            }
            if ((string = this.n) != null) {
                p p4;
                p4 = null;
                try {
                    p4 = p.a((String)string, null);
                }
                catch (Parser.ParseException parseException) {}
                p p5 = p4;
                StringBuilder stringBuilder8 = new StringBuilder();
                stringBuilder8.append("Class type signature: ");
                String string4 = p5 == null ? this.n : p5.a(this.a, false, this.b, this.d, this.c);
                stringBuilder8.append(string4);
                p3.a(stringBuilder8.toString());
            }
        }
    }

    public void a(String string) {
        this.h = string;
    }

    public void a(String string, String string2) {
        if (this.i == null) {
            this.i = new ArrayList();
        }
        this.i.add((Object)new AbstractMap.SimpleEntry((Object)string, (Object)string2));
    }

    public void a(List<e> list) {
        this.j = list;
    }

    void b(String string) {
        if (this.f == null) {
            this.f = new ArrayList();
        }
        this.f.add((Object)string);
    }

    void c(String string) {
        this.e = string;
    }

    void d(String string) {
        this.n = string;
    }
}

