/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.util.Map
 */
package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.ILogger;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

public class Reflection {
    public static Object createDefaultInstance(Class class_) {
        try {
            Object object = class_.newInstance();
            return object;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public static Object createDefaultInstance(String string) {
        return Reflection.createDefaultInstance(Reflection.forName(string));
    }

    public static /* varargs */ Object createInstance(String string, Class[] arrclass, Object ... arrobject) {
        try {
            Object object = Class.forName((String)string).getConstructor(arrclass).newInstance(arrobject);
            return object;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public static Class forName(String string) {
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    private static Object getAdvertisingInfoObject(Context context) throws Exception {
        return Reflection.invokeStaticMethod("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", new Class[]{Context.class}, new Object[]{context});
    }

    /*
     * Exception decompiling
     */
    static Map<String, String> getImeiParameters(Context var0, ILogger var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl36.1 : ACONST_NULL : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String getPlayAdId(Context context) {
        try {
            String string = (String)Reflection.invokeInstanceMethod(Reflection.getAdvertisingInfoObject(context), "getId", null, new Object[0]);
            return string;
        }
        catch (Throwable throwable) {
            return null;
        }
    }

    public static /* varargs */ Object invokeInstanceMethod(Object object, String string, Class[] arrclass, Object ... arrobject) throws Exception {
        return Reflection.invokeMethod(object.getClass(), string, object, arrclass, arrobject);
    }

    public static /* varargs */ Object invokeMethod(Class class_, String string, Object object, Class[] arrclass, Object ... arrobject) throws Exception {
        Method method = class_.getMethod(string, arrclass);
        if (method == null) {
            return null;
        }
        return method.invoke(object, arrobject);
    }

    public static /* varargs */ Object invokeStaticMethod(String string, String string2, Class[] arrclass, Object ... arrobject) throws Exception {
        return Reflection.invokeMethod(Class.forName((String)string), string2, null, arrclass, arrobject);
    }

    public static Boolean isPlayTrackingEnabled(Context context) {
        Boolean bl;
        boolean bl2;
        block5 : {
            Boolean bl3;
            block4 : {
                bl = null;
                try {
                    bl3 = (Boolean)Reflection.invokeInstanceMethod(Reflection.getAdvertisingInfoObject(context), "isLimitAdTrackingEnabled", null, new Object[0]);
                    if (bl3 != null) break block4;
                    return null;
                }
                catch (Throwable throwable) {}
            }
            boolean bl4 = bl3;
            bl2 = false;
            if (bl4) break block5;
            bl2 = true;
        }
        bl = bl2;
        return bl;
    }

    public static Object readField(String string, String string2) throws Exception {
        return Reflection.readField(string, string2, null);
    }

    public static Object readField(String string, String string2, Object object) throws Exception {
        Class class_ = Reflection.forName(string);
        if (class_ == null) {
            return null;
        }
        Field field = class_.getField(string2);
        if (field == null) {
            return null;
        }
        return field.get(object);
    }
}

