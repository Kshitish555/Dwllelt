/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.Namespace
 *  org.simpleframework.xml.NamespaceList
 *  org.simpleframework.xml.core.Decorator
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.Namespace;
import org.simpleframework.xml.NamespaceList;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.NamespaceDecorator;
import org.simpleframework.xml.stream.OutputNode;

class Qualifier
implements Decorator {
    private NamespaceDecorator decorator = new NamespaceDecorator();

    public Qualifier(Contact contact) {
        this.scan(contact);
    }

    private void namespace(Contact contact) {
        Namespace namespace = (Namespace)contact.getAnnotation(Namespace.class);
        if (namespace != null) {
            this.decorator.set(namespace);
            this.decorator.add(namespace);
        }
    }

    private void scan(Contact contact) {
        this.namespace(contact);
        this.scope(contact);
    }

    private void scope(Contact contact) {
        NamespaceList namespaceList = (NamespaceList)contact.getAnnotation(NamespaceList.class);
        if (namespaceList != null) {
            for (Namespace namespace : namespaceList.value()) {
                this.decorator.add(namespace);
            }
        }
    }

    public void decorate(OutputNode outputNode) {
        this.decorator.decorate(outputNode);
    }

    public void decorate(OutputNode outputNode, Decorator decorator) {
        this.decorator.decorate(outputNode, decorator);
    }
}

