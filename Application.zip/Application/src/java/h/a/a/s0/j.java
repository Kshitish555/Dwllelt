/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Comparable
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Array
 *  java.lang.reflect.Field
 *  java.util.AbstractMap
 *  java.util.AbstractMap$SimpleEntry
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.atomic.AtomicInteger
 */
package h.a.a.s0;

import h.a.a.s0.a;
import h.a.a.s0.b;
import h.a.a.s0.c;
import h.a.a.s0.e;
import h.a.a.s0.g;
import h.a.a.s0.i;
import h.a.a.s0.k;
import h.a.a.s0.m;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public class j {
    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Object a(Object var0, Set<m<Object>> var1_1, Set<m<Object>> var2_2, a var3_3, Map<m<Object>, g> var4_4, boolean var5_5) {
        block22 : {
            block21 : {
                block26 : {
                    block25 : {
                        block24 : {
                            if (var0 == null) return var0;
                            if (var0 instanceof String != false) return var0;
                            if (var0 instanceof Integer != false) return var0;
                            if (var0 instanceof Boolean != false) return var0;
                            if (var0 instanceof Long != false) return var0;
                            if (var0 instanceof Float != false) return var0;
                            if (var0 instanceof Double != false) return var0;
                            if (var0 instanceof Short != false) return var0;
                            if (var0 instanceof Byte != false) return var0;
                            if (var0 instanceof Character != false) return var0;
                            if (var0.getClass().isEnum()) {
                                return var0;
                            }
                            var6_6 = new m<Object>(var0);
                            if (!var1_1.add(var6_6)) {
                                if (!k.b(var0)) {
                                    return new i(var0);
                                }
                                var52_7 = new StringBuilder();
                                var52_7.append("Cycles involving collections cannot be serialized, since collections are not assigned object ids. Reached cycle at: ");
                                var52_7.append(var0);
                                throw new IllegalArgumentException(var52_7.toString());
                            }
                            var7_8 = var0.getClass();
                            var8_9 = Map.class.isAssignableFrom(var7_8);
                            var9_10 = null;
                            var10_11 = 0;
                            if (!var8_9) break block24;
                            var36_12 = (Map)var0;
                            var37_13 = new ArrayList((Collection)var36_12.keySet());
                            var38_14 = var37_13.size();
                            for (var39_15 = 0; var39_15 < var38_14 && var9_10 == null; ++var39_15) {
                                var9_10 = var37_13.get(var39_15);
                            }
                            if (var9_10 != null && Comparable.class.isAssignableFrom(var9_10.getClass())) {
                                Collections.sort((List)var37_13);
                                var40_16 = true;
                            } else {
                                var40_16 = false;
                            }
                            var41_17 = new String[var38_14];
                            for (var42_18 = 0; var42_18 < var38_14; ++var42_18) {
                                var47_19 = var37_13.get(var42_18);
                                if (!k.a(var47_19)) {
                                    var48_20 = new StringBuilder();
                                    var48_20.append("Map key of type ");
                                    var48_20.append(var47_19.getClass().getName());
                                    var48_20.append(" is not a basic type (String, Integer, etc.), so can't be easily serialized as a JSON associative array key");
                                    throw new IllegalArgumentException(var48_20.toString());
                                }
                                var41_17[var42_18] = k.a(var47_19.toString());
                            }
                            if (!var40_16) {
                                Arrays.sort((Object[])var41_17);
                            }
                            var43_21 = new Object[var38_14];
                            for (var44_22 = 0; var44_22 < var38_14; ++var44_22) {
                                var43_21[var44_22] = var36_12.get(var37_13.get(var44_22));
                            }
                            j.a(var43_21, var1_1, var2_2, var3_3, var4_4, var5_5);
                            var45_23 = new ArrayList(var38_14);
                            while (var10_11 < var38_14) {
                                var45_23.add((Object)new AbstractMap.SimpleEntry(var41_17[var10_11], var43_21[var10_11]));
                                ++var10_11;
                            }
                            var15_24 = new g((List<Map.Entry<String, Object>>)var45_23);
                            break block22;
                        }
                        if (var7_8.isArray() || List.class.isAssignableFrom(var7_8)) ** GOTO lbl82
                        if (!Collection.class.isAssignableFrom(var7_8)) break block25;
                        var31_25 = (Collection)var0;
                        var32_26 = new ArrayList();
                        var33_27 = var31_25.iterator();
                        while (var33_27.hasNext()) {
                            var32_26.add(var33_27.next());
                        }
                        var34_28 = var32_26.toArray();
                        j.a(var34_28, var1_1, var2_2, var3_3, var4_4, var5_5);
                        var15_24 = new e((List<Object>)Arrays.asList((Object[])var34_28));
                        break block22;
                    }
                    var22_29 = var3_3.a(var7_8).a;
                    var23_30 = var22_29.size();
                    var24_31 = new String[var23_30];
                    var25_32 = new Object[var23_30];
                    break block26;
lbl82: // 1 sources:
                    var11_41 = List.class.isAssignableFrom(var7_8);
                    var12_42 = null;
                    if (var11_41) {
                        var12_42 = (List)var0;
                    }
                    var13_43 = var11_41 != false ? var12_42.size() : Array.getLength((Object)var0);
                    var14_44 = new Object[var13_43];
                    break block21;
                }
                for (var26_33 = 0; var26_33 < var23_30; ++var26_33) {
                    var27_34 = ((c)var22_29.get((int)var26_33)).a;
                    var24_31[var26_33] = var27_34.getName();
                    var25_32[var26_33] = k.a(var0, var27_34);
                }
                j.a(var25_32, var1_1, var2_2, var3_3, var4_4, var5_5);
                var28_35 = new ArrayList(var23_30);
                while (var10_11 < var23_30) {
                    var28_35.add((Object)new AbstractMap.SimpleEntry((Object)var24_31[var10_11], var25_32[var10_11]));
                    ++var10_11;
                }
                try {
                    var30_36 = new g((List<Map.Entry<String, Object>>)var28_35);
                    var15_24 = var30_36;
                    break block22;
                }
                catch (IllegalAccessException var18_37) {
                }
                catch (IllegalArgumentException var18_38) {
                    // empty catch block
                }
                var19_40 = new StringBuilder();
                var19_40.append("Could not get value of field in object: ");
                var19_40.append(var0);
                throw new RuntimeException(var19_40.toString(), (Throwable)var18_39);
            }
            while (var10_11 < var13_43) {
                var17_45 = var11_41 != false ? var12_42.get(var10_11) : Array.get((Object)var0, (int)var10_11);
                var14_44[var10_11] = var17_45;
                ++var10_11;
            }
            j.a(var14_44, var1_1, var2_2, var3_3, var4_4, var5_5);
            var15_24 = new e((List<Object>)Arrays.asList((Object[])var14_44));
        }
        var1_1.remove(var6_6);
        return var15_24;
    }

    public static String a(Object object) {
        return j.a(object, 0, false);
    }

    public static String a(Object object, int n2, boolean bl) {
        return j.a(object, n2, bl, new a(false, false));
    }

    public static String a(Object object, int n2, boolean bl, a a2) {
        HashMap hashMap = new HashMap();
        Object object2 = j.a(object, (Set<m<Object>>)new HashSet(), (Set<m<Object>>)new HashSet(), a2, (Map<m<Object>, g>)hashMap, bl);
        HashMap hashMap2 = new HashMap();
        j.a(object2, (Map<m<Object>, g>)hashMap, a2, (Map<m<i>, CharSequence>)hashMap2, new AtomicInteger(0), bl);
        StringBuilder stringBuilder = new StringBuilder(32768);
        j.a(object2, (Map<m<i>, CharSequence>)hashMap2, false, 0, n2, stringBuilder);
        return stringBuilder.toString();
    }

    public static String a(Object object, String string, int n2, boolean bl) {
        return j.a(object, string, n2, bl, new a(false, bl));
    }

    public static String a(Object object, String string, int n2, boolean bl, a a2) {
        c c2 = (c)a2.a(object.getClass()).b.get((Object)string);
        if (c2 != null) {
            Field field = c2.a;
            if (k.a(field, false)) {
                Object object2;
                try {
                    object2 = k.a(object, field);
                }
                catch (Exception exception) {
                    throw new IllegalArgumentException("Could not parse JSON", (Throwable)exception);
                }
                return j.a(object2, n2, bl, a2);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Field ");
            stringBuilder.append(object.getClass().getName());
            stringBuilder.append(".");
            stringBuilder.append(string);
            stringBuilder.append(" needs to be accessible, non-transient, and non-final");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Class ");
        stringBuilder.append(object.getClass().getName());
        stringBuilder.append(" does not have a field named \"");
        stringBuilder.append(string);
        stringBuilder.append("\"");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void a(Object object, Map<m<Object>, g> map, a a2, Map<m<i>, CharSequence> map2, AtomicInteger atomicInteger, boolean bl) {
        String string;
        g g2;
        i i2;
        block13 : {
            if (object == null) {
                return;
            }
            if (object instanceof g) {
                Iterator iterator = ((g)object).a.iterator();
                while (iterator.hasNext()) {
                    j.a(((Map.Entry)iterator.next()).getValue(), map, a2, map2, atomicInteger, bl);
                }
                return;
            }
            if (object instanceof e) {
                Iterator iterator = ((e)object).a.iterator();
                while (iterator.hasNext()) {
                    j.a(iterator.next(), map, a2, map2, atomicInteger, bl);
                }
                return;
            }
            if (!(object instanceof i)) return;
            i2 = (i)object;
            Object object2 = i2.a;
            if (object2 == null) {
                throw new RuntimeException("Internal inconsistency");
            }
            g2 = (g)map.get(new m<Object>(object2));
            if (g2 == null) {
                throw new RuntimeException("Internal inconsistency");
            }
            Field field = a2.a(object2.getClass()).c;
            string = null;
            if (field != null) {
                void var16_17;
                try {
                    Object object3 = field.get(object2);
                    string = null;
                    if (object3 != null) {
                        String string2 = object3.toString();
                        g2.b = string2;
                        string = string2;
                    }
                    break block13;
                }
                catch (IllegalAccessException illegalAccessException) {
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    // empty catch block
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Could not access @Id-annotated field ");
                stringBuilder.append((Object)field);
                throw new IllegalArgumentException(stringBuilder.toString(), (Throwable)var16_17);
            }
        }
        if (string == null && g2.b == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("[#");
            stringBuilder.append(atomicInteger.getAndIncrement());
            stringBuilder.append("]");
            string = stringBuilder.toString();
            g2.b = string;
        }
        map2.put(new m<i>(i2), string);
    }

    static void a(Object object, Map<m<i>, CharSequence> map, boolean bl, int n2, int n3, StringBuilder stringBuilder) {
        if (object == null) {
            stringBuilder.append("null");
            return;
        }
        if (object instanceof g) {
            ((g)object).a(map, bl, n2, n3, stringBuilder);
            return;
        }
        if (object instanceof e) {
            ((e)object).a(map, bl, n2, n3, stringBuilder);
            return;
        }
        if (object instanceof i) {
            j.a(map.get(new m<i>((i)object)), map, bl, n2, n3, stringBuilder);
            return;
        }
        if (!(object instanceof CharSequence || object instanceof Character || object.getClass().isEnum())) {
            stringBuilder.append(object.toString());
            return;
        }
        stringBuilder.append('\"');
        k.a(object.toString(), stringBuilder);
        stringBuilder.append('\"');
    }

    private static void a(Object[] arrobject, Set<m<Object>> set, Set<m<Object>> set2, a a2, Map<m<Object>, g> map, boolean bl) {
        m[] arrm = new m[arrobject.length];
        boolean[] arrbl = new boolean[arrobject.length];
        int n2 = 0;
        do {
            int n3 = arrobject.length;
            if (n2 >= n3) break;
            Object object = arrobject[n2];
            arrbl[n2] = true ^ k.a(object);
            if (arrbl[n2] && !k.b(object)) {
                m<Object> m2;
                arrm[n2] = m2 = new m<Object>(object);
                if (true ^ set2.add(m2)) {
                    arrobject[n2] = new i(object);
                    arrbl[n2] = false;
                }
            }
            ++n2;
        } while (true);
        for (int i2 = 0; i2 < arrobject.length; ++i2) {
            if (!arrbl[i2]) continue;
            Object object = arrobject[i2];
            arrobject[i2] = j.a(object, set, set2, a2, map, bl);
            if (k.b(object)) continue;
            map.put((Object)arrm[i2], (Object)((g)arrobject[i2]));
        }
    }
}

