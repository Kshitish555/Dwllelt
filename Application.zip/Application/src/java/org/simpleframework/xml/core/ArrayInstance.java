/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Array
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Value
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Array;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.strategy.Value;

class ArrayInstance
implements Instance {
    private final int length;
    private final Class type;
    private final Value value;

    public ArrayInstance(Value value) {
        this.length = value.getLength();
        this.type = value.getType();
        this.value = value;
    }

    public Object getInstance() throws Exception {
        if (this.value.isReference()) {
            return this.value.getValue();
        }
        Object object = Array.newInstance((Class)this.type, (int)this.length);
        Value value = this.value;
        if (value != null) {
            value.setValue(object);
        }
        return object;
    }

    public Class getType() {
        return this.type;
    }

    public boolean isReference() {
        return this.value.isReference();
    }

    public Object setInstance(Object object) {
        Value value = this.value;
        if (value != null) {
            value.setValue(object);
        }
        return object;
    }
}

