/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.s0.d
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Field
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Map
 */
package h.a.a.s0;

import h.a.a.s0.a;
import h.a.a.s0.c;
import h.a.a.s0.d;
import h.a.a.s0.k;
import h.a.a.s0.n;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

class b {
    final List<c> a = new ArrayList();
    final Map<String, c> b = new HashMap();
    Field c;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public b(Class<?> var1_1, boolean var2_2, boolean var3_3, a var4_4) {
        super();
        var5_5 = new HashSet();
        var6_6 = new ArrayList();
        block0 : do lbl-1000: // 3 sources:
        {
            var7_7 = null;
            do {
                if (var1_1 != Object.class && var1_1 != null) {
                    if (var1_1 instanceof ParameterizedType) {
                        var14_8 = (Class)((ParameterizedType)var1_1).getRawType();
                    } else {
                        if (!(var1_1 instanceof Class)) {
                            var11_19 = new StringBuilder();
                            var11_19.append("Illegal class type: ");
                            var11_19.append((Object)var1_1);
                            throw new IllegalArgumentException(var11_19.toString());
                        }
                        var14_8 = (Class)var1_1;
                    }
                    var15_9 = var14_8.getDeclaredFields();
                    var16_10 = new ArrayList();
                } else {
                    var8_20 = -1 + var6_6.size();
                    while (var8_20 >= 0) {
                        var9_21 = (List)var6_6.get(var8_20);
                        this.a.addAll((Collection)var9_21);
                        --var8_20;
                    }
                    return;
                }
                for (var17_11 = 0; var17_11 < var15_9.length; ++var17_11) {
                    var22_12 = var15_9[var17_11];
                    if (!var5_5.add((Object)var22_12.getName())) continue;
                    var23_13 = var22_12.isAnnotationPresent(d.class);
                    if (var23_13) {
                        if (this.c != null) {
                            var33_16 = new StringBuilder();
                            var33_16.append("More than one @Id annotation: ");
                            var33_16.append((Object)this.c.getDeclaringClass());
                            var33_16.append(".");
                            var33_16.append((Object)this.c);
                            var33_16.append(" ; ");
                            var33_16.append(var14_8.getName());
                            var33_16.append(".");
                            var33_16.append(var22_12.getName());
                            throw new IllegalArgumentException(var33_16.toString());
                        }
                        this.c = var22_12;
                    }
                    if (k.a(var22_12, var3_3)) {
                        var29_14 = var22_12.getGenericType();
                        if (var7_7 != null && var2_2) {
                            var29_14 = var7_7.a(var29_14);
                        }
                        var30_15 = new c(var22_12, var29_14, var4_4);
                        this.b.put((Object)var22_12.getName(), (Object)var30_15);
                        var16_10.add((Object)var30_15);
                        continue;
                    }
                    if (!var23_13) continue;
                    var24_17 = new StringBuilder();
                    var24_17.append("@Id annotation field must be accessible, final, and non-transient: ");
                    var24_17.append(var14_8.getName());
                    var24_17.append(".");
                    var24_17.append(var22_12.getName());
                    throw new IllegalArgumentException(var24_17.toString());
                }
                var6_6.add((Object)var16_10);
                var1_1 = var14_8.getGenericSuperclass();
                if (!var2_2) continue;
                if (!(var1_1 instanceof ParameterizedType)) continue block0;
                if (var7_7 != null) {
                    var1_1 = var7_7.a(var1_1);
                }
                if (!(var1_1 instanceof ParameterizedType)) ** GOTO lbl-1000
                var7_7 = new n((ParameterizedType)var1_1);
            } while (true);
        } while (var1_1 instanceof Class);
        var19_18 = new StringBuilder();
        var19_18.append("Got unexpected supertype ");
        var19_18.append((Object)var1_1);
        throw new IllegalArgumentException(var19_18.toString());
    }
}

