/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Throwable
 *  lifecyclesurviveapi.q
 *  rx.functions.Func2
 */
package lifecyclesurviveapi;

import lifecyclesurviveapi.q;
import rx.functions.Func2;

public final class b
implements Func2 {
    private final /* synthetic */ Throwable c;

    public /* synthetic */ b(Throwable throwable) {
        this.c = throwable;
    }

    public final Object call(Object object, Object object2) {
        return q.a.a.a(this.c, (Boolean)object, (Boolean)object2);
    }
}

