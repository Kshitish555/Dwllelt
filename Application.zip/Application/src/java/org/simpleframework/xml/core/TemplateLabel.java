/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.KeyBuilder
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.strategy.Type
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.KeyBuilder;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.strategy.Type;

abstract class TemplateLabel
implements Label {
    private final KeyBuilder builder = new KeyBuilder((Label)this);

    protected TemplateLabel() {
    }

    public Type getDependent() throws Exception {
        return null;
    }

    public String getEntry() throws Exception {
        return null;
    }

    public Object getKey() throws Exception {
        return this.builder.getKey();
    }

    public Label getLabel(Class class_) throws Exception {
        return this;
    }

    public String[] getNames() throws Exception {
        return new String[]{this.getPath(), this.getName()};
    }

    public String[] getPaths() throws Exception {
        return new String[]{this.getPath()};
    }

    public Type getType(Class class_) throws Exception {
        return this.getContact();
    }

    public boolean isAttribute() {
        return false;
    }

    public boolean isCollection() {
        return false;
    }

    public boolean isInline() {
        return false;
    }

    public boolean isText() {
        return false;
    }

    public boolean isTextList() {
        return false;
    }

    public boolean isUnion() {
        return false;
    }
}

