/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  l.a.k.a.a
 *  l.a.k.a.d
 *  l.a.k.a.p
 *  l.a.k.a.u
 *  l.a.k.a.v
 */
package l.a.k.a;

import l.a.k.a.a;
import l.a.k.a.d;
import l.a.k.a.g;
import l.a.k.a.p;
import l.a.k.a.u;
import l.a.k.a.v;

final class b
extends a {
    private final g c;
    private int d;
    private final boolean e;
    private final d f;
    private final d g;
    private final int h;
    b i;
    b j;

    b(g g2, boolean bl, d d2, d d3, int n2) {
        super(327680);
        this.c = g2;
        this.e = bl;
        this.f = d2;
        this.g = d3;
        this.h = n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static void a(int var0, v var1_1, d var2_2) {
        var3_3 = var0 >>> 24;
        if (var3_3 != 0 && var3_3 != 1) {
            switch (var3_3) {
                default: {
                    switch (var3_3) {
                        default: {
                            var2_2.b(var3_3, (var0 & 16776960) >> 8);
                            ** break;
                        }
                        case 71: 
                        case 72: 
                        case 73: 
                        case 74: 
                        case 75: 
                    }
                    var2_2.b(var0);
                    ** break;
                }
                case 19: 
                case 20: 
                case 21: {
                    var2_2.a(var3_3);
                    ** break;
                }
                case 22: 
            }
        }
        var2_2.c(var0 >>> 16);
lbl17: // 4 sources:
        if (var1_1 == null) {
            var2_2.a(0);
            return;
        }
        var5_4 = var1_1.a;
        var6_5 = var1_1.b;
        var2_2.a(var5_4, var6_5, 1 + 2 * var5_4[var6_5]);
    }

    static void a(b[] arrb, int n2, d d2) {
        int n3 = 1 + 2 * (arrb.length - n2);
        for (int i2 = n2; i2 < arrb.length; ++i2) {
            int n4 = arrb[i2] == null ? 0 : arrb[i2].b();
            n3 += n4;
        }
        d2.b(n3).a(arrb.length - n2);
        while (n2 < arrb.length) {
            b b2 = arrb[n2];
            b b3 = null;
            int n5 = 0;
            while (b2 != null) {
                ++n5;
                b2.a();
                b2.j = b3;
                b b4 = b2.i;
                b3 = b2;
                b2 = b4;
            }
            d2.c(n5);
            while (b3 != null) {
                d d3 = b3.f;
                d2.a(d3.a, 0, d3.b);
                b3 = b3.j;
            }
            ++n2;
        }
    }

    public a a(String string) {
        this.d = 1 + this.d;
        if (this.e) {
            this.f.c(this.c.e(string));
        }
        this.f.b(91, 0);
        g g2 = this.c;
        d d2 = this.f;
        b b2 = new b(g2, false, d2, d2, -2 + d2.b);
        return b2;
    }

    public a a(String string, String string2) {
        this.d = 1 + this.d;
        if (this.e) {
            this.f.c(this.c.e(string));
        }
        this.f.b(64, this.c.e(string2)).c(0);
        g g2 = this.c;
        d d2 = this.f;
        b b2 = new b(g2, true, d2, d2, -2 + d2.b);
        return b2;
    }

    public void a() {
        d d2 = this.g;
        if (d2 != null) {
            byte[] arrby = d2.a;
            int n2 = this.h;
            int n3 = this.d;
            arrby[n2] = (byte)(n3 >>> 8);
            arrby[n2 + 1] = (byte)n3;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(String string, Object object) {
        int n2;
        int n3;
        block35 : {
            d d2;
            int n4;
            block34 : {
                g g2;
                String string2;
                block32 : {
                    block33 : {
                        block31 : {
                            this.d = 1 + this.d;
                            if (this.e) {
                                this.f.c(this.c.e(string));
                            }
                            if (!(object instanceof String)) break block31;
                            d2 = this.f;
                            n2 = 115;
                            g2 = this.c;
                            string2 = (String)object;
                            break block32;
                        }
                        boolean bl = object instanceof Byte;
                        n2 = 66;
                        if (!bl) break block33;
                        d2 = this.f;
                        n4 = this.c.a((int)((Byte)object).byteValue()).a;
                        break block34;
                    }
                    if (object instanceof Boolean) {
                        int n5 = ((Boolean)object).booleanValue();
                        this.f.b(90, this.c.a((int)n5).a);
                        return;
                    }
                    if (object instanceof Character) {
                        this.f.b(67, this.c.a((int)((Character)object).charValue()).a);
                        return;
                    }
                    if (object instanceof Short) {
                        this.f.b(83, this.c.a((int)((Short)object).shortValue()).a);
                        return;
                    }
                    if (!(object instanceof u)) break block35;
                    d2 = this.f;
                    n2 = 99;
                    g2 = this.c;
                    string2 = ((u)object).d();
                }
                n4 = g2.e(string2);
            }
            d2.b(n2, n4);
            return;
        }
        boolean bl = object instanceof byte[];
        if (bl) {
            byte[] arrby = (byte[])object;
            this.f.b(91, arrby.length);
            for (n3 = 0; n3 < arrby.length; ++n3) {
                this.f.b(n2, this.c.a((int)arrby[n3]).a);
            }
            return;
        } else if (object instanceof boolean[]) {
            boolean[] arrbl = (boolean[])object;
            this.f.b(91, arrbl.length);
            while (n3 < arrbl.length) {
                this.f.b(90, this.c.a((int)arrbl[n3]).a);
                ++n3;
            }
            return;
        } else if (object instanceof short[]) {
            short[] arrs = (short[])object;
            this.f.b(91, arrs.length);
            while (n3 < arrs.length) {
                this.f.b(83, this.c.a((int)arrs[n3]).a);
                ++n3;
            }
            return;
        } else if (object instanceof char[]) {
            char[] arrc = (char[])object;
            this.f.b(91, arrc.length);
            while (n3 < arrc.length) {
                this.f.b(67, this.c.a((int)arrc[n3]).a);
                ++n3;
            }
            return;
        } else if (object instanceof int[]) {
            int[] arrn = (int[])object;
            this.f.b(91, arrn.length);
            while (n3 < arrn.length) {
                this.f.b(73, this.c.a((int)arrn[n3]).a);
                ++n3;
            }
            return;
        } else if (object instanceof long[]) {
            long[] arrl = (long[])object;
            this.f.b(91, arrl.length);
            while (n3 < arrl.length) {
                this.f.b(74, this.c.a((long)arrl[n3]).a);
                ++n3;
            }
            return;
        } else if (object instanceof float[]) {
            float[] arrf = (float[])object;
            this.f.b(91, arrf.length);
            while (n3 < arrf.length) {
                this.f.b(70, this.c.a((float)arrf[n3]).a);
                ++n3;
            }
            return;
        } else if (object instanceof double[]) {
            double[] arrd = (double[])object;
            this.f.b(91, arrd.length);
            while (n3 < arrd.length) {
                this.f.b(68, this.c.a((double)arrd[n3]).a);
                ++n3;
            }
            return;
        } else {
            p p2 = this.c.a(object);
            this.f.b((int)".s.IFJDCS".charAt(p2.b), p2.a);
        }
    }

    public void a(String string, String string2, String string3) {
        this.d = 1 + this.d;
        if (this.e) {
            this.f.c(this.c.e(string));
        }
        this.f.b(101, this.c.e(string2)).c(this.c.e(string3));
    }

    void a(d d2) {
        int n2 = 2;
        int n3 = 0;
        b b2 = null;
        b b3 = this;
        while (b3 != null) {
            ++n3;
            n2 += b3.f.b;
            b3.a();
            b3.j = b2;
            b b4 = b3.i;
            b2 = b3;
            b3 = b4;
        }
        d2.b(n2);
        d2.c(n3);
        while (b2 != null) {
            d d3 = b2.f;
            d2.a(d3.a, 0, d3.b);
            b2 = b2.j;
        }
    }

    int b() {
        int n2 = 0;
        b b2 = this;
        while (b2 != null) {
            n2 += b2.f.b;
            b2 = b2.i;
        }
        return n2;
    }
}

