/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Caller
 *  org.simpleframework.xml.core.Composite$1
 *  org.simpleframework.xml.core.Composite$Builder
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Criteria
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 *  org.simpleframework.xml.core.ObjectFactory
 *  org.simpleframework.xml.core.PersistenceException
 *  org.simpleframework.xml.core.Revision
 *  org.simpleframework.xml.core.Schema
 *  org.simpleframework.xml.core.Section
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.NamespaceMap
 *  org.simpleframework.xml.stream.Node
 *  org.simpleframework.xml.stream.NodeMap
 *  org.simpleframework.xml.stream.Position
 */
package org.simpleframework.xml.core;

import java.util.Iterator;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.AttributeException;
import org.simpleframework.xml.core.Caller;
import org.simpleframework.xml.core.Collector;
import org.simpleframework.xml.core.Composite;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Criteria;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.ObjectFactory;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Primitive;
import org.simpleframework.xml.core.Revision;
import org.simpleframework.xml.core.Schema;
import org.simpleframework.xml.core.Section;
import org.simpleframework.xml.core.TextException;
import org.simpleframework.xml.core.ValueRequiredException;
import org.simpleframework.xml.core.Variable;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.NamespaceMap;
import org.simpleframework.xml.stream.Node;
import org.simpleframework.xml.stream.NodeMap;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Position;

/*
 * Exception performing whole class analysis.
 */
class Composite
implements Converter {
    private final Context context;
    private final Criteria criteria;
    private final ObjectFactory factory;
    private final Primitive primitive;
    private final Revision revision;
    private final Type type;

    public Composite(Context context, Type type) {
        this(context, type, null);
    }

    public Composite(Context context, Type type, Class class_) {
        this.factory = new ObjectFactory(context, type, class_);
        this.primitive = new Primitive(context, type);
        this.criteria = new Collector();
        this.revision = new Revision();
        this.context = context;
        this.type = type;
    }

    private boolean isOverridden(OutputNode outputNode, Object object, Type type) throws Exception {
        return this.factory.setOverride(type, object, outputNode);
    }

    private Object read(InputNode inputNode, Instance instance, Class class_) throws Exception {
        Schema schema = this.context.getSchema(class_);
        Caller caller = schema.getCaller();
        Object object = this.read(schema, instance).read(inputNode);
        caller.validate(object);
        caller.commit(object);
        instance.setInstance(object);
        return this.readResolve(inputNode, object, caller);
    }

    private Builder read(Schema schema, Instance instance) throws Exception {
        if (schema.getInstantiator().isDefault()) {
            return new /* Unavailable Anonymous Inner Class!! */;
        }
        Injector injector = new Injector(this, this.criteria, schema, instance);
        return injector;
    }

    private void read(InputNode inputNode, Object object, Schema schema) throws Exception {
        Section section = schema.getSection();
        this.readVersion(inputNode, object, schema);
        this.readSection(inputNode, object, section);
    }

    private void readAttribute(InputNode inputNode, Object object, Section section, LabelMap labelMap) throws Exception {
        String string2 = section.getAttribute(inputNode.getName());
        Label label = labelMap.getLabel(string2);
        if (label == null) {
            Position position = inputNode.getPosition();
            Class class_ = this.context.getType(this.type, object);
            if (labelMap.isStrict(this.context)) {
                if (!this.revision.isEqual()) {
                    return;
                }
                throw new AttributeException("Attribute '%s' does not have a match in %s at %s", new Object[]{string2, class_, position});
            }
        } else {
            this.readInstance(inputNode, object, label);
        }
    }

    private void readAttributes(InputNode inputNode, Object object, Section section) throws Exception {
        NodeMap<InputNode> nodeMap = inputNode.getAttributes();
        LabelMap labelMap = section.getAttributes();
        Iterator iterator = nodeMap.iterator();
        while (iterator.hasNext()) {
            InputNode inputNode2 = inputNode.getAttribute((String)iterator.next());
            if (inputNode2 == null) continue;
            this.readAttribute(inputNode2, object, section, labelMap);
        }
        this.validate(inputNode, labelMap, object);
    }

    private void readElement(InputNode inputNode, Object object, Section section, LabelMap labelMap) throws Exception {
        String string2 = section.getPath(inputNode.getName());
        Label label = labelMap.getLabel(string2);
        if (label == null) {
            label = this.criteria.resolve(string2);
        }
        if (label == null) {
            Position position = inputNode.getPosition();
            Class class_ = this.context.getType(this.type, object);
            if (labelMap.isStrict(this.context) && this.revision.isEqual()) {
                throw new ElementException("Element '%s' does not have a match in %s at %s", new Object[]{string2, class_, position});
            }
            inputNode.skip();
            return;
        }
        this.readUnion(inputNode, object, labelMap, label);
    }

    private void readElements(InputNode inputNode, Object object, Section section) throws Exception {
        LabelMap labelMap = section.getElements();
        InputNode inputNode2 = inputNode.getNext();
        while (inputNode2 != null) {
            Section section2 = section.getSection(inputNode2.getName());
            if (section2 != null) {
                this.readSection(inputNode2, object, section2);
            } else {
                this.readElement(inputNode2, object, section, labelMap);
            }
            inputNode2 = inputNode.getNext();
        }
        this.validate(inputNode, labelMap, object);
    }

    private Object readInstance(InputNode inputNode, Object object, Label label) throws Exception {
        Object object2 = this.readVariable(inputNode, object, label);
        if (object2 == null) {
            Position position = inputNode.getPosition();
            Class class_ = this.context.getType(this.type, object);
            if (label.isRequired()) {
                if (!this.revision.isEqual()) {
                    return object2;
                }
                throw new ValueRequiredException("Empty value for %s in %s at %s", new Object[]{label, class_, position});
            }
        } else if (object2 != label.getEmpty(this.context)) {
            this.criteria.set(label, object2);
        }
        return object2;
    }

    private Object readPrimitive(InputNode inputNode, Instance instance) throws Exception {
        Class class_ = instance.getType();
        Object object = this.primitive.read(inputNode, class_);
        if (class_ != null) {
            instance.setInstance(object);
        }
        return object;
    }

    private Object readResolve(InputNode inputNode, Object object, Caller caller) throws Exception {
        if (object != null) {
            Class class_;
            Position position = inputNode.getPosition();
            Object object2 = caller.resolve(object);
            Class class_2 = this.type.getType();
            if (class_2.isAssignableFrom(class_ = object2.getClass())) {
                return object2;
            }
            throw new ElementException("Type %s does not match %s at %s", new Object[]{class_, class_2, position});
        }
        return object;
    }

    private void readSection(InputNode inputNode, Object object, Section section) throws Exception {
        this.readText(inputNode, object, section);
        this.readAttributes(inputNode, object, section);
        this.readElements(inputNode, object, section);
    }

    private void readText(InputNode inputNode, Object object, Section section) throws Exception {
        Label label = section.getText();
        if (label != null) {
            this.readInstance(inputNode, object, label);
        }
    }

    private void readUnion(InputNode inputNode, Object object, LabelMap labelMap, Label label) throws Exception {
        Object object2 = this.readInstance(inputNode, object, label);
        String[] arrstring = label.getPaths();
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            labelMap.getLabel(arrstring[i]);
        }
        if (label.isInline()) {
            this.criteria.set(label, object2);
        }
    }

    private Object readVariable(InputNode inputNode, Object object, Label label) throws Exception {
        Converter converter = label.getConverter(this.context);
        if (label.isCollection()) {
            Object object2;
            Variable variable = this.criteria.get(label);
            Contact contact = label.getContact();
            if (variable != null) {
                return converter.read(inputNode, variable.getValue());
            }
            if (object != null && (object2 = contact.get(object)) != null) {
                return converter.read(inputNode, object2);
            }
        }
        return converter.read(inputNode);
    }

    private void readVersion(InputNode inputNode, Object object, Label label) throws Exception {
        Object object2 = this.readInstance(inputNode, object, label);
        Class class_ = this.type.getType();
        if (object2 != null) {
            Double d = this.context.getVersion(class_).revision();
            if (!object2.equals((Object)this.revision)) {
                this.revision.compare((Object)d, object2);
            }
        }
    }

    private void readVersion(InputNode inputNode, Object object, Schema schema) throws Exception {
        Label label = schema.getVersion();
        Class class_ = this.type.getType();
        if (label != null) {
            String string2 = label.getName();
            InputNode inputNode2 = (InputNode)inputNode.getAttributes().remove(string2);
            if (inputNode2 != null) {
                this.readVersion(inputNode2, object, label);
                return;
            }
            Version version = this.context.getVersion(class_);
            Double d = this.revision.getDefault();
            Double d2 = version.revision();
            this.criteria.set(label, (Object)d);
            this.revision.compare((Object)d2, (Object)d);
        }
    }

    private void validate(InputNode inputNode, Label label) throws Exception {
        Converter converter = label.getConverter(this.context);
        Position position = inputNode.getPosition();
        Class class_ = this.type.getType();
        if (converter.validate(inputNode)) {
            this.criteria.set(label, null);
            return;
        }
        throw new PersistenceException("Invalid value for %s in %s at %s", new Object[]{label, class_, position});
    }

    private void validate(InputNode inputNode, LabelMap labelMap) throws Exception {
        Position position = inputNode.getPosition();
        for (Label label : labelMap) {
            Class class_ = this.type.getType();
            if (!label.isRequired() || !this.revision.isEqual()) continue;
            throw new ValueRequiredException("Unable to satisfy %s for %s at %s", new Object[]{label, class_, position});
        }
    }

    private void validate(InputNode inputNode, LabelMap labelMap, Object object) throws Exception {
        Class class_ = this.context.getType(this.type, object);
        Position position = inputNode.getPosition();
        for (Label label : labelMap) {
            if (label.isRequired() && this.revision.isEqual()) {
                throw new ValueRequiredException("Unable to satisfy %s for %s at %s", new Object[]{label, class_, position});
            }
            Object object2 = label.getEmpty(this.context);
            if (object2 == null) continue;
            this.criteria.set(label, object2);
        }
    }

    private boolean validate(InputNode inputNode, Class class_) throws Exception {
        Schema schema = this.context.getSchema(class_);
        Section section = schema.getSection();
        this.validateText(inputNode, schema);
        this.validateSection(inputNode, section);
        return inputNode.isElement();
    }

    private void validateAttribute(InputNode inputNode, Section section, LabelMap labelMap) throws Exception {
        Position position = inputNode.getPosition();
        String string2 = section.getAttribute(inputNode.getName());
        Label label = labelMap.getLabel(string2);
        if (label == null) {
            Class class_ = this.type.getType();
            if (labelMap.isStrict(this.context)) {
                if (!this.revision.isEqual()) {
                    return;
                }
                throw new AttributeException("Attribute '%s' does not exist for %s at %s", new Object[]{string2, class_, position});
            }
        } else {
            this.validate(inputNode, label);
        }
    }

    private void validateAttributes(InputNode inputNode, Section section) throws Exception {
        NodeMap<InputNode> nodeMap = inputNode.getAttributes();
        LabelMap labelMap = section.getAttributes();
        Iterator iterator = nodeMap.iterator();
        while (iterator.hasNext()) {
            InputNode inputNode2 = inputNode.getAttribute((String)iterator.next());
            if (inputNode2 == null) continue;
            this.validateAttribute(inputNode2, section, labelMap);
        }
        this.validate(inputNode, labelMap);
    }

    private void validateElement(InputNode inputNode, Section section, LabelMap labelMap) throws Exception {
        String string2 = section.getPath(inputNode.getName());
        Label label = labelMap.getLabel(string2);
        if (label == null) {
            label = this.criteria.resolve(string2);
        }
        if (label == null) {
            Position position = inputNode.getPosition();
            Class class_ = this.type.getType();
            if (labelMap.isStrict(this.context) && this.revision.isEqual()) {
                throw new ElementException("Element '%s' does not exist for %s at %s", new Object[]{string2, class_, position});
            }
            inputNode.skip();
            return;
        }
        this.validateUnion(inputNode, labelMap, label);
    }

    private void validateElements(InputNode inputNode, Section section) throws Exception {
        LabelMap labelMap = section.getElements();
        InputNode inputNode2 = inputNode.getNext();
        while (inputNode2 != null) {
            Section section2 = section.getSection(inputNode2.getName());
            if (section2 != null) {
                this.validateSection(inputNode2, section2);
            } else {
                this.validateElement(inputNode2, section, labelMap);
            }
            inputNode2 = inputNode.getNext();
        }
        this.validate(inputNode, labelMap);
    }

    private void validateSection(InputNode inputNode, Section section) throws Exception {
        this.validateAttributes(inputNode, section);
        this.validateElements(inputNode, section);
    }

    private void validateText(InputNode inputNode, Schema schema) throws Exception {
        Label label = schema.getText();
        if (label != null) {
            this.validate(inputNode, label);
        }
    }

    private void validateUnion(InputNode inputNode, LabelMap labelMap, Label label) throws Exception {
        String[] arrstring = label.getPaths();
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            labelMap.getLabel(arrstring[i]);
        }
        if (label.isInline()) {
            this.criteria.set(label, null);
        }
        this.validate(inputNode, label);
    }

    private void write(OutputNode outputNode, Object object, Schema schema) throws Exception {
        Section section = schema.getSection();
        this.writeVersion(outputNode, object, schema);
        this.writeSection(outputNode, object, section);
    }

    private void writeAttribute(OutputNode outputNode, Object object, Label label) throws Exception {
        if (object != null) {
            label.getDecorator().decorate(outputNode.setAttribute(label.getName(), this.factory.getText(object)));
        }
    }

    private void writeAttributes(OutputNode outputNode, Object object, Section section) throws Exception {
        for (Label label : section.getAttributes()) {
            Object object2 = label.getContact().get(object);
            Class class_ = this.context.getType(this.type, object);
            if (object2 == null) {
                object2 = label.getEmpty(this.context);
            }
            if (object2 == null && label.isRequired()) {
                throw new AttributeException("Value for %s is null in %s", new Object[]{label, class_});
            }
            this.writeAttribute(outputNode, object2, label);
        }
    }

    private void writeElement(OutputNode outputNode, Object object, Converter converter) throws Exception {
        converter.write(outputNode, object);
    }

    private void writeElement(OutputNode outputNode, Object object, Label label) throws Exception {
        if (object != null) {
            Class class_ = object.getClass();
            Label label2 = label.getLabel(class_);
            String string2 = label2.getName();
            Type type = label.getType(class_);
            OutputNode outputNode2 = outputNode.getChild(string2);
            if (!label2.isInline()) {
                this.writeNamespaces(outputNode2, type, label2);
            }
            if (label2.isInline() || !this.isOverridden(outputNode2, object, type)) {
                Converter converter = label2.getConverter(this.context);
                outputNode2.setData(label2.isData());
                this.writeElement(outputNode2, object, converter);
            }
        }
    }

    private void writeElements(OutputNode outputNode, Object object, Section section) throws Exception {
        for (String string2 : section) {
            Section section2 = section.getSection(string2);
            if (section2 != null) {
                this.writeSection(outputNode.getChild(string2), object, section2);
                continue;
            }
            Label label = section.getElement(section.getPath(string2));
            Class class_ = this.context.getType(this.type, object);
            if (this.criteria.get(label) != null) continue;
            if (label != null) {
                this.writeUnion(outputNode, object, section, label);
                continue;
            }
            throw new ElementException("Element '%s' not defined in %s", new Object[]{string2, class_});
        }
    }

    private void writeNamespaces(OutputNode outputNode, Type type, Label label) throws Exception {
        Class class_ = type.getType();
        Decorator decorator = this.context.getDecorator(class_);
        label.getDecorator().decorate(outputNode, decorator);
    }

    private Object writeReplace(Object object) throws Exception {
        if (object != null) {
            Class class_ = object.getClass();
            object = this.context.getCaller(class_).replace(object);
        }
        return object;
    }

    private void writeSection(OutputNode outputNode, Object object, Section section) throws Exception {
        NamespaceMap namespaceMap = outputNode.getNamespaces();
        String string2 = section.getPrefix();
        if (string2 != null) {
            String string3 = namespaceMap.getReference(string2);
            if (string3 != null) {
                outputNode.setReference(string3);
            } else {
                Object[] arrobject = new Object[]{string2, this.type};
                throw new ElementException("Namespace prefix '%s' in %s is not in scope", arrobject);
            }
        }
        this.writeAttributes(outputNode, object, section);
        this.writeElements(outputNode, object, section);
        this.writeText(outputNode, object, section);
    }

    private void writeText(OutputNode outputNode, Object object, Label label) throws Exception {
        if (object != null && !label.isTextList()) {
            String string2 = this.factory.getText(object);
            outputNode.setData(label.isData());
            outputNode.setValue(string2);
        }
    }

    private void writeText(OutputNode outputNode, Object object, Section section) throws Exception {
        Label label = section.getText();
        if (label != null) {
            Object object2 = label.getContact().get(object);
            Class class_ = this.context.getType(this.type, object);
            if (object2 == null) {
                object2 = label.getEmpty(this.context);
            }
            if (object2 == null && label.isRequired()) {
                throw new TextException("Value for %s is null in %s", new Object[]{label, class_});
            }
            this.writeText(outputNode, object2, label);
        }
    }

    private void writeUnion(OutputNode outputNode, Object object, Section section, Label label) throws Exception {
        Object object2 = label.getContact().get(object);
        Class class_ = this.context.getType(this.type, object);
        if (object2 == null && label.isRequired()) {
            throw new ElementException("Value for %s is null in %s", new Object[]{label, class_});
        }
        Object object3 = this.writeReplace(object2);
        if (object3 != null) {
            this.writeElement(outputNode, object3, label);
        }
        this.criteria.set(label, object3);
    }

    private void writeVersion(OutputNode outputNode, Object object, Schema schema) throws Exception {
        Version version = schema.getRevision();
        Label label = schema.getVersion();
        if (version != null) {
            Double d = this.revision.getDefault();
            Double d2 = version.revision();
            if (this.revision.compare((Object)d2, (Object)d)) {
                if (label.isRequired()) {
                    this.writeAttribute(outputNode, (Object)d2, label);
                    return;
                }
            } else {
                this.writeAttribute(outputNode, (Object)d2, label);
            }
        }
    }

    public Object read(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        Class class_ = instance.getType();
        if (instance.isReference()) {
            return instance.getInstance();
        }
        if (this.context.isPrimitive(class_)) {
            return this.readPrimitive(inputNode, instance);
        }
        return this.read(inputNode, instance, class_);
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Class class_ = object.getClass();
        Schema schema = this.context.getSchema(class_);
        Caller caller = schema.getCaller();
        this.read(inputNode, object, schema);
        this.criteria.commit(object);
        caller.validate(object);
        caller.commit(object);
        return this.readResolve(inputNode, object, caller);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            instance.setInstance(null);
            return this.validate(inputNode, instance.getType());
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Class class_ = object.getClass();
        Schema schema = this.context.getSchema(class_);
        Caller caller = schema.getCaller();
        try {
            if (schema.isPrimitive()) {
                this.primitive.write(outputNode, object);
            } else {
                caller.persist(object);
                this.write(outputNode, object, schema);
            }
            return;
        }
        finally {
            caller.complete(object);
        }
    }

    private class Injector
    extends Builder {
        private Injector(Composite composite2, Criteria criteria, Schema schema, Instance instance) {
            super(composite2, criteria, schema, instance);
        }

        private Object readInject(InputNode inputNode) throws Exception {
            Object object = this.schema.getInstantiator().getInstance(this.criteria);
            this.value.setInstance(object);
            this.criteria.commit(object);
            return object;
        }

        public Object read(InputNode inputNode) throws Exception {
            Section section = this.schema.getSection();
            this.composite.readVersion(inputNode, null, this.schema);
            this.composite.readText(inputNode, null, section);
            this.composite.readAttributes(inputNode, null, section);
            this.composite.readElements(inputNode, null, section);
            return this.readInject(inputNode);
        }
    }

}

