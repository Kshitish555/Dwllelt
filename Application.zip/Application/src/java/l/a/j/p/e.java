/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.i.a
 *  l.a.h.i.d
 *  l.a.j.p.c
 *  l.a.j.p.c$b
 *  l.a.j.p.c$b$d
 */
package l.a.j.p;

import l.a.h.i.a;
import l.a.h.i.d;
import l.a.j.p.c;

public final class e
extends Enum<e>
implements c.b {
    public static final /* enum */ e c;
    private static final /* synthetic */ e[] d;

    static {
        e e2;
        c = e2 = new e();
        d = new e[]{e2};
    }

    public static e valueOf(String string) {
        return (e)Enum.valueOf(e.class, (String)string);
    }

    public static e[] values() {
        return (e[])d.clone();
    }

    public c.b.d a(a a2, c.c c2, c.c c3) {
        int n2;
        int n3 = c2.c().getParameters().size();
        if (n3 == (n2 = c3.c().getParameters().size())) {
            return c.b.d.o;
        }
        if (n3 < n2) {
            return c.b.d.h;
        }
        return c.b.d.f;
    }
}

