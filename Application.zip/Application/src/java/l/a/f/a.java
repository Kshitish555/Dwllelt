/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 *  java.lang.reflect.Type
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  l.a.b
 *  l.a.f.a$b$a
 *  l.a.f.a$b$b
 *  l.a.f.a$f
 *  l.a.f.a$f$a
 *  l.a.f.a$f$a$c
 *  l.a.f.a$f$c
 *  l.a.f.a$f$e
 *  l.a.f.a$f$e$b
 *  l.a.f.a$j
 *  l.a.f.a$k
 *  l.a.f.a$m
 *  l.a.f.a$n
 *  l.a.f.a$r
 *  l.a.f.a$w
 *  l.a.f.b
 *  l.a.f.b$d$c
 *  l.a.h.f.a
 *  l.a.h.f.a$f
 *  l.a.h.f.b
 *  l.a.h.f.d
 *  l.a.h.i.a
 *  l.a.h.i.a$c
 *  l.a.h.i.a$d
 *  l.a.h.i.b
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.i.a
 *  l.a.i.a$c
 *  l.a.i.a$j
 *  l.a.j.e$g
 *  l.a.j.q.b
 *  l.a.j.q.b$c
 *  l.a.j.q.e
 *  l.a.j.q.f
 *  l.a.j.q.i.a
 *  l.a.j.q.l.c
 *  l.a.k.a.a
 *  l.a.k.a.e
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.v
 *  l.a.l.r
 *  l.a.l.s
 *  l.a.l.x
 *  l.a.m.a
 */
package l.a.f;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import l.a.f.a;
import l.a.f.b;
import l.a.h.f.a;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.i.a;
import l.a.j.e;
import l.a.j.q.b;
import l.a.k.a.q;
import l.a.k.a.v;
import l.a.l.s;
import l.a.l.x;

/*
 * Exception performing whole class analysis.
 */
public class a
implements b.d.c,
l.a.j.e {
    private static final a.d P4;
    private static final a.d Q4;
    private static final a.d R4;
    private static final a.d S4;
    private static final a.d T4;
    private static final l.a.k.a.e s;
    private static final a.d t;
    private static final a.d w;
    private final f.a c;
    private final f.b d;
    private final l.a.j.q.i.a f;
    private final l.a.j.q.e h;
    private final l.a.j.e o;

    static {
        l.a.h.i.b b2 = new c.d(m.class).u();
        t = (a.d)((l.a.h.i.b)b2.b((l.a.l.r)s.m((String)"inline"))).b1();
        w = (a.d)((l.a.h.i.b)b2.b((l.a.l.r)s.m((String)"suppress"))).b1();
        Q4 = (a.d)((l.a.h.i.b)b2.b((l.a.l.r)s.m((String)"skipOn"))).b1();
        P4 = (a.d)((l.a.h.i.b)b2.b((l.a.l.r)s.m((String)"prependLineNumber"))).b1();
        l.a.h.i.b b3 = new c.d(n.class).u();
        R4 = (a.d)((l.a.h.i.b)b3.b((l.a.l.r)s.m((String)"inline"))).b1();
        S4 = (a.d)((l.a.h.i.b)b3.b((l.a.l.r)s.m((String)"suppress"))).b1();
        T4 = (a.d)((l.a.h.i.b)b3.b((l.a.l.r)s.m((String)"onThrowable"))).b1();
    }

    protected a(f.a a2, f.b b2) {
        this(a2, b2, l.a.j.q.i.a.w0, l.a.j.q.d.a((l.a.h.k.b)l.a.h.k.c.i0), l.a.j.m.c);
    }

    private a(f.a a2, f.b b2, l.a.j.q.i.a a3, l.a.j.q.e e2, l.a.j.e e3) {
        this.c = a2;
        this.d = b2;
        this.f = a3;
        this.h = e2;
        this.o = e3;
    }

    private static h a(Class<? extends Annotation> class_, a.d d2, h h2, a.d d3) {
        a.f f2 = d3.getDeclaredAnnotations().e(class_);
        if (f2 == null) {
            return h2;
        }
        if (!h2.c()) {
            if (d3.isStatic()) {
                if (((Boolean)f2.a(d2).a(Boolean.class)).booleanValue()) {
                    return new d(d3);
                }
                return new b(d3);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Advice for ");
            stringBuilder.append((Object)d3);
            stringBuilder.append(" is not static");
            throw new IllegalStateException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Duplicate advice for ");
        stringBuilder.append((Object)h2);
        stringBuilder.append(" and ");
        stringBuilder.append((Object)d3);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public static a a(Class<?> class_, Class<?> class_2) {
        l.a.i.a a2;
        ClassLoader classLoader;
        ClassLoader classLoader2 = class_.getClassLoader();
        if (classLoader2 == (classLoader = class_2.getClassLoader())) {
            a2 = a.c.a((ClassLoader)classLoader2);
        } else {
            l.a.i.a[] arra = new l.a.i.a[]{a.c.a((ClassLoader)classLoader2), a.c.a((ClassLoader)classLoader)};
            a2 = new a.b(arra);
        }
        return a.a(class_, class_2, a2);
    }

    public static a a(Class<?> class_, Class<?> class_2, l.a.i.a a2) {
        return a.a((l.a.h.k.c)new c.d(class_), (l.a.h.k.c)new c.d(class_2), a2);
    }

    public static a a(Class<?> class_, l.a.i.a a2) {
        return a.a((l.a.h.k.c)new c.d(class_), a2);
    }

    public static a a(l.a.h.k.c c2, l.a.h.k.c c3) {
        return a.a(c2, c3, (l.a.i.a)a.h.c);
    }

    public static a a(l.a.h.k.c c2, l.a.h.k.c c3, l.a.i.a a2) {
        return a.a(c2, c3, a2, (List<? extends e.b>)Collections.emptyList());
    }

    protected static a a(l.a.h.k.c c2, l.a.h.k.c c3, l.a.i.a a2, List<? extends e.b> list) {
        IllegalArgumentException illegalArgumentException;
        Object object = c.c;
        Iterator iterator = c2.u().iterator();
        Object object2 = object;
        while (iterator.hasNext()) {
            a.d d2 = (a.d)iterator.next();
            object2 = a.a(m.class, t, (h)object2, d2);
        }
        if (object2.c()) {
            for (a.d d3 : c3.u()) {
                object = a.a(n.class, R4, (h)object, d3);
            }
            if (object.c()) {
                try {
                    l.a.k.a.e e2 = object2.k() ? new l.a.k.a.e(a2.a(c2.getName()).resolve()) : s;
                    f.a a3 = object2.a(list, e2);
                    l.a.k.a.e e3 = object.k() ? new l.a.k.a.e(a2.a(c3.getName()).resolve()) : s;
                    a a4 = new a(a3, object.a(list, e3, a3));
                    return a4;
                }
                catch (IOException iOException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Error reading class file of ");
                    stringBuilder.append((Object)c2);
                    stringBuilder.append(" or ");
                    stringBuilder.append((Object)c3);
                    throw new IllegalStateException(stringBuilder.toString(), (Throwable)iOException);
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No enter advice defined by ");
            stringBuilder.append((Object)c3);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No enter advice defined by ");
        stringBuilder.append((Object)c2);
        illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
        throw illegalArgumentException;
    }

    public static a a(l.a.h.k.c c2, l.a.i.a a2) {
        return a.a(c2, a2, (List<? extends e.b>)Collections.emptyList());
    }

    protected static a a(l.a.h.k.c c2, l.a.i.a a2, List<? extends e.b> list) {
        Object object = c.c;
        Iterator iterator = c2.u().iterator();
        Object object2 = object;
        while (iterator.hasNext()) {
            a.d d2 = (a.d)iterator.next();
            object = a.a(m.class, t, (h)object, d2);
            object2 = a.a(n.class, R4, (h)object2, d2);
        }
        if (!object.c() && !object2.c()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No advice defined by ");
            stringBuilder.append((Object)c2);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        try {
            l.a.k.a.e e2 = !object.k() && !object2.k() ? s : new l.a.k.a.e(a2.a(c2.getName()).resolve());
            f.a a3 = object.a(list, e2);
            a a4 = new a(a3, object2.a(list, e2, a3));
            return a4;
        }
        catch (IOException iOException) {
            IllegalStateException illegalStateException;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error reading class file of ");
            stringBuilder.append((Object)c2);
            illegalStateException = new IllegalStateException(stringBuilder.toString(), (Throwable)iOException);
            throw illegalStateException;
        }
    }

    public static a b(Class<?> class_) {
        return a.a(class_, a.c.a((ClassLoader)class_.getClassLoader()));
    }

    static /* synthetic */ a.d b() {
        return T4;
    }

    public static a c(l.a.h.k.c c2) {
        return a.a(c2, (l.a.i.a)a.h.c);
    }

    static /* synthetic */ a.d c() {
        return Q4;
    }

    static /* synthetic */ a.d d() {
        return w;
    }

    static /* synthetic */ a.d e() {
        return P4;
    }

    static /* synthetic */ a.d f() {
        return S4;
    }

    public static w g() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public a a() {
        try {
            a a2 = this.a(l.a.j.q.l.c.a((a.d)new a.c(Throwable.class.getMethod("printStackTrace", new Class[0]))));
            return a2;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new IllegalStateException("Cannot locate Throwable::printStackTrace");
        }
    }

    public a a(l.a.j.q.e e2) {
        a a2 = new a(this.c, this.d, this.f, e2, this.o);
        return a2;
    }

    public a a(l.a.j.q.i.a a2) {
        a a3 = new a(this.c, this.d, a2, this.h, this.o);
        return a3;
    }

    public b.d a(l.a.l.r<? super l.a.h.i.a> r2) {
        return new b.d().a(r2, this);
    }

    public l.a.i.i.c a(l.a.i.i.c c2) {
        return this.o.a(c2);
    }

    @Override
    public l.a.j.q.b a(e.g g2) {
        return new l.a.j.q.b(this, g2, this.o.a(g2)){
            private final a c;
            private final e.g d;
            private final l.a.j.q.b f;
            {
                this.c = a2;
                this.d = g2;
                this.f = b2;
            }

            public b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                a a3 = new a(r2, this.f);
                return a3.a(this.c.a(this.d.c(), a2, a3, d2, 0, 0), d2, a2);
            }

            protected boolean a(Object object) {
                return object instanceof d;
            }

            public boolean equals(Object object) {
                if (object == this) {
                    return true;
                }
                if (!(object instanceof d)) {
                    return false;
                }
                d d2 = object;
                if (!d2.a(this)) {
                    return false;
                }
                a a2 = this.c;
                a a3 = d2.c;
                if (a2 == null ? a3 != null : !a2.equals(a3)) {
                    return false;
                }
                e.g g2 = this.d;
                e.g g3 = d2.d;
                if (g2 == null ? g3 != null : !g2.equals((Object)g3)) {
                    return false;
                }
                l.a.j.q.b b2 = this.f;
                l.a.j.q.b b3 = d2.f;
                return !(b2 == null ? b3 != null : !b2.equals((Object)b3));
            }

            public int hashCode() {
                a a2 = this.c;
                int n2 = 43;
                int n3 = a2 == null ? 43 : a2.hashCode();
                int n4 = n3 + 59;
                e.g g2 = this.d;
                int n5 = n4 * 59;
                int n6 = g2 == null ? 43 : g2.hashCode();
                int n7 = n5 + n6;
                l.a.j.q.b b2 = this.f;
                int n8 = n7 * 59;
                if (b2 != null) {
                    n2 = b2.hashCode();
                }
                return n8 + n2;
            }

            protected static class a
            extends l.a.k.a.r {
                private final l.a.j.q.b f;
                private int h;
                private int o;

                protected a(l.a.k.a.r r2, l.a.j.q.b b2) {
                    super(327680, r2);
                    this.f = b2;
                }

                protected b.c a(l.a.k.a.r r2, e.d d2, l.a.h.i.a a2) {
                    r2.b();
                    b.c c2 = this.f.a(r2, d2, a2);
                    r2.c(c2.b(), c2.a());
                    r2.d();
                    return new b.c(this.h, this.o);
                }

                public void b() {
                }

                public void c(int n2, int n3) {
                    this.h = n2;
                    this.o = n3;
                }

                public void d() {
                }
            }

        };
    }

    protected l.a.k.a.r a(l.a.h.k.c c2, l.a.h.i.a a2, l.a.k.a.r r2, e.d d2, int n2, int n3) {
        l.a.k.a.r r3 = this.c.h() ? new l.a.n.h.b(r2) : r2;
        if (!this.d.c()) {
            b.b b2 = new /* Unavailable Anonymous Inner Class!! */;
            return b2;
        }
        if (this.d.f().a(k.class)) {
            b.b b3 = new b.b(r3, d2, this.f, this.h, c2, a2, this.c, this.d, n2, n3);
            return b3;
        }
        if (!a2.p1()) {
            l.a.j.q.i.a a3 = this.f;
            l.a.j.q.e e2 = this.h;
            f.a a4 = this.c;
            f.b b4 = this.d;
            b.a a5 = new b.a(r3, d2, a3, e2, c2, a2, a4, b4, n2, n3, b4.f());
            return a5;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot catch exception during constructor call for ");
        stringBuilder.append((Object)a2);
        throw new IllegalStateException(stringBuilder.toString());
    }

    public l.a.k.a.r a(l.a.h.k.c c2, l.a.h.i.a a2, l.a.k.a.r r2, e.d d2, l.a.m.a a3, int n2, int n3) {
        if (!a2.isAbstract()) {
            if (a2.b0()) {
                return r2;
            }
            r2 = this.a(c2, a2, r2, d2, n2, n3);
        }
        return r2;
    }

    protected boolean a(Object object) {
        return object instanceof a;
    }

    public l.a.j.e b(l.a.j.e e2) {
        a a2 = new a(this.c, this.d, this.f, this.h, e2);
        return a2;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof a)) {
            return false;
        }
        a a2 = (a)object;
        if (!a2.a(this)) {
            return false;
        }
        f.a a3 = this.c;
        f.a a4 = a2.c;
        if (a3 == null ? a4 != null : !a3.equals((Object)a4)) {
            return false;
        }
        f.b b2 = this.d;
        f.b b3 = a2.d;
        if (b2 == null ? b3 != null : !b2.equals((Object)b3)) {
            return false;
        }
        l.a.j.q.i.a a5 = this.f;
        l.a.j.q.i.a a6 = a2.f;
        if (a5 == null ? a6 != null : !a5.equals((Object)a6)) {
            return false;
        }
        l.a.j.q.e e2 = this.h;
        l.a.j.q.e e3 = a2.h;
        if (e2 == null ? e3 != null : !e2.equals((Object)e3)) {
            return false;
        }
        l.a.j.e e4 = this.o;
        l.a.j.e e5 = a2.o;
        return !(e4 == null ? e5 != null : !e4.equals((Object)e5));
    }

    public int hashCode() {
        f.a a2 = this.c;
        int n2 = 43;
        int n3 = a2 == null ? 43 : a2.hashCode();
        int n4 = n3 + 59;
        f.b b2 = this.d;
        int n5 = n4 * 59;
        int n6 = b2 == null ? 43 : b2.hashCode();
        int n7 = n5 + n6;
        l.a.j.q.i.a a3 = this.f;
        int n8 = n7 * 59;
        int n9 = a3 == null ? 43 : a3.hashCode();
        int n10 = n8 + n9;
        l.a.j.q.e e2 = this.h;
        int n11 = n10 * 59;
        int n12 = e2 == null ? 43 : e2.hashCode();
        int n13 = n11 + n12;
        l.a.j.e e3 = this.o;
        int n14 = n13 * 59;
        if (e3 != null) {
            n2 = e3.hashCode();
        }
        return n14 + n2;
    }

    protected static abstract class l.a.f.a$b
    extends l.a.n.h.a
    implements a.c {
        private static final int R4;
        protected final c P4;
        protected final c Q4;
        protected final l.a.k.a.r h;
        protected final l.a.h.i.a o;
        private final int s;
        private final a.a t;
        protected final a.b w;

        protected l.a.f.a$b(l.a.k.a.r r2, l.a.k.a.r r3, e.d d2, l.a.j.q.i.a a2, l.a.j.q.e e2, l.a.h.k.c c2, l.a.h.i.a a3, f.a a4, f.b b2, List<? extends l.a.h.k.c> list, int n2, int n3) {
            c c3;
            super(327680, r3);
            this.h = r2;
            this.o = a3;
            this.s = a4.i().l().c();
            List list2 = a4.i().a((Type)Void.TYPE) ? Collections.emptyList() : Collections.singletonList((Object)a4.i().y0());
            List list3 = list2;
            this.P4 = l.a.f.a$j$a.a(a3, (List<? extends l.a.h.k.c>)list3, list, n2);
            this.Q4 = c3 = l.a.f.a$r$a.a(c2, a3, (List<? extends l.a.h.k.c>)list3, list, d2.f(), n2, n3);
            this.t = a4.a(c2, a3, r2, d2, a2, this.P4, c3, e2);
            this.w = b2.a(c2, a3, r2, d2, a2, this.P4, this.Q4, e2);
        }

        private int[] a(int[] arrn) {
            int[] arrn2 = new int[arrn.length];
            for (int i2 = 0; i2 < arrn.length; ++i2) {
                arrn2[i2] = this.d(arrn[i2]);
            }
            return arrn2;
        }

        private int d(int n2) {
            if (n2 < this.o.l()) {
                return n2;
            }
            return n2 + this.s;
        }

        public l.a.k.a.a a(int n2, v v2, q[] arrq, q[] arrq2, int[] arrn, String string, boolean bl) {
            return this.d.a(n2, v2, arrq, arrq2, this.a(arrn), string, bl);
        }

        public void a(int n2, int n3, Object[] arrobject, int n4, Object[] arrobject2) {
            this.Q4.a(this.h, n2, n3, arrobject, n4, arrobject2);
        }

        public void a(String string, String string2, String string3, q q2, q q3, int n2) {
            this.d.a(string, string2, string3, q2, q3, this.d(n2));
        }

        protected void c(int n2) {
            this.h(n2, 0);
        }

        public void c(int n2, int n3) {
            this.f();
            this.h.c(this.P4.b(n2), this.P4.d(n3));
        }

        @Override
        protected void e() {
            this.t.prepare();
            this.g();
            this.w.prepare();
            this.t.a(this);
            this.h();
        }

        @Override
        protected void e(int n2, int n3) {
            this.d.a(this.d(n2), n3);
        }

        protected abstract void f();

        protected abstract void g();

        @Override
        protected void g(int n2, int n3) {
            this.d.d(n2, this.d(n3));
        }

        protected abstract void h();

        protected void h(int n2, int n3) {
            this.h.d(n2, n3 + (this.o.l() + this.s));
        }
    }

}

