/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.adjust.sdk;

import com.adjust.sdk.AdjustEventFailure;

public interface OnEventTrackingFailedListener {
    public void onFinishedEventTrackingFailed(AdjustEventFailure var1);
}

