/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Constructor
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Constructor;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.ConcurrentCache;

class InstanceFactory {
    private final Cache<Constructor> cache = new ConcurrentCache<Constructor>();

    public Instance getInstance(Class class_) {
        return new Instance(class_){
            private Class type;
            private Object value;
            {
                this.type = class_;
            }

            @Override
            public Object getInstance() throws Exception {
                if (this.value == null) {
                    this.value = InstanceFactory.this.getObject(this.type);
                }
                return this.value;
            }

            @Override
            public Class getType() {
                return this.type;
            }

            @Override
            public boolean isReference() {
                return false;
            }

            @Override
            public Object setInstance(Object object) throws Exception {
                this.value = object;
                return object;
            }
        };
    }

    public Instance getInstance(Value value) {
        return new Instance(value){
            private final Class type;
            private final Value value;
            {
                this.type = value.getType();
                this.value = value;
            }

            @Override
            public Object getInstance() throws Exception {
                if (this.value.isReference()) {
                    return this.value.getValue();
                }
                Object object = InstanceFactory.this.getObject(this.type);
                Value value = this.value;
                if (value != null) {
                    value.setValue(object);
                }
                return object;
            }

            @Override
            public Class getType() {
                return this.type;
            }

            @Override
            public boolean isReference() {
                return this.value.isReference();
            }

            @Override
            public Object setInstance(Object object) {
                Value value = this.value;
                if (value != null) {
                    value.setValue(object);
                }
                return object;
            }
        };
    }

    protected Object getObject(Class class_) throws Exception {
        Constructor constructor = this.cache.fetch((Object)class_);
        if (constructor == null) {
            constructor = class_.getDeclaredConstructor(new Class[0]);
            if (!constructor.isAccessible()) {
                constructor.setAccessible(true);
            }
            this.cache.cache((Object)class_, constructor);
        }
        return constructor.newInstance(new Object[0]);
    }

}

