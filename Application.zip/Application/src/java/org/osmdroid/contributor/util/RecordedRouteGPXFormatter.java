/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Appendable
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.text.SimpleDateFormat
 *  java.util.Date
 *  java.util.Formatter
 *  java.util.List
 *  org.osmdroid.contributor.util.RecordedGeoPoint
 *  org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants
 */
package org.osmdroid.contributor.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import org.osmdroid.contributor.util.RecordedGeoPoint;
import org.osmdroid.contributor.util.Util;
import org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants;

public class RecordedRouteGPXFormatter
implements OpenStreetMapContributorConstants {
    private static final String GPX_TAG = "<gpx version=\"1.1\" creator=\"%s\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://www.topografix.com/GPX/1/1\" xsi:schemaLocation=\"http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd\">";
    private static final String GPX_TAG_CLOSE = "</gpx>";
    private static final String GPX_TAG_TIME = "<time>%s</time>";
    private static final String GPX_TAG_TRACK = "<trk>";
    private static final String GPX_TAG_TRACK_CLOSE = "</trk>";
    private static final String GPX_TAG_TRACK_NAME = "<name>%s</name>";
    private static final String GPX_TAG_TRACK_SEGMENT = "<trkseg>";
    private static final String GPX_TAG_TRACK_SEGMENT_CLOSE = "</trkseg>";
    public static final String GPX_TAG_TRACK_SEGMENT_POINT = "<trkpt lat=\"%f\" lon=\"%f\">";
    public static final String GPX_TAG_TRACK_SEGMENT_POINT_CLOSE = "</trkpt>";
    public static final String GPX_TAG_TRACK_SEGMENT_POINT_ELE = "<ele>%d</ele>";
    public static final String GPX_TAG_TRACK_SEGMENT_POINT_SAT = "<sat>%d</sat>";
    public static final String GPX_TAG_TRACK_SEGMENT_POINT_TIME = "<time>%s</time>";
    private static final String GPX_VERSION = "1.1";
    private static final String XML_VERSION = "<?xml version=\"1.0\"?>";
    private static final SimpleDateFormat formatterCompleteDateTime = new SimpleDateFormat("yyyyMMdd'_'HHmmss");

    public static String create(List<RecordedGeoPoint> list) throws IllegalArgumentException {
        IllegalArgumentException illegalArgumentException;
        if (list != null) {
            if (list.size() != 0) {
                StringBuilder stringBuilder = new StringBuilder();
                Formatter formatter = new Formatter((Appendable)stringBuilder);
                stringBuilder.append(XML_VERSION);
                formatter.format(GPX_TAG, new Object[]{"AndNav - http://www.andnav.org - Android Navigation System"});
                Object[] arrobject = new Object[]{Util.convertTimestampToUTCString(System.currentTimeMillis())};
                formatter.format("<time>%s</time>", arrobject);
                stringBuilder.append(GPX_TAG_TRACK);
                Object[] arrobject2 = new Object[1];
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("PUT_YOUR_USERNAME_HERE--");
                stringBuilder2.append(formatterCompleteDateTime.format((Object)new Date(((RecordedGeoPoint)list.get(0)).getTimeStamp()).getTime()));
                stringBuilder2.append("-");
                stringBuilder2.append(formatterCompleteDateTime.format((Object)new Date(((RecordedGeoPoint)list.get(list.size() - 1)).getTimeStamp()).getTime()));
                arrobject2[0] = stringBuilder2.toString();
                formatter.format(GPX_TAG_TRACK_NAME, arrobject2);
                stringBuilder.append(GPX_TAG_TRACK_SEGMENT);
                for (RecordedGeoPoint recordedGeoPoint : list) {
                    Object[] arrobject3 = new Object[]{recordedGeoPoint.getLatitudeAsDouble(), recordedGeoPoint.getLongitudeAsDouble()};
                    formatter.format(GPX_TAG_TRACK_SEGMENT_POINT, arrobject3);
                    Object[] arrobject4 = new Object[]{Util.convertTimestampToUTCString(recordedGeoPoint.getTimeStamp())};
                    formatter.format("<time>%s</time>", arrobject4);
                    int n = recordedGeoPoint.mNumSatellites;
                    if (n != Integer.MIN_VALUE) {
                        Object[] arrobject5 = new Object[]{n};
                        formatter.format(GPX_TAG_TRACK_SEGMENT_POINT_SAT, arrobject5);
                    }
                    stringBuilder.append(GPX_TAG_TRACK_SEGMENT_POINT_CLOSE);
                }
                stringBuilder.append(GPX_TAG_TRACK_SEGMENT_CLOSE);
                stringBuilder.append(GPX_TAG_TRACK_CLOSE);
                stringBuilder.append(GPX_TAG_CLOSE);
                return stringBuilder.toString();
            }
            throw new IllegalArgumentException("Records size == 0");
        }
        illegalArgumentException = new IllegalArgumentException("Records may not be null.");
        throw illegalArgumentException;
    }
}

