/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.ConcurrentHashMap
 *  org.simpleframework.xml.util.Cache
 */
package org.simpleframework.xml.util;

import java.util.concurrent.ConcurrentHashMap;
import org.simpleframework.xml.util.Cache;

public class ConcurrentCache<T>
extends ConcurrentHashMap<Object, T>
implements Cache<T> {
    public void cache(Object object, T t) {
        this.put(object, t);
    }

    public boolean contains(Object object) {
        return this.containsKey(object);
    }

    public T fetch(Object object) {
        return (T)this.get(object);
    }

    public T take(Object object) {
        return (T)this.remove(object);
    }
}

