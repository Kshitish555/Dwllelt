/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Factory
 *  org.simpleframework.xml.core.Instance
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Factory;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.InstantiationException;
import org.simpleframework.xml.core.ObjectInstance;
import org.simpleframework.xml.core.PrimitiveFactory;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.stream.InputNode;

class ObjectFactory
extends PrimitiveFactory {
    public ObjectFactory(Context context, Type type, Class class_) {
        super(context, type, class_);
    }

    @Override
    public Instance getInstance(InputNode inputNode) throws Exception {
        Value value = this.getOverride(inputNode);
        Class class_ = this.getType();
        if (value == null) {
            if (Factory.isInstantiable((Class)class_)) {
                return this.context.getInstance(class_);
            }
            Object[] arrobject = new Object[]{class_, this.type};
            throw new InstantiationException("Cannot instantiate %s for %s", arrobject);
        }
        return new ObjectInstance(this.context, value);
    }
}

