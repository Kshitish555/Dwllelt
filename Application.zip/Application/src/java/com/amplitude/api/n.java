/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.ArrayIndexOutOfBoundsException
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amplitude.api;

import com.amplitude.api.d;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class n {
    public static final String a = "com.amplitude.api.Utils";
    private static d b = d.a();

    static JSONObject a(JSONObject jSONObject) {
        JSONArray jSONArray;
        if (jSONObject == null) {
            return null;
        }
        if (jSONObject.length() == 0) {
            return new JSONObject();
        }
        try {
            jSONArray = jSONObject.names();
        }
        catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            b.b(a, arrayIndexOutOfBoundsException.toString());
            jSONArray = null;
        }
        int n2 = jSONArray != null ? jSONArray.length() : 0;
        String[] arrstring = new String[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            arrstring[i2] = jSONArray.optString(i2);
        }
        try {
            JSONObject jSONObject2 = new JSONObject(jSONObject, arrstring);
            return jSONObject2;
        }
        catch (JSONException jSONException) {
            b.b(a, jSONException.toString());
            return null;
        }
    }

    public static boolean a(String string) {
        return string == null || string.length() == 0;
        {
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static boolean a(JSONObject jSONObject, JSONObject jSONObject2) {
        if (jSONObject == jSONObject2) {
            return true;
        }
        if (jSONObject != null && jSONObject2 == null || jSONObject == null && jSONObject2 != null) {
            return false;
        }
        try {
            Object object;
            Object object2;
            boolean bl;
            if (jSONObject.length() != jSONObject2.length()) {
                return false;
            }
            Iterator iterator = jSONObject.keys();
            do {
                if (!iterator.hasNext()) {
                    return true;
                }
                String string = (String)iterator.next();
                if (!jSONObject2.has(string)) {
                    return false;
                }
                object = jSONObject.get(string);
                object2 = jSONObject2.get(string);
                if (object.getClass().equals((Object)object2.getClass())) continue;
                return false;
            } while (!(object.getClass() == JSONObject.class ? !n.a((JSONObject)object, (JSONObject)object2) : !(bl = object.equals(object2))));
            return false;
        }
        catch (JSONException jSONException) {
            return false;
        }
    }

    static String b(String string) {
        if (n.a(string)) {
            string = "$default_instance";
        }
        return string.toLowerCase();
    }
}

