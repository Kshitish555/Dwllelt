/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.text.TextUtils
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import android.content.ContentResolver;
import android.content.Context;
import android.text.TextUtils;
import com.adjust.sdk.ActivityKind;
import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.ActivityState;
import com.adjust.sdk.AdjustAttribution;
import com.adjust.sdk.AdjustConfig;
import com.adjust.sdk.AdjustEvent;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.Reflection;
import com.adjust.sdk.SessionParameters;
import com.adjust.sdk.Util;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class PackageBuilder {
    private static ILogger logger = AdjustFactory.getLogger();
    private a activityStateCopy;
    private AdjustConfig adjustConfig;
    AdjustAttribution attribution;
    long clickTimeInMilliseconds = -1L;
    long clickTimeInSeconds = -1L;
    private long createdAt;
    String deeplink;
    private com.adjust.sdk.a deviceInfo;
    Map<String, String> extraParameters;
    long installBeginTimeInSeconds = -1L;
    String rawReferrer;
    String referrer;
    String reftag;
    private SessionParameters sessionParameters;

    PackageBuilder(AdjustConfig adjustConfig, com.adjust.sdk.a a2, ActivityState activityState, SessionParameters sessionParameters, long l2) {
        this.createdAt = l2;
        this.deviceInfo = a2;
        this.adjustConfig = adjustConfig;
        this.activityStateCopy = new a(activityState);
        this.sessionParameters = sessionParameters;
    }

    public static void addBoolean(Map<String, String> map, String string, Boolean bl) {
        if (bl == null) {
            return;
        }
        PackageBuilder.addLong(map, string, (long)bl.booleanValue());
    }

    private static void addDate(Map<String, String> map, String string, Date date) {
        if (date == null) {
            return;
        }
        PackageBuilder.addString(map, string, Util.dateFormatter.format(date));
    }

    private static void addDateInMilliseconds(Map<String, String> map, String string, long l2) {
        if (l2 <= 0L) {
            return;
        }
        PackageBuilder.addDate(map, string, new Date(l2));
    }

    private static void addDateInSeconds(Map<String, String> map, String string, long l2) {
        if (l2 <= 0L) {
            return;
        }
        PackageBuilder.addDate(map, string, new Date(l2 * 1000L));
    }

    private static void addDouble(Map<String, String> map, String string, Double d2) {
        if (d2 == null) {
            return;
        }
        PackageBuilder.addString(map, string, Util.formatString("%.5f", new Object[]{d2}));
    }

    private static void addDuration(Map<String, String> map, String string, long l2) {
        if (l2 < 0L) {
            return;
        }
        PackageBuilder.addLong(map, string, (l2 + 500L) / 1000L);
    }

    private static void addLong(Map<String, String> map, String string, long l2) {
        if (l2 < 0L) {
            return;
        }
        PackageBuilder.addString(map, string, Long.toString((long)l2));
    }

    static void addMapJson(Map<String, String> map, String string, Map<String, String> map2) {
        if (map2 == null) {
            return;
        }
        if (map2.size() == 0) {
            return;
        }
        PackageBuilder.addString(map, string, new JSONObject(map2).toString());
    }

    public static void addString(Map<String, String> map, String string, String string2) {
        if (TextUtils.isEmpty((CharSequence)string2)) {
            return;
        }
        map.put((Object)string, (Object)string2);
    }

    private void checkDeviceIds(Map<String, String> map) {
        if (!(map == null || map.containsKey((Object)"mac_sha1") || map.containsKey((Object)"mac_md5") || map.containsKey((Object)"android_id") || map.containsKey((Object)"gps_adid"))) {
            logger.error("Missing device id's. Please check if Proguard is correctly set with Adjust SDK", new Object[0]);
        }
    }

    private boolean containsPlayIds(Map<String, String> map) {
        boolean bl;
        block5 : {
            block4 : {
                if (map == null) {
                    return false;
                }
                if (map.containsKey((Object)"tracking_enabled")) break block4;
                boolean bl2 = map.containsKey((Object)"gps_adid");
                bl = false;
                if (!bl2) break block5;
            }
            bl = true;
        }
        return bl;
    }

    private Map<String, String> getAttributionParameters(String string) {
        ContentResolver contentResolver = this.adjustConfig.context.getContentResolver();
        HashMap hashMap = new HashMap();
        Map<String, String> map = Reflection.getImeiParameters(this.adjustConfig.context, logger);
        if (map != null) {
            hashMap.putAll(map);
        }
        this.deviceInfo.b(this.adjustConfig.context);
        PackageBuilder.addString((Map<String, String>)hashMap, "android_uuid", this.activityStateCopy.g);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "tracking_enabled", this.deviceInfo.c);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid", this.deviceInfo.a);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid_src", this.deviceInfo.b);
        if (!this.containsPlayIds((Map<String, String>)hashMap)) {
            logger.warn("Google Advertising ID not detected, fallback to non Google Play identifiers will take place", new Object[0]);
            this.deviceInfo.a(this.adjustConfig.context);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_sha1", this.deviceInfo.e);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_md5", this.deviceInfo.f);
            PackageBuilder.addString((Map<String, String>)hashMap, "android_id", this.deviceInfo.g);
        }
        PackageBuilder.addString((Map<String, String>)hashMap, "api_level", this.deviceInfo.q);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_secret", this.adjustConfig.appSecret);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_token", this.adjustConfig.appToken);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_version", this.deviceInfo.k);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "attribution_deeplink", true);
        PackageBuilder.addDateInMilliseconds((Map<String, String>)hashMap, "created_at", this.createdAt);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "device_known", this.adjustConfig.deviceKnown);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_name", this.deviceInfo.m);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_type", this.deviceInfo.l);
        PackageBuilder.addString((Map<String, String>)hashMap, "environment", this.adjustConfig.environment);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "event_buffering_enabled", this.adjustConfig.eventBufferingEnabled);
        PackageBuilder.addString((Map<String, String>)hashMap, "fire_adid", Util.getFireAdvertisingId(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(contentResolver));
        PackageBuilder.addString((Map<String, String>)hashMap, "initiated_by", string);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "needs_response_details", true);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_name", this.deviceInfo.o);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_version", this.deviceInfo.p);
        PackageBuilder.addString((Map<String, String>)hashMap, "package_name", this.deviceInfo.j);
        PackageBuilder.addString((Map<String, String>)hashMap, "push_token", this.activityStateCopy.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "secret_id", this.adjustConfig.secretId);
        this.checkDeviceIds((Map<String, String>)hashMap);
        return hashMap;
    }

    private Map<String, String> getClickParameters(String string) {
        AdjustAttribution adjustAttribution;
        ContentResolver contentResolver = this.adjustConfig.context.getContentResolver();
        HashMap hashMap = new HashMap();
        Map<String, String> map = Reflection.getImeiParameters(this.adjustConfig.context, logger);
        if (map != null) {
            hashMap.putAll(map);
        }
        this.deviceInfo.b(this.adjustConfig.context);
        PackageBuilder.addString((Map<String, String>)hashMap, "android_uuid", this.activityStateCopy.g);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "tracking_enabled", this.deviceInfo.c);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid", this.deviceInfo.a);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid_src", this.deviceInfo.b);
        if (!this.containsPlayIds((Map<String, String>)hashMap)) {
            logger.warn("Google Advertising ID not detected, fallback to non Google Play identifiers will take place", new Object[0]);
            this.deviceInfo.a(this.adjustConfig.context);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_sha1", this.deviceInfo.e);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_md5", this.deviceInfo.f);
            PackageBuilder.addString((Map<String, String>)hashMap, "android_id", this.deviceInfo.g);
        }
        if ((adjustAttribution = this.attribution) != null) {
            PackageBuilder.addString((Map<String, String>)hashMap, "tracker", adjustAttribution.trackerName);
            PackageBuilder.addString((Map<String, String>)hashMap, "campaign", this.attribution.campaign);
            PackageBuilder.addString((Map<String, String>)hashMap, "adgroup", this.attribution.adgroup);
            PackageBuilder.addString((Map<String, String>)hashMap, "creative", this.attribution.creative);
        }
        PackageBuilder.addString((Map<String, String>)hashMap, "api_level", this.deviceInfo.q);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_secret", this.adjustConfig.appSecret);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_token", this.adjustConfig.appToken);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_version", this.deviceInfo.k);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "attribution_deeplink", true);
        PackageBuilder.addMapJson((Map<String, String>)hashMap, "callback_params", this.sessionParameters.callbackParameters);
        PackageBuilder.addDateInMilliseconds((Map<String, String>)hashMap, "click_time", this.clickTimeInMilliseconds);
        PackageBuilder.addDateInSeconds((Map<String, String>)hashMap, "click_time", this.clickTimeInSeconds);
        PackageBuilder.addLong((Map<String, String>)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "country", this.deviceInfo.s);
        PackageBuilder.addString((Map<String, String>)hashMap, "cpu_type", this.deviceInfo.z);
        PackageBuilder.addDateInMilliseconds((Map<String, String>)hashMap, "created_at", this.createdAt);
        PackageBuilder.addString((Map<String, String>)hashMap, "deeplink", this.deeplink);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "device_known", this.adjustConfig.deviceKnown);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_manufacturer", this.deviceInfo.n);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_name", this.deviceInfo.m);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_type", this.deviceInfo.l);
        PackageBuilder.addString((Map<String, String>)hashMap, "display_height", this.deviceInfo.x);
        PackageBuilder.addString((Map<String, String>)hashMap, "display_width", this.deviceInfo.w);
        PackageBuilder.addString((Map<String, String>)hashMap, "environment", this.adjustConfig.environment);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "event_buffering_enabled", this.adjustConfig.eventBufferingEnabled);
        PackageBuilder.addString((Map<String, String>)hashMap, "fb_id", this.deviceInfo.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "fire_adid", Util.getFireAdvertisingId(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(contentResolver));
        PackageBuilder.addString((Map<String, String>)hashMap, "hardware_name", this.deviceInfo.y);
        PackageBuilder.addDateInSeconds((Map<String, String>)hashMap, "install_begin_time", this.installBeginTimeInSeconds);
        PackageBuilder.addString((Map<String, String>)hashMap, "installed_at", this.deviceInfo.B);
        PackageBuilder.addString((Map<String, String>)hashMap, "language", this.deviceInfo.r);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "last_interval", this.activityStateCopy.e);
        PackageBuilder.addString((Map<String, String>)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "needs_response_details", true);
        PackageBuilder.addLong((Map<String, String>)hashMap, "network_type", Util.getNetworkType(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "os_build", this.deviceInfo.A);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_name", this.deviceInfo.o);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_version", this.deviceInfo.p);
        PackageBuilder.addString((Map<String, String>)hashMap, "package_name", this.deviceInfo.j);
        PackageBuilder.addMapJson((Map<String, String>)hashMap, "params", this.extraParameters);
        PackageBuilder.addMapJson((Map<String, String>)hashMap, "partner_params", this.sessionParameters.partnerParameters);
        PackageBuilder.addString((Map<String, String>)hashMap, "push_token", this.activityStateCopy.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "raw_referrer", this.rawReferrer);
        PackageBuilder.addString((Map<String, String>)hashMap, "referrer", this.referrer);
        PackageBuilder.addString((Map<String, String>)hashMap, "reftag", this.reftag);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_density", this.deviceInfo.v);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_format", this.deviceInfo.u);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_size", this.deviceInfo.t);
        PackageBuilder.addString((Map<String, String>)hashMap, "secret_id", this.adjustConfig.secretId);
        PackageBuilder.addLong((Map<String, String>)hashMap, "session_count", this.activityStateCopy.b);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "session_length", this.activityStateCopy.f);
        PackageBuilder.addString((Map<String, String>)hashMap, "source", string);
        PackageBuilder.addLong((Map<String, String>)hashMap, "subsession_count", this.activityStateCopy.c);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "time_spent", this.activityStateCopy.d);
        PackageBuilder.addString((Map<String, String>)hashMap, "updated_at", this.deviceInfo.C);
        this.checkDeviceIds((Map<String, String>)hashMap);
        return hashMap;
    }

    private ActivityPackage getDefaultActivityPackage(ActivityKind activityKind) {
        ActivityPackage activityPackage = new ActivityPackage(activityKind);
        activityPackage.setClientSdk(this.deviceInfo.i);
        return activityPackage;
    }

    private String getEventSuffix(AdjustEvent adjustEvent) {
        Double d2 = adjustEvent.revenue;
        if (d2 == null) {
            Object[] arrobject = new Object[]{adjustEvent.eventToken};
            return Util.formatString("'%s'", arrobject);
        }
        Object[] arrobject = new Object[]{d2, adjustEvent.currency, adjustEvent.eventToken};
        return Util.formatString("(%.5f %s, '%s')", arrobject);
    }

    private Map<String, String> getGdprParameters() {
        ContentResolver contentResolver = this.adjustConfig.context.getContentResolver();
        HashMap hashMap = new HashMap();
        Map<String, String> map = Reflection.getImeiParameters(this.adjustConfig.context, logger);
        if (map != null) {
            hashMap.putAll(map);
        }
        this.deviceInfo.b(this.adjustConfig.context);
        PackageBuilder.addString((Map<String, String>)hashMap, "android_uuid", this.activityStateCopy.g);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "tracking_enabled", this.deviceInfo.c);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid", this.deviceInfo.a);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid_src", this.deviceInfo.b);
        if (!this.containsPlayIds((Map<String, String>)hashMap)) {
            logger.warn("Google Advertising ID not detected, fallback to non Google Play identifiers will take place", new Object[0]);
            this.deviceInfo.a(this.adjustConfig.context);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_sha1", this.deviceInfo.e);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_md5", this.deviceInfo.f);
            PackageBuilder.addString((Map<String, String>)hashMap, "android_id", this.deviceInfo.g);
        }
        PackageBuilder.addString((Map<String, String>)hashMap, "api_level", this.deviceInfo.q);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_secret", this.adjustConfig.appSecret);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_token", this.adjustConfig.appToken);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_version", this.deviceInfo.k);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "attribution_deeplink", true);
        PackageBuilder.addDateInMilliseconds((Map<String, String>)hashMap, "created_at", this.createdAt);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "device_known", this.adjustConfig.deviceKnown);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_name", this.deviceInfo.m);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_type", this.deviceInfo.l);
        PackageBuilder.addString((Map<String, String>)hashMap, "environment", this.adjustConfig.environment);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "event_buffering_enabled", this.adjustConfig.eventBufferingEnabled);
        PackageBuilder.addString((Map<String, String>)hashMap, "fire_adid", Util.getFireAdvertisingId(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "needs_response_details", true);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_name", this.deviceInfo.o);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_version", this.deviceInfo.p);
        PackageBuilder.addString((Map<String, String>)hashMap, "package_name", this.deviceInfo.j);
        PackageBuilder.addString((Map<String, String>)hashMap, "push_token", this.activityStateCopy.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "secret_id", this.adjustConfig.secretId);
        this.checkDeviceIds((Map<String, String>)hashMap);
        return hashMap;
    }

    private Map<String, String> getInfoParameters(String string) {
        ContentResolver contentResolver = this.adjustConfig.context.getContentResolver();
        HashMap hashMap = new HashMap();
        Map<String, String> map = Reflection.getImeiParameters(this.adjustConfig.context, logger);
        if (map != null) {
            hashMap.putAll(map);
        }
        this.deviceInfo.b(this.adjustConfig.context);
        PackageBuilder.addString((Map<String, String>)hashMap, "android_uuid", this.activityStateCopy.g);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "tracking_enabled", this.deviceInfo.c);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid", this.deviceInfo.a);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid_src", this.deviceInfo.b);
        if (!this.containsPlayIds((Map<String, String>)hashMap)) {
            logger.warn("Google Advertising ID not detected, fallback to non Google Play identifiers will take place", new Object[0]);
            this.deviceInfo.a(this.adjustConfig.context);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_sha1", this.deviceInfo.e);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_md5", this.deviceInfo.f);
            PackageBuilder.addString((Map<String, String>)hashMap, "android_id", this.deviceInfo.g);
        }
        PackageBuilder.addString((Map<String, String>)hashMap, "app_secret", this.adjustConfig.appSecret);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_token", this.adjustConfig.appToken);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "attribution_deeplink", true);
        PackageBuilder.addDateInMilliseconds((Map<String, String>)hashMap, "created_at", this.createdAt);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "device_known", this.adjustConfig.deviceKnown);
        PackageBuilder.addString((Map<String, String>)hashMap, "environment", this.adjustConfig.environment);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "event_buffering_enabled", this.adjustConfig.eventBufferingEnabled);
        PackageBuilder.addString((Map<String, String>)hashMap, "fire_adid", Util.getFireAdvertisingId(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "needs_response_details", true);
        PackageBuilder.addString((Map<String, String>)hashMap, "push_token", this.activityStateCopy.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "secret_id", this.adjustConfig.secretId);
        PackageBuilder.addString((Map<String, String>)hashMap, "source", string);
        this.checkDeviceIds((Map<String, String>)hashMap);
        return hashMap;
    }

    private Map<String, String> getSessionParameters(boolean bl) {
        ContentResolver contentResolver = this.adjustConfig.context.getContentResolver();
        HashMap hashMap = new HashMap();
        Map<String, String> map = Reflection.getImeiParameters(this.adjustConfig.context, logger);
        if (map != null) {
            hashMap.putAll(map);
        }
        if (!bl) {
            PackageBuilder.addMapJson((Map<String, String>)hashMap, "callback_params", this.sessionParameters.callbackParameters);
            PackageBuilder.addMapJson((Map<String, String>)hashMap, "partner_params", this.sessionParameters.partnerParameters);
        }
        this.deviceInfo.b(this.adjustConfig.context);
        PackageBuilder.addString((Map<String, String>)hashMap, "android_uuid", this.activityStateCopy.g);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "tracking_enabled", this.deviceInfo.c);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid", this.deviceInfo.a);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid_src", this.deviceInfo.b);
        if (!this.containsPlayIds((Map<String, String>)hashMap)) {
            logger.warn("Google Advertising ID not detected, fallback to non Google Play identifiers will take place", new Object[0]);
            this.deviceInfo.a(this.adjustConfig.context);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_sha1", this.deviceInfo.e);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_md5", this.deviceInfo.f);
            PackageBuilder.addString((Map<String, String>)hashMap, "android_id", this.deviceInfo.g);
        }
        PackageBuilder.addString((Map<String, String>)hashMap, "api_level", this.deviceInfo.q);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_secret", this.adjustConfig.appSecret);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_token", this.adjustConfig.appToken);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_version", this.deviceInfo.k);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "attribution_deeplink", true);
        PackageBuilder.addLong((Map<String, String>)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "country", this.deviceInfo.s);
        PackageBuilder.addString((Map<String, String>)hashMap, "cpu_type", this.deviceInfo.z);
        PackageBuilder.addDateInMilliseconds((Map<String, String>)hashMap, "created_at", this.createdAt);
        PackageBuilder.addString((Map<String, String>)hashMap, "default_tracker", this.adjustConfig.defaultTracker);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "device_known", this.adjustConfig.deviceKnown);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_manufacturer", this.deviceInfo.n);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_name", this.deviceInfo.m);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_type", this.deviceInfo.l);
        PackageBuilder.addString((Map<String, String>)hashMap, "display_height", this.deviceInfo.x);
        PackageBuilder.addString((Map<String, String>)hashMap, "display_width", this.deviceInfo.w);
        PackageBuilder.addString((Map<String, String>)hashMap, "environment", this.adjustConfig.environment);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "event_buffering_enabled", this.adjustConfig.eventBufferingEnabled);
        PackageBuilder.addString((Map<String, String>)hashMap, "fb_id", this.deviceInfo.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "fire_adid", Util.getFireAdvertisingId(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(contentResolver));
        PackageBuilder.addString((Map<String, String>)hashMap, "hardware_name", this.deviceInfo.y);
        PackageBuilder.addString((Map<String, String>)hashMap, "installed_at", this.deviceInfo.B);
        PackageBuilder.addString((Map<String, String>)hashMap, "language", this.deviceInfo.r);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "last_interval", this.activityStateCopy.e);
        PackageBuilder.addString((Map<String, String>)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "needs_response_details", true);
        PackageBuilder.addLong((Map<String, String>)hashMap, "network_type", Util.getNetworkType(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "os_build", this.deviceInfo.A);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_name", this.deviceInfo.o);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_version", this.deviceInfo.p);
        PackageBuilder.addString((Map<String, String>)hashMap, "package_name", this.deviceInfo.j);
        PackageBuilder.addString((Map<String, String>)hashMap, "push_token", this.activityStateCopy.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_density", this.deviceInfo.v);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_format", this.deviceInfo.u);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_size", this.deviceInfo.t);
        PackageBuilder.addString((Map<String, String>)hashMap, "secret_id", this.adjustConfig.secretId);
        PackageBuilder.addLong((Map<String, String>)hashMap, "session_count", this.activityStateCopy.b);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "session_length", this.activityStateCopy.f);
        PackageBuilder.addLong((Map<String, String>)hashMap, "subsession_count", this.activityStateCopy.c);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "time_spent", this.activityStateCopy.d);
        PackageBuilder.addString((Map<String, String>)hashMap, "updated_at", this.deviceInfo.C);
        this.checkDeviceIds((Map<String, String>)hashMap);
        return hashMap;
    }

    ActivityPackage buildAttributionPackage(String string) {
        Map<String, String> map = this.getAttributionParameters(string);
        ActivityPackage activityPackage = this.getDefaultActivityPackage(ActivityKind.ATTRIBUTION);
        activityPackage.setPath("attribution");
        activityPackage.setSuffix("");
        activityPackage.setParameters(map);
        return activityPackage;
    }

    ActivityPackage buildClickPackage(String string) {
        Map<String, String> map = this.getClickParameters(string);
        ActivityPackage activityPackage = this.getDefaultActivityPackage(ActivityKind.CLICK);
        activityPackage.setPath("/sdk_click");
        activityPackage.setSuffix("");
        activityPackage.setClickTimeInMilliseconds(this.clickTimeInMilliseconds);
        activityPackage.setClickTimeInSeconds(this.clickTimeInSeconds);
        activityPackage.setInstallBeginTimeInSeconds(this.installBeginTimeInSeconds);
        activityPackage.setParameters(map);
        return activityPackage;
    }

    ActivityPackage buildEventPackage(AdjustEvent adjustEvent, boolean bl) {
        Map<String, String> map = this.getEventParameters(adjustEvent, bl);
        ActivityPackage activityPackage = this.getDefaultActivityPackage(ActivityKind.EVENT);
        activityPackage.setPath("/event");
        activityPackage.setSuffix(this.getEventSuffix(adjustEvent));
        activityPackage.setParameters(map);
        if (bl) {
            activityPackage.setCallbackParameters(adjustEvent.callbackParameters);
            activityPackage.setPartnerParameters(adjustEvent.partnerParameters);
        }
        return activityPackage;
    }

    ActivityPackage buildGdprPackage() {
        Map<String, String> map = this.getGdprParameters();
        ActivityPackage activityPackage = this.getDefaultActivityPackage(ActivityKind.GDPR);
        activityPackage.setPath("/gdpr_forget_device");
        activityPackage.setSuffix("");
        activityPackage.setParameters(map);
        return activityPackage;
    }

    ActivityPackage buildInfoPackage(String string) {
        Map<String, String> map = this.getInfoParameters(string);
        ActivityPackage activityPackage = this.getDefaultActivityPackage(ActivityKind.INFO);
        activityPackage.setPath("/sdk_info");
        activityPackage.setSuffix("");
        activityPackage.setParameters(map);
        return activityPackage;
    }

    ActivityPackage buildSessionPackage(boolean bl) {
        Map<String, String> map = this.getSessionParameters(bl);
        ActivityPackage activityPackage = this.getDefaultActivityPackage(ActivityKind.SESSION);
        activityPackage.setPath("/session");
        activityPackage.setSuffix("");
        activityPackage.setParameters(map);
        return activityPackage;
    }

    public Map<String, String> getEventParameters(AdjustEvent adjustEvent, boolean bl) {
        ContentResolver contentResolver = this.adjustConfig.context.getContentResolver();
        HashMap hashMap = new HashMap();
        Map<String, String> map = Reflection.getImeiParameters(this.adjustConfig.context, logger);
        if (map != null) {
            hashMap.putAll(map);
        }
        if (!bl) {
            PackageBuilder.addMapJson((Map<String, String>)hashMap, "callback_params", Util.mergeParameters(this.sessionParameters.callbackParameters, adjustEvent.callbackParameters, "Callback"));
            PackageBuilder.addMapJson((Map<String, String>)hashMap, "partner_params", Util.mergeParameters(this.sessionParameters.partnerParameters, adjustEvent.partnerParameters, "Partner"));
        }
        this.deviceInfo.b(this.adjustConfig.context);
        PackageBuilder.addString((Map<String, String>)hashMap, "android_uuid", this.activityStateCopy.g);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "tracking_enabled", this.deviceInfo.c);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid", this.deviceInfo.a);
        PackageBuilder.addString((Map<String, String>)hashMap, "gps_adid_src", this.deviceInfo.b);
        if (!this.containsPlayIds((Map<String, String>)hashMap)) {
            logger.warn("Google Advertising ID not detected, fallback to non Google Play identifiers will take place", new Object[0]);
            this.deviceInfo.a(this.adjustConfig.context);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_sha1", this.deviceInfo.e);
            PackageBuilder.addString((Map<String, String>)hashMap, "mac_md5", this.deviceInfo.f);
            PackageBuilder.addString((Map<String, String>)hashMap, "android_id", this.deviceInfo.g);
        }
        PackageBuilder.addString((Map<String, String>)hashMap, "api_level", this.deviceInfo.q);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_secret", this.adjustConfig.appSecret);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_token", this.adjustConfig.appToken);
        PackageBuilder.addString((Map<String, String>)hashMap, "app_version", this.deviceInfo.k);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "attribution_deeplink", true);
        PackageBuilder.addLong((Map<String, String>)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "country", this.deviceInfo.s);
        PackageBuilder.addString((Map<String, String>)hashMap, "cpu_type", this.deviceInfo.z);
        PackageBuilder.addDateInMilliseconds((Map<String, String>)hashMap, "created_at", this.createdAt);
        PackageBuilder.addString((Map<String, String>)hashMap, "currency", adjustEvent.currency);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "device_known", this.adjustConfig.deviceKnown);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_manufacturer", this.deviceInfo.n);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_name", this.deviceInfo.m);
        PackageBuilder.addString((Map<String, String>)hashMap, "device_type", this.deviceInfo.l);
        PackageBuilder.addString((Map<String, String>)hashMap, "display_height", this.deviceInfo.x);
        PackageBuilder.addString((Map<String, String>)hashMap, "display_width", this.deviceInfo.w);
        PackageBuilder.addString((Map<String, String>)hashMap, "environment", this.adjustConfig.environment);
        PackageBuilder.addString((Map<String, String>)hashMap, "event_callback_id", adjustEvent.callbackId);
        PackageBuilder.addLong((Map<String, String>)hashMap, "event_count", this.activityStateCopy.a);
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "event_buffering_enabled", this.adjustConfig.eventBufferingEnabled);
        PackageBuilder.addString((Map<String, String>)hashMap, "event_token", adjustEvent.eventToken);
        PackageBuilder.addString((Map<String, String>)hashMap, "fb_id", this.deviceInfo.h);
        PackageBuilder.addString((Map<String, String>)hashMap, "fire_adid", Util.getFireAdvertisingId(contentResolver));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(contentResolver));
        PackageBuilder.addString((Map<String, String>)hashMap, "hardware_name", this.deviceInfo.y);
        PackageBuilder.addString((Map<String, String>)hashMap, "language", this.deviceInfo.r);
        PackageBuilder.addString((Map<String, String>)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
        PackageBuilder.addBoolean((Map<String, String>)hashMap, "needs_response_details", true);
        PackageBuilder.addLong((Map<String, String>)hashMap, "network_type", Util.getNetworkType(this.adjustConfig.context));
        PackageBuilder.addString((Map<String, String>)hashMap, "os_build", this.deviceInfo.A);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_name", this.deviceInfo.o);
        PackageBuilder.addString((Map<String, String>)hashMap, "os_version", this.deviceInfo.p);
        PackageBuilder.addString((Map<String, String>)hashMap, "package_name", this.deviceInfo.j);
        PackageBuilder.addString((Map<String, String>)hashMap, "push_token", this.activityStateCopy.h);
        PackageBuilder.addDouble((Map<String, String>)hashMap, "revenue", adjustEvent.revenue);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_density", this.deviceInfo.v);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_format", this.deviceInfo.u);
        PackageBuilder.addString((Map<String, String>)hashMap, "screen_size", this.deviceInfo.t);
        PackageBuilder.addString((Map<String, String>)hashMap, "secret_id", this.adjustConfig.secretId);
        PackageBuilder.addLong((Map<String, String>)hashMap, "session_count", this.activityStateCopy.b);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "session_length", this.activityStateCopy.f);
        PackageBuilder.addLong((Map<String, String>)hashMap, "subsession_count", this.activityStateCopy.c);
        PackageBuilder.addDuration((Map<String, String>)hashMap, "time_spent", this.activityStateCopy.d);
        this.checkDeviceIds((Map<String, String>)hashMap);
        return hashMap;
    }

    private class a {
        int a = -1;
        int b = -1;
        int c = -1;
        long d = -1L;
        long e = -1L;
        long f = -1L;
        String g = null;
        String h = null;

        a(ActivityState activityState) {
            if (activityState == null) {
                return;
            }
            this.a = activityState.eventCount;
            this.b = activityState.sessionCount;
            this.c = activityState.subsessionCount;
            this.d = activityState.timeSpent;
            this.e = activityState.lastInterval;
            this.f = activityState.sessionLength;
            this.g = activityState.uuid;
            this.h = activityState.pushToken;
        }
    }

}

