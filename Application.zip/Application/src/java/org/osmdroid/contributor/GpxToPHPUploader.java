/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedInputStream
 *  java.io.ByteArrayInputStream
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.List
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpResponse
 *  org.apache.http.StatusLine
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.entity.mime.MultipartEntity
 *  org.apache.http.entity.mime.content.ContentBody
 *  org.apache.http.entity.mime.content.InputStreamBody
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.apache.http.params.HttpParams
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.contributor;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;
import org.osmdroid.contributor.util.RecordedGeoPoint;
import org.osmdroid.contributor.util.RecordedRouteGPXFormatter;
import org.osmdroid.contributor.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GpxToPHPUploader {
    protected static final String UPLOADSCRIPT_URL = "http://www.PLACEYOURDOMAINHERE.com/anyfolder/gpxuploader/upload.php";
    private static final Logger logger = LoggerFactory.getLogger(GpxToPHPUploader.class);

    private GpxToPHPUploader() {
    }

    public static void uploadAsync(final ArrayList<RecordedGeoPoint> arrayList) {
        new Thread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                try {
                    if (!Util.isSufficienDataForUpload((ArrayList<RecordedGeoPoint>)arrayList)) {
                        return;
                    }
                    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(RecordedRouteGPXFormatter.create((List<RecordedGeoPoint>)arrayList).getBytes());
                    DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost(GpxToPHPUploader.UPLOADSCRIPT_URL);
                    MultipartEntity multipartEntity = new MultipartEntity();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(System.currentTimeMillis());
                    stringBuilder.append(".gpx");
                    multipartEntity.addPart("gpxfile", (ContentBody)new InputStreamBody((InputStream)byteArrayInputStream, stringBuilder.toString()));
                    defaultHttpClient.getParams().setBooleanParameter("http.protocol.expect-continue", false);
                    httpPost.setEntity((HttpEntity)multipartEntity);
                    HttpResponse httpResponse = defaultHttpClient.execute((HttpUriRequest)httpPost);
                    int n2 = httpResponse.getStatusLine().getStatusCode();
                    if (n2 != 200) {
                        logger.error("GPXUploader", (Object)"status != HttpStatus.SC_OK");
                        return;
                    }
                    InputStreamReader inputStreamReader = new InputStreamReader((InputStream)new BufferedInputStream(httpResponse.getEntity().getContent()));
                    char[] arrc = new char[8192];
                    StringBuilder stringBuilder2 = new StringBuilder();
                    do {
                        int n3;
                        if ((n3 = inputStreamReader.read(arrc)) == -1) {
                            Logger logger = logger;
                            StringBuilder stringBuilder3 = new StringBuilder();
                            stringBuilder3.append("Response: ");
                            stringBuilder3.append(stringBuilder2.toString());
                            logger.debug("GPXUploader", (Object)stringBuilder3.toString());
                            return;
                        }
                        stringBuilder2.append(arrc, 0, n3);
                    } while (true);
                }
                catch (Exception exception) {}
            }
        }).start();
    }

}

