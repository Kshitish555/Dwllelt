/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.core.PersistenceException
 *  org.simpleframework.xml.core.Traverser
 *  org.simpleframework.xml.strategy.Type
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import org.simpleframework.xml.core.CollectionFactory;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Traverser;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;

class CompositeList
implements Converter {
    private final Type entry;
    private final CollectionFactory factory;
    private final String name;
    private final Traverser root;
    private final Type type;

    public CompositeList(Context context, Type type, Type type2, String string2) {
        this.factory = new CollectionFactory(context, type);
        this.root = new Traverser(context);
        this.entry = type2;
        this.type = type;
        this.name = string2;
    }

    private Object populate(InputNode inputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        do {
            InputNode inputNode2 = inputNode.getNext();
            Class class_ = this.entry.getType();
            if (inputNode2 == null) {
                return collection;
            }
            collection.add(this.root.read(inputNode2, class_));
        } while (true);
    }

    private boolean validate(InputNode inputNode, Class class_) throws Exception {
        do {
            InputNode inputNode2 = inputNode.getNext();
            Class class_2 = this.entry.getType();
            if (inputNode2 == null) {
                return true;
            }
            this.root.validate(inputNode2, class_2);
        } while (true);
    }

    public Object read(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        Object object = instance.getInstance();
        if (!instance.isReference()) {
            return this.populate(inputNode, object);
        }
        return object;
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (instance.isReference()) {
            return instance.getInstance();
        }
        instance.setInstance(object);
        if (object != null) {
            return this.populate(inputNode, object);
        }
        return object;
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            instance.setInstance(null);
            return this.validate(inputNode, instance.getType());
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        for (Object object2 : (Collection)object) {
            Class class_;
            if (object2 == null) continue;
            Class class_2 = this.entry.getType();
            if (class_2.isAssignableFrom(class_ = object2.getClass())) {
                this.root.write(outputNode, object2, class_2, this.name);
                continue;
            }
            Object[] arrobject = new Object[]{class_, this.entry, this.type};
            throw new PersistenceException("Entry %s does not match %s for %s", arrobject);
        }
    }
}

