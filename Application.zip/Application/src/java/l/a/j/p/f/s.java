/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  l.a.h.f.c
 *  l.a.h.i.a
 *  l.a.h.i.c
 *  l.a.h.i.d
 *  l.a.h.k.c
 *  l.a.j.e$g
 *  l.a.j.p.c
 *  l.a.j.p.c$c$a
 *  l.a.j.p.c$c$b
 *  l.a.j.p.c$d
 *  l.a.j.p.c$e
 *  l.a.j.p.c$g
 *  l.a.j.p.c$h
 *  l.a.j.p.f.j
 *  l.a.j.p.f.j$a
 *  l.a.j.p.f.n
 *  l.a.j.p.f.n$a
 *  l.a.j.p.f.s$a
 *  l.a.j.p.f.s$a$a
 *  l.a.j.p.f.s$b
 *  l.a.j.q.e
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 */
package l.a.j.p.f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import l.a.h.i.d;
import l.a.j.e;
import l.a.j.p.c;
import l.a.j.p.f.j;
import l.a.j.p.f.n;
import l.a.j.p.f.s;
import l.a.j.q.i.a;

/*
 * Exception performing whole class analysis ignored.
 */
public class s
implements l.a.j.p.c {
    private final a a;

    protected s(a a2) {
        this.a = a2;
    }

    public static l.a.j.p.c a(List<? extends b<?>> list) {
        return new s(a.a(list));
    }

    public c.g a(l.a.h.i.a a2) {
        if (j.a.a((l.a.h.i.a)a2)) {
            return c.g.a.c;
        }
        ArrayList arrayList = new ArrayList(a2.getParameters().size());
        for (l.a.h.i.c c2 : a2.getParameters()) {
            arrayList.add((Object)this.a.a(c2));
        }
        return new c(a2, (List<a>)arrayList, n.a.a((l.a.h.f.c)a2));
    }

    protected boolean a(Object object) {
        return object instanceof s;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof s)) {
            return false;
        }
        s s2 = (s)object;
        if (!s2.a(this)) {
            return false;
        }
        a a2 = this.a;
        a a3 = s2.a;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public int hashCode() {
        a a2 = this.a;
        int n2 = a2 == null ? 43 : a2.hashCode();
        return 59 + n2;
    }

    protected static class c
    implements c.g {
        private final l.a.h.i.a c;
        private final List<a> d;
        private final a.d f;

        protected c(l.a.h.i.a a2, List<a> list, a.d d2) {
            this.c = a2;
            this.d = list;
            this.f = d2;
        }

        public c.c a(e.g g2, l.a.h.i.a a2, c.h h2, c.d d2, l.a.j.q.i.a a3) {
            if (!this.c.d(g2.c())) {
                return c.c.b.c;
            }
            l.a.j.q.e e2 = h2.a(a3, this.f, a2, this.c);
            if (!e2.x()) {
                return c.c.b.c;
            }
            c.c.a a4 = new c.c.a(d2, this.c);
            Iterator iterator = this.d.iterator();
            while (iterator.hasNext()) {
                c.e e3 = ((a)iterator.next()).a(a2, g2, a3);
                if (e3.x() && a4.a(e3)) continue;
                return c.c.b.c;
            }
            return a4.a(e2);
        }

        protected boolean a(Object object) {
            return object instanceof c;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof c)) {
                return false;
            }
            c c2 = (c)object;
            if (!c2.a(this)) {
                return false;
            }
            l.a.h.i.a a2 = this.c;
            l.a.h.i.a a3 = c2.c;
            if (a2 == null ? a3 != null : !a2.equals((Object)a3)) {
                return false;
            }
            List<a> list = this.d;
            List<a> list2 = c2.d;
            if (list == null ? list2 != null : !list.equals(list2)) {
                return false;
            }
            a.d d2 = this.f;
            a.d d3 = c2.f;
            return !(d2 == null ? d3 != null : !d2.equals((Object)d3));
        }

        public int hashCode() {
            l.a.h.i.a a2 = this.c;
            int n = 43;
            int n2 = a2 == null ? 43 : a2.hashCode();
            int n3 = n2 + 59;
            List<a> list = this.d;
            int n4 = n3 * 59;
            int n5 = list == null ? 43 : list.hashCode();
            int n6 = n4 + n5;
            a.d d2 = this.f;
            int n7 = n6 * 59;
            if (d2 != null) {
                n = d2.hashCode();
            }
            return n7 + n;
        }

        public String toString() {
            return this.c.toString();
        }
    }

}

