/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package org.mockito.exceptions.base;

public class MockitoInitializationException
extends RuntimeException {
    private static final long c = 1L;

    public MockitoInitializationException(String string2) {
        super(string2);
    }

    public MockitoInitializationException(String string2, Throwable throwable) {
        super(string2, throwable);
    }
}

