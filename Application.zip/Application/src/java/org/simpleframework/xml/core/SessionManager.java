/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ThreadLocal
 *  org.simpleframework.xml.core.PersistenceException
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Session;

class SessionManager {
    private ThreadLocal<Reference> local = new ThreadLocal();

    private Session create(boolean bl) throws Exception {
        Reference reference = new Reference(bl);
        this.local.set((Object)reference);
        return reference.get();
    }

    public void close() throws Exception {
        Reference reference = (Reference)this.local.get();
        if (reference != null) {
            if (reference.clear() == 0) {
                this.local.remove();
            }
            return;
        }
        throw new PersistenceException("Session does not exist", new Object[0]);
    }

    public Session open() throws Exception {
        return this.open(true);
    }

    public Session open(boolean bl) throws Exception {
        Reference reference = (Reference)this.local.get();
        if (reference != null) {
            return reference.get();
        }
        return this.create(bl);
    }

    private static class Reference {
        private int count;
        private Session session;

        public Reference(boolean bl) {
            this.session = new Session(bl);
        }

        public int clear() {
            int n;
            this.count = n = -1 + this.count;
            return n;
        }

        public Session get() {
            int n = this.count;
            if (n >= 0) {
                this.count = n + 1;
            }
            return this.session;
        }
    }

}

