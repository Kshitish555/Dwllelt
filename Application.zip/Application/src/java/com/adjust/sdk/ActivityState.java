/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectInputStream$GetField
 *  java.io.ObjectOutputStream
 *  java.io.ObjectStreamField
 *  java.io.Serializable
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Cloneable
 *  java.lang.Double
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Calendar
 *  java.util.LinkedList
 */
package com.adjust.sdk;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.Util;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamField;
import java.io.Serializable;
import java.util.Calendar;
import java.util.LinkedList;

public class ActivityState
implements Serializable,
Cloneable {
    private static final int ORDER_ID_MAXCOUNT = 10;
    private static final ObjectStreamField[] serialPersistentFields;
    private static final long serialVersionUID = 9039439291143138148L;
    protected String adid = null;
    protected boolean askingAttribution = false;
    protected long clickTime = 0L;
    protected boolean enabled = true;
    protected int eventCount = 0;
    protected long installBegin = 0L;
    protected String installReferrer = null;
    protected boolean isGdprForgotten = false;
    protected long lastActivity = -1L;
    protected long lastInterval = -1L;
    private transient ILogger logger = AdjustFactory.getLogger();
    protected LinkedList<String> orderIds = null;
    protected String pushToken = null;
    protected int sessionCount = 0;
    protected long sessionLength = -1L;
    protected int subsessionCount = -1;
    protected long timeSpent = -1L;
    protected boolean updatePackages = false;
    protected String uuid = Util.createUuid();

    static {
        ObjectStreamField[] arrobjectStreamField = new ObjectStreamField[]{new ObjectStreamField("uuid", String.class), new ObjectStreamField("enabled", Boolean.TYPE), new ObjectStreamField("isGdprForgotten", Boolean.TYPE), new ObjectStreamField("askingAttribution", Boolean.TYPE), new ObjectStreamField("eventCount", Integer.TYPE), new ObjectStreamField("sessionCount", Integer.TYPE), new ObjectStreamField("subsessionCount", Integer.TYPE), new ObjectStreamField("sessionLength", Long.TYPE), new ObjectStreamField("timeSpent", Long.TYPE), new ObjectStreamField("lastActivity", Long.TYPE), new ObjectStreamField("lastInterval", Long.TYPE), new ObjectStreamField("updatePackages", Boolean.TYPE), new ObjectStreamField("orderIds", LinkedList.class), new ObjectStreamField("pushToken", String.class), new ObjectStreamField("adid", String.class), new ObjectStreamField("clickTime", Long.TYPE), new ObjectStreamField("installBegin", Long.TYPE), new ObjectStreamField("installReferrer", String.class)};
        serialPersistentFields = arrobjectStreamField;
    }

    protected ActivityState() {
    }

    private void readObject(ObjectInputStream objectInputStream) throws IOException, ClassNotFoundException {
        ObjectInputStream.GetField getField = objectInputStream.readFields();
        this.eventCount = Util.readIntField(getField, "eventCount", 0);
        this.sessionCount = Util.readIntField(getField, "sessionCount", 0);
        this.subsessionCount = Util.readIntField(getField, "subsessionCount", -1);
        this.sessionLength = Util.readLongField(getField, "sessionLength", -1L);
        this.timeSpent = Util.readLongField(getField, "timeSpent", -1L);
        this.lastActivity = Util.readLongField(getField, "lastActivity", -1L);
        this.lastInterval = Util.readLongField(getField, "lastInterval", -1L);
        this.uuid = Util.readStringField(getField, "uuid", null);
        this.enabled = Util.readBooleanField(getField, "enabled", true);
        this.isGdprForgotten = Util.readBooleanField(getField, "isGdprForgotten", false);
        this.askingAttribution = Util.readBooleanField(getField, "askingAttribution", false);
        this.updatePackages = Util.readBooleanField(getField, "updatePackages", false);
        this.orderIds = Util.readObjectField(getField, "orderIds", null);
        this.pushToken = Util.readStringField(getField, "pushToken", null);
        this.adid = Util.readStringField(getField, "adid", null);
        this.clickTime = Util.readLongField(getField, "clickTime", -1L);
        this.installBegin = Util.readLongField(getField, "installBegin", -1L);
        this.installReferrer = Util.readStringField(getField, "installReferrer", null);
        if (this.uuid == null) {
            this.uuid = Util.createUuid();
        }
    }

    private static String stamp(long l2) {
        Calendar.getInstance().setTimeInMillis(l2);
        Object[] arrobject = new Object[]{11, 12, 13};
        return Util.formatString("%02d:%02d:%02d", arrobject);
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
    }

    protected void addOrderId(String string) {
        if (this.orderIds == null) {
            this.orderIds = new LinkedList();
        }
        if (this.orderIds.size() >= 10) {
            this.orderIds.removeLast();
        }
        this.orderIds.addFirst((Object)string);
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (ActivityState.class != object.getClass()) {
            return false;
        }
        ActivityState activityState = (ActivityState)object;
        if (!Util.equalString(this.uuid, activityState.uuid)) {
            return false;
        }
        if (!Util.equalBoolean(this.enabled, activityState.enabled)) {
            return false;
        }
        if (!Util.equalBoolean(this.isGdprForgotten, activityState.isGdprForgotten)) {
            return false;
        }
        if (!Util.equalBoolean(this.askingAttribution, activityState.askingAttribution)) {
            return false;
        }
        if (!Util.equalInt(this.eventCount, activityState.eventCount)) {
            return false;
        }
        if (!Util.equalInt(this.sessionCount, activityState.sessionCount)) {
            return false;
        }
        if (!Util.equalInt(this.subsessionCount, activityState.subsessionCount)) {
            return false;
        }
        if (!Util.equalLong(this.sessionLength, activityState.sessionLength)) {
            return false;
        }
        if (!Util.equalLong(this.timeSpent, activityState.timeSpent)) {
            return false;
        }
        if (!Util.equalLong(this.lastInterval, activityState.lastInterval)) {
            return false;
        }
        if (!Util.equalBoolean(this.updatePackages, activityState.updatePackages)) {
            return false;
        }
        if (!Util.equalObject(this.orderIds, activityState.orderIds)) {
            return false;
        }
        if (!Util.equalString(this.pushToken, activityState.pushToken)) {
            return false;
        }
        if (!Util.equalString(this.adid, activityState.adid)) {
            return false;
        }
        if (!Util.equalLong(this.clickTime, activityState.clickTime)) {
            return false;
        }
        if (!Util.equalLong(this.installBegin, activityState.installBegin)) {
            return false;
        }
        return Util.equalString(this.installReferrer, activityState.installReferrer);
    }

    protected boolean findOrderId(String string) {
        LinkedList<String> linkedList = this.orderIds;
        if (linkedList == null) {
            return false;
        }
        return linkedList.contains((Object)string);
    }

    public int hashCode() {
        return 37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (37 * (629 + Util.hashString(this.uuid)) + Util.hashBoolean(this.enabled)) + Util.hashBoolean(this.isGdprForgotten)) + Util.hashBoolean(this.askingAttribution)) + this.eventCount) + this.sessionCount) + this.subsessionCount) + Util.hashLong(this.sessionLength)) + Util.hashLong(this.timeSpent)) + Util.hashLong(this.lastInterval)) + Util.hashBoolean(this.updatePackages)) + Util.hashObject(this.orderIds)) + Util.hashString(this.pushToken)) + Util.hashString(this.adid)) + Util.hashLong(this.clickTime)) + Util.hashLong(this.installBegin)) + Util.hashString(this.installReferrer);
    }

    protected void resetSessionAttributes(long l2) {
        this.subsessionCount = 1;
        this.sessionLength = 0L;
        this.timeSpent = 0L;
        this.lastActivity = l2;
        this.lastInterval = -1L;
    }

    public String toString() {
        Object[] arrobject = new Object[7];
        arrobject[0] = this.eventCount;
        arrobject[1] = this.sessionCount;
        arrobject[2] = this.subsessionCount;
        double d2 = this.sessionLength;
        Double.isNaN((double)d2);
        arrobject[3] = d2 / 1000.0;
        double d3 = this.timeSpent;
        Double.isNaN((double)d3);
        arrobject[4] = d3 / 1000.0;
        arrobject[5] = ActivityState.stamp(this.lastActivity);
        arrobject[6] = this.uuid;
        return Util.formatString("ec:%d sc:%d ssc:%d sl:%.1f ts:%.1f la:%s uuid:%s", arrobject);
    }
}

