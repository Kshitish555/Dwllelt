/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.osmdroid.api.IGeoPoint
 */
package org.osmdroid.api;

import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IMapController;
import org.osmdroid.api.IProjection;

public interface IMapView {
    public IMapController getController();

    public int getLatitudeSpan();

    public int getLongitudeSpan();

    public IGeoPoint getMapCenter();

    public int getMaxZoomLevel();

    public IProjection getProjection();

    public int getZoomLevel();

    public void setBackgroundColor(int var1);
}

