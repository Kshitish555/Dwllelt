/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 */
package h.a.a.s0;

import h.a.a.s0.i;
import h.a.a.s0.j;
import h.a.a.s0.k;
import h.a.a.s0.m;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class g {
    List<Map.Entry<String, Object>> a;
    CharSequence b;

    public g(int n2) {
        this.a = new ArrayList(n2);
    }

    public g(List<Map.Entry<String, Object>> list) {
        this.a = list;
    }

    void a(Map<m<i>, CharSequence> map, boolean bl, int n2, int n3, StringBuilder stringBuilder) {
        char c2;
        int n4;
        boolean bl2 = n3 > 0;
        int n5 = this.a.size();
        if (bl) {
            n4 = n5;
        } else {
            int n6 = 0;
            for (int i2 = 0; i2 < n5; ++i2) {
                if (((Map.Entry)this.a.get(i2)).getValue() == null) continue;
                ++n6;
            }
            n4 = n6;
        }
        if (this.b == null && n4 == 0) {
            stringBuilder.append("{}");
            return;
        }
        String string = bl2 ? "{\n" : "{";
        stringBuilder.append(string);
        if (this.b != null) {
            if (bl2) {
                k.a(n2 + 1, n3, stringBuilder);
            }
            stringBuilder.append('\"');
            stringBuilder.append("__ID");
            String string2 = bl2 ? "\": " : "\":";
            stringBuilder.append(string2);
            CharSequence charSequence = this.b;
            int n7 = n2 + 1;
            c2 = '\"';
            j.a((Object)charSequence, map, bl, n7, n3, stringBuilder);
            if (n4 > 0) {
                stringBuilder.append(',');
            }
            if (bl2) {
                stringBuilder.append('\n');
            }
        } else {
            c2 = '\"';
        }
        int n8 = 0;
        int n9 = 0;
        while (n8 < n5) {
            block20 : {
                int n10;
                block19 : {
                    Map.Entry entry;
                    Object object;
                    block18 : {
                        entry = (Map.Entry)this.a.get(n8);
                        object = entry.getValue();
                        if (object != null || bl) break block18;
                        n10 = n8;
                        break block19;
                    }
                    String string3 = (String)entry.getKey();
                    if (string3 == null) break block20;
                    if (bl2) {
                        k.a(n2 + 1, n3, stringBuilder);
                    }
                    stringBuilder.append(c2);
                    k.a(string3, stringBuilder);
                    String string4 = bl2 ? "\": " : "\":";
                    stringBuilder.append(string4);
                    int n11 = n2 + 1;
                    n10 = n8;
                    j.a(object, map, bl, n11, n3, stringBuilder);
                    int n12 = n9 + 1;
                    if (n12 < n4) {
                        stringBuilder.append(',');
                    }
                    if (bl2) {
                        stringBuilder.append('\n');
                    }
                    n9 = n12;
                }
                n8 = n10 + 1;
                continue;
            }
            throw new IllegalArgumentException("Cannot serialize JSON object with null key");
        }
        if (bl2) {
            k.a(n2, n3, stringBuilder);
        }
        stringBuilder.append('}');
    }
}

