/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package h.b;

public final class b
extends Enum<b> {
    public static final /* enum */ b c;
    public static final /* enum */ b d;
    public static final /* enum */ b f;
    public static final /* enum */ b h;
    public static final /* enum */ b o;
    private static final /* synthetic */ b[] s;

    static {
        b b2;
        c = new b();
        d = new b();
        f = new b();
        h = new b();
        o = b2 = new b();
        b[] arrb = new b[]{c, d, f, h, b2};
        s = arrb;
    }

    public static b valueOf(String string) {
        return (b)Enum.valueOf(b.class, (String)string);
    }

    public static b[] values() {
        return (b[])s.clone();
    }
}

