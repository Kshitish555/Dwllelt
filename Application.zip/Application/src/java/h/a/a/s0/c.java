/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.GenericArrayType
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.lang.reflect.TypeVariable
 *  java.util.Collection
 *  java.util.Map
 */
package h.a.a.s0;

import h.a.a.s0.a;
import h.a.a.s0.k;
import h.a.a.s0.n;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.Collection;
import java.util.Map;

class c {
    final Field a;
    private final Type b;
    private final boolean c;
    private final boolean d;
    private final int e;
    private Constructor<?> f;
    private Constructor<?> g;

    public c(Field field, Type type, a a2) {
        boolean bl;
        this.a = field;
        this.b = type;
        this.d = bl = type instanceof TypeVariable;
        boolean bl2 = bl || c.a(type);
        this.c = bl2;
        boolean bl3 = type instanceof GenericArrayType || type instanceof Class && ((Class)type).isArray();
        if (!bl3 && !this.d) {
            Class<?> class_ = k.a(type);
            this.e = class_ == Integer.TYPE ? 1 : (class_ == Long.TYPE ? 2 : (class_ == Short.TYPE ? 3 : (class_ == Double.TYPE ? 4 : (class_ == Float.TYPE ? 5 : (class_ == Boolean.TYPE ? 6 : (class_ == Byte.TYPE ? 7 : (class_ == Character.TYPE ? 8 : 0)))))));
            if (!k.a(class_)) {
                if (Collection.class.isAssignableFrom(class_) || Map.class.isAssignableFrom(class_)) {
                    this.f = a2.b(class_);
                }
                if (this.f == null) {
                    this.g = a2.c(class_);
                    return;
                }
            }
        } else {
            this.e = 0;
        }
    }

    private static boolean a(Type type) {
        if (!(type instanceof TypeVariable)) {
            if (type instanceof GenericArrayType) {
                return true;
            }
            if (type instanceof ParameterizedType) {
                Type[] arrtype = ((ParameterizedType)type).getActualTypeArguments();
                int n2 = arrtype.length;
                for (int i2 = 0; i2 < n2; ++i2) {
                    if (!c.a(arrtype[i2])) continue;
                    return true;
                }
            }
            return false;
        }
        return true;
    }

    public Constructor<?> a(Type type, a a2) {
        if (!this.d) {
            return this.f;
        }
        Class<?> class_ = k.a(type);
        if (!Collection.class.isAssignableFrom(class_) && !Map.class.isAssignableFrom(class_)) {
            return null;
        }
        return a2.b(class_);
    }

    public Type a(n n2) {
        if (!this.c) {
            return this.b;
        }
        return n2.a(this.b);
    }

    void a(Object object, Object object2) {
        void var3_13;
        if (this.e != 0 && object2 == null) {
            throw new IllegalArgumentException("Tried to set primitive-typed field to null value");
        }
        try {
            switch (this.e) {
                default: {
                    break;
                }
                case 8: {
                    if (object2 instanceof Character) {
                        this.a.setChar(object, ((Character)object2).charValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Character; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 7: {
                    if (object2 instanceof Byte) {
                        this.a.setByte(object, ((Byte)object2).byteValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Byte; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 6: {
                    if (object2 instanceof Boolean) {
                        this.a.setBoolean(object, ((Boolean)object2).booleanValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Boolean; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 5: {
                    if (object2 instanceof Float) {
                        this.a.setFloat(object, ((Float)object2).floatValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Float; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 4: {
                    if (object2 instanceof Double) {
                        this.a.setDouble(object, ((Double)object2).doubleValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Double; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 3: {
                    if (object2 instanceof Short) {
                        this.a.setShort(object, ((Short)object2).shortValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Short; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 2: {
                    if (object2 instanceof Long) {
                        this.a.setLong(object, ((Long)object2).longValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Long; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 1: {
                    if (object2 instanceof Integer) {
                        this.a.setInt(object, ((Integer)object2).intValue());
                        return;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected value of type Integer; got ");
                    stringBuilder.append(object2.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                case 0: {
                    this.a.set(object, object2);
                    return;
                }
            }
            throw new IllegalArgumentException();
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (IllegalArgumentException illegalArgumentException) {
            // empty catch block
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not set field ");
        stringBuilder.append(this.a.getDeclaringClass().getName());
        stringBuilder.append(".");
        stringBuilder.append(this.a.getName());
        throw new IllegalArgumentException(stringBuilder.toString(), (Throwable)var3_13);
    }

    public Constructor<?> b(Type type, a a2) {
        if (!this.d) {
            return this.g;
        }
        return a2.c(k.a(type));
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((Object)this.b);
        stringBuilder.append(" ");
        stringBuilder.append(this.a.getDeclaringClass().getName());
        stringBuilder.append(".");
        stringBuilder.append(this.a.getDeclaringClass().getName());
        return stringBuilder.toString();
    }
}

