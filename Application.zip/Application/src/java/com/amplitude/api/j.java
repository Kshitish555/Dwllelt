/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Set
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amplitude.api;

import com.amplitude.api.d;
import com.amplitude.api.n;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class j {
    public static final String c = "com.amplitude.api.Identify";
    protected JSONObject a = new JSONObject();
    protected Set<String> b = new HashSet();

    private JSONArray a(double[] arrd) {
        JSONArray jSONArray = new JSONArray();
        for (double d2 : arrd) {
            try {
                jSONArray.put(d2);
            }
            catch (JSONException jSONException) {
                d d3 = d.a();
                Object[] arrobject = new Object[]{d2, jSONException.toString()};
                d3.b(c, String.format((String)"Error converting double %d to JSON: %s", (Object[])arrobject));
            }
        }
        return jSONArray;
    }

    private JSONArray a(float[] arrf) {
        JSONArray jSONArray = new JSONArray();
        for (float f2 : arrf) {
            double d2 = f2;
            try {
                jSONArray.put(d2);
            }
            catch (JSONException jSONException) {
                d d3 = d.a();
                Object[] arrobject = new Object[]{Float.valueOf((float)f2), jSONException.toString()};
                d3.b(c, String.format((String)"Error converting float %f to JSON: %s", (Object[])arrobject));
            }
        }
        return jSONArray;
    }

    private JSONArray a(int[] arrn) {
        JSONArray jSONArray = new JSONArray();
        int n2 = arrn.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            jSONArray.put(arrn[i2]);
        }
        return jSONArray;
    }

    private JSONArray a(long[] arrl) {
        JSONArray jSONArray = new JSONArray();
        int n2 = arrl.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            jSONArray.put(arrl[i2]);
        }
        return jSONArray;
    }

    private JSONArray a(String[] arrstring) {
        JSONArray jSONArray = new JSONArray();
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            jSONArray.put((Object)arrstring[i2]);
        }
        return jSONArray;
    }

    private JSONArray a(boolean[] arrbl) {
        JSONArray jSONArray = new JSONArray();
        int n2 = arrbl.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            jSONArray.put(arrbl[i2]);
        }
        return jSONArray;
    }

    private void a(String string, String string2, Object object) {
        if (n.a(string2)) {
            d.a().e(c, String.format((String)"Attempting to perform operation %s with a null or empty string property, ignoring", (Object[])new Object[]{string}));
            return;
        }
        if (object == null) {
            d.a().e(c, String.format((String)"Attempting to perform operation %s with null value for property %s, ignoring", (Object[])new Object[]{string, string2}));
            return;
        }
        if (this.a.has("$clearAll")) {
            d.a().e(c, String.format((String)"This Identify already contains a $clearAll operation, ignoring operation %s", (Object[])new Object[]{string}));
            return;
        }
        if (this.b.contains((Object)string2)) {
            d.a().e(c, String.format((String)"Already used property %s in previous operation, ignoring operation %s", (Object[])new Object[]{string2, string}));
            return;
        }
        try {
            if (!this.a.has(string)) {
                this.a.put(string, (Object)new JSONObject());
            }
            this.a.getJSONObject(string).put(string2, object);
            this.b.add((Object)string2);
            return;
        }
        catch (JSONException jSONException) {
            d.a().b(c, jSONException.toString());
            return;
        }
    }

    public j a() {
        if (this.a.length() > 0) {
            if (!this.b.contains((Object)"$clearAll")) {
                d.a().e(c, String.format((String)"Need to send $clearAll on its own Identify object without any other operations, ignoring $clearAll", (Object[])new Object[0]));
            }
            return this;
        }
        try {
            this.a.put("$clearAll", (Object)"-");
            return this;
        }
        catch (JSONException jSONException) {
            d.a().b(c, jSONException.toString());
            return this;
        }
    }

    public j a(String string) {
        this.a("$unset", string, "-");
        return this;
    }

    public j a(String string, double d2) {
        this.a("$add", string, d2);
        return this;
    }

    public j a(String string, float f2) {
        this.a("$add", string, (Object)Float.valueOf((float)f2));
        return this;
    }

    public j a(String string, int n2) {
        this.a("$add", string, n2);
        return this;
    }

    public j a(String string, long l2) {
        this.a("$add", string, l2);
        return this;
    }

    public j a(String string, Object object) {
        d.a().e(c, "This version of set is deprecated. Please use one with a different signature.");
        return this;
    }

    public j a(String string, String string2) {
        this.a("$add", string, string2);
        return this;
    }

    public j a(String string, JSONArray jSONArray) {
        this.a("$append", string, (Object)jSONArray);
        return this;
    }

    public j a(String string, JSONObject jSONObject) {
        this.a("$add", string, (Object)jSONObject);
        return this;
    }

    public j a(String string, boolean bl) {
        this.a("$append", string, bl);
        return this;
    }

    public j a(String string, double[] arrd) {
        this.a("$append", string, (Object)this.a(arrd));
        return this;
    }

    public j a(String string, float[] arrf) {
        this.a("$append", string, (Object)this.a(arrf));
        return this;
    }

    public j a(String string, int[] arrn) {
        this.a("$append", string, (Object)this.a(arrn));
        return this;
    }

    public j a(String string, long[] arrl) {
        this.a("$append", string, (Object)this.a(arrl));
        return this;
    }

    public j a(String string, String[] arrstring) {
        this.a("$append", string, (Object)this.a(arrstring));
        return this;
    }

    public j a(String string, boolean[] arrbl) {
        this.a("$append", string, (Object)this.a(arrbl));
        return this;
    }

    public j b(String string, double d2) {
        this.a("$append", string, d2);
        return this;
    }

    public j b(String string, float f2) {
        this.a("$append", string, (Object)Float.valueOf((float)f2));
        return this;
    }

    public j b(String string, int n2) {
        this.a("$append", string, n2);
        return this;
    }

    public j b(String string, long l2) {
        this.a("$append", string, l2);
        return this;
    }

    public j b(String string, Object object) {
        d.a().e(c, "This version of setOnce is deprecated. Please use one with a different signature.");
        return this;
    }

    public j b(String string, String string2) {
        this.a("$append", string, string2);
        return this;
    }

    public j b(String string, JSONArray jSONArray) {
        this.a("$prepend", string, (Object)jSONArray);
        return this;
    }

    public j b(String string, JSONObject jSONObject) {
        this.a("$append", string, (Object)jSONObject);
        return this;
    }

    public j b(String string, boolean bl) {
        this.a("$prepend", string, bl);
        return this;
    }

    public j b(String string, double[] arrd) {
        this.a("$prepend", string, (Object)this.a(arrd));
        return this;
    }

    public j b(String string, float[] arrf) {
        this.a("$prepend", string, (Object)this.a(arrf));
        return this;
    }

    public j b(String string, int[] arrn) {
        this.a("$prepend", string, (Object)this.a(arrn));
        return this;
    }

    public j b(String string, long[] arrl) {
        this.a("$prepend", string, (Object)this.a(arrl));
        return this;
    }

    public j b(String string, String[] arrstring) {
        this.a("$prepend", string, (Object)this.a(arrstring));
        return this;
    }

    public j b(String string, boolean[] arrbl) {
        this.a("$prepend", string, (Object)this.a(arrbl));
        return this;
    }

    public JSONObject b() {
        try {
            JSONObject jSONObject = new JSONObject(this.a.toString());
            return jSONObject;
        }
        catch (JSONException jSONException) {
            d.a().b(c, jSONException.toString());
            return new JSONObject();
        }
    }

    public j c(String string, double d2) {
        this.a("$prepend", string, d2);
        return this;
    }

    public j c(String string, float f2) {
        this.a("$prepend", string, (Object)Float.valueOf((float)f2));
        return this;
    }

    public j c(String string, int n2) {
        this.a("$prepend", string, n2);
        return this;
    }

    public j c(String string, long l2) {
        this.a("$prepend", string, l2);
        return this;
    }

    j c(String string, Object object) {
        this.a("$set", string, object);
        return this;
    }

    public j c(String string, String string2) {
        this.a("$prepend", string, string2);
        return this;
    }

    public j c(String string, JSONArray jSONArray) {
        this.a("$set", string, (Object)jSONArray);
        return this;
    }

    public j c(String string, JSONObject jSONObject) {
        this.a("$prepend", string, (Object)jSONObject);
        return this;
    }

    public j c(String string, boolean bl) {
        this.a("$set", string, bl);
        return this;
    }

    public j c(String string, double[] arrd) {
        this.a("$set", string, (Object)this.a(arrd));
        return this;
    }

    public j c(String string, float[] arrf) {
        this.a("$set", string, (Object)this.a(arrf));
        return this;
    }

    public j c(String string, int[] arrn) {
        this.a("$set", string, (Object)this.a(arrn));
        return this;
    }

    public j c(String string, long[] arrl) {
        this.a("$set", string, (Object)this.a(arrl));
        return this;
    }

    public j c(String string, String[] arrstring) {
        this.a("$set", string, (Object)this.a(arrstring));
        return this;
    }

    public j c(String string, boolean[] arrbl) {
        this.a("$set", string, (Object)this.a(arrbl));
        return this;
    }

    public j d(String string, double d2) {
        this.a("$set", string, d2);
        return this;
    }

    public j d(String string, float f2) {
        this.a("$set", string, (Object)Float.valueOf((float)f2));
        return this;
    }

    public j d(String string, int n2) {
        this.a("$set", string, n2);
        return this;
    }

    public j d(String string, long l2) {
        this.a("$set", string, l2);
        return this;
    }

    public j d(String string, String string2) {
        this.a("$set", string, string2);
        return this;
    }

    public j d(String string, JSONArray jSONArray) {
        this.a("$setOnce", string, (Object)jSONArray);
        return this;
    }

    public j d(String string, JSONObject jSONObject) {
        this.a("$set", string, (Object)jSONObject);
        return this;
    }

    public j d(String string, boolean bl) {
        this.a("$setOnce", string, bl);
        return this;
    }

    public j d(String string, double[] arrd) {
        this.a("$setOnce", string, (Object)this.a(arrd));
        return this;
    }

    public j d(String string, float[] arrf) {
        this.a("$setOnce", string, (Object)this.a(arrf));
        return this;
    }

    public j d(String string, int[] arrn) {
        this.a("$setOnce", string, (Object)this.a(arrn));
        return this;
    }

    public j d(String string, long[] arrl) {
        this.a("$setOnce", string, (Object)this.a(arrl));
        return this;
    }

    public j d(String string, String[] arrstring) {
        this.a("$setOnce", string, (Object)this.a(arrstring));
        return this;
    }

    public j d(String string, boolean[] arrbl) {
        this.a("$setOnce", string, (Object)this.a(arrbl));
        return this;
    }

    public j e(String string, double d2) {
        this.a("$setOnce", string, d2);
        return this;
    }

    public j e(String string, float f2) {
        this.a("$setOnce", string, (Object)Float.valueOf((float)f2));
        return this;
    }

    public j e(String string, int n2) {
        this.a("$setOnce", string, n2);
        return this;
    }

    public j e(String string, long l2) {
        this.a("$setOnce", string, l2);
        return this;
    }

    public j e(String string, String string2) {
        this.a("$setOnce", string, string2);
        return this;
    }

    public j e(String string, JSONObject jSONObject) {
        this.a("$setOnce", string, (Object)jSONObject);
        return this;
    }
}

