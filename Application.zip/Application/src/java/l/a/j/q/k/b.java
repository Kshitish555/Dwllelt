/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Void
 *  java.lang.reflect.Type
 *  l.a.h.k.b
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import java.lang.reflect.Type;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.k.c;
import l.a.j.q.k.e;
import l.a.j.q.k.f;
import l.a.j.q.k.h;
import l.a.j.q.k.j;
import l.a.k.a.r;

public final class b
extends Enum<b>
implements l.a.j.q.e {
    public static final /* enum */ b d;
    public static final /* enum */ b f;
    public static final /* enum */ b h;
    public static final /* enum */ b o;
    public static final /* enum */ b s;
    public static final /* enum */ b t;
    private static final /* synthetic */ b[] w;
    private final l.a.j.q.e c;

    static {
        b b2;
        d = new b(f.f);
        f = new b(h.d);
        h = new b(e.d);
        o = new b(c.d);
        s = new b(e.d.c);
        t = b2 = new b(j.d);
        b[] arrb = new b[]{d, f, h, o, s, b2};
        w = arrb;
    }

    private b(l.a.j.q.e e2) {
        this.c = e2;
    }

    public static l.a.j.q.e a(l.a.h.k.b b2) {
        if (b2.isPrimitive()) {
            if (b2.a((Type)Long.TYPE)) {
                return f;
            }
            if (b2.a((Type)Double.TYPE)) {
                return o;
            }
            if (b2.a((Type)Float.TYPE)) {
                return h;
            }
            if (b2.a((Type)Void.TYPE)) {
                return s;
            }
            return d;
        }
        return t;
    }

    public static b valueOf(String string) {
        return (b)Enum.valueOf(b.class, (String)string);
    }

    public static b[] values() {
        return (b[])w.clone();
    }

    public e.c a(r r2, e.d d2) {
        return this.c.a(r2, d2);
    }

    public boolean x() {
        return this.c.x();
    }
}

