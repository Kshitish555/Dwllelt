/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  android.graphics.Point
 *  android.graphics.PointF
 *  android.graphics.Rect
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  microsoft.mappoint.TileSystem
 */
package org.osmdroid.views.util;

import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import java.util.List;
import microsoft.mappoint.TileSystem;
import org.osmdroid.util.BoundingBoxE6;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;

public class PathProjection {
    public static Path toPixels(MapView.Projection projection, List<? extends GeoPoint> list, Path path) {
        return PathProjection.toPixels(projection, list, path, true);
    }

    public static Path toPixels(MapView.Projection projection, List<? extends GeoPoint> list, Path path, boolean bl) throws IllegalArgumentException {
        IllegalArgumentException illegalArgumentException;
        if (list.size() >= 2) {
            if (path == null) {
                path = new Path();
            }
            path.incReserve(list.size());
            boolean bl2 = true;
            for (GeoPoint geoPoint : list) {
                double d2 = geoPoint.getLatitudeE6();
                Double.isNaN((double)d2);
                double d3 = d2 / 1000000.0;
                double d4 = geoPoint.getLongitudeE6();
                Double.isNaN((double)d4);
                Point point = TileSystem.LatLongToPixelXY((double)d3, (double)(d4 / 1000000.0), (int)projection.getZoomLevel(), null);
                TileSystem.PixelXYToTileXY((int)point.x, (int)point.y, (Point)point);
                Point point2 = TileSystem.TileXYToPixelXY((int)point.x, (int)point.y, null);
                Point point3 = TileSystem.TileXYToPixelXY((int)(point.x + TileSystem.getTileSize()), (int)(point.y + TileSystem.getTileSize()), null);
                GeoPoint geoPoint2 = TileSystem.PixelXYToLatLong((int)point2.x, (int)point2.y, (int)projection.getZoomLevel(), null);
                GeoPoint geoPoint3 = TileSystem.PixelXYToLatLong((int)point3.x, (int)point3.y, (int)projection.getZoomLevel(), null);
                BoundingBoxE6 boundingBoxE6 = new BoundingBoxE6(geoPoint2.getLatitudeE6(), geoPoint2.getLongitudeE6(), geoPoint3.getLatitudeE6(), geoPoint3.getLongitudeE6());
                PointF pointF = bl && projection.getZoomLevel() < 7 ? boundingBoxE6.getRelativePositionOfGeoPointInBoundingBoxWithExactGudermannInterpolation(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6(), null) : boundingBoxE6.getRelativePositionOfGeoPointInBoundingBoxWithLinearInterpolation(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6(), null);
                Rect rect = projection.getScreenRect();
                Point point4 = TileSystem.PixelXYToTileXY((int)rect.centerX(), (int)rect.centerY(), null);
                Point point5 = TileSystem.TileXYToPixelXY((int)point4.x, (int)point4.y, null);
                int n2 = point4.x - point.x;
                int n3 = point4.y - point.y;
                int n4 = point5.x - n2 * TileSystem.getTileSize();
                int n5 = point5.y - n3 * TileSystem.getTileSize();
                int n6 = n4 + (int)(pointF.x * (float)TileSystem.getTileSize());
                int n7 = n5 + (int)(pointF.y * (float)TileSystem.getTileSize());
                if (bl2) {
                    path.moveTo((float)n6, (float)n7);
                } else {
                    path.lineTo((float)n6, (float)n7);
                }
                bl2 = false;
            }
            return path;
        }
        illegalArgumentException = new IllegalArgumentException("List of GeoPoints needs to be at least 2.");
        throw illegalArgumentException;
    }
}

