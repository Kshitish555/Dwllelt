/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  l.a.h.k.c
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.k.a.r
 */
package l.a.j.q;

import l.a.h.k.c;
import l.a.j.e;
import l.a.j.q.e;
import l.a.k.a.r;

public class h
implements e {
    private final c c;

    protected h(c c2) {
        this.c = c2;
    }

    public static e c(c c2) {
        if (!(c2.isArray() || c2.isPrimitive() || c2.isAbstract())) {
            return new h(c2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((Object)c2);
        stringBuilder.append(" is not instantiable");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public e.c a(r r2, e.d d2) {
        r2.a(187, this.c.d());
        return new e.c(1, 1);
    }

    protected boolean b(Object object) {
        return object instanceof h;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof h)) {
            return false;
        }
        h h2 = (h)object;
        if (!h2.b(this)) {
            return false;
        }
        c c2 = this.c;
        c c3 = h2.c;
        return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
    }

    public int hashCode() {
        c c2 = this.c;
        int n2 = c2 == null ? 43 : c2.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }
}

