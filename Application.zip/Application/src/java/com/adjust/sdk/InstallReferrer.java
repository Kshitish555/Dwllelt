/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.lang.reflect.Proxy
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.InstallReferrerReadListener;
import com.adjust.sdk.Reflection;
import com.adjust.sdk.Util;
import com.adjust.sdk.scheduler.TimerOnce;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicBoolean;

public class InstallReferrer
implements InvocationHandler {
    private static final String PACKAGE_BASE_NAME = "com.android.installreferrer.";
    private static final int STATUS_DEVELOPER_ERROR = 3;
    private static final int STATUS_FEATURE_NOT_SUPPORTED = 2;
    private static final int STATUS_OK = 0;
    private static final int STATUS_SERVICE_DISCONNECTED = -1;
    private static final int STATUS_SERVICE_UNAVAILABLE = 1;
    private Context context;
    private final AtomicBoolean hasInstallReferrerBeenRead;
    private ILogger logger;
    private Object playInstallReferrer;
    private final InstallReferrerReadListener referrerCallback;
    private Object referrerClient;
    private int retries;
    private TimerOnce retryTimer;
    private int retryWaitTime = 3000;

    public InstallReferrer(Context context, InstallReferrerReadListener installReferrerReadListener) {
        ILogger iLogger;
        this.logger = iLogger = AdjustFactory.getLogger();
        this.playInstallReferrer = this.createInstallReferrer(context, installReferrerReadListener, iLogger);
        this.context = context;
        this.hasInstallReferrerBeenRead = new AtomicBoolean(false);
        this.retries = 0;
        this.retryTimer = new TimerOnce(new Runnable(){

            public void run() {
                InstallReferrer.this.startConnection();
            }
        }, "InstallReferrer");
        this.referrerCallback = installReferrerReadListener;
    }

    private void closeReferrerClient() {
        Object object = this.referrerClient;
        if (object == null) {
            return;
        }
        try {
            Reflection.invokeInstanceMethod(object, "endConnection", null, new Object[0]);
            this.logger.debug("Install Referrer API connection closed", new Object[0]);
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("closeReferrerClient error (%s) thrown by (%s)", arrobject);
        }
        this.referrerClient = null;
    }

    private Object createInstallReferrer(Context context, InstallReferrerReadListener installReferrerReadListener, ILogger iLogger) {
        return Reflection.createInstance("com.adjust.sdk.play.InstallReferrer", new Class[]{Context.class, InstallReferrerReadListener.class, ILogger.class}, new Object[]{context, installReferrerReadListener, iLogger});
    }

    private Object createInstallReferrerClient(Context context) {
        try {
            Object object = Reflection.invokeInstanceMethod(Reflection.invokeStaticMethod("com.android.installreferrer.api.InstallReferrerClient", "newBuilder", new Class[]{Context.class}, new Object[]{context}), "build", null, new Object[0]);
            return object;
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("createInstallReferrerClient error (%s) from (%s)", arrobject);
            return null;
        }
        catch (ClassNotFoundException classNotFoundException) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{classNotFoundException.getMessage(), classNotFoundException.getClass().getCanonicalName()};
            iLogger.warn("InstallReferrer not integrated in project (%s) thrown by (%s)", arrobject);
            return null;
        }
    }

    private Object createProxyInstallReferrerStateListener(Class class_) {
        try {
            Object object = Proxy.newProxyInstance((ClassLoader)class_.getClassLoader(), (Class[])new Class[]{class_}, (InvocationHandler)this);
            return object;
        }
        catch (NullPointerException throwable) {
            this.logger.error("Null argument passed to InstallReferrer proxy", new Object[0]);
        }
        catch (IllegalArgumentException throwable) {
            this.logger.error("InstallReferrer proxy violating parameter restrictions", new Object[0]);
        }
        return null;
    }

    private long getInstallBeginTimestampSeconds(Object object) {
        if (object == null) {
            return -1L;
        }
        try {
            long l2 = (Long)Reflection.invokeInstanceMethod(object, "getInstallBeginTimestampSeconds", null, new Object[0]);
            return l2;
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("getInstallBeginTimestampSeconds error (%s) thrown by (%s)", arrobject);
            return -1L;
        }
    }

    private Object getInstallReferrer() {
        Object object = this.referrerClient;
        if (object == null) {
            return null;
        }
        try {
            Object object2 = Reflection.invokeInstanceMethod(object, "getInstallReferrer", null, new Object[0]);
            return object2;
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("getInstallReferrer error (%s) thrown by (%s)", arrobject);
            return null;
        }
    }

    private Class getInstallReferrerStateListenerClass() {
        try {
            Class class_ = Class.forName((String)"com.android.installreferrer.api.InstallReferrerStateListener");
            return class_;
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("getInstallReferrerStateListenerClass error (%s) from (%s)", arrobject);
            return null;
        }
    }

    private long getReferrerClickTimestampSeconds(Object object) {
        if (object == null) {
            return -1L;
        }
        try {
            long l2 = (Long)Reflection.invokeInstanceMethod(object, "getReferrerClickTimestampSeconds", null, new Object[0]);
            return l2;
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("getReferrerClickTimestampSeconds error (%s) thrown by (%s)", arrobject);
            return -1L;
        }
    }

    private String getStringInstallReferrer(Object object) {
        if (object == null) {
            return null;
        }
        try {
            String string = (String)Reflection.invokeInstanceMethod(object, "getInstallReferrer", null, new Object[0]);
            return string;
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("getStringInstallReferrer error (%s) thrown by (%s)", arrobject);
            return null;
        }
    }

    private void onInstallReferrerSetupFinishedInt(int n2) {
        boolean bl;
        block9 : {
            block3 : {
                block8 : {
                    block4 : {
                        block5 : {
                            block6 : {
                                block7 : {
                                    bl = true;
                                    if (n2 == -1) break block3;
                                    if (n2 == 0) break block4;
                                    if (n2 == bl) break block5;
                                    if (n2 == 2) break block6;
                                    if (n2 == 3) break block7;
                                    ILogger iLogger = this.logger;
                                    Object[] arrobject = new Object[bl];
                                    arrobject[0] = n2;
                                    iLogger.debug("Unexpected response code of install referrer response: %d. Closing connection", arrobject);
                                    break block8;
                                }
                                this.logger.debug("Install Referrer API general errors caused by incorrect usage. Retrying...", new Object[0]);
                                break block9;
                            }
                            this.logger.debug("Install Referrer API not supported by the installed Play Store app. Closing connection", new Object[0]);
                            break block8;
                        }
                        this.logger.debug("Could not initiate connection to the Install Referrer service. Retrying...", new Object[0]);
                        break block9;
                    }
                    try {
                        Object object = this.getInstallReferrer();
                        String string = this.getStringInstallReferrer(object);
                        long l2 = this.getReferrerClickTimestampSeconds(object);
                        long l3 = this.getInstallBeginTimestampSeconds(object);
                        ILogger iLogger = this.logger;
                        Object[] arrobject = new Object[3];
                        arrobject[0] = string;
                        arrobject[bl] = l2;
                        arrobject[2] = l3;
                        iLogger.debug("installReferrer: %s, clickTime: %d, installBeginTime: %d", arrobject);
                        this.logger.debug("Install Referrer read successfully. Closing connection", new Object[0]);
                        this.referrerCallback.onInstallReferrerRead(string, l2, l3);
                        this.hasInstallReferrerBeenRead.set(bl);
                    }
                    catch (Exception exception) {
                        ILogger iLogger = this.logger;
                        Object[] arrobject = new Object[bl];
                        arrobject[0] = exception.getMessage();
                        iLogger.warn("Couldn't get install referrer from client (%s). Retrying...", arrobject);
                    }
                }
                bl = false;
                break block9;
                break block9;
            }
            this.logger.debug("Play Store service is not connected now. Retrying...", new Object[0]);
        }
        if (bl) {
            this.retry();
            return;
        }
        this.closeReferrerClient();
    }

    private void retry() {
        int n2;
        if (this.hasInstallReferrerBeenRead.get()) {
            this.logger.debug("Install referrer has already been read", new Object[0]);
            this.closeReferrerClient();
            return;
        }
        if (1 + this.retries > 2) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{2};
            iLogger.debug("Limit number of retry of %d for install referrer surpassed", arrobject);
            return;
        }
        long l2 = this.retryTimer.getFireIn();
        if (l2 > 0L) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{l2};
            iLogger.debug("Already waiting to retry to read install referrer in %d milliseconds", arrobject);
            return;
        }
        this.retries = n2 = 1 + this.retries;
        ILogger iLogger = this.logger;
        Object[] arrobject = new Object[]{n2};
        iLogger.debug("Retry number %d to connect to install referrer API", arrobject);
        this.retryTimer.startIn(this.retryWaitTime);
    }

    private void startConnection(Class class_, Object object) {
        try {
            Reflection.invokeInstanceMethod(this.referrerClient, "startConnection", new Class[]{class_}, object);
            return;
        }
        catch (Exception exception) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{exception.getMessage(), exception.getClass().getCanonicalName()};
            iLogger.error("startConnection error (%s) thrown by (%s)", arrobject);
            return;
        }
        catch (InvocationTargetException invocationTargetException) {
            if (Util.hasRootCause((Exception)((Object)invocationTargetException))) {
                ILogger iLogger = this.logger;
                Object[] arrobject = new Object[]{Util.getRootCause((Exception)((Object)invocationTargetException))};
                iLogger.error("InstallReferrer encountered an InvocationTargetException %s", arrobject);
            }
            return;
        }
    }

    public Object invoke(Object object, Method method, Object[] arrobject) throws Throwable {
        if (method == null) {
            this.logger.error("InstallReferrer invoke method null", new Object[0]);
            return null;
        }
        String string = method.getName();
        if (string == null) {
            this.logger.error("InstallReferrer invoke method name null", new Object[0]);
            return null;
        }
        this.logger.debug("InstallReferrer invoke method name: %s", string);
        if (arrobject == null) {
            this.logger.warn("InstallReferrer invoke args null", new Object[0]);
            arrobject = new Object[]{};
        }
        int n2 = arrobject.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            Object object2 = arrobject[i2];
            this.logger.debug("InstallReferrer invoke arg: %s", object2);
        }
        if (string.equals((Object)"onInstallReferrerSetupFinished")) {
            if (arrobject.length != 1) {
                ILogger iLogger = this.logger;
                Object[] arrobject2 = new Object[]{arrobject.length};
                iLogger.error("InstallReferrer invoke onInstallReferrerSetupFinished args lenght not 1: %d", arrobject2);
                return null;
            }
            Object object3 = arrobject[0];
            if (!(object3 instanceof Integer)) {
                this.logger.error("InstallReferrer invoke onInstallReferrerSetupFinished arg not int", new Object[0]);
                return null;
            }
            Integer n3 = (Integer)object3;
            if (n3 == null) {
                this.logger.error("InstallReferrer invoke onInstallReferrerSetupFinished responseCode arg is null", new Object[0]);
                return null;
            }
            this.onInstallReferrerSetupFinishedInt(n3);
            return null;
        }
        if (string.equals((Object)"onInstallReferrerServiceDisconnected")) {
            this.logger.debug("Connection to install referrer service was lost. Retrying ...", new Object[0]);
            this.retry();
        }
        return null;
    }

    public void startConnection() {
        Object object;
        Object object2 = this.playInstallReferrer;
        if (object2 != null) {
            try {
                Reflection.invokeInstanceMethod(object2, "startConnection", null, new Object[0]);
                return;
            }
            catch (Exception exception) {
                ILogger iLogger = this.logger;
                Object[] arrobject = new Object[]{exception.getMessage()};
                iLogger.error("Call to Play startConnection error: %s", arrobject);
            }
        }
        if (!AdjustFactory.getTryInstallReferrer()) {
            return;
        }
        this.closeReferrerClient();
        if (this.hasInstallReferrerBeenRead.get()) {
            this.logger.debug("Install referrer has already been read", new Object[0]);
            return;
        }
        Context context = this.context;
        if (context == null) {
            return;
        }
        this.referrerClient = object = this.createInstallReferrerClient(context);
        if (object == null) {
            return;
        }
        Class class_ = this.getInstallReferrerStateListenerClass();
        if (class_ == null) {
            return;
        }
        Object object3 = this.createProxyInstallReferrerStateListener(class_);
        if (object3 == null) {
            return;
        }
        this.startConnection(class_, object3);
    }

}

