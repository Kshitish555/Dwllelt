/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.views.util.constants.MapViewConstants
 */
package org.osmdroid.views.util;

import android.graphics.Point;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.BoundingBoxE6;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.util.constants.MapViewConstants;

public class Mercator
implements MapViewConstants {
    static final double DEG2RAD = 0.017453292519943295;

    private Mercator() {
    }

    public static BoundingBoxE6 getBoundingBoxFromCoords(int n, int n2, int n3, int n4, int n5) {
        BoundingBoxE6 boundingBoxE6 = new BoundingBoxE6(Mercator.tile2lat(n2, n5), Mercator.tile2lon(n3, n5), Mercator.tile2lat(n4, n5), Mercator.tile2lon(n, n5));
        return boundingBoxE6;
    }

    public static BoundingBoxE6 getBoundingBoxFromPointInMapTile(Point point, int n) {
        BoundingBoxE6 boundingBoxE6 = new BoundingBoxE6(Mercator.tile2lat(point.y, n), Mercator.tile2lon(1 + point.x, n), Mercator.tile2lat(1 + point.y, n), Mercator.tile2lon(point.x, n));
        return boundingBoxE6;
    }

    public static Point projectGeoPoint(double d, double d2, int n, Point point) {
        if (point == null) {
            point = new Point(0, 0);
        }
        double d3 = (d2 + 180.0) / 360.0;
        double d4 = 1 << n;
        Double.isNaN((double)d4);
        point.x = (int)Math.floor((double)(d3 * d4));
        double d5 = d * 0.017453292519943295;
        double d6 = (1.0 - Math.log((double)(Math.tan((double)d5) + 1.0 / Math.cos((double)d5))) / 3.141592653589793) / 2.0;
        Double.isNaN((double)d4);
        point.y = (int)Math.floor((double)(d6 * d4));
        return point;
    }

    public static Point projectGeoPoint(int n, int n2, int n3, Point point) {
        double d = n;
        Double.isNaN((double)d);
        double d2 = d * 1.0E-6;
        double d3 = n2;
        Double.isNaN((double)d3);
        return Mercator.projectGeoPoint(d2, d3 * 1.0E-6, n3, point);
    }

    public static Point projectGeoPoint(IGeoPoint iGeoPoint, int n, Point point) {
        double d = iGeoPoint.getLatitudeE6();
        Double.isNaN((double)d);
        double d2 = d * 1.0E-6;
        double d3 = iGeoPoint.getLongitudeE6();
        Double.isNaN((double)d3);
        return Mercator.projectGeoPoint(d2, d3 * 1.0E-6, n, point);
    }

    public static GeoPoint projectPoint(int n, int n2, int n3) {
        return new GeoPoint((int)(1000000.0 * Mercator.tile2lat(n2, n3)), (int)(1000000.0 * Mercator.tile2lon(n, n3)));
    }

    public static double tile2lat(int n, int n2) {
        double d = n;
        Double.isNaN((double)d);
        double d2 = d * 6.283185307179586;
        double d3 = 1 << n2;
        Double.isNaN((double)d3);
        double d4 = 3.141592653589793 - d2 / d3;
        return 57.29577951308232 * Math.atan((double)(0.5 * (Math.exp((double)d4) - Math.exp((double)(-d4)))));
    }

    public static double tile2lon(int n, int n2) {
        double d = n;
        double d2 = 1 << n2;
        Double.isNaN((double)d);
        Double.isNaN((double)d2);
        return 360.0 * (d / d2) - 180.0;
    }
}

