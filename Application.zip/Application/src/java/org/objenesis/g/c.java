/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Deprecated
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 */
package org.objenesis.g;

import java.lang.reflect.Field;
import org.objenesis.ObjenesisException;

public final class c {
    public static final String a = "BEA";
    public static final String b = "GNU libgcj";
    public static final String c = "Java HotSpot";
    @Deprecated
    public static final String d = "Java HotSpot";
    public static final String e = "OpenJDK";
    public static final String f = "PERC";
    public static final String g = "Dalvik";
    public static final String h = System.getProperty((String)"java.specification.version");
    public static final String i = System.getProperty((String)"java.runtime.version");
    public static final String j = System.getProperty((String)"java.vm.info");
    public static final String k = System.getProperty((String)"java.vm.version");
    public static final String l = System.getProperty((String)"java.vm.vendor");
    public static final String m = System.getProperty((String)"java.vm.name");
    public static final int n = c.b();
    public static final boolean o = c.e();
    public static final String p = c.d();

    private c() {
    }

    private static int a(Class<?> class_) {
        Field field;
        String string2;
        try {
            field = class_.getField("SDK");
        }
        catch (NoSuchFieldException noSuchFieldException) {
            throw new ObjenesisException(noSuchFieldException);
        }
        try {
            string2 = (String)field.get(null);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new RuntimeException((Throwable)illegalAccessException);
        }
        return Integer.parseInt((String)string2);
    }

    public static String a() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Java ");
        stringBuilder.append(h);
        stringBuilder.append(" (VM vendor name=\"");
        stringBuilder.append(l);
        stringBuilder.append("\", VM vendor version=");
        stringBuilder.append(k);
        stringBuilder.append(", JVM name=\"");
        stringBuilder.append(m);
        stringBuilder.append("\", JVM version=");
        stringBuilder.append(i);
        stringBuilder.append(", JVM info=");
        stringBuilder.append(j);
        String string2 = stringBuilder.toString();
        if (n != 0) {
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string2);
            stringBuilder2.append(", API level=");
            stringBuilder2.append(n);
            string2 = stringBuilder2.toString();
        }
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(string2);
        stringBuilder3.append(")");
        return stringBuilder3.toString();
    }

    public static boolean a(String string2) {
        return m.startsWith(string2);
    }

    private static int b() {
        if (!c.a(g)) {
            return 0;
        }
        return c.c();
    }

    private static int c() {
        Class class_;
        Field field;
        try {
            class_ = Class.forName((String)"android.os.Build$VERSION");
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new ObjenesisException(classNotFoundException);
        }
        try {
            field = class_.getField("SDK_INT");
        }
        catch (NoSuchFieldException noSuchFieldException) {
            return c.a(class_);
        }
        try {
            int n2 = (Integer)field.get(null);
            return n2;
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new RuntimeException((Throwable)illegalAccessException);
        }
    }

    private static String d() {
        return System.getProperty((String)"com.google.appengine.runtime.version");
    }

    private static boolean e() {
        if (c.b() == 0) {
            return false;
        }
        String string2 = System.getProperty((String)"java.boot.class.path");
        boolean bl = false;
        if (string2 != null) {
            boolean bl2 = string2.toLowerCase().contains((CharSequence)"core-oj.jar");
            bl = false;
            if (bl2) {
                bl = true;
            }
        }
        return bl;
    }

    public static boolean f() {
        return o;
    }

    public static boolean g() {
        return p != null;
    }
}

