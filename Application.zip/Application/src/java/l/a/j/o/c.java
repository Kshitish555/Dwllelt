/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  l.a.a
 *  l.a.b
 *  l.a.h.f.a
 *  l.a.h.f.a$c
 *  l.a.h.j.f
 *  l.a.h.j.f$d
 *  l.a.i.b
 *  l.a.i.b$a
 *  l.a.i.i.d
 *  l.a.i.i.d$a
 *  l.a.i.i.d$b
 *  l.a.i.i.j.a
 *  l.a.j.i
 *  l.a.j.o.a
 *  l.a.j.o.a$b
 */
package l.a.j.o;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import l.a.b;
import l.a.h.f.a;
import l.a.h.j.f;
import l.a.i.b;
import l.a.i.i.d;
import l.a.i.i.j.a;
import l.a.j.i;
import l.a.j.o.a;

public final class c
extends Enum<c>
implements a {
    public static final /* enum */ c d;
    public static final /* enum */ c f;
    private static final /* synthetic */ c[] h;
    private final boolean c;

    static {
        c c2;
        d = new c(true);
        f = c2 = new c(false);
        c[] arrc = new c[]{d, c2};
        h = arrc;
    }

    private c(boolean bl) {
        this.c = bl;
    }

    public static c valueOf(String string) {
        return (c)Enum.valueOf(c.class, (String)string);
    }

    public static c[] values() {
        return (c[])h.clone();
    }

    public l.a.i.b a(String string, b b2, i i2) {
        b.a a2 = new l.a.a(b2).a((d.a)d.b.c).a(Object.class, (l.a.i.i.j.a)a.b.c);
        List list = this.c ? Collections.singletonList((Object)a.c.a(a.b.class).a()) : Collections.emptyList();
        return a2.d((Collection)list).b(string).a(a.t0).a();
    }
}

