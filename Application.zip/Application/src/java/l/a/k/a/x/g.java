/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  l.a.k.a.f
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.u
 *  l.a.k.a.x.l
 *  l.a.k.a.x.y
 */
package l.a.k.a.x;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import l.a.k.a.f;
import l.a.k.a.n;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.u;
import l.a.k.a.x.k;
import l.a.k.a.x.l;
import l.a.k.a.x.y;

public class g
extends k {
    public static final int A5 = 157;
    public static final int B5 = 158;
    static /* synthetic */ Class C5;
    private static final String T4 = "Ljava/lang/Class;";
    private static final u U4;
    private static final u V4;
    private static final u W4;
    private static final u X4;
    private static final u Y4;
    private static final u Z4;
    private static final u a5;
    private static final u b5;
    private static final u c5;
    private static final u d5;
    private static final l e5;
    private static final l f5;
    private static final l g5;
    private static final l h5;
    private static final l i5;
    private static final l j5;
    public static final int k5 = 96;
    public static final int l5 = 100;
    public static final int m5 = 104;
    public static final int n5 = 108;
    public static final int o5 = 112;
    public static final int p5 = 116;
    public static final int q5 = 120;
    public static final int r5 = 122;
    public static final int s5 = 124;
    public static final int t5 = 126;
    public static final int u5 = 128;
    public static final int v5 = 130;
    public static final int w5 = 153;
    public static final int x5 = 154;
    public static final int y5 = 155;
    public static final int z5 = 156;
    private final int P4;
    private final u Q4;
    private final u[] R4;
    private final List S4 = new ArrayList();

    static {
        g.z();
        U4 = u.d((String)"java/lang/Byte");
        V4 = u.d((String)"java/lang/Boolean");
        W4 = u.d((String)"java/lang/Short");
        X4 = u.d((String)"java/lang/Character");
        Y4 = u.d((String)"java/lang/Integer");
        Z4 = u.d((String)"java/lang/Float");
        a5 = u.d((String)"java/lang/Long");
        b5 = u.d((String)"java/lang/Double");
        c5 = u.d((String)"java/lang/Number");
        d5 = u.d((String)"java/lang/Object");
        e5 = l.a((String)"boolean booleanValue()");
        f5 = l.a((String)"char charValue()");
        g5 = l.a((String)"int intValue()");
        h5 = l.a((String)"float floatValue()");
        i5 = l.a((String)"long longValue()");
        j5 = l.a((String)"double doubleValue()");
    }

    protected g(int n2, r r2, int n3, String string, String string2) {
        super(n2, n3, string2, r2);
        this.P4 = n3;
        this.Q4 = u.e((String)string2);
        this.R4 = u.a((String)string2);
    }

    public g(int n2, l l2, String string, u[] arru, f f2) {
        this(n2, l2, f2.a(n2, l2.c(), l2.b(), string, g.a(arru)));
    }

    public g(int n2, l l2, r r2) {
        this(r2, n2, null, l2.b());
    }

    public g(r r2, int n2, String string, String string2) {
        this(327680, r2, n2, string, string2);
        if (this.getClass() == C5) {
            return;
        }
        throw new IllegalStateException();
    }

    static /* synthetic */ Class a(String string) {
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new NoClassDefFoundError(classNotFoundException.getMessage());
        }
    }

    private void a(int n2, u u2, String string, u u3) {
        this.d.a(n2, u2.g(), string, u3.d());
    }

    private void a(int n2, u u2, l l2, boolean bl) {
        String string = u2.j() == 9 ? u2.d() : u2.g();
        String string2 = string;
        this.d.a(n2, string2, l2.c(), l2.b(), bl);
    }

    private void a(u u2, int n2) {
        this.d.d(u2.a(21), n2);
    }

    private static String[] a(u[] arru) {
        if (arru == null) {
            return null;
        }
        int n2 = arru.length;
        String[] arrstring = new String[n2];
        for (int i2 = 0; i2 < n2; ++i2) {
            arrstring[i2] = arru[i2].g();
        }
        return arrstring;
    }

    private void b(u u2, int n2) {
        this.d.d(u2.a(54), n2);
    }

    private void e(int n2, u u2) {
        this.d.a(n2, u2.g());
    }

    private int i(int n2) {
        int n3;
        int n4 = 8 & this.P4;
        int n5 = 0;
        if (n4 == 0) {
            n3 = 1;
            n5 = 0;
        } else {
            n3 = 0;
        }
        while (n5 < n2) {
            n3 += this.R4[n5].i();
            ++n5;
        }
        return n3;
    }

    private static u m(u u2) {
        switch (u2.j()) {
            default: {
                return u2;
            }
            case 8: {
                return b5;
            }
            case 7: {
                return a5;
            }
            case 6: {
                return Z4;
            }
            case 5: {
                return Y4;
            }
            case 4: {
                return W4;
            }
            case 3: {
                return U4;
            }
            case 2: {
                return X4;
            }
            case 1: 
        }
        return V4;
    }

    private static void z() {
        C5 = g.a("net.bytebuddy.jar.asm.commons.GeneratorAdapter");
    }

    public void a(double d2) {
        long l2 = Double.doubleToLongBits((double)d2);
        if (l2 != 0L && l2 != 4607182418800017408L) {
            this.d.a((Object)new Double(d2));
            return;
        }
        this.d.a(14 + (int)d2);
    }

    public void a(float f2) {
        int n2 = Float.floatToIntBits((float)f2);
        if ((long)n2 != 0L && n2 != 1065353216 && n2 != 1073741824) {
            this.d.a((Object)new Float(f2));
            return;
        }
        this.d.a(11 + (int)f2);
    }

    @Override
    protected void a(int n2, u u2) {
        int n3 = n2 - this.o;
        while (this.S4.size() < n3 + 1) {
            this.S4.add(null);
        }
        this.S4.set(n3, (Object)u2);
    }

    public void a(long l2) {
        if (l2 != 0L && l2 != 1L) {
            this.d.a((Object)new Long(l2));
            return;
        }
        this.d.a(9 + (int)l2);
    }

    public void a(n n2) {
        this.d.a((Object)n2);
    }

    public void a(q q2, q q3, u u2) {
        q q4 = new q();
        if (u2 == null) {
            this.d.a(q2, q3, q4, null);
        } else {
            this.d.a(q2, q3, q4, u2.g());
        }
        this.e(q4);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(u u2, int n2, q q2) {
        int n3;
        block18 : {
            r r2;
            int n4;
            switch (u2.j()) {
                default: {
                    n3 = -1;
                    switch (n2) {
                        default: {
                            break;
                        }
                        case 158: {
                            n3 = 164;
                            break;
                        }
                        case 157: {
                            n3 = 163;
                            break;
                        }
                        case 156: {
                            n3 = 162;
                            break;
                        }
                        case 155: {
                            n3 = 161;
                            break;
                        }
                        case 154: {
                            n3 = 160;
                            break;
                        }
                        case 153: {
                            n3 = 159;
                            break;
                        }
                    }
                    break block18;
                }
                case 9: 
                case 10: {
                    if (n2 == 153) {
                        this.d.a(165, q2);
                        return;
                    }
                    if (n2 == 154) {
                        this.d.a(166, q2);
                        return;
                    }
                    StringBuffer stringBuffer = new StringBuffer();
                    stringBuffer.append("Bad comparison for type ");
                    stringBuffer.append((Object)u2);
                    throw new IllegalArgumentException(stringBuffer.toString());
                }
                case 8: {
                    r2 = this.d;
                    if (n2 != 156 && n2 != 157) {
                        n4 = 152;
                        break;
                    }
                    n4 = 151;
                    break;
                }
                case 7: {
                    r2 = this.d;
                    n4 = 148;
                    break;
                }
                case 6: {
                    r2 = this.d;
                    if (n2 != 156 && n2 != 157) {
                        n4 = 150;
                        break;
                    }
                    n4 = 149;
                }
            }
            r2.a(n4);
            this.d.a(n2, q2);
            return;
        }
        this.d.a(n3, q2);
    }

    public void a(u u2, String string) {
        this.i(u2);
        this.f();
        this.b(string);
        this.a(u2, l.a((String)"void <init> (String)"));
        this.y();
    }

    public void a(u u2, String string, u u3) {
        this.a(180, u2, string, u3);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(u u2, u u3) {
        block2 : {
            int n2;
            r r2;
            block5 : {
                block18 : {
                    block17 : {
                        block16 : {
                            block15 : {
                                block14 : {
                                    block11 : {
                                        int n3;
                                        r r3;
                                        block7 : {
                                            block13 : {
                                                block12 : {
                                                    block8 : {
                                                        block10 : {
                                                            block9 : {
                                                                block3 : {
                                                                    block6 : {
                                                                        block4 : {
                                                                            if (u2 == u3) break block2;
                                                                            if (u2 != u.y) break block3;
                                                                            if (u3 != u.w) break block4;
                                                                            r2 = this.d;
                                                                            n2 = 144;
                                                                            break block5;
                                                                        }
                                                                        if (u3 != u.x) break block6;
                                                                        r2 = this.d;
                                                                        n2 = 143;
                                                                        break block5;
                                                                    }
                                                                    r3 = this.d;
                                                                    n3 = 142;
                                                                    break block7;
                                                                }
                                                                if (u2 != u.w) break block8;
                                                                if (u3 != u.y) break block9;
                                                                r2 = this.d;
                                                                n2 = 141;
                                                                break block5;
                                                            }
                                                            if (u3 != u.x) break block10;
                                                            r2 = this.d;
                                                            n2 = 140;
                                                            break block5;
                                                        }
                                                        r3 = this.d;
                                                        n3 = 139;
                                                        break block7;
                                                    }
                                                    if (u2 != u.x) break block11;
                                                    if (u3 != u.y) break block12;
                                                    r2 = this.d;
                                                    n2 = 138;
                                                    break block5;
                                                }
                                                if (u3 != u.w) break block13;
                                                r2 = this.d;
                                                n2 = 137;
                                                break block5;
                                            }
                                            r3 = this.d;
                                            n3 = 136;
                                        }
                                        r3.a(n3);
                                        this.a(u.v, u3);
                                        return;
                                    }
                                    if (u3 != u.t) break block14;
                                    r2 = this.d;
                                    n2 = 145;
                                    break block5;
                                }
                                if (u3 != u.s) break block15;
                                r2 = this.d;
                                n2 = 146;
                                break block5;
                            }
                            if (u3 != u.y) break block16;
                            r2 = this.d;
                            n2 = 135;
                            break block5;
                        }
                        if (u3 != u.w) break block17;
                        r2 = this.d;
                        n2 = 134;
                        break block5;
                    }
                    if (u3 != u.x) break block18;
                    r2 = this.d;
                    n2 = 133;
                    break block5;
                }
                if (u3 != u.u) break block2;
                r2 = this.d;
                n2 = 147;
            }
            r2.a(n2);
            return;
        }
    }

    public void a(u u2, l l2) {
        this.a(183, u2, l2, false);
    }

    public void a(boolean bl) {
        this.e((int)bl);
    }

    public void a(int[] arrn, y y2) {
        float f2 = arrn.length == 0 ? 0.0f : (float)arrn.length / (float)(1 + (arrn[arrn.length - 1] - arrn[0]));
        float f3 = f2 FCMPL 0.5f;
        boolean bl = false;
        if (f3 >= 0) {
            bl = true;
        }
        this.a(arrn, y2, bl);
    }

    public void a(int[] arrn, y y2, boolean bl) {
        for (int i2 = 1; i2 < arrn.length; ++i2) {
            if (arrn[i2] >= arrn[i2 - 1]) {
                continue;
            }
            throw new IllegalArgumentException("keys must be sorted ascending");
        }
        q q2 = this.s();
        q q3 = this.s();
        if (arrn.length > 0) {
            int n2 = arrn.length;
            int n3 = 0;
            int n4 = arrn[0];
            int n5 = arrn[n2 - 1];
            int n6 = 1 + (n5 - n4);
            if (bl) {
                Object[] arrobject = new q[n6];
                Arrays.fill((Object[])arrobject, (Object)q2);
                for (int i3 = 0; i3 < n2; ++i3) {
                    arrobject[arrn[i3] - n4] = this.s();
                }
                this.d.a(n4, n5, q2, (q[])arrobject);
                while (n3 < n6) {
                    Object object = arrobject[n3];
                    if (object != q2) {
                        this.e((q)object);
                        y2.a(n3 + n4, q3);
                    }
                    ++n3;
                }
            } else {
                q[] arrq = new q[n2];
                for (int i4 = 0; i4 < n2; ++i4) {
                    arrq[i4] = this.s();
                }
                this.d.a(q2, arrn, arrq);
                while (n3 < n2) {
                    this.e(arrq[n3]);
                    y2.a(arrn[n3], q3);
                    ++n3;
                }
            }
        }
        this.e(q2);
        y2.a();
        this.e(q3);
    }

    public u b(int n2) {
        return (u)this.S4.get(n2 - this.o);
    }

    public void b(int n2, u u2) {
        this.a(n2, u2);
        this.a(u2, n2);
    }

    public void b(String string) {
        if (string == null) {
            this.d.a(1);
            return;
        }
        this.d.a((Object)string);
    }

    public /* varargs */ void b(String string, String string2, n n2, Object ... arrobject) {
        this.d.a(string, string2, n2, arrobject);
    }

    public void b(q q2) {
        this.d.a(167, q2);
    }

    public void b(u u2, String string, u u3) {
        this.a(178, u2, string, u3);
    }

    public void b(u u2, u u3) {
        int n2 = u3.i();
        int n3 = u2.i();
        if (n2 == 1) {
            if (n3 == 1) {
                this.x();
                return;
            }
            this.k();
            this.u();
            return;
        }
        if (n3 == 1) {
            this.h();
        } else {
            this.i();
        }
        this.v();
    }

    public void b(u u2, l l2) {
        this.a(185, u2, l2, true);
    }

    public void c(int n2) {
        this.a(this.R4[n2], this.i(n2));
    }

    public void c(int n2, q q2) {
        this.a(u.v, n2, q2);
    }

    public void c(int n2, u u2) {
        this.d.a(u2.a(n2));
    }

    public void c(q q2) {
        this.d.a(199, q2);
    }

    public void c(u u2) {
        this.d.a(u2.a(46));
    }

    public void c(u u2, String string, u u3) {
        this.a(181, u2, string, u3);
    }

    public void c(u u2, l l2) {
        this.a(184, u2, l2, false);
    }

    public void d(int n2) {
        this.a(this.b(n2), n2);
    }

    public void d(int n2, q q2) {
        this.d.a(n2, q2);
    }

    public void d(int n2, u u2) {
        this.a(n2, u2);
        this.b(u2, n2);
    }

    public void d(q q2) {
        this.d.a(198, q2);
    }

    public void d(u u2) {
        this.d.a(u2.a(79));
    }

    public void d(u u2, String string, u u3) {
        this.a(179, u2, string, u3);
    }

    public void d(u u2, l l2) {
        this.a(182, u2, l2, false);
    }

    public void e() {
        this.d.a(190);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void e(int n2) {
        block6 : {
            int n3;
            r r2;
            block5 : {
                block4 : {
                    if (n2 >= -1 && n2 <= 5) {
                        this.d.a(n2 + 3);
                        return;
                    }
                    if (n2 < -128 || n2 > 127) break block4;
                    r2 = this.d;
                    n3 = 16;
                    break block5;
                }
                if (n2 < -32768 || n2 > 32767) break block6;
                r2 = this.d;
                n3 = 17;
            }
            r2.b(n3, n2);
            return;
        }
        this.d.a((Object)new Integer(n2));
    }

    public void e(int n2, int n3) {
        this.d.a(n2, n3);
    }

    public void e(q q2) {
        this.d.a(q2);
    }

    public void e(u u2) {
        if (u2.j() != 10) {
            if (u2.j() == 9) {
                return;
            }
            if (u2 == u.q) {
                this.b((String)null);
                return;
            }
            u u3 = g.m(u2);
            this.i(u3);
            if (u2.i() == 2) {
                this.k();
                this.k();
                this.u();
            } else {
                this.j();
                this.x();
            }
            this.a(u3, new l("<init>", u.q, new u[]{u2}));
        }
    }

    public void f() {
        this.d.a(89);
    }

    public void f(int n2) {
        this.d.d(169, n2);
    }

    public void f(int n2, int n3) {
        int n4 = this.i(n2);
        for (int i2 = 0; i2 < n3; ++i2) {
            u u2 = this.R4[n2 + i2];
            this.a(u2, n4);
            n4 += u2.i();
        }
    }

    public void f(u u2) {
        if (!u2.equals((Object)d5)) {
            this.e(192, u2);
        }
    }

    public void g() {
        this.d.a(92);
    }

    public void g(int n2) {
        this.b(this.R4[n2], this.i(n2));
    }

    public void g(u u2) {
        this.e(193, u2);
    }

    public void h() {
        this.d.a(93);
    }

    public void h(int n2) {
        this.b(this.b(n2), n2);
    }

    public void h(u u2) {
        int n2;
        switch (u2.j()) {
            default: {
                this.e(189, u2);
                return;
            }
            case 8: {
                n2 = 7;
                break;
            }
            case 7: {
                n2 = 11;
                break;
            }
            case 6: {
                n2 = 6;
                break;
            }
            case 5: {
                n2 = 10;
                break;
            }
            case 4: {
                n2 = 9;
                break;
            }
            case 3: {
                n2 = 8;
                break;
            }
            case 2: {
                n2 = 5;
                break;
            }
            case 1: {
                n2 = 4;
            }
        }
        this.d.b(188, n2);
    }

    public void i() {
        this.d.a(94);
    }

    public void i(u u2) {
        this.e(187, u2);
    }

    public void j() {
        this.d.a(90);
    }

    public void j(u u2) {
        String string;
        r r2;
        if (u2 == null) {
            this.d.a(1);
            return;
        }
        switch (u2.j()) {
            default: {
                this.d.a((Object)u2);
                return;
            }
            case 8: {
                r2 = this.d;
                string = "java/lang/Double";
                break;
            }
            case 7: {
                r2 = this.d;
                string = "java/lang/Long";
                break;
            }
            case 6: {
                r2 = this.d;
                string = "java/lang/Float";
                break;
            }
            case 5: {
                r2 = this.d;
                string = "java/lang/Integer";
                break;
            }
            case 4: {
                r2 = this.d;
                string = "java/lang/Short";
                break;
            }
            case 3: {
                r2 = this.d;
                string = "java/lang/Byte";
                break;
            }
            case 2: {
                r2 = this.d;
                string = "java/lang/Character";
                break;
            }
            case 1: {
                r2 = this.d;
                string = "java/lang/Boolean";
            }
        }
        r2.a(178, string, "TYPE", T4);
    }

    public void k() {
        this.d.a(91);
    }

    public void k(u u2) {
        l l2;
        u u3 = c5;
        switch (u2.j()) {
            default: {
                l2 = null;
                break;
            }
            case 8: {
                l2 = j5;
                break;
            }
            case 7: {
                l2 = i5;
                break;
            }
            case 6: {
                l2 = h5;
                break;
            }
            case 3: 
            case 4: 
            case 5: {
                l2 = g5;
                break;
            }
            case 2: {
                u3 = X4;
                l2 = f5;
                break;
            }
            case 1: {
                u3 = V4;
                l2 = e5;
                break;
            }
            case 0: {
                return;
            }
        }
        if (l2 == null) {
            this.f(u2);
            return;
        }
        this.f(u3);
        this.d(u3, l2);
    }

    public void l() {
        if ((1024 & this.P4) == 0) {
            this.d.c(0, 0);
        }
        this.d.d();
    }

    public void l(u u2) {
        if (u2.j() != 10) {
            if (u2.j() == 9) {
                return;
            }
            if (u2 == u.q) {
                this.b((String)null);
                return;
            }
            u u3 = g.m(u2);
            this.c(u3, new l("valueOf", u3, new u[]{u2}));
        }
    }

    public void m() {
        this.e(this.R4.length);
        this.h(d5);
        for (int i2 = 0; i2 < this.R4.length; ++i2) {
            this.f();
            this.e(i2);
            this.c(i2);
            this.e(this.R4[i2]);
            this.d(d5);
        }
    }

    public void n() {
        this.f(0, this.R4.length);
    }

    public void o() {
        if ((8 & this.P4) == 0) {
            this.d.d(25, 0);
            return;
        }
        throw new IllegalStateException("no 'this' pointer within static method");
    }

    public q p() {
        q q2 = new q();
        this.d.a(q2);
        return q2;
    }

    public void q() {
        this.d.a(194);
    }

    public void r() {
        this.d.a(195);
    }

    public q s() {
        return new q();
    }

    public void t() {
        this.d.a(4);
        this.d.a(130);
    }

    public void u() {
        this.d.a(87);
    }

    public void v() {
        this.d.a(88);
    }

    public void w() {
        this.d.a(this.Q4.a(172));
    }

    public void x() {
        this.d.a(95);
    }

    public void y() {
        this.d.a(191);
    }
}

