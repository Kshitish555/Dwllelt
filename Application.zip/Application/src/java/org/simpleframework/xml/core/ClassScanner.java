/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  org.simpleframework.xml.DefaultType
 *  org.simpleframework.xml.Namespace
 *  org.simpleframework.xml.NamespaceList
 *  org.simpleframework.xml.Order
 *  org.simpleframework.xml.Root
 *  org.simpleframework.xml.core.Commit
 *  org.simpleframework.xml.core.Complete
 *  org.simpleframework.xml.core.Persist
 *  org.simpleframework.xml.core.Replace
 *  org.simpleframework.xml.core.Resolve
 *  org.simpleframework.xml.core.Validate
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Namespace;
import org.simpleframework.xml.NamespaceList;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.core.Commit;
import org.simpleframework.xml.core.Complete;
import org.simpleframework.xml.core.ConstructorScanner;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.Function;
import org.simpleframework.xml.core.MethodDetail;
import org.simpleframework.xml.core.NamespaceDecorator;
import org.simpleframework.xml.core.ParameterMap;
import org.simpleframework.xml.core.Persist;
import org.simpleframework.xml.core.Replace;
import org.simpleframework.xml.core.Resolve;
import org.simpleframework.xml.core.Signature;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.core.Validate;

class ClassScanner {
    private Function commit;
    private Function complete;
    private NamespaceDecorator decorator;
    private Order order;
    private Function persist;
    private Function replace;
    private Function resolve;
    private Root root;
    private ConstructorScanner scanner;
    private Support support;
    private Function validate;

    public ClassScanner(Detail detail, Support support) throws Exception {
        this.scanner = new ConstructorScanner(detail, support);
        this.decorator = new NamespaceDecorator();
        this.support = support;
        this.scan(detail);
    }

    private void commit(Method method) {
        if (this.commit == null) {
            this.commit = this.getFunction(method);
        }
    }

    private void commit(Detail detail) {
        Namespace namespace = detail.getNamespace();
        if (namespace != null) {
            this.decorator.set(namespace);
        }
    }

    private void complete(Method method) {
        if (this.complete == null) {
            this.complete = this.getFunction(method);
        }
    }

    private void definition(Detail detail) throws Exception {
        if (this.root == null) {
            this.root = detail.getRoot();
        }
        if (this.order == null) {
            this.order = detail.getOrder();
        }
    }

    private Function getFunction(Method method) {
        boolean bl = this.isContextual(method);
        if (!method.isAccessible()) {
            method.setAccessible(true);
        }
        return new Function(method, bl);
    }

    private boolean isContextual(Method method) {
        Class[] arrclass = method.getParameterTypes();
        if (arrclass.length == 1) {
            return Map.class.equals((Object)arrclass[0]);
        }
        return false;
    }

    private void method(Detail detail) throws Exception {
        Iterator iterator = detail.getMethods().iterator();
        while (iterator.hasNext()) {
            this.method((MethodDetail)iterator.next());
        }
    }

    private void method(MethodDetail methodDetail) {
        Annotation[] arrannotation = methodDetail.getAnnotations();
        Method method = methodDetail.getMethod();
        for (Annotation annotation : arrannotation) {
            if (annotation instanceof Commit) {
                this.commit(method);
            }
            if (annotation instanceof Validate) {
                this.validate(method);
            }
            if (annotation instanceof Persist) {
                this.persist(method);
            }
            if (annotation instanceof Complete) {
                this.complete(method);
            }
            if (annotation instanceof Replace) {
                this.replace(method);
            }
            if (!(annotation instanceof Resolve)) continue;
            this.resolve(method);
        }
    }

    private void namespace(Detail detail) throws Exception {
        NamespaceList namespaceList = detail.getNamespaceList();
        Namespace namespace = detail.getNamespace();
        if (namespace != null) {
            this.decorator.add(namespace);
        }
        if (namespaceList != null) {
            for (Namespace namespace2 : namespaceList.value()) {
                this.decorator.add(namespace2);
            }
        }
    }

    private void persist(Method method) {
        if (this.persist == null) {
            this.persist = this.getFunction(method);
        }
    }

    private void replace(Method method) {
        if (this.replace == null) {
            this.replace = this.getFunction(method);
        }
    }

    private void resolve(Method method) {
        if (this.resolve == null) {
            this.resolve = this.getFunction(method);
        }
    }

    private void scan(Detail detail) throws Exception {
        DefaultType defaultType = detail.getOverride();
        Class class_ = detail.getType();
        while (class_ != null) {
            Detail detail2 = this.support.getDetail(class_, defaultType);
            this.namespace(detail2);
            this.method(detail2);
            this.definition(detail2);
            class_ = detail2.getSuper();
        }
        this.commit(detail);
    }

    private void validate(Method method) {
        if (this.validate == null) {
            this.validate = this.getFunction(method);
        }
    }

    public Function getCommit() {
        return this.commit;
    }

    public Function getComplete() {
        return this.complete;
    }

    public Decorator getDecorator() {
        return this.decorator;
    }

    public Order getOrder() {
        return this.order;
    }

    public ParameterMap getParameters() {
        return this.scanner.getParameters();
    }

    public Function getPersist() {
        return this.persist;
    }

    public Function getReplace() {
        return this.replace;
    }

    public Function getResolve() {
        return this.resolve;
    }

    public Root getRoot() {
        return this.root;
    }

    public Signature getSignature() {
        return this.scanner.getSignature();
    }

    public List<Signature> getSignatures() {
        return this.scanner.getSignatures();
    }

    public Function getValidate() {
        return this.validate;
    }
}

