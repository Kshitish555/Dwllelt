/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashSet
 *  java.util.Set
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amplitude.api;

import com.amplitude.api.d;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class m {
    private static String[] b = new String[]{"city", "country", "dma", "ip_address", "lat_lng", "region"};
    public static final String c = "com.amplitude.api.TrackingOptions";
    Set<String> a = new HashSet();

    private void a(String string) {
        this.a.add((Object)string);
    }

    private boolean b(String string) {
        return true ^ this.a.contains((Object)string);
    }

    boolean A() {
        return this.b("language");
    }

    boolean B() {
        return this.b("lat_lng");
    }

    boolean C() {
        return this.b("os_name");
    }

    boolean D() {
        return this.b("os_version");
    }

    boolean E() {
        return this.b("platform");
    }

    boolean F() {
        return this.b("region");
    }

    boolean G() {
        return this.b("version_name");
    }

    public m a() {
        this.a("adid");
        return this;
    }

    public m b() {
        this.a("carrier");
        return this;
    }

    public m c() {
        this.a("city");
        return this;
    }

    public m d() {
        this.a("country");
        return this;
    }

    public m e() {
        this.a("device_brand");
        return this;
    }

    public m f() {
        this.a("device_manufacturer");
        return this;
    }

    public m g() {
        this.a("device_model");
        return this;
    }

    public m h() {
        this.a("dma");
        return this;
    }

    public m i() {
        this.a("ip_address");
        return this;
    }

    public m j() {
        this.a("language");
        return this;
    }

    public m k() {
        this.a("lat_lng");
        return this;
    }

    public m l() {
        this.a("os_name");
        return this;
    }

    public m m() {
        this.a("os_version");
        return this;
    }

    public m n() {
        this.a("platform");
        return this;
    }

    public m o() {
        this.a("region");
        return this;
    }

    public m p() {
        this.a("version_name");
        return this;
    }

    protected JSONObject q() {
        JSONObject jSONObject = new JSONObject();
        if (this.a.isEmpty()) {
            return jSONObject;
        }
        for (String string : b) {
            if (!this.a.contains((Object)string)) continue;
            try {
                jSONObject.put(string, false);
            }
            catch (JSONException jSONException) {
                d.a().b(c, jSONException.toString());
            }
        }
        return jSONObject;
    }

    boolean r() {
        return this.b("adid");
    }

    boolean s() {
        return this.b("carrier");
    }

    boolean t() {
        return this.b("city");
    }

    boolean u() {
        return this.b("country");
    }

    boolean v() {
        return this.b("device_brand");
    }

    boolean w() {
        return this.b("device_manufacturer");
    }

    boolean x() {
        return this.b("device_model");
    }

    boolean y() {
        return this.b("dma");
    }

    boolean z() {
        return this.b("ip_address");
    }
}

