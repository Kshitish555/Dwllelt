/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  org.simpleframework.xml.util.Cache
 */
package org.simpleframework.xml.util;

import java.util.LinkedHashMap;
import java.util.Map;
import org.simpleframework.xml.util.Cache;

public class LimitedCache<T>
extends LinkedHashMap<Object, T>
implements Cache<T> {
    private final int capacity;

    public LimitedCache() {
        this(50000);
    }

    public LimitedCache(int n) {
        this.capacity = n;
    }

    public void cache(Object object, T t) {
        this.put(object, t);
    }

    public boolean contains(Object object) {
        return this.containsKey(object);
    }

    public T fetch(Object object) {
        return (T)this.get(object);
    }

    protected boolean removeEldestEntry(Map.Entry<Object, T> entry) {
        return this.size() > this.capacity;
    }

    public T take(Object object) {
        return (T)this.remove(object);
    }
}

