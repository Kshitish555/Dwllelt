/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

public interface InstallReferrerReadListener {
    public void onInstallReferrerRead(String var1, long var2, long var4);
}

