/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.amplitude.api;

public class e {
    public static final String A = "$identify";
    public static final String B = "$groupidentify";
    public static final String C = "$add";
    public static final String D = "$append";
    public static final String E = "$clearAll";
    public static final String F = "$prepend";
    public static final String G = "$set";
    public static final String H = "$setOnce";
    public static final String I = "$unset";
    public static final String J = "revenue_amount";
    public static final String K = "$productId";
    public static final String L = "$quantity";
    public static final String M = "$price";
    public static final String N = "$revenueType";
    public static final String O = "$receipt";
    public static final String P = "$receiptSig";
    public static final String Q = "adid";
    public static final String R = "carrier";
    public static final String S = "city";
    public static final String T = "country";
    public static final String U = "device_brand";
    public static final String V = "device_manufacturer";
    public static final String W = "device_model";
    public static final String X = "dma";
    public static final String Y = "ip_address";
    public static final String Z = "language";
    public static final String a = "amplitude-android";
    public static final String a0 = "lat_lng";
    public static final String b = "Android";
    public static final String b0 = "os_name";
    public static final String c = "2.22.0";
    public static final String c0 = "os_version";
    public static final String d = "https://api.amplitude.com/";
    public static final String d0 = "platform";
    public static final String e = "com.amplitude.api";
    public static final String e0 = "region";
    public static final int f = 2;
    public static final String f0 = "version_name";
    public static final String g = "com.amplitude.api";
    public static final int h = 3;
    public static final String i = "$default_instance";
    public static final int j = 30;
    public static final int k = 50;
    public static final int l = 1000;
    public static final int m = 20;
    public static final long n = 30000L;
    public static final long o = 300000L;
    public static final long p = 1800000L;
    public static final int q = 1024;
    public static final int r = 1000;
    public static final String s = "com.amplitude.api";
    public static final String t = "com.amplitude.api.lastEventId";
    public static final String u = "com.amplitude.api.lastEventTime";
    public static final String v = "com.amplitude.api.lastIdentifyId";
    public static final String w = "com.amplitude.api.previousSessionId";
    public static final String x = "com.amplitude.api.deviceId";
    public static final String y = "com.amplitude.api.userId";
    public static final String z = "com.amplitude.api.optOut";
}

