/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.b
 *  l.a.h.i.a
 *  l.a.h.i.a$g
 *  l.a.h.i.b
 *  l.a.h.i.b$b
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.i.i.d
 *  l.a.i.i.d$d
 *  l.a.i.i.d$d$b
 *  l.a.i.i.j.c$c
 *  l.a.j.e$g
 *  l.a.j.e$g$a$a
 *  l.a.j.e$g$b
 *  l.a.l.r
 *  l.a.l.r$a
 *  l.a.l.s
 *  l.a.l.x
 */
package l.a.i.i.j;

import l.a.h.i.a;
import l.a.h.i.b;
import l.a.h.k.c;
import l.a.i.i.d;
import l.a.i.i.j.c;
import l.a.j.e;
import l.a.l.r;
import l.a.l.s;
import l.a.l.x;

public class c
extends e.g$a {
    protected final c d;

    protected c(l.a.h.k.c c2, d.c c3, e.g$a.a a2, c c4) {
        super(c2, c3, a2);
        this.d = c4;
    }

    private e.f d(a.g g2) {
        c.f f2 = this.a.a0();
        Object object = f2 == null ? new b.b() : (l.a.h.i.b)f2.u().b((r)s.a((a.g)g2).a((r)s.o((l.a.h.k.c)this.a)));
        if (object.size() == 1) {
            return e.f.c.a((a)object.b1(), this.a.a0().y0());
        }
        return e.f.b.c;
    }

    private e.f e(a.g g2) {
        d.d d2 = this.b.c().a(g2);
        if (d2.k().f()) {
            return e.f.c.a(d2.e(), this.a.a0().y0());
        }
        return e.f.b.c;
    }

    public l.a.h.k.b a() {
        return this.d.a(this.a);
    }

    @Override
    protected boolean a(Object object) {
        return object instanceof c;
    }

    public e.f b(a.g g2) {
        if (g2.b().equals((Object)"<init>")) {
            return this.d(g2);
        }
        return this.e(g2);
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof c)) {
            return false;
        }
        c c2 = (c)object;
        if (!c2.a(this)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        c c3 = this.d;
        c c4 = c2.d;
        return !(c3 == null ? c4 != null : !c3.equals((Object)c4));
    }

    @Override
    public int hashCode() {
        int n2 = 59 + super.hashCode();
        c c2 = this.d;
        int n3 = n2 * 59;
        int n4 = c2 == null ? 43 : c2.hashCode();
        return n3 + n4;
    }

}

