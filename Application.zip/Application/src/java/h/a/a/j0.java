/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.j
 *  io.github.classgraph.utils.e
 *  io.github.classgraph.utils.m
 *  io.github.classgraph.utils.p
 *  io.github.classgraph.utils.q
 *  java.io.Closeable
 *  java.io.File
 *  java.lang.AutoCloseable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.IllegalArgumentException
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  java.net.URL
 *  java.net.URLClassLoader
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package h.a.a;

import h.a.a.e0;
import h.a.a.h;
import h.a.a.h0;
import h.a.a.i;
import h.a.a.i0;
import h.a.a.k;
import h.a.a.l0;
import h.a.a.r;
import h.a.a.s0.f;
import h.a.a.s0.j;
import io.github.classgraph.utils.e;
import io.github.classgraph.utils.m;
import io.github.classgraph.utils.p;
import io.github.classgraph.utils.q;
import java.io.Closeable;
import java.io.File;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class j0
implements Closeable,
AutoCloseable {
    private static final Set<WeakReference<j0>> U4 = Collections.newSetFromMap((Map)new ConcurrentHashMap());
    private static final String V4 = "4";
    private Map<String, i0> P4;
    private i Q4;
    private volatile boolean R4;
    final p S4;
    private final WeakReference<j0> T4;
    final l0 c;
    private final List<String> d;
    private final List<r> f;
    private i0 h;
    final ClassLoader[] o;
    private final q s;
    private final Map<File, Long> t;
    private final Map<String, h.a.a.j> w;

    static {
        Runtime.getRuntime().addShutdownHook(new Thread(){

            public void run() {
                for (WeakReference weakReference : new ArrayList((Collection)U4)) {
                    j0 j02 = (j0)weakReference.get();
                    if (j02 != null) {
                        j02.close();
                        continue;
                    }
                    U4.remove((Object)weakReference);
                }
            }
        });
    }

    j0(l0 l02, List<r> list, List<String> list2, ClassLoader[] arrclassLoader, Map<String, h.a.a.j> map, Map<File, Long> map2, q q2, p p2) {
        WeakReference weakReference;
        this.c = l02;
        this.d = list2;
        this.f = list;
        for (r r2 : list) {
            if (r2.f == null) continue;
            if (this.h == null) {
                this.h = new i0();
                this.P4 = new HashMap();
            }
            this.h.addAll(r2.f);
            for (h0 h02 : r2.f) {
                String string = h02.getPath();
                i0 i02 = (i0)((Object)this.P4.get((Object)string));
                if (i02 == null) {
                    Map<String, i0> map3 = this.P4;
                    i0 i03 = new i0();
                    map3.put((Object)string, (Object)i03);
                    i02 = i03;
                }
                i02.add((Object)h02);
            }
        }
        this.o = arrclassLoader;
        this.t = map2;
        this.w = map;
        this.s = q2;
        this.S4 = p2;
        if (map != null) {
            Iterator iterator = map.values().iterator();
            while (iterator.hasNext()) {
                ((h.a.a.j)iterator.next()).a(this);
            }
        }
        this.Q4 = new i(this);
        this.T4 = weakReference = new WeakReference((Object)this);
        U4.add((Object)weakReference);
    }

    public static j0 p(String string) {
        IllegalArgumentException illegalArgumentException;
        Matcher matcher = Pattern.compile((String)"\\{[\\n\\r ]*\"serializationFormat\"[ ]?:[ ]?\"([^\"]+)\"").matcher((CharSequence)string);
        if (matcher.find()) {
            if (V4.equals((Object)matcher.group(1))) {
                b b2 = f.a(b.class, string);
                if (b2.a.equals((Object)V4)) {
                    List<URL> list = new h().a((Iterable<?>)b2.c).p();
                    ClassLoader[] arrclassLoader = new e(b2.b, null).a();
                    ClassLoader classLoader = null;
                    if (arrclassLoader != null) {
                        classLoader = arrclassLoader.length == 0 ? null : arrclassLoader[0];
                    }
                    ClassLoader[] arrclassLoader2 = new ClassLoader[]{new URLClassLoader((URL[])list.toArray((Object[])new URL[0]), classLoader)};
                    HashMap hashMap = new HashMap();
                    for (h.a.a.j j2 : b2.d) {
                        j2.X4 = arrclassLoader2;
                        hashMap.put((Object)j2.P(), (Object)j2);
                    }
                    j0 j02 = new j0(b2.b, (List<r>)Collections.emptyList(), b2.c, arrclassLoader2, (Map<String, h.a.a.j>)hashMap, null, null, null);
                    return j02;
                }
                throw new IllegalArgumentException("JSON was serialized by newer version of ClassGraph");
            }
            throw new IllegalArgumentException("JSON was serialized in a different format from the format used by the current version of ClassGraph -- please serialize and deserialize your ScanResult using the same version of ClassGraph");
        }
        illegalArgumentException = new IllegalArgumentException("JSON is not in correct format");
        throw illegalArgumentException;
    }

    public long a() {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            long l2 = 0L;
            if (this.t != null) {
                long l3 = System.currentTimeMillis();
                Iterator iterator = this.t.values().iterator();
                while (iterator.hasNext()) {
                    long l4 = (Long)iterator.next();
                    if (l4 <= l2 || l4 >= l3) continue;
                    l2 = l4;
                }
            }
            return l2;
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    public i0 a(Pattern pattern) {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            i0 i02 = this.h;
            if (i02 != null && !i02.isEmpty()) {
                i0 i03 = new i0();
                Iterator iterator = this.h.iterator();
                while (iterator.hasNext()) {
                    h0 h02 = (h0)iterator.next();
                    if (!pattern.matcher((CharSequence)h02.getPath()).matches()) continue;
                    i03.add((Object)h02);
                }
                return i03;
            }
            return new i0(1);
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    <T> Class<T> a(String string, Class<T> class_, boolean bl) throws IllegalArgumentException {
        if (!this.R4) {
            if (string != null && !string.isEmpty()) {
                if (class_ != null) {
                    Class class_2;
                    block8 : {
                        block9 : {
                            try {
                                class_2 = Class.forName((String)string, (boolean)this.c.I, (ClassLoader)this.Q4);
                                if (class_2 == null) break block8;
                            }
                            catch (Throwable throwable) {
                                if (bl) {
                                    return null;
                                }
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Could not load class ");
                                stringBuilder.append(string);
                                stringBuilder.append(" : ");
                                stringBuilder.append((Object)throwable);
                                throw new IllegalArgumentException(stringBuilder.toString());
                            }
                            if (class_.isAssignableFrom(class_2)) break block8;
                            if (!bl) break block9;
                            return null;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Loaded class ");
                        stringBuilder.append(class_2.getName());
                        stringBuilder.append(" cannot be cast to ");
                        stringBuilder.append(class_.getName());
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    return class_2;
                }
                throw new IllegalArgumentException("superclassOrInterfaceType parameter cannot be null");
            }
            throw new IllegalArgumentException("className cannot be null or empty");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    Class<?> a(String string, boolean bl) throws IllegalArgumentException {
        if (!this.R4) {
            if (string != null && !string.isEmpty()) {
                try {
                    Class class_ = Class.forName((String)string, (boolean)this.c.I, (ClassLoader)this.Q4);
                    return class_;
                }
                catch (Throwable throwable) {
                    if (bl) {
                        return null;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Could not load class ");
                    stringBuilder.append(string);
                    stringBuilder.append(" : ");
                    stringBuilder.append((Object)throwable);
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
            }
            throw new IllegalArgumentException("className cannot be null or empty");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public String a(int n2) {
        if (!this.R4) {
            if (this.c.q) {
                ArrayList arrayList = new ArrayList(this.w.values());
                Collections.sort((List)arrayList);
                return j.a(new b(V4, this.c, (List<h.a.a.j>)arrayList, this.d), n2, false);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k b(String string) {
        if (!this.R4) {
            l0 l02 = this.c;
            if (l02.q && l02.t) {
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.i();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() and #enableAnnotationInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public boolean b() {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            Map<File, Long> map = this.t;
            if (map == null) {
                return true;
            }
            for (Map.Entry entry : map.entrySet()) {
                if (((File)entry.getKey()).lastModified() == ((Long)entry.getValue()).longValue()) continue;
                return true;
            }
            return false;
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    public k c() {
        if (!this.R4) {
            l0 l02 = this.c;
            if (l02.q && l02.t) {
                return h.a.a.j.a((Collection)this.w.values(), (l0)this.c, (j0)this);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() and #enableAnnotationInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public void close() {
        if (!this.R4) {
            Map<File, Long> map;
            List<String> list;
            q q2;
            Map<String, h.a.a.j> map2;
            List<r> list2;
            this.R4 = true;
            i0 i02 = this.h;
            if (i02 != null) {
                Iterator iterator = i02.iterator();
                while (iterator.hasNext()) {
                    ((h0)iterator.next()).close();
                }
                this.h.clear();
                this.P4.clear();
            }
            if ((list = this.d) != null) {
                list.clear();
            }
            if ((q2 = this.s) != null) {
                q2.a(this.S4);
            }
            if ((list2 = this.f) != null) {
                Iterator iterator = list2.iterator();
                while (iterator.hasNext()) {
                    ((r)iterator.next()).a();
                }
                this.f.clear();
            }
            if ((map2 = this.w) != null) {
                map2.clear();
            }
            if ((map = this.t) != null) {
                map.clear();
            }
            this.Q4 = null;
            U4.remove(this.T4);
            p p2 = this.S4;
            if (p2 != null) {
                p2.b();
            }
        }
    }

    public h.a.a.j d(String string) {
        if (!this.R4) {
            if (this.c.q) {
                return (h.a.a.j)this.w.get((Object)string);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k d() {
        if (!this.R4) {
            if (this.c.q) {
                return h.a.a.j.b((Collection)this.w.values(), (l0)this.c, (j0)this);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k e() {
        if (!this.R4) {
            if (this.c.q) {
                return h.a.a.j.c((Collection)this.w.values(), (l0)this.c, (j0)this);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k f(String string) {
        if (!this.R4) {
            if (this.c.q) {
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.k();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    protected void finalize() throws Throwable {
        this.close();
    }

    public k g() {
        if (!this.R4) {
            l0 l02 = this.c;
            if (l02.q && l02.t) {
                return h.a.a.j.d((Collection)this.w.values(), (l0)this.c, (j0)this);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() and #enableAnnotationInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k g(String string) {
        if (!this.R4) {
            l0 l02 = this.c;
            if (l02.q && l02.t) {
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.l();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() and #enableAnnotationInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public i0 h() {
        i0 i02 = this.h;
        if (i02 != null && !i02.isEmpty()) {
            return this.h;
        }
        return new i0(1);
    }

    public k h(String string) {
        if (!this.R4) {
            l0 l02 = this.c;
            if (l02.q && l02.r && l02.t) {
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.n();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo(), #enableFieldInfo(), and #enableAnnotationInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k i() {
        if (!this.R4) {
            if (this.c.q) {
                return h.a.a.j.e((Collection)this.w.values(), (l0)this.c, (j0)this);
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k i(String string) {
        if (!this.R4) {
            l0 l02 = this.c;
            if (l02.q && l02.s && l02.t) {
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.p();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo(), #enableMethodInfo(), and #enableAnnotationInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public k j(String string) {
        if (!this.R4) {
            if (this.c.q) {
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.E();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public String j() {
        if (!this.R4) {
            return m.a(this.k());
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public i0 k(String string) {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            i0 i02 = this.h;
            if (i02 != null && !i02.isEmpty()) {
                while (string.startsWith(".")) {
                    string = string.substring(1);
                }
                i0 i03 = new i0();
                Iterator iterator = this.h.iterator();
                while (iterator.hasNext()) {
                    h0 h02 = (h0)iterator.next();
                    String string2 = h02.getPath();
                    int n2 = string2.lastIndexOf(47);
                    int n3 = string2.lastIndexOf(46);
                    if (n3 <= n2 || !string2.substring(n3 + 1).equalsIgnoreCase(string)) continue;
                    i03.add((Object)h02);
                }
                return i03;
            }
            return new i0(1);
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    public List<File> k() {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            ArrayList arrayList = new ArrayList();
            for (r r2 : this.f) {
                e0 e02 = r2.c();
                if (e02 != null) {
                    File file;
                    if (e02.o() || (file = e02.h()) == null) continue;
                    arrayList.add((Object)file);
                    continue;
                }
                arrayList.add((Object)r2.a(this.S4));
            }
            return arrayList;
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    public i0 l(String string) {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            i0 i02 = this.h;
            if (i02 != null && !i02.isEmpty()) {
                i0 i03 = new i0();
                Iterator iterator = this.h.iterator();
                while (iterator.hasNext()) {
                    h0 h02 = (h0)iterator.next();
                    String string2 = h02.getPath();
                    if (!string2.substring(1 + string2.lastIndexOf(47)).equals((Object)string)) continue;
                    i03.add((Object)h02);
                }
                return i03;
            }
            return new i0(1);
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    /*
     * Exception decompiling
     */
    public List<URL> l() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl12 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public i0 m(String string) {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            i0 i02 = this.h;
            if (i02 != null && !i02.isEmpty()) {
                while (string.startsWith("/")) {
                    string = string.substring(1);
                }
                i0 i03 = (i0)((Object)this.P4.get((Object)string));
                if (i03 == null) {
                    i03 = new i0(1);
                }
                return i03;
            }
            return new i0(1);
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    public List<e0> m() {
        IllegalArgumentException illegalArgumentException;
        if (!this.R4) {
            ArrayList arrayList = new ArrayList();
            Iterator iterator = this.f.iterator();
            while (iterator.hasNext()) {
                e0 e02 = ((r)iterator.next()).c();
                if (e02 == null) continue;
                arrayList.add((Object)e02);
            }
            return arrayList;
        }
        illegalArgumentException = new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
        throw illegalArgumentException;
    }

    public k n(String string) {
        if (!this.R4) {
            if (this.c.q) {
                if (string.equals((Object)"java.lang.Object")) {
                    return this.i();
                }
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.S();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    public String n() {
        return this.a(0);
    }

    public k o(String string) {
        if (!this.R4) {
            if (this.c.q) {
                h.a.a.j j2 = (h.a.a.j)this.w.get((Object)string);
                if (j2 == null) {
                    return k.f;
                }
                return j2.U();
            }
            throw new IllegalArgumentException("Please call ClassGraph#enableClassInfo() before #scan()");
        }
        throw new IllegalArgumentException("Cannot use a ScanResult after it has been closed");
    }

    private static class b {
        public String a;
        public l0 b;
        public List<String> c;
        public List<h.a.a.j> d;

        public b() {
        }

        public b(String string, l0 l02, List<h.a.a.j> list, List<String> list2) {
            this.a = string;
            this.b = l02;
            this.c = list2;
            this.d = list;
        }
    }

}

