/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  edu.umd.cs.findbugs.annotations.SuppressFBWarnings
 *  java.lang.Class
 *  java.lang.ClassFormatError
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Package
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.instrument.ClassFileTransformer
 *  java.lang.instrument.IllegalClassFormatException
 *  java.net.URL
 *  java.security.AccessControlContext
 *  java.security.AccessController
 *  java.security.PrivilegedAction
 *  java.security.ProtectionDomain
 *  java.util.Enumeration
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.ConcurrentMap
 *  l.a.h.k.c
 *  l.a.i.h.a$b
 *  l.a.i.h.a$c
 *  l.a.i.h.a$d
 *  l.a.i.h.a$e
 *  l.a.i.h.a$e$a
 *  l.a.i.h.a$f
 *  l.a.i.h.a$g
 *  l.a.i.h.a$h
 *  l.a.i.h.a$h$a
 *  l.a.i.h.a$h$d
 *  l.a.i.h.c
 *  l.a.i.h.e
 *  l.a.i.h.g
 *  l.a.i.h.h
 */
package l.a.i.h;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.net.URL;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import l.a.i.h.a;
import l.a.i.h.h;

/*
 * Exception performing whole class analysis.
 */
public class a
extends l.a.i.h.e {
    public static final String g = "bytebuddy";
    private static final int h;
    private static final Class<?> i;
    private static final URL j;
    private static final e k;
    protected static final d l;
    protected final ConcurrentMap<String, byte[]> a;
    protected final f b;
    protected final ProtectionDomain c;
    protected final l.a.i.h.h d;
    protected final ClassFileTransformer e;
    protected final AccessControlContext f;

    static {
        k = AccessController.doPrivileged((PrivilegedAction)a.c);
        l = (d)AccessController.doPrivileged((PrivilegedAction)a.c);
    }

    public a(ClassLoader classLoader, Map<String, byte[]> map) {
        this(classLoader, map, f.f);
    }

    public a(ClassLoader classLoader, Map<String, byte[]> map, ProtectionDomain protectionDomain, f f2, l.a.i.h.h h2) {
        this(classLoader, map, protectionDomain, f2, h2, (ClassFileTransformer)l.a.i.h.g.c);
    }

    public a(ClassLoader classLoader, Map<String, byte[]> map, ProtectionDomain protectionDomain, f f2, l.a.i.h.h h2, ClassFileTransformer classFileTransformer) {
        super(classLoader);
        this.a = new ConcurrentHashMap(map);
        this.c = protectionDomain;
        this.b = f2;
        this.d = h2;
        this.e = classFileTransformer;
        this.f = AccessController.getContext();
    }

    public a(ClassLoader classLoader, Map<String, byte[]> map, f f2) {
        this(classLoader, map, l.a.i.h.c.p0, f2, h.d.c);
    }

    static /* synthetic */ Class a(a a2, String string, byte[] arrby, int n2, int n3, ProtectionDomain protectionDomain) throws ClassFormatError {
        return a2.defineClass(string, arrby, n2, n3, protectionDomain);
    }

    @SuppressFBWarnings(justification="Privilege is explicit user responsibility", value={"DP_CREATE_CLASSLOADER_INSIDE_DO_PRIVILEGED"})
    public static ClassLoader a(ClassLoader classLoader, Map<l.a.h.k.c, byte[]> map, ProtectionDomain protectionDomain, f f2, l.a.i.h.h h2, boolean bl) {
        HashMap hashMap = new HashMap();
        for (Map.Entry entry : map.entrySet()) {
            hashMap.put((Object)((l.a.h.k.c)entry.getKey()).getName(), entry.getValue());
        }
        if (bl) {
            b b2 = new /* Unavailable Anonymous Inner Class!! */;
            return b2;
        }
        a a2 = new a(classLoader, (Map<String, byte[]>)hashMap, protectionDomain, f2, h2);
        return a2;
    }

    private Package a(String string) {
        return this.getPackage(string);
    }

    static /* synthetic */ Package a(a a2, String string) {
        return a2.a(string);
    }

    static /* synthetic */ Package a(a a2, String string, String string2, String string3, String string4, String string5, String string6, String string7, URL uRL) throws IllegalArgumentException {
        return a2.definePackage(string, string2, string3, string4, string5, string6, string7, uRL);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Map<l.a.h.k.c, Class<?>> a(ClassLoader classLoader, Map<l.a.h.k.c, byte[]> map, ProtectionDomain protectionDomain, f f2, l.a.i.h.h h2, boolean bl, boolean bl2) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        ClassLoader classLoader2 = a.a(classLoader, map, protectionDomain, f2, h2, bl);
        Iterator iterator = map.keySet().iterator();
        while (iterator.hasNext()) {
            l.a.h.k.c c2 = (l.a.h.k.c)iterator.next();
            try {
                Class class_ = Class.forName((String)c2.getName(), (boolean)false, (ClassLoader)classLoader2);
                if (bl2 && class_.getClassLoader() != classLoader2) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Class already loaded: ");
                    stringBuilder.append((Object)class_);
                    throw new IllegalStateException(stringBuilder.toString());
                }
                linkedHashMap.put((Object)c2, (Object)class_);
            }
            catch (ClassNotFoundException classNotFoundException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot load class ");
                stringBuilder.append((Object)c2);
                throw new IllegalStateException(stringBuilder.toString(), (Throwable)classNotFoundException);
            }
        }
        return linkedHashMap;
    }

    static /* synthetic */ e a() {
        return k;
    }

    static /* synthetic */ URL b() {
        return j;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Class<?> a(String string, byte[] arrby) throws ClassNotFoundException {
        Object object;
        Object object2 = object = l.c().a((ClassLoader)this, string);
        synchronized (object2) {
            Class class_;
            byte[] arrby2;
            block8 : {
                arrby2 = (byte[])this.a.putIfAbsent((Object)string, (Object)arrby);
                try {
                    class_ = this.loadClass(string);
                    if (class_ == null) break block8;
                }
                catch (Throwable throwable) {
                    if (arrby2 == null) {
                        this.a.remove((Object)string);
                        throw throwable;
                    }
                    this.a.put((Object)string, (Object)arrby2);
                    throw throwable;
                }
                if (class_.getClassLoader() == this) return class_;
            }
            if (arrby2 == null) {
                this.a.remove((Object)string);
            } else {
                this.a.put((Object)string, (Object)arrby2);
            }
            return class_;
        }
    }

    protected Class<?> findClass(String string) throws ClassNotFoundException {
        byte[] arrby = this.b.a(string, this.a);
        if (arrby != null) {
            block4 : {
                try {
                    byte[] arrby2 = this.e.transform((ClassLoader)this, string, i, this.c, arrby);
                    if (arrby2 == null) break block4;
                    arrby = arrby2;
                }
                catch (IllegalClassFormatException illegalClassFormatException) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("The class file for ");
                    stringBuilder.append(string);
                    stringBuilder.append(" is not legal");
                    throw new IllegalStateException(stringBuilder.toString(), (Throwable)illegalClassFormatException);
                }
            }
            Class class_ = (Class)AccessController.doPrivileged((PrivilegedAction)new /* Unavailable Anonymous Inner Class!! */, (AccessControlContext)this.f);
            return class_;
        }
        throw new ClassNotFoundException(string);
    }

    protected URL findResource(String string) {
        return this.b.b(string, this.a);
    }

    protected Enumeration<URL> findResources(String string) {
        URL uRL = this.b.b(string, this.a);
        if (uRL == null) {
            return d.c;
        }
        return new /* Unavailable Anonymous Inner Class!! */;
    }
}

