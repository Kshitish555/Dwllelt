/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public final class g
extends Enum<g>
implements e {
    public static final /* enum */ g c;
    private static final /* synthetic */ g[] d;

    static {
        g g2;
        c = g2 = new g();
        d = new g[]{g2};
    }

    public static g valueOf(String string) {
        return (g)Enum.valueOf(g.class, (String)string);
    }

    public static g[] values() {
        return (g[])d.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(191);
        return f.f.e();
    }

    public boolean x() {
        return true;
    }
}

