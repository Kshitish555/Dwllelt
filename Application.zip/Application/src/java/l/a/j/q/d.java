/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.k.b
 *  l.a.j.q.d$a
 *  l.a.j.q.d$b
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q;

import l.a.j.e;
import l.a.j.q.d;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public class d
extends Enum<d>
implements e {
    public static final /* enum */ d f;
    public static final /* enum */ d h;
    public static final /* enum */ d o;
    private static final /* synthetic */ d[] s;
    private final e.c c;
    private final int d;

    static {
        d d2;
        f = new a("ZERO", 0, f.d, 0);
        h = new d(f.f, 87);
        o = d2 = new d(f.h, 88);
        d[] arrd = new d[]{f, h, d2};
        s = arrd;
    }

    private d(f f2, int n3) {
        this.c = f2.e();
        this.d = n3;
    }

    public static e a(l.a.h.k.b b2) {
        int n2 = b.a[b2.l().ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 == 3) {
                    return f;
                }
                throw new AssertionError();
            }
            return o;
        }
        return h;
    }

    public static d valueOf(String string) {
        return (d)Enum.valueOf(d.class, (String)string);
    }

    public static d[] values() {
        return (d[])s.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.d);
        return this.c;
    }

    public boolean x() {
        return true;
    }
}

