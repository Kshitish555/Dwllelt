/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.i.a
 *  l.a.j.p.c
 *  l.a.j.p.c$b
 *  l.a.j.p.c$b$d
 */
package l.a.j.p;

import l.a.h.i.a;
import l.a.j.p.c;

public final class d
extends Enum<d>
implements c.b {
    public static final /* enum */ d c;
    private static final /* synthetic */ d[] d;

    static {
        d d2;
        c = d2 = new d();
        d = new d[]{d2};
    }

    public static d valueOf(String string) {
        return (d)Enum.valueOf(d.class, (String)string);
    }

    public static d[] values() {
        return (d[])d.clone();
    }

    public c.b.d a(a a2, c.c c2, c.c c3) {
        boolean bl = c2.c().getName().equals((Object)a2.getName());
        if (bl ^ c3.c().getName().equals((Object)a2.getName())) {
            if (bl) {
                return c.b.d.f;
            }
            return c.b.d.h;
        }
        return c.b.d.o;
    }
}

