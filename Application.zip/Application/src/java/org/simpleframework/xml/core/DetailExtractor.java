/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  org.simpleframework.xml.DefaultType
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.core.ContactList;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.DetailScanner;
import org.simpleframework.xml.core.FieldScanner;
import org.simpleframework.xml.core.MethodScanner;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.ConcurrentCache;

class DetailExtractor {
    private final Cache<Detail> details = new ConcurrentCache<Detail>();
    private final Cache<ContactList> fields = new ConcurrentCache<ContactList>();
    private final Cache<ContactList> methods = new ConcurrentCache<ContactList>();
    private final DefaultType override;
    private final Support support;

    public DetailExtractor(Support support) {
        this(support, null);
    }

    public DetailExtractor(Support support, DefaultType defaultType) {
        this.override = defaultType;
        this.support = support;
    }

    private ContactList getFields(Class class_, Detail detail) throws Exception {
        FieldScanner fieldScanner = new FieldScanner(detail, this.support);
        if (detail != null) {
            this.fields.cache((Object)class_, fieldScanner);
        }
        return fieldScanner;
    }

    private ContactList getMethods(Class class_, Detail detail) throws Exception {
        MethodScanner methodScanner = new MethodScanner(detail, this.support);
        if (detail != null) {
            this.methods.cache((Object)class_, methodScanner);
        }
        return methodScanner;
    }

    public Detail getDetail(Class class_) {
        Detail detail = this.details.fetch((Object)class_);
        if (detail == null) {
            detail = new DetailScanner(class_, this.override);
            this.details.cache((Object)class_, detail);
        }
        return detail;
    }

    public ContactList getFields(Class class_) throws Exception {
        Detail detail;
        ContactList contactList = this.fields.fetch((Object)class_);
        if (contactList == null && (detail = this.getDetail(class_)) != null) {
            contactList = this.getFields(class_, detail);
        }
        return contactList;
    }

    public ContactList getMethods(Class class_) throws Exception {
        Detail detail;
        ContactList contactList = this.methods.fetch((Object)class_);
        if (contactList == null && (detail = this.getDetail(class_)) != null) {
            contactList = this.getMethods(class_, detail);
        }
        return contactList;
    }
}

