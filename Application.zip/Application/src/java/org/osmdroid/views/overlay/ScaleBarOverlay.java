/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Picture
 *  android.graphics.Rect
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IProjection
 *  org.osmdroid.util.constants.GeoConstants
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Picture;
import android.graphics.Rect;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IProjection;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.constants.GeoConstants;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

public class ScaleBarOverlay
extends Overlay
implements GeoConstants {
    private Paint barPaint;
    private final Context context;
    boolean imperial;
    private float lastLatitude;
    private int lastZoomLevel;
    boolean latitudeBar;
    float lineWidth;
    boolean longitudeBar;
    private final Rect mBounds;
    int minZoom;
    boolean nautical;
    private MapView.Projection projection;
    private final ResourceProxy resourceProxy;
    protected final Picture scaleBarPicture;
    public int screenHeight;
    public int screenWidth;
    private Paint textPaint;
    final int textSize;
    float xOffset;
    public float xdpi;
    float yOffset;
    public float ydpi;

    public ScaleBarOverlay(Context context) {
        this(context, new DefaultResourceProxyImpl(context));
    }

    /*
     * Exception decompiling
     */
    public ScaleBarOverlay(Context var1, ResourceProxy var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl141.1 : LDC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private void createScaleBarPicture(MapView mapView) {
        IProjection iProjection = mapView.getProjection();
        this.projection = iProjection;
        if (iProjection == null) {
            return;
        }
        IGeoPoint iGeoPoint = iProjection.fromPixels((float)(this.screenWidth / 2) - this.xdpi / 2.0f, (float)(this.screenHeight / 2));
        IGeoPoint iGeoPoint2 = this.projection.fromPixels((float)(this.screenWidth / 2) + this.xdpi / 2.0f, (float)(this.screenHeight / 2));
        int n2 = ((GeoPoint)iGeoPoint).distanceTo(iGeoPoint2);
        IGeoPoint iGeoPoint3 = this.projection.fromPixels((float)(this.screenWidth / 2), (float)(this.screenHeight / 2) - this.ydpi / 2.0f);
        IGeoPoint iGeoPoint4 = this.projection.fromPixels((float)(this.screenWidth / 2), (float)(this.screenHeight / 2) + this.ydpi / 2.0f);
        int n3 = ((GeoPoint)iGeoPoint3).distanceTo(iGeoPoint4);
        Canvas canvas = this.scaleBarPicture.beginRecording((int)this.xdpi, (int)this.ydpi);
        if (this.latitudeBar) {
            String string2 = this.scaleBarLengthText(n2, this.imperial, this.nautical);
            Rect rect = new Rect();
            this.textPaint.getTextBounds(string2, 0, string2.length(), rect);
            double d2 = rect.height();
            Double.isNaN((double)d2);
            int n4 = (int)(d2 / 5.0);
            canvas.drawRect(0.0f, 0.0f, this.xdpi, this.lineWidth, this.barPaint);
            float f2 = this.xdpi;
            float f3 = f2 + this.lineWidth;
            float f4 = (float)rect.height() + this.lineWidth;
            float f5 = n4;
            canvas.drawRect(f2, 0.0f, f3, f4 + f5, this.barPaint);
            if (!this.longitudeBar) {
                canvas.drawRect(0.0f, 0.0f, this.lineWidth, f5 + ((float)rect.height() + this.lineWidth), this.barPaint);
            }
            canvas.drawText(string2, this.xdpi / 2.0f - (float)(rect.width() / 2), f5 + ((float)rect.height() + this.lineWidth), this.textPaint);
        }
        if (this.longitudeBar) {
            String string3 = this.scaleBarLengthText(n3, this.imperial, this.nautical);
            Rect rect = new Rect();
            this.textPaint.getTextBounds(string3, 0, string3.length(), rect);
            double d3 = rect.height();
            Double.isNaN((double)d3);
            int n5 = (int)(d3 / 5.0);
            canvas.drawRect(0.0f, 0.0f, this.lineWidth, this.ydpi, this.barPaint);
            float f6 = this.ydpi;
            float f7 = rect.height();
            float f8 = this.lineWidth;
            float f9 = f7 + f8;
            float f10 = n5;
            canvas.drawRect(0.0f, f6, f9 + f10, f8 + this.ydpi, this.barPaint);
            if (!this.latitudeBar) {
                float f11 = rect.height();
                float f12 = this.lineWidth;
                canvas.drawRect(0.0f, 0.0f, f10 + (f11 + f12), f12, this.barPaint);
            }
            float f13 = f10 + ((float)rect.height() + this.lineWidth);
            float f14 = this.ydpi / 2.0f + (float)(rect.width() / 2);
            canvas.rotate(-90.0f, f13, f14);
            canvas.drawText(string3, f13, f14 + f10, this.textPaint);
        }
        this.scaleBarPicture.endRecording();
    }

    public void disableScaleBar() {
        this.setEnabled(false);
    }

    @Override
    public void draw(Canvas canvas, MapView mapView, boolean bl) {
        block6 : {
            IProjection iProjection;
            block8 : {
                IGeoPoint iGeoPoint;
                int n2;
                block7 : {
                    if (bl) {
                        return;
                    }
                    if (mapView.isAnimating()) {
                        return;
                    }
                    n2 = mapView.getZoomLevel();
                    if (n2 < this.minZoom) break block6;
                    iProjection = mapView.getProjection();
                    if (iProjection == null) {
                        return;
                    }
                    iGeoPoint = iProjection.fromPixels(this.screenWidth / 2, this.screenHeight / 2);
                    if (n2 != this.lastZoomLevel) break block7;
                    double d2 = iGeoPoint.getLatitudeE6();
                    Double.isNaN((double)d2);
                    int n3 = (int)(d2 / 1000000.0);
                    double d3 = this.lastLatitude;
                    Double.isNaN((double)d3);
                    if (n3 == (int)(d3 / 1000000.0)) break block8;
                }
                this.lastZoomLevel = n2;
                this.lastLatitude = iGeoPoint.getLatitudeE6();
                this.createScaleBarPicture(mapView);
            }
            this.mBounds.set(iProjection.getScreenRect());
            this.mBounds.offset((int)this.xOffset, (int)this.yOffset);
            Rect rect = this.mBounds;
            int n4 = rect.left;
            rect.set(n4, rect.top, n4 + this.scaleBarPicture.getWidth(), this.mBounds.top + this.scaleBarPicture.getHeight());
            canvas.drawPicture(this.scaleBarPicture, this.mBounds);
        }
    }

    public void drawLatitudeScale(boolean bl) {
        this.latitudeBar = bl;
    }

    public void drawLongitudeScale(boolean bl) {
        this.longitudeBar = bl;
    }

    public void enableScaleBar() {
        this.setEnabled(true);
    }

    public Paint getBarPaint() {
        return this.barPaint;
    }

    public Paint getTextPaint() {
        return this.textPaint;
    }

    protected String scaleBarLengthText(int n2, boolean bl, boolean bl2) {
        if (this.imperial) {
            double d2 = n2;
            if (d2 >= 8046.72) {
                ResourceProxy resourceProxy = this.resourceProxy;
                ResourceProxy.string string2 = ResourceProxy.string.format_distance_miles;
                Object[] arrobject = new Object[1];
                Double.isNaN((double)d2);
                arrobject[0] = (int)(d2 / 1609.344);
                return resourceProxy.getString(string2, arrobject);
            }
            if (d2 >= 321.8688) {
                ResourceProxy resourceProxy = this.resourceProxy;
                ResourceProxy.string string3 = ResourceProxy.string.format_distance_miles;
                Object[] arrobject = new Object[1];
                Double.isNaN((double)d2);
                double d3 = (int)(d2 / 160.9344);
                Double.isNaN((double)d3);
                arrobject[0] = d3 / 10.0;
                return resourceProxy.getString(string3, arrobject);
            }
            ResourceProxy resourceProxy = this.resourceProxy;
            ResourceProxy.string string4 = ResourceProxy.string.format_distance_feet;
            Object[] arrobject = new Object[1];
            Double.isNaN((double)d2);
            arrobject[0] = (int)(d2 * 3.2808399);
            return resourceProxy.getString(string4, arrobject);
        }
        if (this.nautical) {
            double d4 = n2;
            if (d4 >= 9260.0) {
                ResourceProxy resourceProxy = this.resourceProxy;
                ResourceProxy.string string5 = ResourceProxy.string.format_distance_nautical_miles;
                Object[] arrobject = new Object[1];
                Double.isNaN((double)d4);
                arrobject[0] = (int)(d4 / 1852.0);
                return resourceProxy.getString(string5, arrobject);
            }
            if (d4 >= 370.4) {
                ResourceProxy resourceProxy = this.resourceProxy;
                ResourceProxy.string string6 = ResourceProxy.string.format_distance_nautical_miles;
                Object[] arrobject = new Object[1];
                Double.isNaN((double)d4);
                double d5 = (int)(d4 / 185.2);
                Double.isNaN((double)d5);
                arrobject[0] = d5 / 10.0;
                return resourceProxy.getString(string6, arrobject);
            }
            ResourceProxy resourceProxy = this.resourceProxy;
            ResourceProxy.string string7 = ResourceProxy.string.format_distance_feet;
            Object[] arrobject = new Object[1];
            Double.isNaN((double)d4);
            arrobject[0] = (int)(d4 * 3.2808399);
            return resourceProxy.getString(string7, arrobject);
        }
        if (n2 >= 5000) {
            ResourceProxy resourceProxy = this.resourceProxy;
            ResourceProxy.string string8 = ResourceProxy.string.format_distance_kilometers;
            Object[] arrobject = new Object[]{n2 / 1000};
            return resourceProxy.getString(string8, arrobject);
        }
        if (n2 >= 200) {
            ResourceProxy resourceProxy = this.resourceProxy;
            ResourceProxy.string string9 = ResourceProxy.string.format_distance_kilometers;
            Object[] arrobject = new Object[1];
            double d6 = n2;
            Double.isNaN((double)d6);
            double d7 = (int)(d6 / 100.0);
            Double.isNaN((double)d7);
            arrobject[0] = d7 / 10.0;
            return resourceProxy.getString(string9, arrobject);
        }
        ResourceProxy resourceProxy = this.resourceProxy;
        ResourceProxy.string string10 = ResourceProxy.string.format_distance_meters;
        Object[] arrobject = new Object[]{n2};
        return resourceProxy.getString(string10, arrobject);
    }

    public void setBarPaint(Paint paint) {
        if (paint != null) {
            this.barPaint = paint;
            return;
        }
        throw new IllegalArgumentException("pBarPaint argument cannot be null");
    }

    public void setImperial() {
        this.imperial = true;
        this.nautical = false;
        this.lastZoomLevel = -1;
    }

    public void setLineWidth(float f2) {
        this.lineWidth = f2;
    }

    public void setMetric() {
        this.nautical = false;
        this.imperial = false;
        this.lastZoomLevel = -1;
    }

    public void setMinZoom(int n2) {
        this.minZoom = n2;
    }

    public void setNautical() {
        this.nautical = true;
        this.imperial = false;
        this.lastZoomLevel = -1;
    }

    public void setScaleBarOffset(float f2, float f3) {
        this.xOffset = f2;
        this.yOffset = f3;
    }

    public void setTextPaint(Paint paint) {
        if (paint != null) {
            this.textPaint = paint;
            return;
        }
        throw new IllegalArgumentException("pTextPaint argument cannot be null");
    }

    public void setTextSize(float f2) {
        this.textPaint.setTextSize(f2);
    }
}

