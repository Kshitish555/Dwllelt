/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 *  l.a.h.g.a
 *  l.a.h.i.a
 *  l.a.h.i.a$b
 *  l.a.h.i.a$c
 *  l.a.h.i.a$d
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.h.k.d
 *  l.a.h.k.d$e
 *  l.a.i.i.a
 *  l.a.i.i.a$b
 *  l.a.i.i.a$c
 *  l.a.i.i.a$c$a
 *  l.a.i.i.c
 *  l.a.j.e
 *  l.a.j.e$b
 *  l.a.j.e$c
 *  l.a.j.e$g
 *  l.a.j.g$c
 *  l.a.j.g$d
 *  l.a.j.g$d$a
 *  l.a.j.g$d$a$a
 *  l.a.j.g$d$a$b
 *  l.a.j.g$d$a$c
 *  l.a.j.g$d$a$d
 *  l.a.j.g$d$a$e
 *  l.a.j.g$d$a$f
 *  l.a.j.g$d$a$g
 *  l.a.j.g$d$a$h
 *  l.a.j.g$d$a$i
 *  l.a.j.g$d$a$j
 *  l.a.j.g$d$a$k
 *  l.a.j.g$d$a$l
 *  l.a.j.g$d$a$m
 *  l.a.j.g$d$a$n
 *  l.a.j.g$d$a$o
 *  l.a.j.g$d$a$p
 *  l.a.j.g$d$a$q
 *  l.a.j.g$d$a$r
 *  l.a.j.g$d$a$t
 *  l.a.j.g$d$b
 *  l.a.j.g$e
 *  l.a.j.g$g
 *  l.a.j.g$h
 *  l.a.j.g$h$a
 *  l.a.j.g$h$b
 *  l.a.j.g$h$c
 *  l.a.j.q.b
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 *  l.a.k.a.u
 *  l.a.n.b
 *  l.a.n.b$a
 *  l.a.n.b$b
 *  l.a.n.d
 */
package l.a.j;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.h.k.d;
import l.a.i.i.a;
import l.a.j.e;
import l.a.j.g;
import l.a.j.q.i.a;
import l.a.k.a.u;
import l.a.n.b;

/*
 * Exception performing whole class analysis.
 * Exception performing whole class analysis ignored.
 */
public class g
implements e.b {
    protected final a.d c;
    protected final List<?> d;
    protected final d f;
    protected final e h;
    protected final l.a.j.q.i.a o;
    protected final a.d s;

    protected g(a.d d2, List<?> list, d d3, e e2, l.a.j.q.i.a a2, a.d d4) {
        this.c = d2;
        this.d = list;
        this.f = d3;
        this.h = e2;
        this.o = a2;
        this.s = d4;
    }

    public static g a(Constructor<?> constructor, List<?> list) {
        return g.a((a.d)new a.b(constructor), list);
    }

    public static /* varargs */ g a(Constructor<?> constructor, Object ... arrobject) {
        return g.a((a.d)new a.b(constructor), arrobject);
    }

    public static g a(Method method, List<?> list) {
        return g.a((a.d)new a.c(method), list);
    }

    public static /* varargs */ g a(Method method, Object ... arrobject) {
        return g.a((a.d)new a.c(method), arrobject);
    }

    public static g a(a.d d2, List<?> list) {
        IllegalArgumentException illegalArgumentException;
        ArrayList arrayList = new ArrayList(list.size());
        for (Object object : list) {
            if (object instanceof Class) {
                object = new c.d((Class)object);
            } else if (l.a.n.d.d.c().isInstance(object)) {
                object = b.a.b((Object)object);
            } else if (l.a.n.d.f.c().isInstance(object)) {
                object = b.b.b((Object)object);
            }
            arrayList.add(object);
        }
        if (d2.b((List)arrayList)) {
            ArrayList arrayList2 = new ArrayList(arrayList.size());
            for (Object object : arrayList) {
                if (object instanceof l.a.h.k.c) {
                    object = u.f((String)((l.a.h.k.c)object).getDescriptor());
                } else if (object instanceof l.a.n.b) {
                    object = ((l.a.n.b)object).a();
                }
                arrayList2.add(object);
            }
            g g2 = new /* Unavailable Anonymous Inner Class!! */;
            return g2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Not a valid bootstrap method ");
        stringBuilder.append((Object)d2);
        stringBuilder.append(" for ");
        stringBuilder.append((Object)arrayList);
        illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
        throw illegalArgumentException;
    }

    public static /* varargs */ g a(a.d d2, Object ... arrobject) {
        return g.a(d2, Arrays.asList((Object[])arrobject));
    }

    public l.a.i.i.c a(l.a.i.i.c c2) {
        return this.f.a(c2);
    }

    public e.b a(l.a.j.q.i.a a2, a.d d2) {
        g g2 = new g(this.c, this.d, this.f, this.h, a2, d2);
        return g2;
    }

    public l.a.j.e a(l.a.j.e e2) {
        l.a.j.e[] arre = new l.a.j.e[2];
        g g2 = new g(this.c, this.d, this.f, e.d, this.o, this.s);
        arre[0] = g2;
        arre[1] = e2;
        return new e.c(arre);
    }

    protected d a() {
        return this.f;
    }

    public h a(String string) {
        return this.a(string, (a.b)a.c.a.c);
    }

    public h a(String string, a.b b2) {
        b b3 = new b(this.c, this.d, this.f, this.h, this.o, this.s, string, b2);
        return b3;
    }

    public /* varargs */ g a(a.b b2, String ... arrstring) {
        ArrayList arrayList = new ArrayList(arrstring.length);
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.h(arrstring[i2], b2));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(byte ... arrby) {
        ArrayList arrayList = new ArrayList(arrby.length);
        int n2 = arrby.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.c(arrby[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(char ... arrc) {
        ArrayList arrayList = new ArrayList(arrc.length);
        int n2 = arrc.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.d(arrc[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(double ... arrd) {
        ArrayList arrayList = new ArrayList(arrd.length);
        int n2 = arrd.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.f(arrd[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(float ... arrf) {
        ArrayList arrayList = new ArrayList(arrf.length);
        int n2 = arrf.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.i(arrf[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(int ... arrn) {
        ArrayList arrayList = new ArrayList(arrn.length);
        for (int n2 : arrn) {
            if (n2 >= 0) {
                arrayList.add((Object)new a.p(n2));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Method parameter indices cannot be negative: ");
            stringBuilder.append(n2);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(long ... arrl) {
        ArrayList arrayList = new ArrayList(arrl.length);
        int n2 = arrl.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.o(arrl[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(Class<?> ... arrclass) {
        return this.a((l.a.h.k.c[])new d.e(arrclass).toArray((Object[])new l.a.h.k.c[arrclass.length]));
    }

    public /* varargs */ g a(Object ... arrobject) {
        ArrayList arrayList = new ArrayList(arrobject.length);
        int n2 = arrobject.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)a.j.b((Object)arrobject[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(String ... arrstring) {
        return this.a((a.b)a.c.a.c, arrstring);
    }

    public /* varargs */ g a(l.a.h.g.a ... arra) {
        ArrayList arrayList = new ArrayList(arra.length);
        int n2 = arra.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.g(arra[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(l.a.h.k.c ... arrc) {
        ArrayList arrayList = new ArrayList(arrc.length);
        for (l.a.h.k.c c2 : arrc) {
            if (!c2.isPrimitive()) {
                arrayList.add((Object)new a.q(c2));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot assign null to primitive type: ");
            stringBuilder.append((Object)c2);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(l.a.n.b ... arrb) {
        ArrayList arrayList = new ArrayList(arrb.length);
        int n2 = arrb.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.n(arrb[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(short ... arrs) {
        ArrayList arrayList = new ArrayList(arrs.length);
        int n2 = arrs.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.r(arrs[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g a(boolean ... arrbl) {
        ArrayList arrayList = new ArrayList(arrbl.length);
        int n2 = arrbl.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.b(arrbl[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public l.a.j.q.b a(e.g g2) {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    protected boolean a(Object object) {
        return object instanceof g;
    }

    public h b(int n2) {
        if (n2 >= 0) {
            a a2 = new a(this.c, this.d, this.f, this.h, this.o, this.s, n2);
            return a2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Method parameter indices cannot be negative: ");
        stringBuilder.append(n2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public h b(Object object) {
        c c2 = new c(this.c, this.d, this.f, this.h, this.o, this.s, object);
        return c2;
    }

    public g b() {
        g g2 = new g(this.c, this.d, this.f.a((a)a.l.c), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g b(int ... arrn) {
        ArrayList arrayList = new ArrayList(arrn.length);
        int n2 = arrn.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.k(arrn[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g b(Class<?> ... arrclass) {
        return this.b((l.a.h.k.c[])new d.e(arrclass).toArray((Object[])new l.a.h.k.c[arrclass.length]));
    }

    public /* varargs */ g b(Object ... arrobject) {
        ArrayList arrayList = new ArrayList(arrobject.length);
        int n2 = arrobject.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)a.a.b((Object)arrobject[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g b(l.a.h.k.c ... arrc) {
        ArrayList arrayList = new ArrayList(arrc.length);
        int n2 = arrc.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.t(arrc[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public g c() {
        g g2 = new g(this.c, this.d, this.f.a((a)a.m.c), this.h, this.o, this.s);
        return g2;
    }

    public /* varargs */ g c(l.a.h.k.c ... arrc) {
        ArrayList arrayList = new ArrayList(arrc.length);
        int n2 = arrc.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new a.e(arrc[i2]));
        }
        g g2 = new g(this.c, this.d, this.f.a((List)arrayList), this.h, this.o, this.s);
        return g2;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof g)) {
            return false;
        }
        g g2 = (g)object;
        if (!g2.a((Object)this)) {
            return false;
        }
        a.d d2 = this.c;
        a.d d3 = g2.c;
        if (d2 == null ? d3 != null : !d2.equals((Object)d3)) {
            return false;
        }
        List<?> list = this.d;
        List<?> list2 = g2.d;
        if (list == null ? list2 != null : !list.equals(list2)) {
            return false;
        }
        d d4 = this.a();
        d d5 = g2.a();
        if (d4 == null ? d5 != null : !d4.equals((Object)d5)) {
            return false;
        }
        e e2 = this.h;
        e e3 = g2.h;
        if (e2 == null ? e3 != null : !e2.equals((Object)e3)) {
            return false;
        }
        l.a.j.q.i.a a2 = this.o;
        l.a.j.q.i.a a3 = g2.o;
        if (a2 == null ? a3 != null : !a2.equals((Object)a3)) {
            return false;
        }
        a.d d6 = this.s;
        a.d d7 = g2.s;
        return !(d6 == null ? d7 != null : !d6.equals((Object)d7));
    }

    public int hashCode() {
        a.d d2 = this.c;
        int n2 = 43;
        int n3 = d2 == null ? 43 : d2.hashCode();
        int n4 = n3 + 59;
        List<?> list = this.d;
        int n5 = n4 * 59;
        int n6 = list == null ? 43 : list.hashCode();
        int n7 = n5 + n6;
        d d3 = this.a();
        int n8 = n7 * 59;
        int n9 = d3 == null ? 43 : d3.hashCode();
        int n10 = n8 + n9;
        e e2 = this.h;
        int n11 = n10 * 59;
        int n12 = e2 == null ? 43 : e2.hashCode();
        int n13 = n11 + n12;
        l.a.j.q.i.a a2 = this.o;
        int n14 = n13 * 59;
        int n15 = a2 == null ? 43 : a2.hashCode();
        int n16 = n14 + n15;
        a.d d4 = this.s;
        int n17 = n16 * 59;
        if (d4 != null) {
            n2 = d4.hashCode();
        }
        return n17 + n2;
    }
}

