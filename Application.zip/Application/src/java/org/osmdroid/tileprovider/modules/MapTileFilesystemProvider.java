/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Runnable
 *  java.lang.String
 *  org.osmdroid.tileprovider.IRegisterReceiver
 *  org.osmdroid.tileprovider.modules.MapTileFileStorageProviderBase
 *  org.osmdroid.tileprovider.modules.MapTileFilesystemProvider$1
 *  org.osmdroid.tileprovider.modules.MapTileFilesystemProvider$TileLoader
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
 *  org.osmdroid.tileprovider.tilesource.TileSourceFactory
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import org.osmdroid.tileprovider.IRegisterReceiver;
import org.osmdroid.tileprovider.modules.MapTileFileStorageProviderBase;
import org.osmdroid.tileprovider.modules.MapTileFilesystemProvider;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Exception performing whole class analysis.
 */
public class MapTileFilesystemProvider
extends MapTileFileStorageProviderBase {
    private static final Logger logger;
    private final long mMaximumCachedFileAge;
    private ITileSource mTileSource;

    static {
        logger = LoggerFactory.getLogger(MapTileFilesystemProvider.class);
    }

    public MapTileFilesystemProvider(IRegisterReceiver iRegisterReceiver) {
        this(iRegisterReceiver, (ITileSource)TileSourceFactory.DEFAULT_TILE_SOURCE);
    }

    public MapTileFilesystemProvider(IRegisterReceiver iRegisterReceiver, ITileSource iTileSource) {
        this(iRegisterReceiver, iTileSource, 604800000L);
    }

    public MapTileFilesystemProvider(IRegisterReceiver iRegisterReceiver, ITileSource iTileSource, long l2) {
        super(iRegisterReceiver, 8, 40);
        this.mTileSource = iTileSource;
        this.mMaximumCachedFileAge = l2;
    }

    static /* synthetic */ ITileSource access$100(MapTileFilesystemProvider mapTileFilesystemProvider) {
        return mapTileFilesystemProvider.mTileSource;
    }

    static /* synthetic */ long access$200(MapTileFilesystemProvider mapTileFilesystemProvider) {
        return mapTileFilesystemProvider.mMaximumCachedFileAge;
    }

    static /* synthetic */ Logger access$300() {
        return logger;
    }

    public int getMaximumZoomLevel() {
        ITileSource iTileSource = this.mTileSource;
        if (iTileSource != null) {
            return iTileSource.getMaximumZoomLevel();
        }
        return 22;
    }

    public int getMinimumZoomLevel() {
        ITileSource iTileSource = this.mTileSource;
        if (iTileSource != null) {
            return iTileSource.getMinimumZoomLevel();
        }
        return 0;
    }

    protected String getName() {
        return "File System Cache Provider";
    }

    protected String getThreadGroupName() {
        return "filesystem";
    }

    protected Runnable getTileLoader() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public boolean getUsesDataConnection() {
        return false;
    }

    public void setTileSource(ITileSource iTileSource) {
        this.mTileSource = iTileSource;
    }
}

