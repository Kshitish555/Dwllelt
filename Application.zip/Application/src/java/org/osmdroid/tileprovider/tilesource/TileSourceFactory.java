/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package org.osmdroid.tileprovider.tilesource;

import java.util.ArrayList;
import java.util.Iterator;
import org.osmdroid.ResourceProxy;
import org.osmdroid.tileprovider.tilesource.CloudmadeTileSource;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.XYTileSource;

public class TileSourceFactory {
    public static final OnlineTileSourceBase BASE;
    public static final OnlineTileSourceBase BASE_OVERLAY_NL;
    public static final OnlineTileSourceBase CLOUDMADESMALLTILES;
    public static final OnlineTileSourceBase CLOUDMADESTANDARDTILES;
    public static final OnlineTileSourceBase CYCLEMAP;
    public static final OnlineTileSourceBase DEFAULT_TILE_SOURCE;
    public static final OnlineTileSourceBase FIETS_OVERLAY_NL;
    public static final OnlineTileSourceBase HILLS;
    public static final OnlineTileSourceBase MAPNIK;
    public static final OnlineTileSourceBase MAPQUESTAERIAL;
    public static final OnlineTileSourceBase MAPQUESTOSM;
    public static final OnlineTileSourceBase PUBLIC_TRANSPORT;
    public static final OnlineTileSourceBase ROADS_OVERLAY_NL;
    public static final OnlineTileSourceBase TOPO;
    private static ArrayList<ITileSource> mTileSources;

    static {
        ArrayList arrayList;
        XYTileSource xYTileSource = new XYTileSource("Mapnik", ResourceProxy.string.mapnik, 0, 18, 256, ".png", "http://tile.openstreetmap.org/");
        MAPNIK = xYTileSource;
        XYTileSource xYTileSource2 = new XYTileSource("CycleMap", ResourceProxy.string.cyclemap, 0, 17, 256, ".png", "http://a.tile.opencyclemap.org/cycle/", "http://b.tile.opencyclemap.org/cycle/", "http://c.tile.opencyclemap.org/cycle/");
        CYCLEMAP = xYTileSource2;
        XYTileSource xYTileSource3 = new XYTileSource("OSMPublicTransport", ResourceProxy.string.public_transport, 0, 17, 256, ".png", "http://tile.xn--pnvkarte-m4a.de/tilegen/");
        PUBLIC_TRANSPORT = xYTileSource3;
        XYTileSource xYTileSource4 = new XYTileSource("Base", ResourceProxy.string.base, 4, 17, 256, ".png", "http://topo.openstreetmap.de/base/");
        BASE = xYTileSource4;
        XYTileSource xYTileSource5 = new XYTileSource("Topo", ResourceProxy.string.topo, 4, 17, 256, ".png", "http://topo.openstreetmap.de/topo/");
        TOPO = xYTileSource5;
        XYTileSource xYTileSource6 = new XYTileSource("Hills", ResourceProxy.string.hills, 8, 17, 256, ".png", "http://topo.geofabrik.de/hills/");
        HILLS = xYTileSource6;
        CloudmadeTileSource cloudmadeTileSource = new CloudmadeTileSource("CloudMadeStandardTiles", ResourceProxy.string.cloudmade_standard, 0, 18, 256, ".png", "http://a.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s", "http://b.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s", "http://c.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s");
        CLOUDMADESTANDARDTILES = cloudmadeTileSource;
        CloudmadeTileSource cloudmadeTileSource2 = new CloudmadeTileSource("CloudMadeSmallTiles", ResourceProxy.string.cloudmade_small, 0, 21, 64, ".png", "http://a.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s", "http://b.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s", "http://c.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s");
        CLOUDMADESMALLTILES = cloudmadeTileSource2;
        XYTileSource xYTileSource7 = new XYTileSource("MapquestOSM", ResourceProxy.string.mapquest_osm, 0, 18, 256, ".png", "http://otile1.mqcdn.com/tiles/1.0.0/osm/", "http://otile2.mqcdn.com/tiles/1.0.0/osm/", "http://otile3.mqcdn.com/tiles/1.0.0/osm/", "http://otile4.mqcdn.com/tiles/1.0.0/osm/");
        MAPQUESTOSM = xYTileSource7;
        XYTileSource xYTileSource8 = new XYTileSource("MapquestAerial", ResourceProxy.string.mapquest_aerial, 0, 11, 256, ".png", "http://oatile1.mqcdn.com/naip/", "http://oatile2.mqcdn.com/naip/", "http://oatile3.mqcdn.com/naip/", "http://oatile4.mqcdn.com/naip/");
        MAPQUESTAERIAL = xYTileSource8;
        DEFAULT_TILE_SOURCE = MAPNIK;
        XYTileSource xYTileSource9 = new XYTileSource("Fiets", ResourceProxy.string.fiets_nl, 3, 18, 256, ".png", "http://overlay.openstreetmap.nl/openfietskaart-overlay/");
        FIETS_OVERLAY_NL = xYTileSource9;
        XYTileSource xYTileSource10 = new XYTileSource("BaseNL", ResourceProxy.string.base_nl, 0, 18, 256, ".png", "http://overlay.openstreetmap.nl/basemap/");
        BASE_OVERLAY_NL = xYTileSource10;
        XYTileSource xYTileSource11 = new XYTileSource("RoadsNL", ResourceProxy.string.roads_nl, 0, 18, 256, ".png", "http://overlay.openstreetmap.nl/roads/");
        ROADS_OVERLAY_NL = xYTileSource11;
        mTileSources = arrayList = new ArrayList();
        arrayList.add((Object)MAPNIK);
        mTileSources.add((Object)CYCLEMAP);
        mTileSources.add((Object)PUBLIC_TRANSPORT);
        mTileSources.add((Object)BASE);
        mTileSources.add((Object)TOPO);
        mTileSources.add((Object)HILLS);
        mTileSources.add((Object)CLOUDMADESTANDARDTILES);
        mTileSources.add((Object)CLOUDMADESMALLTILES);
        mTileSources.add((Object)MAPQUESTOSM);
        mTileSources.add((Object)MAPQUESTAERIAL);
    }

    public static void addTileSource(ITileSource iTileSource) {
        mTileSources.add((Object)iTileSource);
    }

    public static boolean containsTileSource(String string2) {
        Iterator iterator = mTileSources.iterator();
        while (iterator.hasNext()) {
            if (!((ITileSource)iterator.next()).name().equals((Object)string2)) continue;
            return true;
        }
        return false;
    }

    public static ITileSource getTileSource(int n2) throws IllegalArgumentException {
        IllegalArgumentException illegalArgumentException;
        for (ITileSource iTileSource : mTileSources) {
            if (iTileSource.ordinal() != n2) continue;
            return iTileSource;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No tile source at position: ");
        stringBuilder.append(n2);
        illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
        throw illegalArgumentException;
    }

    public static ITileSource getTileSource(String string2) throws IllegalArgumentException {
        IllegalArgumentException illegalArgumentException;
        for (ITileSource iTileSource : mTileSources) {
            if (!iTileSource.name().equals((Object)string2)) continue;
            return iTileSource;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No such tile source: ");
        stringBuilder.append(string2);
        illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
        throw illegalArgumentException;
    }

    public static ArrayList<ITileSource> getTileSources() {
        return mTileSources;
    }
}

