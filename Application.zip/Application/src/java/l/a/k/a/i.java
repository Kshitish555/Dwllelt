/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  l.a.k.a.m
 *  l.a.k.a.p
 *  l.a.k.a.q
 */
package l.a.k.a;

import l.a.k.a.g;
import l.a.k.a.m;
import l.a.k.a.p;
import l.a.k.a.q;

class i
extends m {
    i() {
    }

    void a(int n2, int n3, g g2, p p2) {
        super.a(n2, n3, g2, p2);
        m m2 = new m();
        this.a(g2, m2, 0);
        this.a(m2);
        this.a.g = 0;
    }
}

