/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Type
 *  java.util.Iterator
 *  java.util.List
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.j.q.j.b$a$a
 *  l.a.j.q.j.b$a$b
 *  l.a.j.q.j.c
 *  l.a.k.a.r
 */
package l.a.j.q.j;

import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import l.a.h.k.c;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.j.q.j.b;
import l.a.j.q.j.c;
import l.a.k.a.r;

/*
 * Exception performing whole class analysis.
 */
public class b
implements c {
    private final c.f a;
    private final a b;
    private final e.c c;

    protected b(c.f f2, a a2) {
        this.a = f2;
        this.b = a2;
        this.c = f.h.e().a(f2.l().e());
    }

    private static a a(l.a.h.k.b b2) {
        if (b2.isPrimitive()) {
            if (b2.a((Type)Boolean.TYPE)) {
                return a.a.f;
            }
            if (b2.a((Type)Byte.TYPE)) {
                return a.a.h;
            }
            if (b2.a((Type)Short.TYPE)) {
                return a.a.o;
            }
            if (b2.a((Type)Character.TYPE)) {
                return a.a.s;
            }
            if (b2.a((Type)Integer.TYPE)) {
                return a.a.t;
            }
            if (b2.a((Type)Long.TYPE)) {
                return a.a.w;
            }
            if (b2.a((Type)Float.TYPE)) {
                return a.a.P4;
            }
            if (b2.a((Type)Double.TYPE)) {
                return a.a.Q4;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot create array of type ");
            stringBuilder.append((Object)b2);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static b a(c.f f2) {
        return new b(f2, b.a((l.a.h.k.b)f2));
    }

    public e a(List<? extends e> list) {
        return new b(list);
    }

    protected boolean a(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (!b2.a(this)) {
            return false;
        }
        c.f f2 = this.getComponentType();
        c.f f3 = b2.getComponentType();
        if (f2 == null ? f3 != null : !f2.equals((Object)f3)) {
            return false;
        }
        a a2 = this.b;
        a a3 = b2.b;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public c.f getComponentType() {
        return this.a;
    }

    public int hashCode() {
        c.f f2 = this.getComponentType();
        int n2 = 43;
        int n3 = f2 == null ? 43 : f2.hashCode();
        int n4 = n3 + 59;
        a a2 = this.b;
        int n5 = n4 * 59;
        if (a2 != null) {
            n2 = a2.hashCode();
        }
        return n5 + n2;
    }

    protected static interface l.a.j.q.j.b$a
    extends e {
        public static final e.c x0 = f.d.e();

        public int e();
    }

    protected class b
    implements e {
        private final List<? extends e> c;

        protected b(List<? extends e> list) {
            this.c = list;
        }

        private b a() {
            return b.this;
        }

        public e.c a(r r2, e.d d2) {
            e.c c2 = l.a.j.q.k.f.a(this.c.size()).a(r2, d2).a(b.this.b.a(r2, d2));
            Iterator iterator = this.c.iterator();
            int n2 = 0;
            while (iterator.hasNext()) {
                e e2 = (e)iterator.next();
                r2.a(89);
                e.c c3 = c2.a(f.f.f());
                int n3 = n2 + 1;
                e.c c4 = c3.a(l.a.j.q.k.f.a(n2).a(r2, d2)).a(e2.a(r2, d2));
                r2.a(b.this.b.e());
                c2 = c4.a(b.this.c);
                n2 = n3;
            }
            return c2;
        }

        public boolean equals(Object object) {
            b b2;
            b b3;
            return this == object || object != null && b.class == object.getClass() && (b3 = b.this).equals((b2 = (b)object).a()) && this.c.equals(b2.c);
            {
            }
        }

        public int hashCode() {
            return this.c.hashCode();
        }

        public boolean x() {
            Iterator iterator = this.c.iterator();
            while (iterator.hasNext()) {
                if (((e)iterator.next()).x()) continue;
                return false;
            }
            return b.this.b.x();
        }
    }

}

