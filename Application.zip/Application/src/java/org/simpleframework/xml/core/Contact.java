/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.strategy.Type
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.strategy.Type;

interface Contact
extends Type {
    public Object get(Object var1) throws Exception;

    public Annotation getAnnotation();

    public Class getDeclaringClass();

    public Class getDependent();

    public Class[] getDependents();

    public String getName();

    public boolean isReadOnly();

    public void set(Object var1, Object var2) throws Exception;

    public String toString();
}

