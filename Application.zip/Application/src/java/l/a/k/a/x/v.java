/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.Stack
 *  l.a.k.a.x.n
 *  l.a.k.a.y.b
 */
package l.a.k.a.x;

import java.util.Stack;
import l.a.k.a.x.n;
import l.a.k.a.y.b;

public class v
extends b {
    private final b e;
    private final n f;
    private Stack g = new Stack();

    protected v(int n2, b b2, n n3) {
        super(n2);
        this.e = b2;
        this.f = n3;
    }

    public v(b b2, n n2) {
        this(327680, b2, n2);
    }

    public b a() {
        this.e.a();
        return this;
    }

    public void a(char c2) {
        this.e.a(c2);
    }

    public void a(String string) {
        this.g.push((Object)string);
        this.e.a(this.f.d(string));
    }

    public b b() {
        this.e.b();
        return this;
    }

    public b b(char c2) {
        this.e.b(c2);
        return this;
    }

    public void b(String string) {
        this.e.b(string);
    }

    public void c() {
        this.e.c();
        this.g.pop();
    }

    public void c(String string) {
        String string2 = (String)this.g.pop();
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(string2);
        stringBuffer.append('$');
        stringBuffer.append(string);
        String string3 = stringBuffer.toString();
        this.g.push((Object)string3);
        StringBuffer stringBuffer2 = new StringBuffer();
        stringBuffer2.append(this.f.d(string2));
        stringBuffer2.append('$');
        String string4 = stringBuffer2.toString();
        String string5 = this.f.d(string3);
        int n2 = string5.startsWith(string4) ? string4.length() : 1 + string5.lastIndexOf(36);
        this.e.c(string5.substring(n2));
    }

    public b d() {
        this.e.d();
        return this;
    }

    public void d(String string) {
        this.e.d(string);
    }

    public b e() {
        this.e.e();
        return this;
    }

    public b f() {
        this.e.f();
        return this;
    }

    public b g() {
        this.e.g();
        return this;
    }

    public b h() {
        this.e.h();
        return this;
    }

    public b i() {
        this.e.i();
        return this;
    }

    public void j() {
        this.e.j();
    }
}

