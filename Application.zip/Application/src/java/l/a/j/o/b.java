/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  edu.umd.cs.findbugs.annotations.SuppressFBWarnings
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.reflect.Type
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.Callable
 *  l.a.a
 *  l.a.b
 *  l.a.h.f.d
 *  l.a.h.i.a
 *  l.a.h.i.a$d
 *  l.a.h.i.a$f
 *  l.a.h.i.a$g
 *  l.a.h.i.b
 *  l.a.h.i.c
 *  l.a.h.i.d
 *  l.a.h.j.f
 *  l.a.h.j.f$a
 *  l.a.h.j.f$b
 *  l.a.h.j.f$d
 *  l.a.h.j.m
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.h.k.c$f
 *  l.a.h.k.c$f$f
 *  l.a.h.k.c$f$f$b
 *  l.a.i.b
 *  l.a.i.b$a
 *  l.a.i.b$a$b
 *  l.a.i.b$a$b$a$b
 *  l.a.i.b$a$c$b
 *  l.a.i.b$a$c$c
 *  l.a.i.b$a$c$d$c
 *  l.a.i.b$a$c$e
 *  l.a.i.i.d
 *  l.a.i.i.d$a
 *  l.a.i.i.d$c$a
 *  l.a.i.i.d$d
 *  l.a.i.i.j.a
 *  l.a.j.i
 *  l.a.j.i$a
 *  l.a.j.o.a
 *  l.a.j.o.b$c
 *  l.a.j.o.b$d
 *  l.a.j.q.c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.h
 *  l.a.j.q.i.a
 *  l.a.j.q.l.c
 *  l.a.j.q.l.e
 *  l.a.k.a.r
 *  l.a.l.r
 *  l.a.l.s
 *  l.a.l.x
 */
package l.a.j.o;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import l.a.h.i.a;
import l.a.h.j.f;
import l.a.h.j.m;
import l.a.h.k.c;
import l.a.i.b;
import l.a.i.i.d;
import l.a.i.i.j.a;
import l.a.j.e;
import l.a.j.i;
import l.a.j.o.a;
import l.a.j.o.b;
import l.a.j.q.e;
import l.a.j.q.h;
import l.a.l.r;
import l.a.l.s;
import l.a.l.x;

/*
 * Exception performing whole class analysis.
 */
public class b
implements a {
    private static final String h = "argument";
    private final e.f c;
    private final boolean d;
    private final l.a.j.q.i.a f;

    public b(e.f f2, boolean bl) {
        this(f2, bl, l.a.j.q.i.a.w0);
    }

    public b(e.f f2, boolean bl, l.a.j.q.i.a a2) {
        this.c = f2;
        this.d = bl;
        this.f = a2;
    }

    private static String a(int n2) {
        Object[] arrobject = new Object[]{h, n2};
        return String.format((String)"%s%d", (Object[])arrobject);
    }

    private static LinkedHashMap<String, l.a.h.k.c> a(l.a.h.i.a a2) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        boolean bl = a2.isStatic();
        int n2 = 0;
        if (!bl) {
            linkedHashMap.put((Object)b.a(0), (Object)a2.e().y0());
            n2 = 1;
        }
        for (l.a.h.i.c c2 : a2.getParameters()) {
            int n3 = n2 + 1;
            linkedHashMap.put((Object)b.a(n2), (Object)c2.getType().y0());
            n2 = n3;
        }
        return linkedHashMap;
    }

    public l.a.i.b a(String string, l.a.b b2, i i2) {
        a.d d2 = i2.a(this.c, i.a.f);
        LinkedHashMap<String, l.a.h.k.c> linkedHashMap = b.a((l.a.h.i.a)d2);
        b.a.c.e e2 = new l.a.a(b2).a((d.a)e.d).a(Object.class, (l.a.i.i.j.a)a.b.c).b(string).a(a.t0).b(new Type[]{Runnable.class, Callable.class}).a((l.a.j.e)new /* Unavailable Anonymous Inner Class!! */);
        Class[] arrclass = this.d ? new Class[]{Serializable.class} : new Class[]{};
        b.a.c.e e3 = e2.b((Type[])arrclass).a(new f.b[0]).h(linkedHashMap.values()).a((l.a.j.e)c.d);
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            String string2 = (String)entry.getKey();
            l.a.h.k.b b3 = (l.a.h.k.b)entry.getValue();
            f.a[] arra = new f.a[]{m.o};
            e3 = e3.a(string2, b3, arra);
        }
        return e3.a();
    }

    protected boolean a(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (!b2.a(this)) {
            return false;
        }
        e.f f2 = this.c;
        e.f f3 = b2.c;
        if (f2 == null ? f3 != null : !f2.equals((Object)f3)) {
            return false;
        }
        if (this.d != b2.d) {
            return false;
        }
        l.a.j.q.i.a a2 = this.f;
        l.a.j.q.i.a a3 = b2.f;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public int hashCode() {
        e.f f2 = this.c;
        int n2 = 43;
        int n3 = f2 == null ? 43 : f2.hashCode();
        int n4 = 59 * (n3 + 59);
        int n5 = this.d ? 79 : 97;
        int n6 = n4 + n5;
        l.a.j.q.i.a a2 = this.f;
        int n7 = n6 * 59;
        if (a2 != null) {
            n2 = a2.hashCode();
        }
        return n7 + n2;
    }

    public static class b
    implements l.a.j.q.e {
        private final e.f c;
        private final boolean d;

        public b(e.f f2, boolean bl) {
            this.c = f2;
            this.d = bl;
        }

        public e.c a(l.a.k.a.r r2, e.d d2) {
            l.a.h.k.c c2 = d2.a(new b(this.c, this.d));
            l.a.j.q.e[] arre = new l.a.j.q.e[]{h.c((l.a.h.k.c)c2), l.a.j.q.c.h, l.a.j.q.l.e.a((l.a.h.i.a)this.c.i()).a(), l.a.j.q.l.c.a((a.d)((a.d)((l.a.h.i.b)c2.u().b((r)s.g())).b1()))};
            return new e.a(arre).a(r2, d2);
        }

        protected boolean b(Object object) {
            return object instanceof b;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof b)) {
                return false;
            }
            b b2 = (b)object;
            if (!b2.b(this)) {
                return false;
            }
            e.f f2 = this.c;
            e.f f3 = b2.c;
            if (f2 == null ? f3 != null : !f2.equals((Object)f3)) {
                return false;
            }
            return this.d == b2.d;
        }

        public int hashCode() {
            e.f f2 = this.c;
            int n2 = f2 == null ? 43 : f2.hashCode();
            int n3 = 59 * (n2 + 59);
            int n4 = this.d ? 79 : 97;
            return n3 + n4;
        }

        public boolean x() {
            return true;
        }
    }

    /*
     * Exception performing whole class analysis.
     */
    protected static final class e
    extends Enum<e>
    implements d.a {
        public static final /* enum */ e d;
        private static final /* synthetic */ e[] f;
        private final d.c c;

        static {
            e e2;
            d = e2 = new e();
            f = new e[]{e2};
        }

        @SuppressFBWarnings(justification="Precomputed method graph is not intended for serialization", value={"SE_BAD_FIELD_STORE"})
        private e() {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            a.f f2 = new a.f((l.a.h.k.c)new c.d(Callable.class), "call", 1025, Collections.emptyList(), c.f.b0, Collections.emptyList(), Collections.singletonList((Object)new c.f.f.b(Exception.class)), Collections.emptyList(), l.a.h.f.d.a, c.f.e0);
            linkedHashMap.put((Object)f2.h(), (Object)new d.d.a((l.a.h.i.a)f2));
            a.f f3 = new a.f((l.a.h.k.c)new c.d(Runnable.class), "run", 1025, Collections.emptyList(), c.f.c0, Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), l.a.h.f.d.a, c.f.e0);
            linkedHashMap.put((Object)f3.h(), (Object)new d.d.a((l.a.h.i.a)f3));
            d.f f4 = new d.f((LinkedHashMap<a.g, d.d>)linkedHashMap);
            this.c = new /* Unavailable Anonymous Inner Class!! */;
        }

        public static e valueOf(String string) {
            return (e)Enum.valueOf(e.class, (String)string);
        }

        public static e[] values() {
            return (e[])f.clone();
        }

        public d.c a(l.a.h.k.b b2, l.a.h.k.c c2) {
            return this.c;
        }

        public d.c a(l.a.h.k.c c2) {
            return this.a((l.a.h.k.b)c2, c2);
        }
    }

}

