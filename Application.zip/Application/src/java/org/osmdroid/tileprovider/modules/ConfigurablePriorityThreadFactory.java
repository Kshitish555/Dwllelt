/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.concurrent.ThreadFactory
 */
package org.osmdroid.tileprovider.modules;

import java.util.concurrent.ThreadFactory;

public class ConfigurablePriorityThreadFactory
implements ThreadFactory {
    private final String mName;
    private final int mPriority;

    public ConfigurablePriorityThreadFactory(int n2, String string2) {
        this.mPriority = n2;
        this.mName = string2;
    }

    public Thread newThread(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setPriority(this.mPriority);
        String string2 = this.mName;
        if (string2 != null) {
            thread.setName(string2);
        }
        return thread;
    }
}

