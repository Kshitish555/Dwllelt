/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.io.Serializable
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.ArrayList
 *  java.util.Iterator
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.util.BoundingBoxE6$1
 *  org.osmdroid.views.util.constants.MapViewConstants
 */
package org.osmdroid.util;

import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.util.BoundingBoxE6;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MyMath;
import org.osmdroid.views.util.constants.MapViewConstants;

public class BoundingBoxE6
implements Parcelable,
Serializable,
MapViewConstants {
    public static final Parcelable.Creator<BoundingBoxE6> CREATOR = new 1();
    static final long serialVersionUID = 2L;
    protected final int mLatNorthE6;
    protected final int mLatSouthE6;
    protected final int mLonEastE6;
    protected final int mLonWestE6;

    public BoundingBoxE6(double d, double d2, double d3, double d4) {
        this.mLatNorthE6 = (int)(d * 1000000.0);
        this.mLonEastE6 = (int)(d2 * 1000000.0);
        this.mLatSouthE6 = (int)(d3 * 1000000.0);
        this.mLonWestE6 = (int)(d4 * 1000000.0);
    }

    public BoundingBoxE6(int n, int n2, int n3, int n4) {
        this.mLatNorthE6 = n;
        this.mLonEastE6 = n2;
        this.mLatSouthE6 = n3;
        this.mLonWestE6 = n4;
    }

    static /* synthetic */ BoundingBoxE6 access$000(Parcel parcel) {
        return BoundingBoxE6.readFromParcel(parcel);
    }

    public static BoundingBoxE6 fromGeoPoints(ArrayList<? extends GeoPoint> arrayList) {
        Iterator iterator = arrayList.iterator();
        int n = Integer.MIN_VALUE;
        int n2 = Integer.MIN_VALUE;
        int n3 = Integer.MAX_VALUE;
        int n4 = Integer.MAX_VALUE;
        while (iterator.hasNext()) {
            GeoPoint geoPoint = (GeoPoint)iterator.next();
            int n5 = geoPoint.getLatitudeE6();
            int n6 = geoPoint.getLongitudeE6();
            n3 = Math.min((int)n3, (int)n5);
            n4 = Math.min((int)n4, (int)n6);
            n = Math.max((int)n, (int)n5);
            n2 = Math.max((int)n2, (int)n6);
        }
        return new BoundingBoxE6(n3, n4, n, n2);
    }

    private static BoundingBoxE6 readFromParcel(Parcel parcel) {
        return new BoundingBoxE6(parcel.readInt(), parcel.readInt(), parcel.readInt(), parcel.readInt());
    }

    public GeoPoint bringToBoundingBox(int n, int n2) {
        return new GeoPoint(Math.max((int)this.mLatSouthE6, (int)Math.min((int)this.mLatNorthE6, (int)n)), Math.max((int)this.mLonWestE6, (int)Math.min((int)this.mLonEastE6, (int)n2)));
    }

    public boolean contains(int n, int n2) {
        return n < this.mLatNorthE6 && n > this.mLatSouthE6 && n2 < this.mLonEastE6 && n2 > this.mLonWestE6;
    }

    public boolean contains(GeoPoint geoPoint) {
        return this.contains(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6());
    }

    public int describeContents() {
        return 0;
    }

    public GeoPoint getCenter() {
        return new GeoPoint((this.mLatNorthE6 + this.mLatSouthE6) / 2, (this.mLonEastE6 + this.mLonWestE6) / 2);
    }

    public int getDiagonalLengthInMeters() {
        return new GeoPoint(this.mLatNorthE6, this.mLonWestE6).distanceTo(new GeoPoint(this.mLatSouthE6, this.mLonEastE6));
    }

    public GeoPoint getGeoPointOfRelativePositionWithExactGudermannInterpolation(float f, float f2) {
        int n;
        double d = this.mLatNorthE6;
        Double.isNaN((double)d);
        double d2 = MyMath.gudermannInverse(d / 1000000.0);
        double d3 = this.mLatSouthE6;
        Double.isNaN((double)d3);
        double d4 = MyMath.gudermannInverse(d3 / 1000000.0);
        double d5 = 1.0f - f2;
        double d6 = d2 - d4;
        Double.isNaN((double)d5);
        int n2 = (int)((float)this.mLonWestE6 + f * (float)this.getLongitudeSpanE6());
        for (n = (int)(1000000.0 * MyMath.gudermann((double)(d4 + d5 * d6))); n > 90500000; n -= 90500000) {
        }
        while (n < -90500000) {
            n += 90500000;
        }
        while (n2 > 180000000) {
            n2 -= 180000000;
        }
        while (n2 < -180000000) {
            n2 += 180000000;
        }
        return new GeoPoint(n, n2);
    }

    public GeoPoint getGeoPointOfRelativePositionWithLinearInterpolation(float f, float f2) {
        int n;
        int n2 = (int)((float)this.mLonWestE6 + f * (float)this.getLongitudeSpanE6());
        for (n = (int)((float)this.mLatNorthE6 - f2 * (float)this.getLatitudeSpanE6()); n > 90500000; n -= 90500000) {
        }
        while (n < -90500000) {
            n += 90500000;
        }
        while (n2 > 180000000) {
            n2 -= 180000000;
        }
        while (n2 < -180000000) {
            n2 += 180000000;
        }
        return new GeoPoint(n, n2);
    }

    public int getLatNorthE6() {
        return this.mLatNorthE6;
    }

    public int getLatSouthE6() {
        return this.mLatSouthE6;
    }

    public int getLatitudeSpanE6() {
        return Math.abs((int)(this.mLatNorthE6 - this.mLatSouthE6));
    }

    public int getLonEastE6() {
        return this.mLonEastE6;
    }

    public int getLonWestE6() {
        return this.mLonWestE6;
    }

    public int getLongitudeSpanE6() {
        return Math.abs((int)(this.mLonEastE6 - this.mLonWestE6));
    }

    public PointF getRelativePositionOfGeoPointInBoundingBoxWithExactGudermannInterpolation(int n, int n2, PointF pointF) {
        if (pointF == null) {
            pointF = new PointF();
        }
        double d = this.mLatNorthE6;
        Double.isNaN((double)d);
        double d2 = MyMath.gudermannInverse(d / 1000000.0);
        double d3 = n;
        Double.isNaN((double)d3);
        double d4 = d2 - MyMath.gudermannInverse(d3 / 1000000.0);
        double d5 = this.mLatNorthE6;
        Double.isNaN((double)d5);
        double d6 = MyMath.gudermannInverse(d5 / 1000000.0);
        double d7 = this.mLatSouthE6;
        Double.isNaN((double)d7);
        float f = (float)(d4 / (d6 - MyMath.gudermannInverse(d7 / 1000000.0)));
        pointF.set(1.0f - (float)(this.mLonEastE6 - n2) / (float)this.getLongitudeSpanE6(), f);
        return pointF;
    }

    public PointF getRelativePositionOfGeoPointInBoundingBoxWithLinearInterpolation(int n, int n2, PointF pointF) {
        if (pointF == null) {
            pointF = new PointF();
        }
        float f = (float)(this.mLatNorthE6 - n) / (float)this.getLatitudeSpanE6();
        pointF.set(1.0f - (float)(this.mLonEastE6 - n2) / (float)this.getLongitudeSpanE6(), f);
        return pointF;
    }

    public BoundingBoxE6 increaseByScale(float f) {
        GeoPoint geoPoint = this.getCenter();
        int n = (int)(f * (float)this.getLatitudeSpanE6() / 2.0f);
        int n2 = (int)(f * (float)this.getLongitudeSpanE6() / 2.0f);
        return new BoundingBoxE6(n + geoPoint.getLatitudeE6(), n2 + geoPoint.getLongitudeE6(), geoPoint.getLatitudeE6() - n, geoPoint.getLongitudeE6() - n2);
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("N:");
        stringBuffer.append(this.mLatNorthE6);
        stringBuffer.append("; E:");
        stringBuffer.append(this.mLonEastE6);
        stringBuffer.append("; S:");
        stringBuffer.append(this.mLatSouthE6);
        stringBuffer.append("; W:");
        stringBuffer.append(this.mLonWestE6);
        return stringBuffer.toString();
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeInt(this.mLatNorthE6);
        parcel.writeInt(this.mLonEastE6);
        parcel.writeInt(this.mLatSouthE6);
        parcel.writeInt(this.mLonWestE6);
    }
}

