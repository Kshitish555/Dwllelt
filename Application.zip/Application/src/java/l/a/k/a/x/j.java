/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintStream
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalStateException
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.BitSet
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.t
 *  l.a.k.a.x.i
 *  net.bytebuddy.jar.asm.tree.AbstractInsnNode
 *  net.bytebuddy.jar.asm.tree.InsnList
 *  net.bytebuddy.jar.asm.tree.InsnNode
 *  net.bytebuddy.jar.asm.tree.JumpInsnNode
 *  net.bytebuddy.jar.asm.tree.LabelNode
 *  net.bytebuddy.jar.asm.tree.LocalVariableNode
 *  net.bytebuddy.jar.asm.tree.LookupSwitchInsnNode
 *  net.bytebuddy.jar.asm.tree.MethodNode
 *  net.bytebuddy.jar.asm.tree.TableSwitchInsnNode
 *  net.bytebuddy.jar.asm.tree.TryCatchBlockNode
 */
package l.a.k.a.x;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.t;
import l.a.k.a.x.i;
import net.bytebuddy.jar.asm.tree.AbstractInsnNode;
import net.bytebuddy.jar.asm.tree.InsnList;
import net.bytebuddy.jar.asm.tree.InsnNode;
import net.bytebuddy.jar.asm.tree.JumpInsnNode;
import net.bytebuddy.jar.asm.tree.LabelNode;
import net.bytebuddy.jar.asm.tree.LocalVariableNode;
import net.bytebuddy.jar.asm.tree.LookupSwitchInsnNode;
import net.bytebuddy.jar.asm.tree.MethodNode;
import net.bytebuddy.jar.asm.tree.TableSwitchInsnNode;
import net.bytebuddy.jar.asm.tree.TryCatchBlockNode;

public class j
extends MethodNode
implements t {
    static /* synthetic */ Class h;
    private final Map c = new HashMap();
    private final BitSet d = new BitSet();
    final BitSet f = new BitSet();

    static {
        h = j.a("net.bytebuddy.jar.asm.commons.JSRInlinerAdapter");
    }

    protected j(int n2, r r2, int n3, String string, String string2, String string3, String[] arrstring) {
        super(n2, n3, string, string2, string3, arrstring);
        this.mv = r2;
    }

    public j(r r2, int n2, String string, String string2, String string3, String[] arrstring) {
        this(327680, r2, n2, string, string2, string3, arrstring);
        if (j.class == h) {
            return;
        }
        throw new IllegalStateException();
    }

    static /* synthetic */ Class a(String string) {
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new NoClassDefFoundError(classNotFoundException.getMessage());
        }
    }

    private void a(BitSet bitSet, int n2, BitSet bitSet2) {
        this.b(bitSet, n2, bitSet2);
        boolean bl = true;
        while (bl) {
            bl = false;
            for (TryCatchBlockNode tryCatchBlockNode : this.tryCatchBlocks) {
                int n3 = this.instructions.indexOf((AbstractInsnNode)tryCatchBlockNode.handler);
                if (bitSet.get(n3)) continue;
                int n4 = this.instructions.indexOf((AbstractInsnNode)tryCatchBlockNode.start);
                int n5 = this.instructions.indexOf((AbstractInsnNode)tryCatchBlockNode.end);
                int n6 = bitSet.nextSetBit(n4);
                if (n6 == -1 || n6 >= n5) continue;
                this.b(bitSet, n3, bitSet2);
                bl = true;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void a(i i2, List list, InsnList insnList, List list2, List list3) {
        int n2 = this.instructions.size();
        LabelNode labelNode = null;
        for (int i3 = 0; i3 < n2; ++i3) {
            AbstractInsnNode abstractInsnNode;
            AbstractInsnNode abstractInsnNode2 = this.instructions.get(i3);
            i i4 = i2.a(i3);
            if (abstractInsnNode2.getType() == 8) {
                LabelNode labelNode2 = i2.b((LabelNode)abstractInsnNode2);
                if (labelNode2 == labelNode) continue;
                insnList.add((AbstractInsnNode)labelNode2);
                labelNode = labelNode2;
                continue;
            }
            if (i4 != i2) continue;
            if (abstractInsnNode2.getOpcode() == 169) {
                i i5 = i2;
                LabelNode labelNode3 = null;
                while (i5 != null) {
                    if (i5.d.get(i3)) {
                        labelNode3 = i5.h;
                    }
                    i5 = i5.c;
                }
                if (labelNode3 == null) {
                    StringBuffer stringBuffer = new StringBuffer();
                    stringBuffer.append("Instruction #");
                    stringBuffer.append(i3);
                    stringBuffer.append(" is a RET not owned by any subroutine");
                    throw new RuntimeException(stringBuffer.toString());
                }
                abstractInsnNode = new JumpInsnNode(167, labelNode3);
            } else {
                if (abstractInsnNode2.getOpcode() == 168) {
                    LabelNode labelNode4 = ((JumpInsnNode)abstractInsnNode2).label;
                    i i6 = new i(this, i2, (BitSet)this.c.get((Object)labelNode4));
                    LabelNode labelNode5 = i6.a(labelNode4);
                    insnList.add((AbstractInsnNode)new InsnNode(1));
                    insnList.add((AbstractInsnNode)new JumpInsnNode(167, labelNode5));
                    insnList.add((AbstractInsnNode)i6.h);
                    list.add((Object)i6);
                    continue;
                }
                abstractInsnNode = abstractInsnNode2.clone((Map)i2);
            }
            insnList.add(abstractInsnNode);
        }
        for (TryCatchBlockNode tryCatchBlockNode : this.tryCatchBlocks) {
            LabelNode labelNode6;
            LabelNode labelNode7 = i2.b(tryCatchBlockNode.start);
            if (labelNode7 == (labelNode6 = i2.b(tryCatchBlockNode.end))) continue;
            LabelNode labelNode8 = i2.a(tryCatchBlockNode.handler);
            if (labelNode7 != null && labelNode6 != null && labelNode8 != null) {
                list2.add((Object)new TryCatchBlockNode(labelNode7, labelNode6, labelNode8, tryCatchBlockNode.type));
                continue;
            }
            throw new RuntimeException("Internal error!");
        }
        Iterator iterator = this.localVariables.iterator();
        while (iterator.hasNext()) {
            LabelNode labelNode9;
            LocalVariableNode localVariableNode = (LocalVariableNode)iterator.next();
            LabelNode labelNode10 = i2.b(localVariableNode.start);
            if (labelNode10 == (labelNode9 = i2.b(localVariableNode.end))) continue;
            LocalVariableNode localVariableNode2 = new LocalVariableNode(localVariableNode.name, localVariableNode.desc, localVariableNode.signature, labelNode10, labelNode9, localVariableNode.index);
            list3.add((Object)localVariableNode2);
        }
        return;
    }

    private void b() {
        LinkedList linkedList = new LinkedList();
        linkedList.add((Object)new i(this, null, this.d));
        InsnList insnList = new InsnList();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        while (!linkedList.isEmpty()) {
            this.a((i)linkedList.removeFirst(), (List)linkedList, insnList, (List)arrayList, (List)arrayList2);
        }
        this.instructions = insnList;
        this.tryCatchBlocks = arrayList;
        this.localVariables = arrayList2;
    }

    private static void b(String string) {
        System.err.println(string);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void b(BitSet bitSet, int n2, BitSet bitSet2) {
        block5 : do {
            int n3;
            AbstractInsnNode abstractInsnNode = this.instructions.get(n2);
            if (bitSet.get(n2)) {
                return;
            }
            bitSet.set(n2);
            if (bitSet2.get(n2)) {
                this.f.set(n2);
            }
            bitSet2.set(n2);
            if (abstractInsnNode.getType() == 7 && abstractInsnNode.getOpcode() != 168) {
                JumpInsnNode jumpInsnNode = (JumpInsnNode)abstractInsnNode;
                this.b(bitSet, this.instructions.indexOf((AbstractInsnNode)jumpInsnNode.label), bitSet2);
            }
            if (abstractInsnNode.getType() == 11) {
                TableSwitchInsnNode tableSwitchInsnNode = (TableSwitchInsnNode)abstractInsnNode;
                this.b(bitSet, this.instructions.indexOf((AbstractInsnNode)tableSwitchInsnNode.dflt), bitSet2);
                for (int i2 = -1 + tableSwitchInsnNode.labels.size(); i2 >= 0; --i2) {
                    LabelNode labelNode = (LabelNode)tableSwitchInsnNode.labels.get(i2);
                    this.b(bitSet, this.instructions.indexOf((AbstractInsnNode)labelNode), bitSet2);
                }
            }
            if (abstractInsnNode.getType() == 12) {
                LookupSwitchInsnNode lookupSwitchInsnNode = (LookupSwitchInsnNode)abstractInsnNode;
                this.b(bitSet, this.instructions.indexOf((AbstractInsnNode)lookupSwitchInsnNode.dflt), bitSet2);
                for (int i3 = -1 + lookupSwitchInsnNode.labels.size(); i3 >= 0; --i3) {
                    LabelNode labelNode = (LabelNode)lookupSwitchInsnNode.labels.get(i3);
                    int n4 = this.instructions.indexOf((AbstractInsnNode)labelNode);
                    this.b(bitSet, n4, bitSet2);
                    continue;
                }
            }
            if ((n3 = this.instructions.get(n2).getOpcode()) == 167) return;
            if (n3 == 191) return;
            switch (n3) {
                default: {
                    if (++n2 < this.instructions.size()) continue block5;
                }
                case 169: 
                case 170: 
                case 171: 
                case 172: 
                case 173: 
                case 174: 
                case 175: 
                case 176: 
                case 177: 
            }
            break;
        } while (true);
        return;
        catch (Throwable throwable) {
            throw throwable;
        }
    }

    private void c() {
        BitSet bitSet = new BitSet();
        this.a(this.d, 0, bitSet);
        for (Map.Entry entry : this.c.entrySet()) {
            LabelNode labelNode = (LabelNode)entry.getKey();
            this.a((BitSet)entry.getValue(), this.instructions.indexOf((AbstractInsnNode)labelNode), bitSet);
        }
    }

    public void a() {
        if (!this.c.isEmpty()) {
            this.c();
            this.b();
        }
        if (this.mv != null) {
            this.accept(this.mv);
        }
    }

    public void a(int n2, q q2) {
        super.visitJumpInsn(n2, q2);
        LabelNode labelNode = ((JumpInsnNode)this.instructions.getLast()).label;
        if (n2 == 168 && !this.c.containsKey((Object)labelNode)) {
            this.c.put((Object)labelNode, (Object)new BitSet());
        }
    }
}

