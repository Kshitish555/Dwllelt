/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Point
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.drawable.Drawable
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$bitmap
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IProjection
 *  org.osmdroid.views.overlay.ItemizedIconOverlay$OnItemGestureListener
 *  org.osmdroid.views.overlay.ItemizedOverlay
 *  org.osmdroid.views.overlay.OverlayItem
 *  org.osmdroid.views.overlay.OverlayItem$HotspotPlace
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import java.util.List;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IProjection;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.ItemizedOverlay;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.OverlayItem;

public class ItemizedOverlayWithFocus<Item extends OverlayItem>
extends ItemizedIconOverlay<Item> {
    protected static final int DEFAULTMARKER_BACKGROUNDCOLOR = 0;
    public static final int DESCRIPTION_BOX_CORNERWIDTH = 3;
    public static final int DESCRIPTION_BOX_PADDING = 3;
    public static final int DESCRIPTION_LINE_HEIGHT = 12;
    protected static final int DESCRIPTION_MAXWIDTH = 200;
    public static final int DESCRIPTION_TITLE_EXTRA_LINE_HEIGHT = 2;
    private final String UNKNOWN;
    protected final Paint mDescriptionPaint;
    protected boolean mFocusItemsOnTap;
    protected int mFocusedItemIndex;
    private final Point mFocusedScreenCoords = new Point();
    protected final Paint mMarkerBackgroundPaint;
    protected final int mMarkerFocusedBackgroundColor;
    protected Drawable mMarkerFocusedBase;
    private final Rect mRect = new Rect();
    protected final Paint mTitlePaint;

    static {
        DEFAULTMARKER_BACKGROUNDCOLOR = Color.rgb((int)101, (int)185, (int)74);
    }

    public ItemizedOverlayWithFocus(Context context, List<Item> list, ItemizedIconOverlay.OnItemGestureListener<Item> onItemGestureListener) {
        this(list, onItemGestureListener, new DefaultResourceProxyImpl(context));
    }

    public ItemizedOverlayWithFocus(List<Item> list, Drawable drawable, Drawable drawable2, int n2, ItemizedIconOverlay.OnItemGestureListener<Item> onItemGestureListener, ResourceProxy resourceProxy) {
        Paint paint;
        Paint paint2;
        super(list, drawable, onItemGestureListener, resourceProxy);
        this.UNKNOWN = ((Overlay)this).mResourceProxy.getString(ResourceProxy.string.unknown);
        this.mMarkerFocusedBase = drawable2 == null ? this.boundToHotspot(((Overlay)this).mResourceProxy.getDrawable(ResourceProxy.bitmap.marker_default_focused_base), OverlayItem.HotspotPlace.BOTTOM_CENTER) : drawable2;
        if (n2 == Integer.MIN_VALUE) {
            n2 = DEFAULTMARKER_BACKGROUNDCOLOR;
        }
        this.mMarkerFocusedBackgroundColor = n2;
        this.mMarkerBackgroundPaint = new Paint();
        this.mDescriptionPaint = paint = new Paint();
        paint.setAntiAlias(true);
        this.mTitlePaint = paint2 = new Paint();
        paint2.setFakeBoldText(true);
        this.mTitlePaint.setAntiAlias(true);
        this.unSetFocusedItem();
    }

    public ItemizedOverlayWithFocus(List<Item> list, ItemizedIconOverlay.OnItemGestureListener<Item> onItemGestureListener, ResourceProxy resourceProxy) {
        this(list, resourceProxy.getDrawable(ResourceProxy.bitmap.marker_default), null, Integer.MIN_VALUE, onItemGestureListener, resourceProxy);
    }

    public void draw(Canvas canvas, MapView mapView, boolean bl) {
        String string2;
        int n2;
        ItemizedOverlay.super.draw(canvas, mapView, bl);
        if (bl) {
            return;
        }
        int n3 = this.mFocusedItemIndex;
        if (n3 == Integer.MIN_VALUE) {
            return;
        }
        OverlayItem overlayItem = (OverlayItem)this.mItemList.get(n3);
        Drawable drawable = overlayItem.getMarker(4);
        if (drawable == null) {
            drawable = this.mMarkerFocusedBase;
        }
        Drawable drawable2 = drawable;
        mapView.getProjection().toMapPixels(overlayItem.mGeoPoint, this.mFocusedScreenCoords);
        drawable2.copyBounds(this.mRect);
        Rect rect = this.mRect;
        Point point = this.mFocusedScreenCoords;
        rect.offset(point.x, point.y);
        String string3 = overlayItem.mTitle;
        if (string3 == null) {
            string3 = this.UNKNOWN;
        }
        if ((string2 = overlayItem.mDescription) == null) {
            string2 = this.UNKNOWN;
        }
        int n4 = string2.length();
        float[] arrf = new float[n4];
        this.mDescriptionPaint.getTextWidths(string2, arrf);
        StringBuilder stringBuilder = new StringBuilder();
        int n5 = 0;
        int n6 = 0;
        int n7 = 0;
        int n8 = 0;
        for (n2 = 0; n2 < n4; ++n2) {
            float f2;
            if (!Character.isLetter((char)string2.charAt(n2))) {
                n8 = n2;
            }
            if ((f2 = arrf[n2]) + (float)n7 > 200.0f) {
                n2 = n5 == n8 ? --n2 : n8;
                stringBuilder.append(string2.subSequence(n5, n2));
                stringBuilder.append('\n');
                n6 = Math.max((int)n6, (int)n7);
                n5 = n2;
                n7 = 0;
            }
            n7 = (int)(f2 + (float)n7);
        }
        if (n2 != n5) {
            String string4 = string2.substring(n5, n2);
            n6 = Math.max((int)n6, (int)((int)this.mDescriptionPaint.measureText(string4)));
            stringBuilder.append(string4);
        }
        String[] arrstring = stringBuilder.toString().split("\n");
        int n9 = Math.min((int)Math.max((int)n6, (int)((int)this.mDescriptionPaint.measureText(string3))), (int)200);
        Rect rect2 = this.mRect;
        int n10 = -3 + (rect2.left - n9 / 2) + rect2.width() / 2;
        int n11 = 6 + (n9 + n10);
        int n12 = this.mRect.top;
        int n13 = -6 + (n12 - 2 - 12 * (1 + arrstring.length));
        this.mMarkerBackgroundPaint.setColor(-16777216);
        canvas.drawRoundRect(new RectF((float)(n10 - 1), (float)(n13 - 1), (float)(n11 + 1), (float)(n12 + 1)), 3.0f, 3.0f, this.mDescriptionPaint);
        this.mMarkerBackgroundPaint.setColor(this.mMarkerFocusedBackgroundColor);
        float f3 = n10;
        float f4 = n13;
        float f5 = n11;
        canvas.drawRoundRect(new RectF(f3, f4, f5, (float)n12), 3.0f, 3.0f, this.mMarkerBackgroundPaint);
        int n14 = n10 + 3;
        int n15 = n12 - 3;
        for (int i2 = -1 + arrstring.length; i2 >= 0; --i2) {
            canvas.drawText(arrstring[i2].trim(), (float)n14, (float)n15, this.mDescriptionPaint);
            n15 -= 12;
        }
        canvas.drawText(string3, (float)n14, (float)(n15 - 2), this.mTitlePaint);
        float f6 = n15;
        canvas.drawLine(f3, f6, f5, f6, this.mDescriptionPaint);
        Point point2 = this.mFocusedScreenCoords;
        Overlay.drawAt(canvas, drawable2, point2.x, point2.y, false);
    }

    public Item getFocusedItem() {
        int n2 = this.mFocusedItemIndex;
        if (n2 == Integer.MIN_VALUE) {
            return null;
        }
        return (Item)((OverlayItem)this.mItemList.get(n2));
    }

    @Override
    protected boolean onSingleTapUpHelper(int n2, Item Item, MapView mapView) {
        if (this.mFocusItemsOnTap) {
            this.mFocusedItemIndex = n2;
            mapView.postInvalidate();
        }
        return this.mOnItemGestureListener.onItemSingleTapUp(n2, Item);
    }

    public void setFocusItemsOnTap(boolean bl) {
        this.mFocusItemsOnTap = bl;
    }

    public void setFocusedItem(int n2) {
        this.mFocusedItemIndex = n2;
    }

    public void setFocusedItem(Item Item) {
        int n2 = this.mItemList.indexOf(Item);
        if (n2 >= 0) {
            this.setFocusedItem(n2);
            return;
        }
        throw new IllegalArgumentException();
    }

    public void unSetFocusedItem() {
        this.mFocusedItemIndex = Integer.MIN_VALUE;
    }
}

