/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.Animator$AnimatorPauseListener
 *  androidx.annotation.m0
 *  b.f.c.a$a
 *  b.f.c.a$b
 *  b.f.c.a$c
 *  b.f.c.a$d
 *  b.f.c.a$f
 *  b.f.c.a$g
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.i2.s.l
 *  kotlin.i2.t.i0
 *  kotlin.r1
 *  o.c.a.d
 */
package b.f.c;

import android.animation.Animator;
import androidx.annotation.m0;
import b.f.c.a;
import kotlin.Metadata;
import kotlin.i2.t.i0;
import kotlin.r1;

@Metadata(bv={1, 0, 3}, d1={"\u0000(\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\n\u001a\u00a1\u0001\u0010\u0000\u001a\u00020\u0001*\u00020\u00022#\b\u0006\u0010\u0003\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\t\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\n\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\u000b\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0086\b\u001aW\u0010\f\u001a\u00020\r*\u00020\u00022#\b\u0006\u0010\u000e\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u00042#\b\u0006\u0010\u000f\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0087\b\u001a2\u0010\u0010\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0086\b\u001a2\u0010\u0012\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0086\b\u001a2\u0010\u0013\u001a\u00020\r*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0087\b\u001a2\u0010\u0014\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0086\b\u001a2\u0010\u0015\u001a\u00020\r*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0087\b\u001a2\u0010\u0016\u001a\u00020\u0001*\u00020\u00022#\b\u0004\u0010\u0011\u001a\u001d\u0012\u0013\u0012\u00110\u0002\u00a2\u0006\f\b\u0005\u0012\b\b\u0006\u0012\u0004\b\b(\u0007\u0012\u0004\u0012\u00020\b0\u0004H\u0086\b\u00a8\u0006\u0017"}, d2={"addListener", "Landroid/animation/Animator$AnimatorListener;", "Landroid/animation/Animator;", "onEnd", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "animator", "", "onStart", "onCancel", "onRepeat", "addPauseListener", "Landroid/animation/Animator$AnimatorPauseListener;", "onResume", "onPause", "doOnCancel", "action", "doOnEnd", "doOnPause", "doOnRepeat", "doOnResume", "doOnStart", "core-ktx_release"}, k=2, mv={1, 1, 15})
public final class a {
    @o.c.a.d
    public static final Animator.AnimatorListener a(@o.c.a.d Animator animator, final @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2) {
        i0.f((Object)animator, (String)"$this$doOnCancel");
        i0.f(l2, (String)"action");
        Animator.AnimatorListener animatorListener = new Animator.AnimatorListener(){

            public void onAnimationCancel(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                l2.invoke((Object)animator);
            }

            public void onAnimationEnd(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationRepeat(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationStart(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }
        };
        animator.addListener(animatorListener);
        return animatorListener;
    }

    @o.c.a.d
    public static final Animator.AnimatorListener a(@o.c.a.d Animator animator, @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2, @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l3, @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l4, @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l5) {
        i0.f((Object)animator, (String)"$this$addListener");
        i0.f(l2, (String)"onEnd");
        i0.f(l3, (String)"onStart");
        i0.f(l4, (String)"onCancel");
        i0.f(l5, (String)"onRepeat");
        Animator.AnimatorListener animatorListener = new Animator.AnimatorListener(l5, l2, l4, l3){
            final /* synthetic */ kotlin.i2.s.l a;
            final /* synthetic */ kotlin.i2.s.l b;
            final /* synthetic */ kotlin.i2.s.l c;
            final /* synthetic */ kotlin.i2.s.l d;
            {
                this.a = l2;
                this.b = l3;
                this.c = l4;
                this.d = l5;
            }

            public void onAnimationCancel(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                this.c.invoke((Object)animator);
            }

            public void onAnimationEnd(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                this.b.invoke((Object)animator);
            }

            public void onAnimationRepeat(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                this.a.invoke((Object)animator);
            }

            public void onAnimationStart(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                this.d.invoke((Object)animator);
            }
        };
        animator.addListener(animatorListener);
        return animatorListener;
    }

    public static /* synthetic */ Animator.AnimatorListener a(Animator animator, kotlin.i2.s.l l2, kotlin.i2.s.l l3, kotlin.i2.s.l l4, kotlin.i2.s.l l5, int n2, Object object) {
        if ((n2 & 1) != 0) {
            l2 = a.c;
        }
        if ((n2 & 2) != 0) {
            l3 = b.c;
        }
        if ((n2 & 4) != 0) {
            l4 = c.c;
        }
        if ((n2 & 8) != 0) {
            l5 = d.c;
        }
        i0.f((Object)animator, (String)"$this$addListener");
        i0.f((Object)l2, (String)"onEnd");
        i0.f((Object)l3, (String)"onStart");
        i0.f((Object)l4, (String)"onCancel");
        i0.f((Object)l5, (String)"onRepeat");
        Animator.AnimatorListener animatorListener = new /* invalid duplicate definition of identical inner class */;
        animator.addListener(animatorListener);
        return animatorListener;
    }

    @m0(value=19)
    @o.c.a.d
    public static final Animator.AnimatorPauseListener a(@o.c.a.d Animator animator, @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2, @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l3) {
        i0.f((Object)animator, (String)"$this$addPauseListener");
        i0.f(l2, (String)"onResume");
        i0.f(l3, (String)"onPause");
        Animator.AnimatorPauseListener animatorPauseListener = new Animator.AnimatorPauseListener(l3, l2){
            final /* synthetic */ kotlin.i2.s.l a;
            final /* synthetic */ kotlin.i2.s.l b;
            {
                this.a = l2;
                this.b = l3;
            }

            public void onAnimationPause(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                this.a.invoke((Object)animator);
            }

            public void onAnimationResume(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                this.b.invoke((Object)animator);
            }
        };
        animator.addPauseListener(animatorPauseListener);
        return animatorPauseListener;
    }

    public static /* synthetic */ Animator.AnimatorPauseListener a(Animator animator, kotlin.i2.s.l l2, kotlin.i2.s.l l3, int n2, Object object) {
        if ((n2 & 1) != 0) {
            l2 = f.c;
        }
        if ((n2 & 2) != 0) {
            l3 = g.c;
        }
        i0.f((Object)animator, (String)"$this$addPauseListener");
        i0.f((Object)l2, (String)"onResume");
        i0.f((Object)l3, (String)"onPause");
        Animator.AnimatorPauseListener animatorPauseListener = new /* invalid duplicate definition of identical inner class */;
        animator.addPauseListener(animatorPauseListener);
        return animatorPauseListener;
    }

    @o.c.a.d
    public static final Animator.AnimatorListener b(@o.c.a.d Animator animator, final @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2) {
        i0.f((Object)animator, (String)"$this$doOnEnd");
        i0.f(l2, (String)"action");
        Animator.AnimatorListener animatorListener = new Animator.AnimatorListener(){

            public void onAnimationCancel(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationEnd(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                l2.invoke((Object)animator);
            }

            public void onAnimationRepeat(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationStart(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }
        };
        animator.addListener(animatorListener);
        return animatorListener;
    }

    @m0(value=19)
    @o.c.a.d
    public static final Animator.AnimatorPauseListener c(@o.c.a.d Animator animator, final @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2) {
        i0.f((Object)animator, (String)"$this$doOnPause");
        i0.f(l2, (String)"action");
        Animator.AnimatorPauseListener animatorPauseListener = new Animator.AnimatorPauseListener(){

            public void onAnimationPause(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                l2.invoke((Object)animator);
            }

            public void onAnimationResume(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }
        };
        animator.addPauseListener(animatorPauseListener);
        return animatorPauseListener;
    }

    @o.c.a.d
    public static final Animator.AnimatorListener d(@o.c.a.d Animator animator, final @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2) {
        i0.f((Object)animator, (String)"$this$doOnRepeat");
        i0.f(l2, (String)"action");
        Animator.AnimatorListener animatorListener = new Animator.AnimatorListener(){

            public void onAnimationCancel(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationEnd(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationRepeat(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                l2.invoke((Object)animator);
            }

            public void onAnimationStart(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }
        };
        animator.addListener(animatorListener);
        return animatorListener;
    }

    @m0(value=19)
    @o.c.a.d
    public static final Animator.AnimatorPauseListener e(@o.c.a.d Animator animator, final @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2) {
        i0.f((Object)animator, (String)"$this$doOnResume");
        i0.f(l2, (String)"action");
        Animator.AnimatorPauseListener animatorPauseListener = new Animator.AnimatorPauseListener(){

            public void onAnimationPause(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationResume(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                l2.invoke((Object)animator);
            }
        };
        animator.addPauseListener(animatorPauseListener);
        return animatorPauseListener;
    }

    @o.c.a.d
    public static final Animator.AnimatorListener f(@o.c.a.d Animator animator, final @o.c.a.d kotlin.i2.s.l<? super Animator, r1> l2) {
        i0.f((Object)animator, (String)"$this$doOnStart");
        i0.f(l2, (String)"action");
        Animator.AnimatorListener animatorListener = new Animator.AnimatorListener(){

            public void onAnimationCancel(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationEnd(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationRepeat(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
            }

            public void onAnimationStart(@o.c.a.d Animator animator) {
                i0.f((Object)animator, (String)"animator");
                l2.invoke((Object)animator);
            }
        };
        animator.addListener(animatorListener);
        return animatorListener;
    }

}

