/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.t0.f
 *  h.b.t0.g
 *  h.b.x0.b.b
 *  h.b.x0.j.q
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package h.b;

import h.b.t0.f;
import h.b.t0.g;
import h.b.x0.b.b;
import h.b.x0.j.q;

public final class a0<T> {
    static final a0<Object> b = new a0<T>(null);
    final Object a;

    private a0(Object object) {
        this.a = object;
    }

    @f
    public static <T> a0<T> a(@f T t2) {
        b.a(t2, (String)"value is null");
        return new a0<T>(t2);
    }

    @f
    public static <T> a0<T> a(@f Throwable throwable) {
        b.a((Object)throwable, (String)"error is null");
        return new a0<T>(q.a((Throwable)throwable));
    }

    @f
    public static <T> a0<T> f() {
        return b;
    }

    @g
    public Throwable a() {
        Object object = this.a;
        if (q.i((Object)object)) {
            return q.b((Object)object);
        }
        return null;
    }

    @g
    public T b() {
        Object object = this.a;
        if (object != null && !q.i((Object)object)) {
            return (T)this.a;
        }
        return null;
    }

    public boolean c() {
        return this.a == null;
    }

    public boolean d() {
        return q.i((Object)this.a);
    }

    public boolean e() {
        Object object = this.a;
        return object != null && !q.i((Object)object);
    }

    public boolean equals(Object object) {
        if (object instanceof a0) {
            a0 a02 = (a0)object;
            return b.a((Object)this.a, (Object)a02.a);
        }
        return false;
    }

    public int hashCode() {
        Object object = this.a;
        if (object != null) {
            return object.hashCode();
        }
        return 0;
    }

    public String toString() {
        Object object = this.a;
        if (object == null) {
            return "OnCompleteNotification";
        }
        if (q.i((Object)object)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("OnErrorNotification[");
            stringBuilder.append((Object)q.b((Object)object));
            stringBuilder.append("]");
            return stringBuilder.toString();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("OnNextNotification[");
        stringBuilder.append(this.a);
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

