/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.b0
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  o.c.a.d
 *  o.c.a.e
 *  p.a.a
 *  profile.dto.EmailDto
 *  profile.dto.IdentificationItem
 *  profile.dto.NicknameResponseDto
 *  profile.dto.PriorityPackageAutoRenewalDto
 *  profile.dto.PriorityPackageDto
 *  profile.dto.SmsNotificationDto
 *  profile.dto.SmsNotificationUpdateDto
 *  retrofit2.q.a
 *  retrofit2.q.f
 *  retrofit2.q.p
 *  retrofit2.q.s
 *  rx.Observable
 */
package p.a;

import h.b.b0;
import java.util.List;
import o.c.a.d;
import o.c.a.e;
import p.a.a;
import profile.dto.EmailDto;
import profile.dto.IdentificationItem;
import profile.dto.NicknameResponseDto;
import profile.dto.PriorityPackageAutoRenewalDto;
import profile.dto.PriorityPackageDto;
import profile.dto.SmsNotificationDto;
import profile.dto.SmsNotificationUpdateDto;
import retrofit2.q.f;
import retrofit2.q.p;
import retrofit2.q.s;
import rx.Observable;

public interface b {
    @p(value="/person-profile/v2/persons/{prsId}/sms-notification")
    @d
    public b0<SmsNotificationDto> a(@s(value="prsId") @e String var1, @retrofit2.q.a @d SmsNotificationUpdateDto var2);

    @f(value="/person-profile/v1/profile/current")
    @d
    public Observable<a> a();

    @f(value="/qw-nicknames/v1/persons/{prsId}/nickname")
    @d
    public Observable<NicknameResponseDto> a(@s(value="prsId") @e String var1);

    @p(value="person-profile/v2/persons/{prsId}/priority-package")
    @d
    public Observable<PriorityPackageDto> a(@s(value="prsId") @d String var1, @retrofit2.q.a @d PriorityPackageAutoRenewalDto var2);

    @f(value="/person-profile/v1/persons/{prsId}/email")
    @d
    public Observable<EmailDto> b(@s(value="prsId") @e String var1);

    @f(value="/identification/v4/persons/{personId}/identifications")
    @d
    public Observable<List<IdentificationItem>> c(@s(value="personId") @e String var1);

    @f(value="/person-profile/v2/persons/{prsId}/sms-notification")
    @d
    public b0<SmsNotificationDto> d(@s(value="prsId") @e String var1);

    @f(value="/person-profile/v2/persons/{prsId}/priority-package")
    @d
    public Observable<PriorityPackageDto> e(@s(value="prsId") @e String var1);
}

