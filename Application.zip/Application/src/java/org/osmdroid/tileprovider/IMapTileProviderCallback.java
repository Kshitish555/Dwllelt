/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 */
package org.osmdroid.tileprovider;

import android.graphics.drawable.Drawable;
import org.osmdroid.tileprovider.MapTileRequestState;

public interface IMapTileProviderCallback {
    public void mapTileRequestCompleted(MapTileRequestState var1, Drawable var2);

    public void mapTileRequestFailed(MapTileRequestState var1);

    public boolean useDataConnection();
}

