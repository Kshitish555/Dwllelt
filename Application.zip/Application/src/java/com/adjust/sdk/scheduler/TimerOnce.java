/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.adjust.sdk.scheduler.SingleThreadFutureScheduler
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.text.DecimalFormat
 *  java.util.concurrent.ScheduledFuture
 *  java.util.concurrent.TimeUnit
 */
package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.Util;
import com.adjust.sdk.scheduler.FutureScheduler;
import com.adjust.sdk.scheduler.SingleThreadFutureScheduler;
import java.text.DecimalFormat;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class TimerOnce {
    private Runnable command;
    private ILogger logger;
    private String name;
    private FutureScheduler scheduler;
    private ScheduledFuture waitingTask;

    public TimerOnce(Runnable runnable, String string) {
        this.name = string;
        this.scheduler = new SingleThreadFutureScheduler(string, true);
        this.command = runnable;
        this.logger = AdjustFactory.getLogger();
    }

    private void cancel(boolean bl) {
        ScheduledFuture scheduledFuture = this.waitingTask;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(bl);
        }
        this.waitingTask = null;
        ILogger iLogger = this.logger;
        Object[] arrobject = new Object[]{this.name};
        iLogger.verbose("%s canceled", arrobject);
    }

    public void cancel() {
        this.cancel(false);
    }

    public long getFireIn() {
        ScheduledFuture scheduledFuture = this.waitingTask;
        if (scheduledFuture == null) {
            return 0L;
        }
        return scheduledFuture.getDelay(TimeUnit.MILLISECONDS);
    }

    public void startIn(long l2) {
        this.cancel(false);
        DecimalFormat decimalFormat = Util.SecondsDisplayFormat;
        double d2 = l2;
        Double.isNaN((double)d2);
        String string = decimalFormat.format(d2 / 1000.0);
        ILogger iLogger = this.logger;
        Object[] arrobject = new Object[]{this.name, string};
        iLogger.verbose("%s starting. Launching in %s seconds", arrobject);
        this.waitingTask = this.scheduler.scheduleFuture(new Runnable(){

            public void run() {
                ILogger iLogger = TimerOnce.this.logger;
                Object[] arrobject = new Object[]{TimerOnce.this.name};
                iLogger.verbose("%s fired", arrobject);
                TimerOnce.this.command.run();
                TimerOnce.this.waitingTask = null;
            }
        }, l2);
    }

    public void teardown() {
        this.cancel(true);
        FutureScheduler futureScheduler = this.scheduler;
        if (futureScheduler != null) {
            futureScheduler.teardown();
        }
        this.scheduler = null;
    }

}

