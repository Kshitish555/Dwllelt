/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

public final class LogLevel
extends Enum<LogLevel> {
    private static final /* synthetic */ LogLevel[] $VALUES;
    public static final /* enum */ LogLevel ASSERT;
    public static final /* enum */ LogLevel DEBUG;
    public static final /* enum */ LogLevel ERROR;
    public static final /* enum */ LogLevel INFO;
    public static final /* enum */ LogLevel SUPRESS;
    public static final /* enum */ LogLevel VERBOSE;
    public static final /* enum */ LogLevel WARN;
    final int androidLogLevel;

    static {
        LogLevel logLevel;
        VERBOSE = new LogLevel(2);
        DEBUG = new LogLevel(3);
        INFO = new LogLevel(4);
        WARN = new LogLevel(5);
        ERROR = new LogLevel(6);
        ASSERT = new LogLevel(7);
        SUPRESS = logLevel = new LogLevel(8);
        LogLevel[] arrlogLevel = new LogLevel[]{VERBOSE, DEBUG, INFO, WARN, ERROR, ASSERT, logLevel};
        $VALUES = arrlogLevel;
    }

    private LogLevel(int n3) {
        this.androidLogLevel = n3;
    }

    public static LogLevel valueOf(String string) {
        return (LogLevel)Enum.valueOf(LogLevel.class, (String)string);
    }

    public static LogLevel[] values() {
        return (LogLevel[])$VALUES.clone();
    }

    public int getAndroidLogLevel() {
        return this.androidLogLevel;
    }
}

