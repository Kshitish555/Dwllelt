/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.ScheduledFuture
 */
package com.adjust.sdk.scheduler;

import java.util.concurrent.ScheduledFuture;

public interface FutureScheduler {
    public ScheduledFuture<?> scheduleFuture(Runnable var1, long var2);

    public ScheduledFuture<?> scheduleFutureWithFixedDelay(Runnable var1, long var2, long var4);

    public void teardown();
}

