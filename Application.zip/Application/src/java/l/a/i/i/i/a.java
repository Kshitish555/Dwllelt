/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  l.a.b
 *  l.a.f.b
 *  l.a.h.i.a
 *  l.a.h.k.c
 *  l.a.i.a
 *  l.a.i.b
 *  l.a.i.b$a
 *  l.a.i.b$a$a
 *  l.a.i.b$a$a$a
 *  l.a.i.b$d
 *  l.a.i.g
 *  l.a.i.i.b
 *  l.a.i.i.c
 *  l.a.i.i.c$f
 *  l.a.i.i.d
 *  l.a.i.i.d$a
 *  l.a.i.i.e
 *  l.a.i.i.g
 *  l.a.j.e
 *  l.a.j.e$d
 *  l.a.j.e$d$d
 *  l.a.j.n.b
 *  l.a.j.n.c
 *  l.a.j.n.c$c
 *  l.a.j.n.f
 *  l.a.j.o.a
 *  l.a.j.o.a$a
 *  l.a.l.c0
 *  l.a.m.a
 */
package l.a.i.i.i;

import l.a.i.b;
import l.a.i.i.b;
import l.a.i.i.c;
import l.a.i.i.d;
import l.a.i.i.e;
import l.a.i.i.g;
import l.a.j.e;
import l.a.j.n.c;
import l.a.j.n.f;
import l.a.j.o.a;
import l.a.l.c0;
import l.a.m.a;

public abstract class a<T>
extends b.a.a.a<T> {
    protected final l.a.h.k.c n;
    protected final l.a.i.a o;

    protected a(c.f f2, b b2, e e2, f f3, l.a.f.b b3, l.a.b b4, a.a a2, c.c c2, l.a.j.n.b b5, e.d.d d2, d.a a3, g g2, c0<? super l.a.h.i.a> c02, l.a.h.k.c c3, l.a.i.a a4) {
        super(f2, b2, e2, f3, b3, b4, a2, c2, b5, d2, a3, g2, c02);
        this.n = c3;
        this.o = a4;
    }

    public b.d<T> a(l.a.i.g g2) {
        return this.a(g2, a.e.a(this.o));
    }

    protected boolean a(Object object) {
        return object instanceof a;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof a)) {
            return false;
        }
        a a2 = (a)((Object)object);
        if (!a2.a((Object)this)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        l.a.h.k.c c2 = this.n;
        l.a.h.k.c c3 = a2.n;
        if (c2 == null ? c3 != null : !c2.equals((Object)c3)) {
            return false;
        }
        l.a.i.a a3 = this.o;
        l.a.i.a a4 = a2.o;
        return !(a3 == null ? a4 != null : !a3.equals((Object)a4));
    }

    public int hashCode() {
        int n2 = 59 + super.hashCode();
        l.a.h.k.c c2 = this.n;
        int n3 = n2 * 59;
        int n4 = 43;
        int n5 = c2 == null ? 43 : c2.hashCode();
        int n6 = n3 + n5;
        l.a.i.a a2 = this.o;
        int n7 = n6 * 59;
        if (a2 != null) {
            n4 = a2.hashCode();
        }
        return n7 + n4;
    }
}

