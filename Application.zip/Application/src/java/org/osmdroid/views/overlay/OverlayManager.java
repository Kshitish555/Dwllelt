/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Point
 *  android.view.KeyEvent
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.MotionEvent
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.util.AbstractList
 *  java.util.Iterator
 *  java.util.ListIterator
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package org.osmdroid.views.overlay;

import android.graphics.Canvas;
import android.graphics.Point;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import java.util.AbstractList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.concurrent.CopyOnWriteArrayList;
import org.osmdroid.api.IMapView;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.IOverlayMenuProvider;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.TilesOverlay;

public class OverlayManager
extends AbstractList<Overlay> {
    private final CopyOnWriteArrayList<Overlay> mOverlayList;
    private TilesOverlay mTilesOverlay;

    public OverlayManager(TilesOverlay tilesOverlay) {
        this.setTilesOverlay(tilesOverlay);
        this.mOverlayList = new CopyOnWriteArrayList();
    }

    public void add(int n2, Overlay overlay) {
        this.mOverlayList.add(n2, (Object)overlay);
    }

    public Overlay get(int n2) {
        return (Overlay)this.mOverlayList.get(n2);
    }

    public TilesOverlay getTilesOverlay() {
        return this.mTilesOverlay;
    }

    public boolean onCreateOptionsMenu(Menu menu, int n2, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        boolean bl = true;
        while (iterator.hasNext()) {
            IOverlayMenuProvider iOverlayMenuProvider;
            Overlay overlay = (Overlay)iterator.next();
            if (!(overlay instanceof IOverlayMenuProvider) || !(iOverlayMenuProvider = (IOverlayMenuProvider)((Object)overlay)).isOptionsMenuEnabled()) continue;
            bl &= iOverlayMenuProvider.onCreateOptionsMenu(menu, n2, mapView);
        }
        TilesOverlay tilesOverlay = this.mTilesOverlay;
        if (tilesOverlay != null && tilesOverlay instanceof IOverlayMenuProvider && tilesOverlay.isOptionsMenuEnabled()) {
            bl &= this.mTilesOverlay.onCreateOptionsMenu(menu, n2, mapView);
        }
        return bl;
    }

    public void onDetach(MapView mapView) {
        TilesOverlay tilesOverlay = this.mTilesOverlay;
        if (tilesOverlay != null) {
            tilesOverlay.onDetach(mapView);
        }
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            ((Overlay)iterator.next()).onDetach(mapView);
        }
    }

    public boolean onDoubleTap(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onDoubleTap(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onDoubleTapEvent(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onDoubleTapEvent(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onDown(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onDown(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public void onDraw(Canvas canvas, MapView mapView) {
        TilesOverlay tilesOverlay = this.mTilesOverlay;
        if (tilesOverlay != null && tilesOverlay.isEnabled()) {
            this.mTilesOverlay.draw(canvas, mapView, true);
        }
        for (Overlay overlay : this.mOverlayList) {
            if (!overlay.isEnabled()) continue;
            overlay.draw(canvas, mapView, true);
        }
        TilesOverlay tilesOverlay2 = this.mTilesOverlay;
        if (tilesOverlay2 != null && tilesOverlay2.isEnabled()) {
            this.mTilesOverlay.draw(canvas, mapView, false);
        }
        for (Overlay overlay : this.mOverlayList) {
            if (!overlay.isEnabled()) continue;
            overlay.draw(canvas, mapView, false);
        }
    }

    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onFling(motionEvent, motionEvent2, f2, f3, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onKeyDown(int n2, KeyEvent keyEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onKeyDown(n2, keyEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onKeyUp(int n2, KeyEvent keyEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onKeyUp(n2, keyEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onLongPress(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onLongPress(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem, int n2, MapView mapView) {
        for (Overlay overlay : this.overlaysReversed()) {
            IOverlayMenuProvider iOverlayMenuProvider;
            if (!(overlay instanceof IOverlayMenuProvider) || !(iOverlayMenuProvider = (IOverlayMenuProvider)((Object)overlay)).isOptionsMenuEnabled() || !iOverlayMenuProvider.onOptionsItemSelected(menuItem, n2, mapView)) continue;
            return true;
        }
        TilesOverlay tilesOverlay = this.mTilesOverlay;
        return tilesOverlay != null && tilesOverlay instanceof IOverlayMenuProvider && tilesOverlay.isOptionsMenuEnabled() && this.mTilesOverlay.onOptionsItemSelected(menuItem, n2, mapView);
    }

    public boolean onPrepareOptionsMenu(Menu menu, int n2, MapView mapView) {
        for (Overlay overlay : this.overlaysReversed()) {
            IOverlayMenuProvider iOverlayMenuProvider;
            if (!(overlay instanceof IOverlayMenuProvider) || !(iOverlayMenuProvider = (IOverlayMenuProvider)((Object)overlay)).isOptionsMenuEnabled()) continue;
            iOverlayMenuProvider.onPrepareOptionsMenu(menu, n2, mapView);
        }
        TilesOverlay tilesOverlay = this.mTilesOverlay;
        if (tilesOverlay != null && tilesOverlay instanceof IOverlayMenuProvider && tilesOverlay.isOptionsMenuEnabled()) {
            this.mTilesOverlay.onPrepareOptionsMenu(menu, n2, mapView);
        }
        return true;
    }

    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f2, float f3, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onScroll(motionEvent, motionEvent2, f2, f3, mapView)) continue;
            return true;
        }
        return false;
    }

    public void onShowPress(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            ((Overlay)iterator.next()).onShowPress(motionEvent, mapView);
        }
    }

    public boolean onSingleTapConfirmed(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onSingleTapConfirmed(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onSingleTapUp(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onSingleTapUp(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onSnapToItem(int n2, int n3, Point point, IMapView iMapView) {
        for (Overlay overlay : this.overlaysReversed()) {
            if (!(overlay instanceof Overlay.Snappable) || !((Object)overlay).onSnapToItem(n2, n3, point, iMapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onTouchEvent(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onTouchEvent(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public boolean onTrackballEvent(MotionEvent motionEvent, MapView mapView) {
        Iterator iterator = this.overlaysReversed().iterator();
        while (iterator.hasNext()) {
            if (!((Overlay)iterator.next()).onTrackballEvent(motionEvent, mapView)) continue;
            return true;
        }
        return false;
    }

    public Iterable<Overlay> overlaysReversed() {
        return new Iterable<Overlay>(){

            public Iterator<Overlay> iterator() {
                return new Iterator<Overlay>(OverlayManager.this.mOverlayList.listIterator(OverlayManager.this.mOverlayList.size())){
                    final /* synthetic */ ListIterator val$i;
                    {
                        this.val$i = listIterator;
                    }

                    public boolean hasNext() {
                        return this.val$i.hasPrevious();
                    }

                    public Overlay next() {
                        return (Overlay)this.val$i.previous();
                    }

                    public void remove() {
                        this.val$i.remove();
                    }
                };
            }

        };
    }

    public Overlay remove(int n2) {
        return (Overlay)this.mOverlayList.remove(n2);
    }

    public Overlay set(int n2, Overlay overlay) {
        return (Overlay)this.mOverlayList.set(n2, (Object)overlay);
    }

    public void setOptionsMenusEnabled(boolean bl) {
        for (Overlay overlay : this.mOverlayList) {
            IOverlayMenuProvider iOverlayMenuProvider;
            if (!(overlay instanceof IOverlayMenuProvider) || !(iOverlayMenuProvider = (IOverlayMenuProvider)((Object)overlay)).isOptionsMenuEnabled()) continue;
            iOverlayMenuProvider.setOptionsMenuEnabled(bl);
        }
    }

    public void setTilesOverlay(TilesOverlay tilesOverlay) {
        this.mTilesOverlay = tilesOverlay;
    }

    public int size() {
        return this.mOverlayList.size();
    }

}

