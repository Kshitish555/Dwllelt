/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.adjust.sdk.scheduler;

public interface ThreadExecutor {
    public void submit(Runnable var1);

    public void teardown();
}

