/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  l.a.k.a.q
 *  l.a.k.a.r
 */
package l.a.n.h;

import l.a.k.a.q;
import l.a.k.a.r;
import l.a.n.h.a;

public class b
extends a {
    private final q h = new q();
    private boolean o = true;

    public b(r r2) {
        super(327680, r2);
    }

    public void b(int n2, q q2) {
        if (this.o) {
            q2 = this.h;
            this.o = false;
        }
        r.super.b(n2, q2);
    }

    @Override
    protected void e() {
        super.a(this.h);
    }
}

