/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public final class a
extends Enum<a>
implements e {
    public static final /* enum */ a f;
    public static final /* enum */ a h;
    public static final /* enum */ a o;
    public static final /* enum */ a s;
    private static final /* synthetic */ a[] t;
    private final int c;
    private final f d;

    static {
        a a2;
        f = new a(96, f.f);
        h = new a(97, f.h);
        o = new a(98, f.f);
        s = a2 = new a(99, f.h);
        a[] arra = new a[]{f, h, o, a2};
        t = arra;
    }

    private a(int n3, f f2) {
        this.c = n3;
        this.d = f2;
    }

    public static a valueOf(String string) {
        return (a)Enum.valueOf(a.class, (String)string);
    }

    public static a[] values() {
        return (a[])t.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.c);
        return this.d.e();
    }

    public boolean x() {
        return true;
    }
}

