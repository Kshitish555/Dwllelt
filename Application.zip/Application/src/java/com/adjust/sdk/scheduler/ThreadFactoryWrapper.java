/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.lang.Thread$UncaughtExceptionHandler
 *  java.lang.Throwable
 *  java.util.concurrent.Executors
 *  java.util.concurrent.ThreadFactory
 */
package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class ThreadFactoryWrapper
implements ThreadFactory {
    private String source;

    public ThreadFactoryWrapper(String string) {
        this.source = string;
    }

    public Thread newThread(Runnable runnable) {
        Thread thread = Executors.defaultThreadFactory().newThread(runnable);
        thread.setPriority(9);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Adjust-");
        stringBuilder.append(thread.getName());
        stringBuilder.append("-");
        stringBuilder.append(this.source);
        thread.setName(stringBuilder.toString());
        thread.setDaemon(true);
        thread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){

            public void uncaughtException(Thread thread, Throwable throwable) {
                ILogger iLogger = AdjustFactory.getLogger();
                Object[] arrobject = new Object[]{thread.getName(), throwable.getMessage()};
                iLogger.error("Thread [%s] with error [%s]", arrobject);
            }
        });
        return thread;
    }

}

