/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  com.adjust.sdk.AttributionResponseData
 *  com.adjust.sdk.EventResponseData
 *  com.adjust.sdk.SdkClickResponseData
 *  com.adjust.sdk.SessionResponseData
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

import android.content.Context;
import android.net.Uri;
import com.adjust.sdk.ActivityState;
import com.adjust.sdk.AdjustAttribution;
import com.adjust.sdk.AdjustConfig;
import com.adjust.sdk.AdjustEvent;
import com.adjust.sdk.AttributionResponseData;
import com.adjust.sdk.EventResponseData;
import com.adjust.sdk.ResponseData;
import com.adjust.sdk.SdkClickResponseData;
import com.adjust.sdk.SessionParameters;
import com.adjust.sdk.SessionResponseData;
import com.adjust.sdk.a;

public interface IActivityHandler {
    public void addSessionCallbackParameter(String var1, String var2);

    public void addSessionPartnerParameter(String var1, String var2);

    public void finishedTrackingActivity(ResponseData var1);

    public void gdprForgetMe();

    public ActivityState getActivityState();

    public String getAdid();

    public AdjustConfig getAdjustConfig();

    public AdjustAttribution getAttribution();

    public String getBasePath();

    public Context getContext();

    public a getDeviceInfo();

    public String getGdprPath();

    public SessionParameters getSessionParameters();

    public void gotOptOutResponse();

    public void init(AdjustConfig var1);

    public boolean isEnabled();

    public void launchAttributionResponseTasks(AttributionResponseData var1);

    public void launchEventResponseTasks(EventResponseData var1);

    public void launchSdkClickResponseTasks(SdkClickResponseData var1);

    public void launchSessionResponseTasks(SessionResponseData var1);

    public void onPause();

    public void onResume();

    public void readOpenUrl(Uri var1, long var2);

    public void removeSessionCallbackParameter(String var1);

    public void removeSessionPartnerParameter(String var1);

    public void resetSessionCallbackParameters();

    public void resetSessionPartnerParameters();

    public void sendFirstPackages();

    public void sendInstallReferrer(String var1, long var2, long var4);

    public void sendReftagReferrer();

    public void setAskingAttribution(boolean var1);

    public void setEnabled(boolean var1);

    public void setOfflineMode(boolean var1);

    public void setPushToken(String var1, boolean var2);

    public void teardown();

    public void trackEvent(AdjustEvent var1);

    public boolean updateAttributionI(AdjustAttribution var1);
}

