/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Constructor
 *  org.simpleframework.xml.Attribute
 *  org.simpleframework.xml.Element
 *  org.simpleframework.xml.ElementArray
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementListUnion
 *  org.simpleframework.xml.ElementMap
 *  org.simpleframework.xml.ElementMapUnion
 *  org.simpleframework.xml.ElementUnion
 *  org.simpleframework.xml.Text
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementArray;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementListUnion;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.ElementMapUnion;
import org.simpleframework.xml.ElementUnion;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.core.AttributeParameter;
import org.simpleframework.xml.core.ElementArrayParameter;
import org.simpleframework.xml.core.ElementListParameter;
import org.simpleframework.xml.core.ElementListUnionParameter;
import org.simpleframework.xml.core.ElementMapParameter;
import org.simpleframework.xml.core.ElementMapUnionParameter;
import org.simpleframework.xml.core.ElementParameter;
import org.simpleframework.xml.core.ElementUnionParameter;
import org.simpleframework.xml.core.Parameter;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.core.TextParameter;
import org.simpleframework.xml.stream.Format;

class ParameterFactory {
    private final Format format;

    public ParameterFactory(Support support) {
        this.format = support.getFormat();
    }

    private ParameterBuilder getBuilder(Annotation annotation) throws Exception {
        if (annotation instanceof Element) {
            return new ParameterBuilder(ElementParameter.class, Element.class);
        }
        if (annotation instanceof ElementList) {
            return new ParameterBuilder(ElementListParameter.class, ElementList.class);
        }
        if (annotation instanceof ElementArray) {
            return new ParameterBuilder(ElementArrayParameter.class, ElementArray.class);
        }
        if (annotation instanceof ElementMapUnion) {
            return new ParameterBuilder(ElementMapUnionParameter.class, ElementMapUnion.class, ElementMap.class);
        }
        if (annotation instanceof ElementListUnion) {
            return new ParameterBuilder(ElementListUnionParameter.class, ElementListUnion.class, ElementList.class);
        }
        if (annotation instanceof ElementUnion) {
            return new ParameterBuilder(ElementUnionParameter.class, ElementUnion.class, Element.class);
        }
        if (annotation instanceof ElementMap) {
            return new ParameterBuilder(ElementMapParameter.class, ElementMap.class);
        }
        if (annotation instanceof Attribute) {
            return new ParameterBuilder(AttributeParameter.class, Attribute.class);
        }
        if (annotation instanceof Text) {
            return new ParameterBuilder(TextParameter.class, Text.class);
        }
        throw new PersistenceException("Annotation %s not supported", new Object[]{annotation});
    }

    private Constructor getConstructor(Annotation annotation) throws Exception {
        Constructor constructor = this.getBuilder(annotation).getConstructor();
        if (!constructor.isAccessible()) {
            constructor.setAccessible(true);
        }
        return constructor;
    }

    public Parameter getInstance(Constructor constructor, Annotation annotation, int n2) throws Exception {
        return this.getInstance(constructor, annotation, null, n2);
    }

    public Parameter getInstance(Constructor constructor, Annotation annotation, Annotation annotation2, int n2) throws Exception {
        Constructor constructor2 = this.getConstructor(annotation);
        if (annotation2 != null) {
            Object[] arrobject = new Object[]{constructor, annotation, annotation2, this.format, n2};
            return (Parameter)constructor2.newInstance(arrobject);
        }
        Object[] arrobject = new Object[]{constructor, annotation, this.format, n2};
        return (Parameter)constructor2.newInstance(arrobject);
    }

    private static class ParameterBuilder {
        private final Class entry;
        private final Class label;
        private final Class type;

        public ParameterBuilder(Class class_, Class class_2) {
            this(class_, class_2, null);
        }

        public ParameterBuilder(Class class_, Class class_2, Class class_3) {
            this.label = class_2;
            this.entry = class_3;
            this.type = class_;
        }

        private /* varargs */ Constructor getConstructor(Class ... arrclass) throws Exception {
            return this.type.getConstructor(arrclass);
        }

        public Constructor getConstructor() throws Exception {
            Class class_ = this.entry;
            if (class_ != null) {
                return this.getConstructor(this.label, class_);
            }
            return this.getConstructor(this.label);
        }

        public Constructor getConstructor(Class class_) throws Exception {
            Class[] arrclass = new Class[]{Constructor.class, class_, Format.class, Integer.TYPE};
            return this.getConstructor(arrclass);
        }

        public Constructor getConstructor(Class class_, Class class_2) throws Exception {
            Class[] arrclass = new Class[]{Constructor.class, class_, class_2, Format.class, Integer.TYPE};
            return this.getConstructor(arrclass);
        }
    }

}

