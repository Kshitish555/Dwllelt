/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.Set
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Entry
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.Style
 */
package org.simpleframework.xml.core;

import java.util.Map;
import java.util.Set;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Entry;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.MapFactory;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Style;

class CompositeMap
implements Converter {
    private final Entry entry;
    private final MapFactory factory;
    private final Converter key;
    private final Style style;
    private final Converter value;

    public CompositeMap(Context context, Entry entry, Type type) throws Exception {
        this.factory = new MapFactory(context, type);
        this.value = entry.getValue(context);
        this.key = entry.getKey(context);
        this.style = context.getStyle();
        this.entry = entry;
    }

    private Object populate(InputNode inputNode, Object object) throws Exception {
        Map map = (Map)object;
        InputNode inputNode2;
        while ((inputNode2 = inputNode.getNext()) != null) {
            map.put(this.key.read(inputNode2), this.value.read(inputNode2));
        }
        return map;
    }

    private boolean validate(InputNode inputNode, Class class_) throws Exception {
        InputNode inputNode2;
        do {
            if ((inputNode2 = inputNode.getNext()) == null) {
                return true;
            }
            if (this.key.validate(inputNode2)) continue;
            return false;
        } while (this.value.validate(inputNode2));
        return false;
    }

    public Object read(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        Object object = instance.getInstance();
        if (!instance.isReference()) {
            return this.populate(inputNode, object);
        }
        return object;
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (instance.isReference()) {
            return instance.getInstance();
        }
        instance.setInstance(object);
        if (object != null) {
            return this.populate(inputNode, object);
        }
        return object;
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            instance.setInstance(null);
            return this.validate(inputNode, instance.getType());
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Map map = (Map)object;
        for (Object object2 : map.keySet()) {
            String string2 = this.entry.getEntry();
            OutputNode outputNode2 = outputNode.getChild(this.style.getElement(string2));
            Object object3 = map.get(object2);
            this.key.write(outputNode2, object2);
            this.value.write(outputNode2, object3);
        }
    }
}

