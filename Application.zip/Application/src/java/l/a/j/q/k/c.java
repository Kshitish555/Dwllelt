/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public final class c
extends Enum<c>
implements e {
    public static final /* enum */ c d;
    public static final /* enum */ c f;
    private static final e.c h;
    private static final /* synthetic */ c[] o;
    private final int c;

    static {
        c c2;
        d = new c(14);
        f = c2 = new c(15);
        c[] arrc = new c[]{d, c2};
        o = arrc;
        h = f.h.f();
    }

    private c(int n3) {
        this.c = n3;
    }

    public static e a(double d2) {
        if (d2 == 0.0) {
            return d;
        }
        if (d2 == 1.0) {
            return f;
        }
        return new a(d2);
    }

    public static c valueOf(String string) {
        return (c)Enum.valueOf(c.class, (String)string);
    }

    public static c[] values() {
        return (c[])o.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.c);
        return h;
    }

    public boolean x() {
        return true;
    }

    protected static class a
    implements e {
        private final double c;

        protected a(double d2) {
            this.c = d2;
        }

        public e.c a(r r2, e.d d2) {
            r2.a((Object)this.c);
            return h;
        }

        protected boolean b(Object object) {
            return object instanceof a;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof a)) {
                return false;
            }
            a a2 = (a)object;
            if (!a2.b(this)) {
                return false;
            }
            return Double.compare((double)this.c, (double)a2.c) == 0;
        }

        public int hashCode() {
            long l2 = Double.doubleToLongBits((double)this.c);
            return 59 + (int)(l2 ^ l2 >>> 32);
        }

        public boolean x() {
            return true;
        }
    }

}

