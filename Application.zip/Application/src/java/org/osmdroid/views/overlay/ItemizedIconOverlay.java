/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Point
 *  android.graphics.drawable.Drawable
 *  android.view.MotionEvent
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.List
 *  org.osmdroid.DefaultResourceProxyImpl
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$bitmap
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IMapView
 *  org.osmdroid.util.GeoPoint
 *  org.osmdroid.views.MapView
 *  org.osmdroid.views.MapView$Projection
 *  org.osmdroid.views.overlay.ItemizedIconOverlay$1
 *  org.osmdroid.views.overlay.ItemizedIconOverlay$2
 *  org.osmdroid.views.overlay.ItemizedIconOverlay$ActiveItem
 *  org.osmdroid.views.overlay.ItemizedIconOverlay$OnItemGestureListener
 *  org.osmdroid.views.overlay.ItemizedOverlay
 *  org.osmdroid.views.overlay.Overlay
 *  org.osmdroid.views.overlay.OverlayItem
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import java.util.Collection;
import java.util.List;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IMapView;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedIconOverlay;
import org.osmdroid.views.overlay.ItemizedOverlay;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.OverlayItem;

public class ItemizedIconOverlay<Item extends OverlayItem>
extends ItemizedOverlay<Item> {
    private int mDrawnItemsLimit = Integer.MAX_VALUE;
    protected final List<Item> mItemList;
    private final Point mItemPoint = new Point();
    protected OnItemGestureListener<Item> mOnItemGestureListener;
    private final Point mTouchScreenPoint = new Point();

    public ItemizedIconOverlay(Context context, List<Item> list, OnItemGestureListener<Item> onItemGestureListener) {
        this(list, new DefaultResourceProxyImpl(context).getDrawable(ResourceProxy.bitmap.marker_default), onItemGestureListener, (ResourceProxy)new DefaultResourceProxyImpl(context));
    }

    public ItemizedIconOverlay(List<Item> list, Drawable drawable, OnItemGestureListener<Item> onItemGestureListener, ResourceProxy resourceProxy) {
        super(drawable, resourceProxy);
        this.mItemList = list;
        this.mOnItemGestureListener = onItemGestureListener;
        this.populate();
    }

    public ItemizedIconOverlay(List<Item> list, OnItemGestureListener<Item> onItemGestureListener, ResourceProxy resourceProxy) {
        this(list, resourceProxy.getDrawable(ResourceProxy.bitmap.marker_default), onItemGestureListener, resourceProxy);
    }

    private boolean activateSelectedItems(MotionEvent motionEvent, MapView mapView, ActiveItem activeItem) {
        MapView.Projection projection = mapView.getProjection();
        projection.fromMapPixels((int)motionEvent.getX(), (int)motionEvent.getY(), this.mTouchScreenPoint);
        for (int i2 = 0; i2 < this.mItemList.size(); ++i2) {
            OverlayItem overlayItem = this.getItem(i2);
            Drawable drawable = overlayItem.getMarker(0) == null ? this.mDefaultMarker : overlayItem.getMarker(0);
            projection.toPixels((IGeoPoint)overlayItem.getPoint(), this.mItemPoint);
            Point point = this.mTouchScreenPoint;
            int n2 = point.x;
            Point point2 = this.mItemPoint;
            if (!this.hitTest(overlayItem, drawable, n2 - point2.x, point.y - point2.y) || !activeItem.run(i2)) continue;
            return true;
        }
        return false;
    }

    public void addItem(int n2, Item Item) {
        this.mItemList.add(n2, Item);
    }

    public boolean addItem(Item Item) {
        boolean bl = this.mItemList.add(Item);
        this.populate();
        return bl;
    }

    public boolean addItems(List<Item> list) {
        boolean bl = this.mItemList.addAll(list);
        this.populate();
        return bl;
    }

    protected Item createItem(int n2) {
        return (Item)((OverlayItem)this.mItemList.get(n2));
    }

    public int getDrawnItemsLimit() {
        return this.mDrawnItemsLimit;
    }

    public boolean onLongPress(MotionEvent motionEvent, MapView mapView) {
        if (this.activateSelectedItems(motionEvent, mapView, new 2(this))) {
            return true;
        }
        return Overlay.super.onLongPress(motionEvent, mapView);
    }

    protected boolean onLongPressHelper(int n2, Item Item) {
        return this.mOnItemGestureListener.onItemLongPress(n2, Item);
    }

    public boolean onSingleTapUp(MotionEvent motionEvent, MapView mapView) {
        if (this.activateSelectedItems(motionEvent, mapView, new 1(this, mapView))) {
            return true;
        }
        return Overlay.super.onSingleTapUp(motionEvent, mapView);
    }

    protected boolean onSingleTapUpHelper(int n2, Item Item, MapView mapView) {
        return this.mOnItemGestureListener.onItemSingleTapUp(n2, Item);
    }

    public boolean onSnapToItem(int n2, int n3, Point point, IMapView iMapView) {
        return false;
    }

    public void removeAllItems() {
        this.removeAllItems(true);
    }

    public void removeAllItems(boolean bl) {
        this.mItemList.clear();
        if (bl) {
            this.populate();
        }
    }

    public Item removeItem(int n2) {
        OverlayItem overlayItem = (OverlayItem)this.mItemList.remove(n2);
        this.populate();
        return (Item)overlayItem;
    }

    public boolean removeItem(Item Item) {
        boolean bl = this.mItemList.remove(Item);
        this.populate();
        return bl;
    }

    public void setDrawnItemsLimit(int n2) {
        this.mDrawnItemsLimit = n2;
    }

    public int size() {
        return Math.min((int)this.mItemList.size(), (int)this.mDrawnItemsLimit);
    }
}

