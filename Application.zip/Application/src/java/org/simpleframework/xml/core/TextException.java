/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  org.simpleframework.xml.core.PersistenceException
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.PersistenceException;

public class TextException
extends PersistenceException {
    public /* varargs */ TextException(String string2, Object ... arrobject) {
        super(string2, arrobject);
    }

    public /* varargs */ TextException(Throwable throwable, String string2, Object ... arrobject) {
        super(throwable, string2, arrobject);
    }
}

