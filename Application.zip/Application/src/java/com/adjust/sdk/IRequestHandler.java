/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.adjust.sdk;

import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.IActivityHandler;
import com.adjust.sdk.IPackageHandler;

public interface IRequestHandler {
    public void init(IActivityHandler var1, IPackageHandler var2);

    public void sendPackage(ActivityPackage var1, int var2);

    public void teardown();
}

