/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Point
 *  android.graphics.Rect
 *  java.lang.Object
 *  microsoft.mappoint.TileSystem
 */
package org.osmdroid.util;

import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import microsoft.mappoint.TileSystem;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.util.MyMath;

public abstract class TileLooper {
    protected final Point mLowerRight = new Point();
    protected final Point mUpperLeft = new Point();

    public abstract void finaliseLoop();

    public abstract void handleTile(Canvas var1, int var2, MapTile var3, int var4, int var5);

    public abstract void initialiseLoop(int var1, int var2);

    public final void loop(Canvas canvas, int n2, int n3, Rect rect) {
        TileSystem.PixelXYToTileXY((int)rect.left, (int)rect.top, (Point)this.mUpperLeft);
        this.mUpperLeft.offset(-1, -1);
        TileSystem.PixelXYToTileXY((int)rect.right, (int)rect.bottom, (Point)this.mLowerRight);
        int n4 = 1 << n2;
        this.initialiseLoop(n2, n3);
        for (int i2 = this.mUpperLeft.y; i2 <= this.mLowerRight.y; ++i2) {
            for (int i3 = this.mUpperLeft.x; i3 <= this.mLowerRight.x; ++i3) {
                int n5 = MyMath.mod(i2, n4);
                this.handleTile(canvas, n3, new MapTile(n2, MyMath.mod(i3, n4), n5), i3, i2);
            }
        }
        this.finaliseLoop();
    }
}

