/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  org.objenesis.b
 *  org.objenesis.g.b
 */
package org.objenesis;

import org.objenesis.g.b;

public class d
extends org.objenesis.b {
    public d() {
        super((b)new org.objenesis.g.d());
    }

    public d(boolean bl) {
        super((b)new org.objenesis.g.d(), bl);
    }
}

