/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.util.AbstractList
 *  java.util.AbstractMap
 *  java.util.AbstractQueue
 *  java.util.AbstractSequentialList
 *  java.util.AbstractSet
 *  java.util.ArrayDeque
 *  java.util.ArrayList
 *  java.util.Deque
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.Map
 *  java.util.NavigableMap
 *  java.util.Queue
 *  java.util.Set
 *  java.util.SortedMap
 *  java.util.SortedSet
 *  java.util.TreeMap
 *  java.util.TreeSet
 *  java.util.concurrent.BlockingDeque
 *  java.util.concurrent.BlockingQueue
 *  java.util.concurrent.ConcurrentHashMap
 *  java.util.concurrent.ConcurrentMap
 *  java.util.concurrent.ConcurrentNavigableMap
 *  java.util.concurrent.ConcurrentSkipListMap
 *  java.util.concurrent.LinkedBlockingDeque
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.LinkedTransferQueue
 *  java.util.concurrent.TransferQueue
 */
package h.a.a.s0;

import h.a.a.s0.b;
import java.lang.reflect.Constructor;
import java.util.AbstractList;
import java.util.AbstractMap;
import java.util.AbstractQueue;
import java.util.AbstractSequentialList;
import java.util.AbstractSet;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TransferQueue;

class a {
    private static final Constructor<?> f;
    private final Map<Class<?>, b> a = new HashMap();
    private final boolean b;
    private final boolean c;
    private final Map<Class<?>, Constructor<?>> d = new HashMap();
    private final Map<Class<?>, Constructor<?>> e = new HashMap();

    static {
        void var0_2;
        try {
            f = a.class.getDeclaredConstructor(new Class[0]);
            return;
        }
        catch (SecurityException securityException) {
        }
        catch (NoSuchMethodException noSuchMethodException) {
            // empty catch block
        }
        throw new RuntimeException((Throwable)var0_2);
    }

    a(boolean bl, boolean bl2) {
        this.b = bl;
        boolean bl3 = !bl && bl2;
        this.c = bl3;
    }

    private static Class<?> a(Class<?> object, boolean bl) {
        if (object != Map.class && object != AbstractMap.class) {
            if (object == ConcurrentMap.class) {
                return ConcurrentHashMap.class;
            }
            if (object != SortedMap.class && object != NavigableMap.class) {
                if (object == ConcurrentNavigableMap.class) {
                    return ConcurrentSkipListMap.class;
                }
                if (object != List.class && object != AbstractList.class) {
                    if (object == AbstractSequentialList.class) {
                        return LinkedList.class;
                    }
                    if (object != Set.class && object != AbstractSet.class) {
                        if (object == SortedSet.class) {
                            return TreeSet.class;
                        }
                        if (object != Queue.class && object != AbstractQueue.class && object != Deque.class) {
                            if (object == BlockingQueue.class) {
                                return LinkedBlockingQueue.class;
                            }
                            if (object == BlockingDeque.class) {
                                return LinkedBlockingDeque.class;
                            }
                            if (object == TransferQueue.class) {
                                object = LinkedTransferQueue.class;
                            }
                            return object;
                        }
                        return ArrayDeque.class;
                    }
                    return HashSet.class;
                }
                return ArrayList.class;
            }
            return TreeMap.class;
        }
        return HashMap.class;
    }

    b a(Class<?> class_) {
        b b2 = (b)this.a.get(class_);
        if (b2 == null) {
            Map<Class<?>, b> map = this.a;
            b b3 = new b(class_, this.b, this.c, this);
            map.put(class_, (Object)b3);
            b2 = b3;
        }
        return b2;
    }

    /*
     * Exception decompiling
     */
    Constructor<?> b(Class<?> var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl22 : ALOAD_3 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    Constructor<?> c(Class<?> var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl15 : ALOAD_3 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private static class a {
    }

}

