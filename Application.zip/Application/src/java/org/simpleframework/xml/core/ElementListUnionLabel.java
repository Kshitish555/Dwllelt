/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementListUnion
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Group
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementListUnion;
import org.simpleframework.xml.core.CompositeListUnion;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.ElementListLabel;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Group;
import org.simpleframework.xml.core.GroupExtractor;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.TemplateLabel;
import org.simpleframework.xml.core.UnionException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.Format;

class ElementListUnionLabel
extends TemplateLabel {
    private Contact contact;
    private GroupExtractor extractor;
    private Label label;
    private Expression path;

    public ElementListUnionLabel(Contact contact, ElementListUnion elementListUnion, ElementList elementList, Format format) throws Exception {
        this.label = new ElementListLabel(contact, elementList, format);
        this.extractor = new GroupExtractor(contact, (Annotation)elementListUnion, format);
        this.contact = contact;
    }

    public Annotation getAnnotation() {
        return this.label.getAnnotation();
    }

    public Contact getContact() {
        return this.contact;
    }

    public Converter getConverter(Context context) throws Exception {
        Expression expression = this.getExpression();
        Contact contact = this.getContact();
        if (contact != null) {
            return new CompositeListUnion(context, this.extractor, expression, contact);
        }
        Object[] arrobject = new Object[]{this.label};
        throw new UnionException("Union %s was not declared on a field or method", arrobject);
    }

    public Decorator getDecorator() throws Exception {
        return this.label.getDecorator();
    }

    @Override
    public Type getDependent() throws Exception {
        return this.label.getDependent();
    }

    public Object getEmpty(Context context) throws Exception {
        return this.label.getEmpty(context);
    }

    @Override
    public String getEntry() throws Exception {
        return this.label.getEntry();
    }

    public Expression getExpression() throws Exception {
        if (this.path == null) {
            this.path = this.label.getExpression();
        }
        return this.path;
    }

    @Override
    public Label getLabel(Class class_) {
        return this;
    }

    public String getName() throws Exception {
        return this.label.getName();
    }

    @Override
    public String[] getNames() throws Exception {
        return this.extractor.getNames();
    }

    public String getOverride() {
        return this.label.getOverride();
    }

    public String getPath() throws Exception {
        return this.label.getPath();
    }

    @Override
    public String[] getPaths() throws Exception {
        return this.extractor.getPaths();
    }

    public Class getType() {
        return this.label.getType();
    }

    @Override
    public Type getType(Class class_) {
        return this.getContact();
    }

    @Override
    public boolean isCollection() {
        return this.label.isCollection();
    }

    public boolean isData() {
        return this.label.isData();
    }

    @Override
    public boolean isInline() {
        return this.label.isInline();
    }

    public boolean isRequired() {
        return this.label.isRequired();
    }

    @Override
    public boolean isTextList() {
        return this.extractor.isTextList();
    }

    @Override
    public boolean isUnion() {
        return true;
    }

    public String toString() {
        return this.label.toString();
    }
}

