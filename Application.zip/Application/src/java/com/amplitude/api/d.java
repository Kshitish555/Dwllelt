/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.amplitude.api;

import android.util.Log;

public class d {
    protected static d c = new d();
    private volatile boolean a = true;
    private volatile int b = 4;

    private d() {
    }

    public static d a() {
        return c;
    }

    int a(int n2, String string, String string2) {
        return Log.println((int)n2, (String)string, (String)string2);
    }

    int a(String string, String string2) {
        if (this.a && this.b <= 3) {
            return Log.d((String)string, (String)string2);
        }
        return 0;
    }

    int a(String string, String string2, Throwable throwable) {
        if (this.a && this.b <= 3) {
            return Log.d((String)string, (String)string2, (Throwable)throwable);
        }
        return 0;
    }

    int a(String string, Throwable throwable) {
        if (this.a && this.b <= 5) {
            return Log.w((String)string, (Throwable)throwable);
        }
        return 0;
    }

    d a(int n2) {
        this.b = n2;
        return c;
    }

    d a(boolean bl) {
        this.a = bl;
        return c;
    }

    String a(Throwable throwable) {
        return Log.getStackTraceString((Throwable)throwable);
    }

    boolean a(String string, int n2) {
        return Log.isLoggable((String)string, (int)n2);
    }

    int b(String string, String string2) {
        if (this.a && this.b <= 6) {
            return Log.e((String)string, (String)string2);
        }
        return 0;
    }

    int b(String string, String string2, Throwable throwable) {
        if (this.a && this.b <= 6) {
            return Log.e((String)string, (String)string2, (Throwable)throwable);
        }
        return 0;
    }

    int b(String string, Throwable throwable) {
        if (this.a && this.b <= 7) {
            return Log.wtf((String)string, (Throwable)throwable);
        }
        return 0;
    }

    int c(String string, String string2) {
        if (this.a && this.b <= 4) {
            return Log.i((String)string, (String)string2);
        }
        return 0;
    }

    int c(String string, String string2, Throwable throwable) {
        if (this.a && this.b <= 4) {
            return Log.i((String)string, (String)string2, (Throwable)throwable);
        }
        return 0;
    }

    int d(String string, String string2) {
        if (this.a && this.b <= 2) {
            return Log.v((String)string, (String)string2);
        }
        return 0;
    }

    int d(String string, String string2, Throwable throwable) {
        if (this.a && this.b <= 2) {
            return Log.v((String)string, (String)string2, (Throwable)throwable);
        }
        return 0;
    }

    int e(String string, String string2) {
        if (this.a && this.b <= 5) {
            return Log.w((String)string, (String)string2);
        }
        return 0;
    }

    int e(String string, String string2, Throwable throwable) {
        if (this.a && this.b <= 5) {
            return Log.w((String)string, (String)string2, (Throwable)throwable);
        }
        return 0;
    }

    int f(String string, String string2) {
        if (this.a && this.b <= 7) {
            return Log.wtf((String)string, (String)string2);
        }
        return 0;
    }

    int f(String string, String string2, Throwable throwable) {
        if (this.a && this.b <= 7) {
            return Log.wtf((String)string, (String)string2, (Throwable)throwable);
        }
        return 0;
    }
}

