/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package org.simpleframework.xml.core;

final class MethodType
extends Enum<MethodType> {
    private static final /* synthetic */ MethodType[] $VALUES;
    public static final /* enum */ MethodType GET;
    public static final /* enum */ MethodType IS;
    public static final /* enum */ MethodType NONE;
    public static final /* enum */ MethodType SET;
    private int prefix;

    static {
        MethodType methodType;
        GET = new MethodType(3);
        IS = new MethodType(2);
        SET = new MethodType(3);
        NONE = methodType = new MethodType(0);
        MethodType[] arrmethodType = new MethodType[]{GET, IS, SET, methodType};
        $VALUES = arrmethodType;
    }

    private MethodType(int n3) {
        this.prefix = n3;
    }

    public static MethodType valueOf(String string2) {
        return (MethodType)Enum.valueOf(MethodType.class, (String)string2);
    }

    public static MethodType[] values() {
        return (MethodType[])$VALUES.clone();
    }

    public int getPrefix() {
        return this.prefix;
    }
}

