/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package h.a.a.s0;

class m<K> {
    private final K a;

    public m(K k2) {
        this.a = k2;
    }

    public boolean equals(Object object) {
        return object != null && object instanceof m && this.a == ((m)object).a;
    }

    public int hashCode() {
        return this.a.hashCode();
    }

    public String toString() {
        return this.a.toString();
    }
}

