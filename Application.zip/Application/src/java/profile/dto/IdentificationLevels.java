/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 */
package profile.dto;

import kotlin.Metadata;

@Metadata(bv={1, 0, 3}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006\u00a8\u0006\u0007"}, d2={"Lprofile/dto/IdentificationLevels;", "", "(Ljava/lang/String;I)V", "ANONYMOUS", "SIMPLE", "VERIFIED", "FULL", "profile_release"}, k=1, mv={1, 1, 15})
public final class IdentificationLevels
extends Enum<IdentificationLevels> {
    private static final /* synthetic */ IdentificationLevels[] $VALUES;
    public static final /* enum */ IdentificationLevels ANONYMOUS;
    public static final /* enum */ IdentificationLevels FULL;
    public static final /* enum */ IdentificationLevels SIMPLE;
    public static final /* enum */ IdentificationLevels VERIFIED;

    static {
        IdentificationLevels identificationLevels;
        IdentificationLevels identificationLevels2;
        IdentificationLevels identificationLevels3;
        IdentificationLevels identificationLevels4;
        IdentificationLevels[] arridentificationLevels = new IdentificationLevels[4];
        ANONYMOUS = identificationLevels2 = new IdentificationLevels();
        arridentificationLevels[0] = identificationLevels2;
        SIMPLE = identificationLevels4 = new IdentificationLevels();
        arridentificationLevels[1] = identificationLevels4;
        VERIFIED = identificationLevels3 = new IdentificationLevels();
        arridentificationLevels[2] = identificationLevels3;
        FULL = identificationLevels = new IdentificationLevels();
        arridentificationLevels[3] = identificationLevels;
        $VALUES = arridentificationLevels;
    }

    public static IdentificationLevels valueOf(String string) {
        return (IdentificationLevels)Enum.valueOf(IdentificationLevels.class, (String)string);
    }

    public static IdentificationLevels[] values() {
        return (IdentificationLevels[])$VALUES.clone();
    }
}

