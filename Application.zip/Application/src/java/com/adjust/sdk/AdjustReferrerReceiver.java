/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  java.lang.String
 */
package com.adjust.sdk;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.adjust.sdk.Adjust;

public class AdjustReferrerReceiver
extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        String string = intent.getStringExtra("referrer");
        if (string == null) {
            return;
        }
        Adjust.getDefaultInstance().sendReferrer(string, context);
    }
}

