/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  androidx.annotation.h0
 *  androidx.annotation.i0
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  java.lang.Object
 *  lifecyclesurviveapi.l
 *  lifecyclesurviveapi.m
 *  lifecyclesurviveapi.p
 */
package lifecyclesurviveapi;

import android.os.Bundle;
import androidx.annotation.h0;
import androidx.annotation.i0;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import lifecyclesurviveapi.ComponentControllerFragment;
import lifecyclesurviveapi.l;
import lifecyclesurviveapi.m;
import lifecyclesurviveapi.p;

public abstract class PresenterControllerFragment<C extends l<P>, P extends m>
extends ComponentControllerFragment<C> {
    private p<P> mPresenterDelegate = new p();

    public P getPresenter() {
        return (P)this.mPresenterDelegate.a();
    }

    @Override
    public void onCreate(@i0 Bundle bundle) {
        super.onCreate(bundle);
        this.mPresenterDelegate.a(((l)this.getComponent()).q0(), bundle);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.mPresenterDelegate.a(this.getActivity().isFinishing());
    }

    public void onDestroyView() {
        Fragment.super.onDestroyView();
        this.mPresenterDelegate.b();
    }

    @Override
    public void onResume() {
        super.onResume();
        this.mPresenterDelegate.c();
        this.mPresenterDelegate.a((Object)this);
    }

    @Override
    public void onSaveInstanceState(@h0 Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.mPresenterDelegate.a(bundle);
    }
}

