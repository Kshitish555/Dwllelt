/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  java.lang.Object
 */
package org.osmdroid;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class SensorEventListenerProxy
implements SensorEventListener {
    private SensorEventListener mListener = null;
    private final SensorManager mSensorManager;

    public SensorEventListenerProxy(SensorManager sensorManager) {
        this.mSensorManager = sensorManager;
    }

    public void onAccuracyChanged(Sensor sensor, int n2) {
        SensorEventListener sensorEventListener = this.mListener;
        if (sensorEventListener != null) {
            sensorEventListener.onAccuracyChanged(sensor, n2);
        }
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        SensorEventListener sensorEventListener = this.mListener;
        if (sensorEventListener != null) {
            sensorEventListener.onSensorChanged(sensorEvent);
        }
    }

    public boolean startListening(SensorEventListener sensorEventListener, int n2, int n3) {
        Sensor sensor = this.mSensorManager.getDefaultSensor(n2);
        if (sensor == null) {
            return false;
        }
        this.mListener = sensorEventListener;
        return this.mSensorManager.registerListener((SensorEventListener)this, sensor, n3);
    }

    public void stopListening() {
        this.mListener = null;
        this.mSensorManager.unregisterListener((SensorEventListener)this);
    }
}

