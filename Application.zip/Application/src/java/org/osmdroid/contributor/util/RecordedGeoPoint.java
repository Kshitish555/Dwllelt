/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.System
 *  org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants
 */
package org.osmdroid.contributor.util;

import org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants;
import org.osmdroid.util.GeoPoint;

public class RecordedGeoPoint
extends GeoPoint
implements OpenStreetMapContributorConstants {
    private static final long serialVersionUID = 7304941424576720318L;
    protected final int mNumSatellites;
    protected final long mTimeStamp;

    public RecordedGeoPoint(int n2, int n3) {
        this(n2, n3, System.currentTimeMillis(), Integer.MIN_VALUE);
    }

    public RecordedGeoPoint(int n2, int n3, long l2, int n4) {
        super(n2, n3);
        this.mTimeStamp = l2;
        this.mNumSatellites = n4;
    }

    public double getLatitudeAsDouble() {
        double d2 = this.getLatitudeE6();
        Double.isNaN((double)d2);
        return d2 / 1000000.0;
    }

    public double getLongitudeAsDouble() {
        double d2 = this.getLongitudeE6();
        Double.isNaN((double)d2);
        return d2 / 1000000.0;
    }

    public int getNumSatellites() {
        return this.mNumSatellites;
    }

    public long getTimeStamp() {
        return this.mTimeStamp;
    }
}

