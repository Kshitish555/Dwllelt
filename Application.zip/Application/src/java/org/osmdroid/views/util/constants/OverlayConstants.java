/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.osmdroid.views.util.constants;

public interface OverlayConstants {
    public static final boolean DEBUGMODE = false;
    public static final int DEFAULT_ZOOMLEVEL_MINIMAP_DIFFERENCE = 3;
    public static final int NOT_SET = Integer.MIN_VALUE;
}

