/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.i.i.c
 *  l.a.j.e
 *  l.a.j.e$b
 *  l.a.j.e$c
 *  l.a.j.e$g
 *  l.a.j.m$b
 *  l.a.j.m$b$a
 *  l.a.j.m$c
 *  l.a.j.q.b
 */
package l.a.j;

import l.a.j.e;
import l.a.j.m;

/*
 * Exception performing whole class analysis.
 */
public final class m
extends Enum<m>
implements e.b {
    public static final /* enum */ m c;
    private static final /* synthetic */ m[] d;

    static {
        m m2;
        c = m2 = new m();
        d = new m[]{m2};
    }

    public static m valueOf(String string) {
        return (m)Enum.valueOf(m.class, (String)string);
    }

    public static m[] values() {
        return (m[])d.clone();
    }

    public l.a.i.i.c a(l.a.i.i.c c2) {
        return c2;
    }

    public e a(e e2) {
        e[] arre = new e[]{c.c, e2};
        return new e.c(arre);
    }

    public l.a.j.q.b a(e.g g2) {
        return new /* Unavailable Anonymous Inner Class!! */;
    }
}

