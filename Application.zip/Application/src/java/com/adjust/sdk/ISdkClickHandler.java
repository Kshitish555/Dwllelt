/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.adjust.sdk;

import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.IActivityHandler;

public interface ISdkClickHandler {
    public void init(IActivityHandler var1, boolean var2);

    public void pauseSending();

    public void resumeSending();

    public void sendReftagReferrers();

    public void sendSdkClick(ActivityPackage var1);

    public void teardown();
}

