/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.simpleframework.xml.core.Parameter
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Parameter;

abstract class TemplateParameter
implements Parameter {
    protected TemplateParameter() {
    }

    public boolean isAttribute() {
        return false;
    }

    public boolean isText() {
        return false;
    }
}

