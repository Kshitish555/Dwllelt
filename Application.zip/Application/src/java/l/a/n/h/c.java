/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  edu.umd.cs.findbugs.annotations.SuppressFBWarnings
 *  java.lang.Double
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.Map
 *  l.a.h.i.a
 *  l.a.j.q.f
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.u
 *  l.a.n.a
 *  l.a.n.h.c$a
 */
package l.a.n.h;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import l.a.j.q.f;
import l.a.k.a.n;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.u;
import l.a.n.h.c;

public class c
extends r {
    private static final int[] s;
    private List<f> f = new ArrayList();
    private final Map<q, List<f>> h = new HashMap();
    private int o;

    static {
        int[] arrn;
        s = new int[202];
        for (int i2 = 0; i2 < (arrn = s).length; ++i2) {
            arrn[i2] = -69 + "EFFFFFFFFGGFFFGGFFFEEFGFGFEEEEEEEEEEEEEEEEEEEEDEDEDDDDDCDCDEEEEEEEEEEEEEEEEEEEEBABABBBBDCFFFGGGEDCDCDCDCDCDCDCDCDCDCEEEEDDDDDDDCDCDCEFEFDDEEFFDEDEEEBDDBBDDDDDDCCCCCCCCEEEDDDCDCDEEEEEEEEEEFEEEEEEDDEEDDEE".charAt(i2);
        }
    }

    public c(r r2, l.a.h.i.a a2) {
        super(327680, r2);
        this.o = a2.l();
    }

    private void a(List<f> list) {
        ListIterator listIterator = list.listIterator(list.size());
        while (listIterator.hasPrevious()) {
            f f2 = (f)listIterator.previous();
            int n2 = a.a[f2.ordinal()];
            if (n2 != 1) {
                if (n2 == 2) {
                    super.a(88);
                    continue;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected stack size: ");
                stringBuilder.append((Object)f2);
                throw new IllegalStateException(stringBuilder.toString());
            }
            super.a(87);
        }
    }

    private void b(int n2) {
        this.e(n2, 0);
    }

    private void e(int n2, int n3) {
        IllegalStateException illegalStateException;
        if (n2 <= 2) {
            if (n2 > 0) {
                int n4 = this.f.size();
                while (n3 > 0 && n4 > 0) {
                    List<f> list = this.f;
                    n3 -= ((f)list.get(--n4)).c();
                }
                if (n3 >= 0) {
                    this.f.add(n4, (Object)f.a((int)n2));
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected offset underflow: ");
                stringBuilder.append(n3);
                throw new IllegalStateException(stringBuilder.toString());
            }
            if (n3 == 0) {
                while (n2 < 0) {
                    if (this.f.isEmpty()) {
                        return;
                    }
                    List<f> list = this.f;
                    n2 += ((f)list.remove(list.size() - 1)).c();
                }
                if (n2 == 1) {
                    this.f.add((Object)f.f);
                    return;
                }
                if (n2 == 0) {
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected remainder on the operand stack: ");
                stringBuilder.append(n2);
                throw new IllegalStateException(stringBuilder.toString());
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot specify non-zero offset ");
            stringBuilder.append(n3);
            stringBuilder.append(" for non-incrementing value: ");
            stringBuilder.append(n2);
            throw new IllegalStateException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot push multiple values onto the operand stack: ");
        stringBuilder.append(n2);
        illegalStateException = new IllegalStateException(stringBuilder.toString());
        throw illegalStateException;
    }

    public int a(int n2, int n3, f f2) {
        int n4;
        block6 : {
            block5 : {
                block4 : {
                    List<f> list = this.f;
                    n4 = ((f)list.get(list.size() - 1)).c() - f2.c();
                    if (this.f.size() == 1 && n4 == 0) {
                        return 0;
                    }
                    super.d(n2, this.o);
                    if (n4 != 1) break block4;
                    super.a(87);
                    break block5;
                }
                if (n4 != 0) break block6;
            }
            List<f> list = this.f;
            this.a((List<f>)list.subList(0, list.size() - 1));
            super.d(n3, this.o);
            return this.o + f2.c();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected remainder on the operand stack: ");
        stringBuilder.append(n4);
        throw new IllegalStateException(stringBuilder.toString());
    }

    /*
     * Exception decompiling
     */
    public void a(int var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:478)
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:61)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:372)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public /* varargs */ void a(int n2, int n3, q q2, q ... arrq) {
        this.b(-1);
        ArrayList arrayList = new ArrayList(this.f);
        this.h.put((Object)q2, (Object)arrayList);
        int n4 = arrq.length;
        for (int i2 = 0; i2 < n4; ++i2) {
            q q3 = arrq[i2];
            this.h.put((Object)q3, (Object)arrayList);
        }
        super.a(n2, n3, q2, arrq);
    }

    public void a(int n2, String string) {
        this.b(s[n2]);
        super.a(n2, string);
    }

    public void a(int n2, String string, String string2, String string3) {
        int n3 = u.f((String)string3).i();
        switch (n2) {
            default: {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unexpected opcode: ");
                stringBuilder.append(n2);
                throw new IllegalStateException(stringBuilder.toString());
            }
            case 181: {
                this.b(-1 + -n3);
                break;
            }
            case 180: {
                this.b(-1);
                this.b(n3);
                break;
            }
            case 179: {
                this.b(-n3);
                break;
            }
            case 178: {
                this.b(n3);
            }
        }
        super.a(n2, string, string2, string3);
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        int n3 = u.b((String)string3);
        int n4 = -(n3 >> 2);
        int n5 = n2 == 184 ? 1 : 0;
        this.b(n4 + n5);
        this.b(n3 & 3);
        super.a(n2, string, string2, string3, bl);
    }

    public void a(int n2, q q2) {
        this.b(s[n2]);
        Map<q, List<f>> map = this.h;
        List list = n2 == 168 ? l.a.n.a.a(this.f, (Object)f.f) : this.f;
        map.put((Object)q2, (Object)new ArrayList((Collection)list));
        if (n2 == 167) {
            this.f.clear();
        }
        super.a(n2, q2);
    }

    public void a(Object object) {
        int n2 = !(object instanceof Long) && !(object instanceof Double) ? 1 : 2;
        this.b(n2);
        super.a(object);
    }

    public void a(String string, int n2) {
        this.b(1 - n2);
        super.a(string, n2);
    }

    public /* varargs */ void a(String string, String string2, n n2, Object ... arrobject) {
        int n3 = u.b((String)string2);
        this.b(1 + -(n3 >> 2));
        this.b(n3 & 3);
        super.a(string, string2, n2, arrobject);
    }

    public void a(q q2) {
        List list = (List)this.h.get((Object)q2);
        if (list != null) {
            this.f = new ArrayList((Collection)list);
        }
        super.a(q2);
    }

    public void a(q q2, List<f> list) {
        this.h.put((Object)q2, list);
    }

    public void a(q q2, q q3, q q4, String string) {
        this.h.put((Object)q4, (Object)Collections.singletonList((Object)f.f));
        super.a(q2, q3, q4, string);
    }

    public void a(q q2, int[] arrn, q[] arrq) {
        this.b(-1);
        ArrayList arrayList = new ArrayList(this.f);
        this.h.put((Object)q2, (Object)arrayList);
        int n2 = arrq.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            q q3 = arrq[i2];
            this.h.put((Object)q3, (Object)arrayList);
        }
        super.a(q2, arrn, arrq);
    }

    public void b(int n2, int n3) {
        this.b(s[n2]);
        super.b(n2, n3);
    }

    public void b(int n2, q q2) {
        super.b(n2, q2);
    }

    @SuppressFBWarnings(justification="No default behavior is applied", value={"SF_SWITCH_NO_DEFAULT"})
    public void d(int n2, int n3) {
        if (n2 != 169) {
            switch (n2) {
                default: {
                    break;
                }
                case 55: 
                case 57: {
                    this.o = Math.max((int)this.o, (int)(n3 + 2));
                    break;
                }
                case 54: 
                case 56: 
                case 58: {
                    this.o = Math.max((int)this.o, (int)(n3 + 1));
                    break;
                }
            }
        } else {
            this.f.clear();
        }
        this.b(s[n2]);
        super.d(n2, n3);
    }

    public void e() {
        this.a(this.f);
    }
}

