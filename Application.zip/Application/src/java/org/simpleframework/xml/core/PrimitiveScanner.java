/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  org.simpleframework.xml.Order
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Caller
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.Function
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 *  org.simpleframework.xml.core.ParameterMap
 *  org.simpleframework.xml.core.Policy
 */
package org.simpleframework.xml.core;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.Caller;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.Function;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.ParameterMap;
import org.simpleframework.xml.core.Policy;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.Section;
import org.simpleframework.xml.core.Signature;

class PrimitiveScanner
implements Scanner {
    private final Detail detail;
    private final Section section = new Section(this){
        private final List<String> list = new LinkedList();
        private final Scanner scanner;
        {
            this.scanner = scanner;
        }

        @Override
        public String getAttribute(String string2) {
            return null;
        }

        @Override
        public LabelMap getAttributes() {
            return new LabelMap((Policy)this.scanner);
        }

        @Override
        public Label getElement(String string2) {
            return null;
        }

        @Override
        public LabelMap getElements() {
            return new LabelMap((Policy)this.scanner);
        }

        @Override
        public String getName() {
            return null;
        }

        @Override
        public String getPath(String string2) {
            return null;
        }

        @Override
        public String getPrefix() {
            return null;
        }

        @Override
        public Section getSection(String string2) {
            return null;
        }

        @Override
        public Label getText() {
            return null;
        }

        @Override
        public boolean isSection(String string2) {
            return false;
        }

        public Iterator<String> iterator() {
            return this.list.iterator();
        }
    };

    public PrimitiveScanner(Detail detail) {
        this.detail = detail;
    }

    @Override
    public Caller getCaller(Context context) {
        return new Caller((Scanner)this, context);
    }

    @Override
    public Function getCommit() {
        return null;
    }

    @Override
    public Function getComplete() {
        return null;
    }

    @Override
    public Decorator getDecorator() {
        return null;
    }

    @Override
    public Instantiator getInstantiator() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public Order getOrder() {
        return null;
    }

    @Override
    public ParameterMap getParameters() {
        return new ParameterMap();
    }

    @Override
    public Function getPersist() {
        return null;
    }

    @Override
    public Function getReplace() {
        return null;
    }

    @Override
    public Function getResolve() {
        return null;
    }

    @Override
    public Version getRevision() {
        return null;
    }

    @Override
    public Section getSection() {
        return this.section;
    }

    @Override
    public Signature getSignature() {
        return null;
    }

    @Override
    public List<Signature> getSignatures() {
        return new LinkedList();
    }

    @Override
    public Label getText() {
        return null;
    }

    @Override
    public Class getType() {
        return this.detail.getType();
    }

    @Override
    public Function getValidate() {
        return null;
    }

    @Override
    public Label getVersion() {
        return null;
    }

    @Override
    public boolean isEmpty() {
        return true;
    }

    @Override
    public boolean isPrimitive() {
        return true;
    }

    @Override
    public boolean isStrict() {
        return true;
    }

}

