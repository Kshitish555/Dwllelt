/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.System
 *  l.a.k.a.a
 *  l.a.k.a.c
 *  l.a.k.a.d
 *  l.a.k.a.e
 *  l.a.k.a.f
 *  l.a.k.a.k
 *  l.a.k.a.n
 *  l.a.k.a.p
 *  l.a.k.a.r
 *  l.a.k.a.u
 *  l.a.k.a.v
 */
package l.a.k.a;

import l.a.k.a.a;
import l.a.k.a.b;
import l.a.k.a.c;
import l.a.k.a.d;
import l.a.k.a.e;
import l.a.k.a.f;
import l.a.k.a.k;
import l.a.k.a.l;
import l.a.k.a.n;
import l.a.k.a.p;
import l.a.k.a.r;
import l.a.k.a.s;
import l.a.k.a.u;
import l.a.k.a.v;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class g
extends f {
    public static final int v5 = 1;
    public static final int w5 = 2;
    static final byte[] x5;
    final p P4;
    final p Q4;
    final p R4;
    final p S4;
    p[] T4;
    private short U4;
    private int V4;
    private int W4;
    String X4;
    private int Y4;
    private int Z4;
    private int a5;
    private int[] b5;
    private int c5;
    private d d5;
    private int e5;
    e f;
    private int f5;
    private b g5;
    int h;
    private b h5;
    private b i5;
    private b j5;
    private c k5;
    private int l5;
    private d m5;
    int n5;
    int o = 1;
    d o5;
    l p5;
    l q5;
    s r5;
    final d s = new d();
    s s5;
    p[] t;
    private int t5;
    boolean u5;
    int w;

    static {
        g.c();
        byte[] arrby = new byte[220];
        for (int i2 = 0; i2 < 220; ++i2) {
            arrby[i2] = (byte)(-65 + "AAAAAAAAAAAAAAAABCLMMDDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAADDDDDEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANAAAAAAAAAAAAAAAAAAAAJJJJJJJJJJJJJJJJDOPAAAAAAGGGGGGGHIFBFAAFFAARQJJKKSSSSSSSSSSSSSSSSSS".charAt(i2));
        }
        x5 = arrby;
    }

    public g(int n2) {
        super(327680);
        p[] arrp = new p[256];
        this.t = arrp;
        double d2 = arrp.length;
        Double.isNaN((double)d2);
        this.w = (int)(d2 * 0.75);
        this.P4 = new p();
        this.Q4 = new p();
        this.R4 = new p();
        this.S4 = new p();
        int n3 = (n2 & 2) != 0 ? 0 : ((n2 & 1) != 0 ? 2 : 3);
        this.t5 = n3;
    }

    public g(e e2, int n2) {
        this(n2);
        e2.a(this);
        this.f = e2;
    }

    private p a(p p2) {
        p[] arrp = this.t;
        p p3 = arrp[p2.h % arrp.length];
        while (!(p3 == null || p3.b == p2.b && p2.a(p3))) {
            p3 = p3.i;
        }
        return p3;
    }

    private void a(int n2, int n3, int n4) {
        this.s.b(n2, n3).c(n4);
    }

    private void b(int n2, int n3, int n4) {
        this.s.a(n2, n3).c(n4);
    }

    private void b(p p2) {
        if (this.o + this.U4 > this.w) {
            int n2 = this.t.length;
            int n3 = 1 + n2 * 2;
            p[] arrp = new p[n3];
            for (int i2 = n2 - 1; i2 >= 0; --i2) {
                p p3 = this.t[i2];
                while (p3 != null) {
                    int n4 = p3.h % n3;
                    p p4 = p3.i;
                    p3.i = arrp[n4];
                    arrp[n4] = p3;
                    p3 = p4;
                }
            }
            this.t = arrp;
            double d2 = n3;
            Double.isNaN((double)d2);
            this.w = (int)(d2 * 0.75);
        }
        int n5 = p2.h;
        p[] arrp = this.t;
        int n6 = n5 % arrp.length;
        p2.i = arrp[n6];
        arrp[n6] = p2;
    }

    private p c(p p2) {
        short s2;
        short s3;
        p[] arrp;
        this.U4 = s2 = (short)(1 + this.U4);
        p p3 = new p((int)s2, this.P4);
        this.b(p3);
        if (this.T4 == null) {
            this.T4 = new p[16];
        }
        if ((s3 = this.U4) == (arrp = this.T4).length) {
            p[] arrp2 = new p[2 * arrp.length];
            System.arraycopy((Object)arrp, (int)0, (Object)arrp2, (int)0, (int)arrp.length);
            this.T4 = arrp2;
        }
        this.T4[this.U4] = p3;
        return p3;
    }

    static /* synthetic */ void c() {
    }

    private p f(String string) {
        this.Q4.a(8, string, null, null);
        p p2 = this.a(this.Q4);
        if (p2 == null) {
            this.s.b(8, this.e(string));
            int n2 = this.o;
            this.o = n2 + 1;
            p2 = new p(n2, this.Q4);
            this.b(p2);
        }
        return p2;
    }

    int a(int n2, int n3) {
        p p2 = this.Q4;
        p2.b = 32;
        p2.d = (long)n2 | (long)n3 << 32;
        p2.h = Integer.MAX_VALUE & n3 + (n2 + 32);
        p p3 = this.a(p2);
        if (p3 == null) {
            p[] arrp = this.T4;
            String string = arrp[n2].e;
            String string2 = arrp[n3].e;
            this.Q4.c = this.b(this.c(string, string2));
            p3 = new p(0, this.Q4);
            this.b(p3);
        }
        return p3.c;
    }

    public int a(int n2, String string, String string2, String string3) {
        boolean bl = n2 == 9;
        return this.b(n2, string, string2, string3, bl);
    }

    int a(String string, int n2) {
        p p2 = this.P4;
        p2.b = 31;
        p2.c = n2;
        p2.e = string;
        p2.h = Integer.MAX_VALUE & n2 + (31 + string.hashCode());
        p p3 = this.a(this.P4);
        if (p3 == null) {
            p3 = this.c(this.P4);
        }
        return p3.a;
    }

    public final a a(int n2, v v2, String string, boolean bl) {
        d d2 = new d();
        b.a(n2, v2, d2);
        d2.c(this.e(string)).c(0);
        b b2 = new b(this, true, d2, d2, -2 + d2.b);
        if (bl) {
            b2.i = this.i5;
            this.i5 = b2;
            return b2;
        }
        b2.i = this.j5;
        this.j5 = b2;
        return b2;
    }

    public final a a(String string, boolean bl) {
        d d2 = new d();
        d2.c(this.e(string)).c(0);
        b b2 = new b(this, true, d2, d2, 2);
        if (bl) {
            b2.i = this.g5;
            this.g5 = b2;
            return b2;
        }
        b2.i = this.h5;
        this.h5 = b2;
        return b2;
    }

    public final k a(int n2, String string, String string2, String string3, Object object) {
        l l2 = new l(this, n2, string, string2, string3, object);
        return l2;
    }

    p a(double d2) {
        this.P4.a(d2);
        p p2 = this.a(this.P4);
        if (p2 == null) {
            this.s.a(6).a(this.P4.d);
            p2 = new p(this.o, this.P4);
            this.o = 2 + this.o;
            this.b(p2);
        }
        return p2;
    }

    p a(float f2) {
        this.P4.a(f2);
        p p2 = this.a(this.P4);
        if (p2 == null) {
            this.s.a(4).b(this.P4.c);
            int n2 = this.o;
            this.o = n2 + 1;
            p2 = new p(n2, this.P4);
            this.b(p2);
        }
        return p2;
    }

    p a(int n2) {
        this.P4.a(n2);
        p p2 = this.a(this.P4);
        if (p2 == null) {
            this.s.a(3).b(n2);
            int n3 = this.o;
            this.o = n3 + 1;
            p2 = new p(n3, this.P4);
            this.b(p2);
        }
        return p2;
    }

    p a(int n2, String string, String string2, String string3, boolean bl) {
        this.S4.a(n2 + 20, string, string2, string3);
        p p2 = this.a(this.S4);
        if (p2 == null) {
            int n3 = n2 <= 4 ? this.c(string, string2, string3) : this.b(string, string2, string3, bl);
            this.b(15, n2, n3);
            int n4 = this.o;
            this.o = n4 + 1;
            p2 = new p(n4, this.S4);
            this.b(p2);
        }
        return p2;
    }

    p a(long l2) {
        this.P4.a(l2);
        p p2 = this.a(this.P4);
        if (p2 == null) {
            this.s.a(5).a(l2);
            p2 = new p(this.o, this.P4);
            this.o = 2 + this.o;
            this.b(p2);
        }
        return p2;
    }

    p a(Object object) {
        if (object instanceof Integer) {
            return this.a((Integer)object);
        }
        if (object instanceof Byte) {
            return this.a(((Byte)object).intValue());
        }
        if (object instanceof Character) {
            return this.a(((Character)object).charValue());
        }
        if (object instanceof Short) {
            return this.a(((Short)object).intValue());
        }
        if (object instanceof Boolean) {
            return this.a((int)((Boolean)object).booleanValue());
        }
        if (object instanceof Float) {
            return this.a(((Float)object).floatValue());
        }
        if (object instanceof Long) {
            return this.a((Long)object);
        }
        if (object instanceof Double) {
            return this.a((Double)object);
        }
        if (object instanceof String) {
            return this.f((String)object);
        }
        if (object instanceof u) {
            u u2 = (u)object;
            int n2 = u2.j();
            if (n2 == 10) {
                return this.a(u2.g());
            }
            String string = u2.d();
            if (n2 == 11) {
                return this.b(string);
            }
            return this.a(string);
        }
        if (object instanceof n) {
            n n3 = (n)object;
            return this.a(n3.a, n3.b, n3.c, n3.d, n3.e);
        }
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("value ");
        stringBuffer.append(object);
        throw new IllegalArgumentException(stringBuffer.toString());
    }

    p a(String string) {
        this.Q4.a(7, string, null, null);
        p p2 = this.a(this.Q4);
        if (p2 == null) {
            this.s.b(7, this.e(string));
            int n2 = this.o;
            this.o = n2 + 1;
            p2 = new p(n2, this.Q4);
            this.b(p2);
        }
        return p2;
    }

    p a(String string, String string2, String string3, boolean bl) {
        int n2 = bl ? 11 : 10;
        this.R4.a(n2, string, string2, string3);
        p p2 = this.a(this.R4);
        if (p2 == null) {
            this.a(n2, this.c(string), this.d(string2, string3));
            int n3 = this.o;
            this.o = n3 + 1;
            p2 = new p(n3, this.R4);
            this.b(p2);
        }
        return p2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    /* varargs */ p a(String var1_1, String var2_2, n var3_3, Object ... var4_4) {
        var5_5 = this.o5;
        if (var5_5 == null) {
            this.o5 = var5_5 = new d();
        }
        var6_6 = var5_5.b;
        var7_7 = var3_3.hashCode();
        var5_5.c(this.b(var3_3.a, var3_3.b, var3_3.c, var3_3.d, var3_3.e()));
        var9_8 = var4_4.length;
        var5_5.c(var9_8);
        for (var11_9 = 0; var11_9 < var9_8; var7_7 ^= var23_10.hashCode(), ++var11_9) {
            var23_10 = var4_4[var11_9];
            var5_5.c(this.b(var23_10));
        }
        var12_11 = var5_5.a;
        var13_12 = var9_8 + 2 << 1;
        var14_13 = var7_7 & Integer.MAX_VALUE;
        var15_14 = this.t;
        var16_15 = var15_14[var14_13 % var15_14.length];
        block1 : while (var16_15 != null) {
            if (var16_15.b != 33 || var16_15.h != var14_13) ** GOTO lbl24
            var21_16 = var16_15.c;
            for (var22_17 = 0; var22_17 < var13_12; ++var22_17) {
                if (var12_11[var6_6 + var22_17] == var12_11[var21_16 + var22_17]) {
                    continue;
                }
lbl24: // 3 sources:
                var16_15 = var16_15.i;
                continue block1;
            }
        }
        if (var16_15 != null) {
            var17_18 = var16_15.a;
            var5_5.b = var6_6;
        } else {
            var17_18 = this.n5;
            this.n5 = var17_18 + 1;
            var18_19 = new p(var17_18);
            var18_19.a(var6_6, var14_13);
            this.b(var18_19);
        }
        this.R4.a(var1_1, var2_2, var17_18);
        var19_20 = this.a(this.R4);
        if (var19_20 != null) return var19_20;
        this.a(18, var17_18, this.d(var1_1, var2_2));
        var20_21 = this.o;
        this.o = var20_21 + 1;
        var19_20 = new p(var20_21, this.R4);
        this.b(var19_20);
        return var19_20;
    }

    public final r a(int n2, String string, String string2, String string3, String[] arrstring) {
        s s2 = new s(this, n2, string, string2, string3, arrstring, this.t5);
        return s2;
    }

    public final void a() {
    }

    public final void a(int n2, int n3, String string, String string2, String string3, String[] arrstring) {
        this.h = n2;
        this.V4 = n3;
        this.W4 = this.c(string);
        this.X4 = string;
        if (string2 != null) {
            this.Y4 = this.e(string2);
        }
        int n4 = string3 == null ? 0 : this.c(string3);
        this.Z4 = n4;
        if (arrstring != null && arrstring.length > 0) {
            int n5;
            this.a5 = n5 = arrstring.length;
            this.b5 = new int[n5];
            for (int i2 = 0; i2 < this.a5; ++i2) {
                this.b5[i2] = this.c(arrstring[i2]);
            }
        }
    }

    public final void a(String string, String string2) {
        if (string != null) {
            this.c5 = this.e(string);
        }
        if (string2 != null) {
            this.d5 = new d().a(string2, 0, Integer.MAX_VALUE);
        }
    }

    public final void a(String string, String string2, String string3) {
        this.e5 = this.c(string);
        if (string2 != null && string3 != null) {
            this.f5 = this.d(string2, string3);
        }
    }

    public final void a(String string, String string2, String string3, int n2) {
        if (this.m5 == null) {
            this.m5 = new d();
        }
        p p2 = this.a(string);
        if (p2.c == 0) {
            this.l5 = 1 + this.l5;
            this.m5.c(p2.a);
            d d2 = this.m5;
            int n3 = string2 == null ? 0 : this.c(string2);
            d2.c(n3);
            d d3 = this.m5;
            int n4 = string3 == null ? 0 : this.e(string3);
            d3.c(n4);
            this.m5.c(n2);
            p2.c = this.l5;
        }
    }

    public final void a(c c2) {
        c2.c = this.k5;
        this.k5 = c2;
    }

    public int b(int n2, String string, String string2, String string3, boolean bl) {
        return this.a((int)n2, (String)string, (String)string2, (String)string3, (boolean)bl).a;
    }

    public int b(Object object) {
        return this.a((Object)object).a;
    }

    int b(String string) {
        this.P4.a(30, string, null, null);
        p p2 = this.a(this.P4);
        if (p2 == null) {
            p2 = this.c(this.P4);
        }
        return p2.a;
    }

    public int b(String string, String string2, String string3, boolean bl) {
        return this.a((String)string, (String)string2, (String)string3, (boolean)bl).a;
    }

    public /* varargs */ int b(String string, String string2, n n2, Object ... arrobject) {
        return this.a((String)string, (String)string2, (n)n2, (Object[])arrobject).a;
    }

    p b(String string) {
        this.Q4.a(16, string, null, null);
        p p2 = this.a(this.Q4);
        if (p2 == null) {
            this.s.b(16, this.e(string));
            int n2 = this.o;
            this.o = n2 + 1;
            p2 = new p(n2, this.Q4);
            this.b(p2);
        }
        return p2;
    }

    p b(String string, String string2) {
        this.Q4.a(12, string, string2, null);
        p p2 = this.a(this.Q4);
        if (p2 == null) {
            this.a(12, this.e(string), this.e(string2));
            int n2 = this.o;
            this.o = n2 + 1;
            p2 = new p(n2, this.Q4);
            this.b(p2);
        }
        return p2;
    }

    p b(String string, String string2, String string3) {
        this.R4.a(9, string, string2, string3);
        p p2 = this.a(this.R4);
        if (p2 == null) {
            this.a(9, this.c(string), this.d(string2, string3));
            int n2 = this.o;
            this.o = n2 + 1;
            p2 = new p(n2, this.R4);
            this.b(p2);
        }
        return p2;
    }

    public byte[] b() {
        RuntimeException runtimeException;
        if (this.o <= 65535) {
            int n2;
            b b2;
            d d2;
            String string;
            int n3;
            String string2;
            d d3;
            int n4;
            b b3;
            d d4;
            d d5;
            String string3;
            c c2;
            b b4;
            int n5;
            String string4;
            String string5;
            b b5;
            int n6 = 24 + 2 * this.a5;
            l l2 = this.p5;
            int n7 = 0;
            while (l2 != null) {
                ++n7;
                n6 += l2.b();
                l2 = (l)l2.b;
            }
            s s2 = this.r5;
            int n8 = 0;
            while (s2 != null) {
                ++n8;
                n6 += s2.e();
                s2 = (s)s2.d;
            }
            d d6 = this.o5;
            if (d6 != null) {
                n6 += 8 + d6.b;
                this.e("BootstrapMethods");
                n5 = 1;
            } else {
                n5 = 0;
            }
            if (this.Y4 != 0) {
                ++n5;
                n6 += 8;
                this.e("Signature");
            }
            if (this.c5 != 0) {
                ++n5;
                n6 += 8;
                this.e("SourceFile");
            }
            if ((d4 = this.d5) != null) {
                ++n5;
                n6 += 6 + d4.b;
                this.e("SourceDebugExtension");
            }
            if (this.e5 != 0) {
                ++n5;
                n6 += 10;
                this.e("EnclosingMethod");
            }
            if ((131072 & this.V4) != 0) {
                ++n5;
                n6 += 6;
                this.e("Deprecated");
            }
            if (((n4 = this.V4) & 4096) != 0 && ((65535 & this.h) < 49 || (n4 & 262144) != 0)) {
                ++n5;
                n6 += 6;
                this.e("Synthetic");
            }
            if ((d3 = this.m5) != null) {
                ++n5;
                n6 += 8 + d3.b;
                this.e("InnerClasses");
            }
            if ((b5 = this.g5) != null) {
                ++n5;
                n6 += 8 + b5.b();
                this.e("RuntimeVisibleAnnotations");
            }
            if ((b3 = this.h5) != null) {
                ++n5;
                n6 += 8 + b3.b();
                this.e("RuntimeInvisibleAnnotations");
            }
            if ((b2 = this.i5) != null) {
                ++n5;
                n6 += 8 + b2.b();
                this.e("RuntimeVisibleTypeAnnotations");
            }
            if ((b4 = this.j5) != null) {
                ++n5;
                n6 += 8 + b4.b();
                this.e("RuntimeInvisibleTypeAnnotations");
            }
            int n9 = n6;
            c c3 = this.k5;
            if (c3 != null) {
                int n10 = n5 + c3.a();
                c c4 = this.k5;
                string5 = "Deprecated";
                string2 = "EnclosingMethod";
                string = "RuntimeVisibleTypeAnnotations";
                string4 = "RuntimeInvisibleAnnotations";
                string3 = "SourceDebugExtension";
                n9 += c4.a(this, null, 0, -1, -1);
                n5 = n10;
            } else {
                string5 = "Deprecated";
                string2 = "EnclosingMethod";
                string = "RuntimeVisibleTypeAnnotations";
                string4 = "RuntimeInvisibleAnnotations";
                string3 = "SourceDebugExtension";
            }
            d d7 = new d(n9 + this.s.b);
            d7.b(-889275714).b(this.h);
            d d8 = d7.c(this.o);
            d d9 = this.s;
            d8.a(d9.a, 0, d9.b);
            int n11 = this.V4;
            d7.c(n11 & (-1 ^ (393216 | (n11 & 262144) / 64))).c(this.W4).c(this.Z4);
            d7.c(this.a5);
            for (int i2 = 0; i2 < this.a5; ++i2) {
                d7.c(this.b5[i2]);
            }
            d7.c(n7);
            l l3 = this.p5;
            while (l3 != null) {
                l3.a(d7);
                l3 = (l)l3.b;
            }
            d7.c(n8);
            s s3 = this.r5;
            while (s3 != null) {
                s3.a(d7);
                s3 = (s)s3.d;
            }
            d7.c(n5);
            if (this.o5 != null) {
                d7.c(this.e("BootstrapMethods"));
                d7.b(2 + this.o5.b).c(this.n5);
                d d10 = this.o5;
                d7.a(d10.a, 0, d10.b);
            }
            if (this.Y4 != 0) {
                d d11 = d7.c(this.e("Signature"));
                n2 = 2;
                d11.b(n2).c(this.Y4);
            } else {
                n2 = 2;
            }
            if (this.c5 != 0) {
                d7.c(this.e("SourceFile")).b(n2).c(this.c5);
            }
            if ((d5 = this.d5) != null) {
                int n12 = d5.b;
                d7.c(this.e(string3)).b(n12);
                d7.a(this.d5.a, 0, n12);
            }
            if (this.e5 != 0) {
                d7.c(this.e(string2)).b(4);
                d7.c(this.e5).c(this.f5);
            }
            if ((131072 & this.V4) != 0) {
                d7.c(this.e(string5)).b(0);
            }
            if (((n3 = this.V4) & 4096) != 0 && ((65535 & this.h) < 49 || (n3 & 262144) != 0)) {
                d7.c(this.e("Synthetic")).b(0);
            }
            if (this.m5 != null) {
                d7.c(this.e("InnerClasses"));
                d7.b(2 + this.m5.b).c(this.l5);
                d d12 = this.m5;
                d7.a(d12.a, 0, d12.b);
            }
            if (this.g5 != null) {
                d7.c(this.e("RuntimeVisibleAnnotations"));
                this.g5.a(d7);
            }
            if (this.h5 != null) {
                d7.c(this.e(string4));
                this.h5.a(d7);
            }
            if (this.i5 != null) {
                d7.c(this.e(string));
                this.i5.a(d7);
            }
            if (this.j5 != null) {
                d7.c(this.e("RuntimeInvisibleTypeAnnotations"));
                this.j5.a(d7);
            }
            if ((c2 = this.k5) != null) {
                d2 = d7;
                c2.a(this, null, 0, -1, -1, d2);
            } else {
                d2 = d7;
            }
            if (this.u5) {
                this.g5 = null;
                this.h5 = null;
                this.k5 = null;
                this.l5 = 0;
                this.m5 = null;
                this.p5 = null;
                this.q5 = null;
                this.r5 = null;
                this.s5 = null;
                this.t5 = 1;
                this.u5 = false;
                new e(d2.a).a((f)this, 264);
                return this.b();
            }
            return d2.a;
        }
        runtimeException = new RuntimeException("Class file too large!");
        throw runtimeException;
    }

    public int c(String string) {
        return this.a((String)string).a;
    }

    public int c(String string, String string2, String string3) {
        return this.b((String)string, (String)string2, (String)string3).a;
    }

    protected String c(String string, String string2) {
        Class class_;
        Class class_2;
        ClassLoader classLoader = this.getClass().getClassLoader();
        try {
            class_ = Class.forName((String)string.replace('/', '.'), (boolean)false, (ClassLoader)classLoader);
            class_2 = Class.forName((String)string2.replace('/', '.'), (boolean)false, (ClassLoader)classLoader);
        }
        catch (Exception exception) {
            RuntimeException runtimeException;
            runtimeException = new RuntimeException(exception.toString());
            throw runtimeException;
        }
        if (class_.isAssignableFrom(class_2)) {
            return string;
        }
        if (class_2.isAssignableFrom(class_)) {
            return string2;
        }
        if (!class_.isInterface() && !class_2.isInterface()) {
            while (!(class_ = class_.getSuperclass()).isAssignableFrom(class_2)) {
            }
            return class_.getName().replace('.', '/');
        }
        return "java/lang/Object";
    }

    public int d(String string) {
        return this.b((String)string).a;
    }

    public int d(String string, String string2) {
        return this.b((String)string, (String)string2).a;
    }

    public int e(String string) {
        this.P4.a(1, string, null, null);
        p p2 = this.a(this.P4);
        if (p2 == null) {
            this.s.a(1).a(string);
            int n2 = this.o;
            this.o = n2 + 1;
            p2 = new p(n2, this.P4);
            this.b(p2);
        }
        return p2.a;
    }
}

