/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.adjust.sdk.ActivityHandler
 *  java.lang.Object
 */
package com.adjust.sdk;

import com.adjust.sdk.ActivityHandler;

public interface IRunActivityHandler {
    public void run(ActivityHandler var1);
}

