/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package org.osmdroid;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

public interface ResourceProxy {
    public Bitmap getBitmap(bitmap var1);

    public float getDisplayMetricsDensity();

    public Drawable getDrawable(bitmap var1);

    public String getString(string var1);

    public /* varargs */ String getString(string var1, Object ... var2);

    public static final class bitmap
    extends Enum<bitmap> {
        private static final /* synthetic */ bitmap[] $VALUES;
        public static final /* enum */ bitmap center;
        public static final /* enum */ bitmap direction_arrow;
        public static final /* enum */ bitmap ic_menu_compass;
        public static final /* enum */ bitmap ic_menu_mapmode;
        public static final /* enum */ bitmap ic_menu_mylocation;
        public static final /* enum */ bitmap ic_menu_offline;
        public static final /* enum */ bitmap marker_default;
        public static final /* enum */ bitmap marker_default_focused_base;
        public static final /* enum */ bitmap navto_small;
        public static final /* enum */ bitmap next;
        public static final /* enum */ bitmap person;
        public static final /* enum */ bitmap previous;
        public static final /* enum */ bitmap unknown;

        static {
            bitmap bitmap2;
            unknown = new bitmap();
            center = new bitmap();
            direction_arrow = new bitmap();
            marker_default = new bitmap();
            marker_default_focused_base = new bitmap();
            navto_small = new bitmap();
            next = new bitmap();
            previous = new bitmap();
            person = new bitmap();
            ic_menu_offline = new bitmap();
            ic_menu_mylocation = new bitmap();
            ic_menu_compass = new bitmap();
            ic_menu_mapmode = bitmap2 = new bitmap();
            bitmap[] arrbitmap = new bitmap[]{unknown, center, direction_arrow, marker_default, marker_default_focused_base, navto_small, next, previous, person, ic_menu_offline, ic_menu_mylocation, ic_menu_compass, bitmap2};
            $VALUES = arrbitmap;
        }

        public static bitmap valueOf(String string2) {
            return (bitmap)Enum.valueOf(bitmap.class, (String)string2);
        }

        public static bitmap[] values() {
            return (bitmap[])$VALUES.clone();
        }
    }

    public static final class string
    extends Enum<string> {
        private static final /* synthetic */ string[] $VALUES;
        public static final /* enum */ string base;
        public static final /* enum */ string base_nl;
        public static final /* enum */ string bing;
        public static final /* enum */ string cloudmade_small;
        public static final /* enum */ string cloudmade_standard;
        public static final /* enum */ string compass;
        public static final /* enum */ string cyclemap;
        public static final /* enum */ string fiets_nl;
        public static final /* enum */ string format_distance_feet;
        public static final /* enum */ string format_distance_kilometers;
        public static final /* enum */ string format_distance_meters;
        public static final /* enum */ string format_distance_miles;
        public static final /* enum */ string format_distance_nautical_miles;
        public static final /* enum */ string hills;
        public static final /* enum */ string map_mode;
        public static final /* enum */ string mapnik;
        public static final /* enum */ string mapquest_aerial;
        public static final /* enum */ string mapquest_osm;
        public static final /* enum */ string my_location;
        public static final /* enum */ string offline_mode;
        public static final /* enum */ string online_mode;
        public static final /* enum */ string public_transport;
        public static final /* enum */ string roads_nl;
        public static final /* enum */ string topo;
        public static final /* enum */ string unknown;

        static {
            string string2;
            mapnik = new string();
            cyclemap = new string();
            public_transport = new string();
            base = new string();
            topo = new string();
            hills = new string();
            cloudmade_small = new string();
            cloudmade_standard = new string();
            mapquest_osm = new string();
            mapquest_aerial = new string();
            bing = new string();
            fiets_nl = new string();
            base_nl = new string();
            roads_nl = new string();
            unknown = new string();
            format_distance_meters = new string();
            format_distance_kilometers = new string();
            format_distance_miles = new string();
            format_distance_nautical_miles = new string();
            format_distance_feet = new string();
            online_mode = new string();
            offline_mode = new string();
            my_location = new string();
            compass = new string();
            map_mode = string2 = new string();
            string[] arrstring = new string[]{mapnik, cyclemap, public_transport, base, topo, hills, cloudmade_small, cloudmade_standard, mapquest_osm, mapquest_aerial, bing, fiets_nl, base_nl, roads_nl, unknown, format_distance_meters, format_distance_kilometers, format_distance_miles, format_distance_nautical_miles, format_distance_feet, online_mode, offline_mode, my_location, compass, string2};
            $VALUES = arrstring;
        }

        public static string valueOf(String string2) {
            return (string)Enum.valueOf(string.class, (String)string2);
        }

        public static string[] values() {
            return (string[])$VALUES.clone();
        }
    }

}

