/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.t0.f
 *  java.lang.Object
 *  java.lang.Runnable
 */
package h.b.d1;

import h.b.t0.f;

public interface a {
    @f
    public Runnable a();
}

