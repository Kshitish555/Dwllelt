/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.util.Collections
 *  java.util.Map
 *  l.a.k.a.x.n
 */
package l.a.k.a.x;

import java.util.Collections;
import java.util.Map;
import l.a.k.a.x.n;

public class w
extends n {
    private final Map a;

    public w(String string, String string2) {
        this.a = Collections.singletonMap((Object)string, (Object)string2);
    }

    public w(Map map) {
        this.a = map;
    }

    public String a(String string) {
        return (String)this.a.get((Object)string);
    }

    public String a(String string, String string2) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append('.');
        stringBuffer.append(string);
        stringBuffer.append(string2);
        String string3 = this.a(stringBuffer.toString());
        if (string3 == null) {
            return string;
        }
        return string3;
    }

    public String a(String string, String string2, String string3) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(string);
        stringBuffer.append('.');
        stringBuffer.append(string2);
        String string4 = this.a(stringBuffer.toString());
        if (string4 == null) {
            return string2;
        }
        return string4;
    }

    public String b(String string, String string2, String string3) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(string);
        stringBuffer.append('.');
        stringBuffer.append(string2);
        stringBuffer.append(string3);
        String string4 = this.a(stringBuffer.toString());
        if (string4 == null) {
            return string2;
        }
        return string4;
    }
}

