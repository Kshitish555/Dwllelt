/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.AbstractSet
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 */
package org.simpleframework.xml.util;

import java.util.AbstractSet;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import org.simpleframework.xml.util.Entry;

public class Dictionary<T extends Entry>
extends AbstractSet<T> {
    protected final Table<T> map = new Table();

    public boolean add(T t) {
        return this.map.put((Object)t.getName(), t) != null;
    }

    public T get(String string) {
        return (T)((Entry)this.map.get((Object)string));
    }

    public Iterator<T> iterator() {
        return this.map.values().iterator();
    }

    public T remove(String string) {
        return (T)((Entry)this.map.remove((Object)string));
    }

    public int size() {
        return this.map.size();
    }

    private static class Table<T>
    extends HashMap<String, T> {
    }

}

