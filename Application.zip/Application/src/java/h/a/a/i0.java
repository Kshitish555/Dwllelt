/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.AutoCloseable
 *  java.lang.FunctionalInterface
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URL
 *  java.nio.ByteBuffer
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 */
package h.a.a;

import h.a.a.h0;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class i0
extends ArrayList<h0>
implements AutoCloseable {
    i0() {
    }

    i0(int n2) {
        super(n2);
    }

    i0(Collection<h0> collection) {
        super(collection);
    }

    public i0 a(d d2) {
        i0 i02 = new i0();
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            h0 h02 = (h0)iterator.next();
            if (!d2.a(h02)) continue;
            i02.add((Object)h02);
        }
        return i02;
    }

    public void a(a a2) {
        this.a(a2, false);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void a(a var1_1, boolean var2_2) {
        var3_3 = this.iterator();
        block4 : while (var3_3.hasNext() != false) {
            var4_4 = (h0)var3_3.next();
            var1_1.a(var4_4, var4_4.p());
            do {
                var4_4.close();
                continue block4;
                break;
            } while (true);
        }
        return;
        {
            catch (Throwable var9_6) {
            }
            catch (IOException var5_5) {}
            if (var2_2) ** continue;
            {
                var6_7 = new StringBuilder();
                var6_7.append("Could not load resource ");
                var6_7.append((Object)var4_4);
                throw new IllegalArgumentException(var6_7.toString(), (Throwable)var5_5);
            }
        }
        var4_4.close();
        throw var9_6;
    }

    public void a(b b2) {
        this.a(b2, false);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void a(b var1_1, boolean var2_2) {
        var3_3 = this.iterator();
        block4 : while (var3_3.hasNext() != false) {
            var4_4 = (h0)var3_3.next();
            var1_1.a(var4_4, var4_4.read());
            do {
                var4_4.close();
                continue block4;
                break;
            } while (true);
        }
        return;
        {
            catch (Throwable var9_6) {
            }
            catch (IOException var5_5) {}
            if (var2_2) ** continue;
            {
                var6_7 = new StringBuilder();
                var6_7.append("Could not load resource ");
                var6_7.append((Object)var4_4);
                throw new IllegalArgumentException(var6_7.toString(), (Throwable)var5_5);
            }
        }
        var4_4.close();
        throw var9_6;
    }

    public void a(c c2) {
        this.a(c2, false);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void a(c var1_1, boolean var2_2) {
        var3_3 = this.iterator();
        block4 : while (var3_3.hasNext() != false) {
            var4_4 = (h0)var3_3.next();
            var1_1.a(var4_4, var4_4.q());
            do {
                var4_4.close();
                continue block4;
                break;
            } while (true);
        }
        return;
        {
            catch (Throwable var9_6) {
            }
            catch (IOException var5_5) {}
            if (var2_2) ** continue;
            {
                var6_7 = new StringBuilder();
                var6_7.append("Could not load resource ");
                var6_7.append((Object)var4_4);
                throw new IllegalArgumentException(var6_7.toString(), (Throwable)var5_5);
            }
        }
        var4_4.close();
        throw var9_6;
    }

    public List<String> b() {
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((h0)iterator.next()).getPath());
        }
        return arrayList;
    }

    public List<String> c() {
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((h0)iterator.next()).getPath());
        }
        return arrayList;
    }

    /*
     * Exception decompiling
     */
    public void close() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl4 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public List<URL> d() {
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((h0)iterator.next()).m());
        }
        return arrayList;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('[');
        int n2 = this.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            if (i2 > 0) {
                stringBuilder.append(", ");
            }
            stringBuilder.append(this.get(i2));
        }
        stringBuilder.append(']');
        return stringBuilder.toString();
    }

    @FunctionalInterface
    public static interface a {
        public void a(h0 var1, byte[] var2);
    }

    @FunctionalInterface
    public static interface b {
        public void a(h0 var1, ByteBuffer var2);
    }

    @FunctionalInterface
    public static interface c {
        public void a(h0 var1, InputStream var2);
    }

    @FunctionalInterface
    public static interface d {
        public boolean a(h0 var1);
    }

}

