/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.PersistenceException
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.PersistenceException;

public class UnionException
extends PersistenceException {
    public /* varargs */ UnionException(String string2, Object ... arrobject) {
        super(String.format((String)string2, (Object[])arrobject), new Object[0]);
    }
}

