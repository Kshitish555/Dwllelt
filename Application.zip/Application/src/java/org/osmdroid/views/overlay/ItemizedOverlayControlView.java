/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageButton
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  java.lang.Object
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;

public class ItemizedOverlayControlView
extends LinearLayout {
    protected ImageButton mCenterToButton;
    protected ItemizedOverlayControlViewListener mLis;
    protected ImageButton mNavToButton;
    protected ImageButton mNextButton;
    protected ImageButton mPreviousButton;

    public ItemizedOverlayControlView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, new DefaultResourceProxyImpl(context));
    }

    public ItemizedOverlayControlView(Context context, AttributeSet attributeSet, ResourceProxy resourceProxy) {
        ImageButton imageButton;
        ImageButton imageButton2;
        ImageButton imageButton3;
        ImageButton imageButton4;
        super(context, attributeSet);
        this.mPreviousButton = imageButton3 = new ImageButton(context);
        imageButton3.setImageBitmap(resourceProxy.getBitmap(ResourceProxy.bitmap.previous));
        this.mNextButton = imageButton2 = new ImageButton(context);
        imageButton2.setImageBitmap(resourceProxy.getBitmap(ResourceProxy.bitmap.next));
        this.mCenterToButton = imageButton = new ImageButton(context);
        imageButton.setImageBitmap(resourceProxy.getBitmap(ResourceProxy.bitmap.center));
        this.mNavToButton = imageButton4 = new ImageButton(context);
        imageButton4.setImageBitmap(resourceProxy.getBitmap(ResourceProxy.bitmap.navto_small));
        this.addView((View)this.mPreviousButton, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        this.addView((View)this.mCenterToButton, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        this.addView((View)this.mNavToButton, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        this.addView((View)this.mNextButton, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        this.initViewListeners();
    }

    private void initViewListeners() {
        this.mNextButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ItemizedOverlayControlViewListener itemizedOverlayControlViewListener = ItemizedOverlayControlView.this.mLis;
                if (itemizedOverlayControlViewListener != null) {
                    itemizedOverlayControlViewListener.onNext();
                }
            }
        });
        this.mPreviousButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ItemizedOverlayControlViewListener itemizedOverlayControlViewListener = ItemizedOverlayControlView.this.mLis;
                if (itemizedOverlayControlViewListener != null) {
                    itemizedOverlayControlViewListener.onPrevious();
                }
            }
        });
        this.mCenterToButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ItemizedOverlayControlViewListener itemizedOverlayControlViewListener = ItemizedOverlayControlView.this.mLis;
                if (itemizedOverlayControlViewListener != null) {
                    itemizedOverlayControlViewListener.onCenter();
                }
            }
        });
        this.mNavToButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                ItemizedOverlayControlViewListener itemizedOverlayControlViewListener = ItemizedOverlayControlView.this.mLis;
                if (itemizedOverlayControlViewListener != null) {
                    itemizedOverlayControlViewListener.onNavTo();
                }
            }
        });
    }

    public void setItemizedOverlayControlViewListener(ItemizedOverlayControlViewListener itemizedOverlayControlViewListener) {
        this.mLis = itemizedOverlayControlViewListener;
    }

    public void setNavToVisible(int n2) {
        this.mNavToButton.setVisibility(n2);
    }

    public void setNextEnabled(boolean bl) {
        this.mNextButton.setEnabled(bl);
    }

    public void setPreviousEnabled(boolean bl) {
        this.mPreviousButton.setEnabled(bl);
    }

    public static interface ItemizedOverlayControlViewListener {
        public void onCenter();

        public void onNavTo();

        public void onNext();

        public void onPrevious();
    }

}

