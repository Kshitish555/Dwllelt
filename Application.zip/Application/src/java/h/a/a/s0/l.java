/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.lang.reflect.TypeVariable
 *  java.util.Arrays
 *  java.util.List
 *  java.util.Map
 *  java.util.Objects
 */
package h.a.a.s0;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

class l
implements ParameterizedType {
    public static final Type h = new l(Map.class, new Type[]{Object.class, Object.class}, null);
    public static final Type o = new l(List.class, new Type[]{Object.class}, null);
    private final Type[] c;
    private final Class<?> d;
    private final Type f;

    l(Class<?> class_, Type[] arrtype, Type type) {
        this.c = arrtype;
        this.d = class_;
        if (type == null) {
            type = class_.getDeclaringClass();
        }
        this.f = type;
        if (class_.getTypeParameters().length == arrtype.length) {
            return;
        }
        throw new IllegalArgumentException("Argument length mismatch");
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof ParameterizedType)) {
            return false;
        }
        ParameterizedType parameterizedType = (ParameterizedType)object;
        Type type = parameterizedType.getOwnerType();
        Type type2 = parameterizedType.getRawType();
        return Objects.equals((Object)this.f, (Object)type) && Objects.equals(this.d, (Object)type2) && Arrays.equals((Object[])this.c, (Object[])parameterizedType.getActualTypeArguments());
    }

    public Type[] getActualTypeArguments() {
        return (Type[])this.c.clone();
    }

    public Type getOwnerType() {
        return this.f;
    }

    public Class<?> getRawType() {
        return this.d;
    }

    public int hashCode() {
        return Arrays.hashCode((Object[])this.c) ^ Objects.hashCode((Object)this.f) ^ Objects.hashCode(this.d);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        Type type = this.f;
        if (type == null) {
            stringBuilder.append(this.d.getName());
        } else {
            if (type instanceof Class) {
                stringBuilder.append(((Class)type).getName());
            } else {
                stringBuilder.append(type.toString());
            }
            stringBuilder.append("$");
            if (this.f instanceof l) {
                String string = this.d.getName();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append(((l)this.f).d.getName());
                stringBuilder2.append("$");
                stringBuilder.append(string.replace((CharSequence)stringBuilder2.toString(), (CharSequence)""));
            } else {
                stringBuilder.append(this.d.getSimpleName());
            }
        }
        Type[] arrtype = this.c;
        if (arrtype != null && arrtype.length > 0) {
            stringBuilder.append("<");
            Type[] arrtype2 = this.c;
            int n2 = arrtype2.length;
            boolean bl = true;
            for (int i2 = 0; i2 < n2; ++i2) {
                Type type2 = arrtype2[i2];
                if (bl) {
                    bl = false;
                } else {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(type2.toString());
            }
            stringBuilder.append(">");
        }
        return stringBuilder.toString();
    }
}

