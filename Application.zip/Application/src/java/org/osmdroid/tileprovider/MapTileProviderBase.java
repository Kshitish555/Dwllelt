/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.os.Handler
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.Set
 *  microsoft.mappoint.TileSystem
 *  org.osmdroid.tileprovider.ExpirableBitmapDrawable
 *  org.osmdroid.tileprovider.IMapTileProviderCallback
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.MapTileProviderBase$ZoomInTileLooper
 *  org.osmdroid.tileprovider.MapTileProviderBase$ZoomOutTileLooper
 *  org.osmdroid.tileprovider.MapTileRequestState
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.util.TileLooper
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import microsoft.mappoint.TileSystem;
import org.osmdroid.tileprovider.ExpirableBitmapDrawable;
import org.osmdroid.tileprovider.IMapTileProviderCallback;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.MapTileCache;
import org.osmdroid.tileprovider.MapTileProviderBase;
import org.osmdroid.tileprovider.MapTileRequestState;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.util.TileLooper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Exception performing whole class analysis.
 */
public abstract class MapTileProviderBase
implements IMapTileProviderCallback,
OpenStreetMapTileProviderConstants {
    private static final Logger logger;
    protected final MapTileCache mTileCache;
    protected Handler mTileRequestCompleteHandler;
    private ITileSource mTileSource;
    protected boolean mUseDataConnection;

    static {
        logger = LoggerFactory.getLogger(MapTileProviderBase.class);
    }

    public MapTileProviderBase(ITileSource iTileSource) {
        this(iTileSource, null);
    }

    public MapTileProviderBase(ITileSource iTileSource, Handler handler) {
        this.mUseDataConnection = true;
        this.mTileCache = new MapTileCache();
        this.mTileRequestCompleteHandler = handler;
        this.mTileSource = iTileSource;
    }

    static /* synthetic */ Logger access$000() {
        return logger;
    }

    public void clearTileCache() {
        this.mTileCache.clear();
    }

    public abstract void detach();

    public void ensureCapacity(int n) {
        this.mTileCache.ensureCapacity(n);
    }

    public abstract Drawable getMapTile(MapTile var1);

    public abstract int getMaximumZoomLevel();

    public abstract int getMinimumZoomLevel();

    public ITileSource getTileSource() {
        return this.mTileSource;
    }

    public void mapTileRequestCompleted(MapTileRequestState mapTileRequestState, Drawable drawable) {
        Handler handler;
        MapTile mapTile = mapTileRequestState.getMapTile();
        if (drawable != null) {
            this.mTileCache.putTile(mapTile, drawable);
        }
        if ((handler = this.mTileRequestCompleteHandler) != null) {
            handler.sendEmptyMessage(0);
        }
    }

    public void mapTileRequestFailed(MapTileRequestState mapTileRequestState) {
        mapTileRequestState.getMapTile();
        Handler handler = this.mTileRequestCompleteHandler;
        if (handler != null) {
            handler.sendEmptyMessage(1);
        }
    }

    public void rescaleCache(int n, int n2, Rect rect) {
        if (n == n2) {
            return;
        }
        long l = System.currentTimeMillis();
        Logger logger = MapTileProviderBase.logger;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("rescale tile cache from ");
        stringBuilder.append(n2);
        stringBuilder.append(" to ");
        stringBuilder.append(n);
        logger.info(stringBuilder.toString());
        int n3 = this.getTileSource().getTileSizePixels();
        int n4 = TileSystem.MapSize((int)n) >> 1;
        Rect rect2 = new Rect(rect);
        rect2.offset(n4, n4);
        Object object = n > n2 ? new /* Unavailable Anonymous Inner Class!! */ : new /* Unavailable Anonymous Inner Class!! */;
        object.loop(null, n, n3, rect2);
        long l2 = System.currentTimeMillis();
        Logger logger2 = MapTileProviderBase.logger;
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Finished rescale in ");
        stringBuilder2.append(l2 - l);
        stringBuilder2.append("ms");
        logger2.info(stringBuilder2.toString());
    }

    public void setTileRequestCompleteHandler(Handler handler) {
        this.mTileRequestCompleteHandler = handler;
    }

    public void setTileSource(ITileSource iTileSource) {
        this.mTileSource = iTileSource;
        this.clearTileCache();
    }

    public void setUseDataConnection(boolean bl) {
        this.mUseDataConnection = bl;
    }

    public boolean useDataConnection() {
        return this.mUseDataConnection;
    }

    private abstract class ScaleTileLooper
    extends TileLooper {
        protected Paint mDebugPaint;
        protected Rect mDestRect;
        protected int mDiff;
        protected final HashMap<MapTile, Bitmap> mNewTiles;
        protected final int mOldZoomLevel;
        protected Rect mSrcRect;
        protected int mTileSize_2;

        public ScaleTileLooper(int n) {
            this.mOldZoomLevel = n;
            this.mNewTiles = new HashMap();
            this.mSrcRect = new Rect();
            this.mDestRect = new Rect();
            this.mDebugPaint = new Paint();
        }

        public void finaliseLoop() {
            while (!this.mNewTiles.isEmpty()) {
                MapTile mapTile = (MapTile)this.mNewTiles.keySet().iterator().next();
                ExpirableBitmapDrawable expirableBitmapDrawable = new ExpirableBitmapDrawable((Bitmap)this.mNewTiles.remove((Object)mapTile));
                expirableBitmapDrawable.setState(new int[]{-1});
                MapTileProviderBase.this.mTileCache.putTile(mapTile, (Drawable)expirableBitmapDrawable);
            }
        }

        protected abstract void handleTile(int var1, MapTile var2, int var3, int var4);

        /*
         * Exception decompiling
         */
        public void handleTile(Canvas var1, int var2, MapTile var3, int var4, int var5) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl16 : RETURN : trying to set 0 previously set to 1
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
            // java.lang.Thread.run(Thread.java:764)
            throw new IllegalStateException("Decompilation failed");
        }

        public void initialiseLoop(int n, int n2) {
            int n3;
            this.mDiff = n3 = Math.abs((int)(n - this.mOldZoomLevel));
            this.mTileSize_2 = n2 >> n3;
        }
    }

}

