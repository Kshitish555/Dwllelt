/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Array
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.core.Traverser
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.Position
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Array;
import org.simpleframework.xml.core.ArrayFactory;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.Traverser;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Position;

class CompositeArray
implements Converter {
    private final Type entry;
    private final ArrayFactory factory;
    private final String parent;
    private final Traverser root;
    private final Type type;

    public CompositeArray(Context context, Type type, Type type2, String string2) {
        this.factory = new ArrayFactory(context, type);
        this.root = new Traverser(context);
        this.parent = string2;
        this.entry = type2;
        this.type = type;
    }

    private void read(InputNode inputNode, Object object, int n) throws Exception {
        Class class_ = this.entry.getType();
        Object object2 = !inputNode.isEmpty() ? this.root.read(inputNode, class_) : null;
        Array.set((Object)object, (int)n, (Object)object2);
    }

    private boolean validate(InputNode inputNode, Class class_) throws Exception {
        InputNode inputNode2;
        while ((inputNode2 = inputNode.getNext()) != null) {
            if (inputNode2.isEmpty()) continue;
            this.root.validate(inputNode2, class_);
        }
        return true;
    }

    public Object read(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        Object object = instance.getInstance();
        if (!instance.isReference()) {
            return this.read(inputNode, object);
        }
        return object;
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        ElementException elementException;
        Position position;
        int n = Array.getLength((Object)object);
        int n2 = 0;
        do {
            position = inputNode.getPosition();
            InputNode inputNode2 = inputNode.getNext();
            if (inputNode2 == null) {
                return object;
            }
            if (n2 >= n) break;
            this.read(inputNode2, object, n2);
            ++n2;
        } while (true);
        Object[] arrobject = new Object[]{this.type, position};
        elementException = new ElementException("Array length missing or incorrect for %s at %s", arrobject);
        throw elementException;
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            instance.setInstance(null);
            return this.validate(inputNode, instance.getType());
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        int n = Array.getLength((Object)object);
        for (int i = 0; i < n; ++i) {
            Object object2 = Array.get((Object)object, (int)i);
            Class class_ = this.entry.getType();
            this.root.write(outputNode, object2, class_, this.parent);
        }
        outputNode.commit();
    }
}

