/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.j
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Set
 */
package h.a.a;

import h.a.a.j;
import h.a.a.j0;
import java.util.Set;

abstract class k0 {
    protected transient j0 c;
    private transient j d;
    private transient Class<?> f;

    k0() {
    }

    <T> Class<T> a(Class<T> class_) {
        return this.a(class_, false);
    }

    <T> Class<T> a(Class<T> class_, boolean bl) {
        if (this.f == null) {
            j j2 = this.c();
            String string = j2 != null ? j2.P() : this.e();
            if (string != null) {
                this.f = this.c.a(string, class_, bl);
            } else {
                throw new IllegalArgumentException("Class name is not set");
            }
        }
        return this.f;
    }

    Class<?> a(boolean bl) {
        if (this.f == null) {
            j j2 = this.c();
            String string = j2 != null ? j2.P() : this.e();
            if (string != null) {
                this.f = this.c.a(string, bl);
            } else {
                throw new IllegalArgumentException("Class name is not set");
            }
        }
        return this.f;
    }

    void a(j0 j02) {
        this.c = j02;
    }

    abstract void a(Set<String> var1);

    j c() {
        if (this.d == null) {
            if (this.c == null) {
                return null;
            }
            String string = this.e();
            if (string != null) {
                this.d = this.c.d(string);
            } else {
                throw new IllegalArgumentException("Class name is not set");
            }
        }
        return this.d;
    }

    protected abstract String e();

    Class<?> f() {
        return this.a(false);
    }
}

