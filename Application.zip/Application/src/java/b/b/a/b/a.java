/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b.b.a.b;

public interface a<I, O> {
    public O apply(I var1);
}

