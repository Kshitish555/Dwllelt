/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.util.concurrent.locks.Lock
 *  java.util.concurrent.locks.ReadWriteLock
 *  java.util.concurrent.locks.ReentrantReadWriteLock
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 */
package org.osmdroid.tileprovider;

import android.graphics.drawable.Drawable;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import org.osmdroid.tileprovider.LRUMapTileCache;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;

public final class MapTileCache
implements OpenStreetMapTileProviderConstants {
    protected LRUMapTileCache mCachedTiles;
    private final ReadWriteLock mReadWriteLock = new ReentrantReadWriteLock();

    public MapTileCache() {
        this(9);
    }

    public MapTileCache(int n) {
        this.mCachedTiles = new LRUMapTileCache(n);
    }

    public void clear() {
        this.mReadWriteLock.writeLock().lock();
        try {
            this.mCachedTiles.clear();
            return;
        }
        finally {
            this.mReadWriteLock.writeLock().unlock();
        }
    }

    public boolean containsTile(MapTile mapTile) {
        this.mReadWriteLock.readLock().lock();
        try {
            boolean bl = this.mCachedTiles.containsKey((Object)mapTile);
            return bl;
        }
        finally {
            this.mReadWriteLock.readLock().unlock();
        }
    }

    public void ensureCapacity(int n) {
        this.mReadWriteLock.readLock().lock();
        try {
            this.mCachedTiles.ensureCapacity(n);
            return;
        }
        finally {
            this.mReadWriteLock.readLock().unlock();
        }
    }

    public Drawable getMapTile(MapTile mapTile) {
        this.mReadWriteLock.readLock().lock();
        try {
            Drawable drawable = (Drawable)this.mCachedTiles.get((Object)mapTile);
            return drawable;
        }
        finally {
            this.mReadWriteLock.readLock().unlock();
        }
    }

    public void putTile(MapTile mapTile, Drawable drawable) {
        if (drawable != null) {
            this.mReadWriteLock.writeLock().lock();
            try {
                this.mCachedTiles.put((Object)mapTile, (Object)drawable);
                return;
            }
            finally {
                this.mReadWriteLock.writeLock().unlock();
            }
        }
    }
}

