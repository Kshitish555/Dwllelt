/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashMap
 *  java.util.Map
 */
package com.adjust.sdk;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.Util;
import java.util.LinkedHashMap;
import java.util.Map;

public class AdjustEvent {
    private static ILogger logger = AdjustFactory.getLogger();
    String callbackId;
    Map<String, String> callbackParameters;
    String currency;
    String eventToken;
    String orderId;
    Map<String, String> partnerParameters;
    Double revenue;

    public AdjustEvent(String string) {
        if (!AdjustEvent.checkEventToken(string, logger)) {
            return;
        }
        this.eventToken = string;
    }

    private static boolean checkEventToken(String string, ILogger iLogger) {
        if (string == null) {
            iLogger.error("Missing Event Token", new Object[0]);
            return false;
        }
        if (string.length() != 6) {
            iLogger.error("Malformed Event Token '%s'", string);
            return false;
        }
        return true;
    }

    private boolean checkRevenue(Double d2, String string) {
        if (d2 != null) {
            if (d2 < 0.0) {
                logger.error("Invalid amount %.5f", new Object[]{d2});
                return false;
            }
            if (string == null) {
                logger.error("Currency must be set with revenue", new Object[0]);
                return false;
            }
            if (string.equals((Object)"")) {
                logger.error("Currency is empty", new Object[0]);
                return false;
            }
        } else if (string != null) {
            logger.error("Revenue must be set with currency", new Object[0]);
            return false;
        }
        return true;
    }

    public void addCallbackParameter(String string, String string2) {
        if (!Util.isValidParameter(string, "key", "Callback")) {
            return;
        }
        if (!Util.isValidParameter(string2, "value", "Callback")) {
            return;
        }
        if (this.callbackParameters == null) {
            this.callbackParameters = new LinkedHashMap();
        }
        if ((String)this.callbackParameters.put((Object)string, (Object)string2) != null) {
            logger.warn("Key %s was overwritten", string);
        }
    }

    public void addPartnerParameter(String string, String string2) {
        if (!Util.isValidParameter(string, "key", "Partner")) {
            return;
        }
        if (!Util.isValidParameter(string2, "value", "Partner")) {
            return;
        }
        if (this.partnerParameters == null) {
            this.partnerParameters = new LinkedHashMap();
        }
        if ((String)this.partnerParameters.put((Object)string, (Object)string2) != null) {
            logger.warn("Key %s was overwritten", string);
        }
    }

    public boolean isValid() {
        return this.eventToken != null;
    }

    public void setCallbackId(String string) {
        this.callbackId = string;
    }

    public void setOrderId(String string) {
        this.orderId = string;
    }

    public void setRevenue(double d2, String string) {
        if (!this.checkRevenue(d2, string)) {
            return;
        }
        this.revenue = d2;
        this.currency = string;
    }
}

