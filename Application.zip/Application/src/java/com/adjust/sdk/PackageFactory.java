/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.net.UrlQuerySanitizer
 *  android.net.UrlQuerySanitizer$ParameterValuePair
 *  android.net.UrlQuerySanitizer$ValueSanitizer
 *  java.io.UnsupportedEncodingException
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.net.URLDecoder
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 */
package com.adjust.sdk;

import android.net.Uri;
import android.net.UrlQuerySanitizer;
import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.ActivityState;
import com.adjust.sdk.AdjustAttribution;
import com.adjust.sdk.AdjustConfig;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.PackageBuilder;
import com.adjust.sdk.SessionParameters;
import com.adjust.sdk.a;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PackageFactory {
    private static final String ADJUST_PREFIX = "adjust_";

    public static ActivityPackage buildDeeplinkSdkClickPackage(Uri uri, long l2, ActivityState activityState, AdjustConfig adjustConfig, a a2, SessionParameters sessionParameters) {
        if (uri == null) {
            return null;
        }
        String string = uri.toString();
        if (string != null) {
            if (string.length() == 0) {
                return null;
            }
            AdjustFactory.getLogger().verbose("Url to parse (%s)", new Object[]{uri});
            UrlQuerySanitizer urlQuerySanitizer = new UrlQuerySanitizer();
            urlQuerySanitizer.setUnregisteredParameterValueSanitizer(UrlQuerySanitizer.getAllButNulLegal());
            urlQuerySanitizer.setAllowUnregisteredParamaters(true);
            urlQuerySanitizer.parseUrl(string);
            PackageBuilder packageBuilder = PackageFactory.queryStringClickPackageBuilder((List<UrlQuerySanitizer.ParameterValuePair>)urlQuerySanitizer.getParameterList(), activityState, adjustConfig, a2, sessionParameters);
            if (packageBuilder == null) {
                return null;
            }
            packageBuilder.deeplink = uri.toString();
            packageBuilder.clickTimeInMilliseconds = l2;
            return packageBuilder.buildClickPackage("deeplink");
        }
        return null;
    }

    public static ActivityPackage buildInstallReferrerSdkClickPackage(String string, long l2, long l3, ActivityState activityState, AdjustConfig adjustConfig, a a2, SessionParameters sessionParameters) {
        if (string != null && string.length() != 0) {
            long l4 = System.currentTimeMillis();
            PackageBuilder packageBuilder = new PackageBuilder(adjustConfig, a2, activityState, sessionParameters, l4);
            packageBuilder.referrer = string;
            packageBuilder.clickTimeInSeconds = l2;
            packageBuilder.installBeginTimeInSeconds = l3;
            return packageBuilder.buildClickPackage("install_referrer");
        }
        return null;
    }

    public static ActivityPackage buildReftagSdkClickPackage(String string, long l2, ActivityState activityState, AdjustConfig adjustConfig, a a2, SessionParameters sessionParameters) {
        String string2 = "malformed";
        if (string != null) {
            if (string.length() == 0) {
                return null;
            }
            try {
                string2 = URLDecoder.decode((String)string, (String)"UTF-8");
            }
            catch (Exception exception) {
                ILogger iLogger = AdjustFactory.getLogger();
                Object[] arrobject = new Object[]{exception.getMessage()};
                iLogger.error("Referrer decoding failed. Message: (%s)", arrobject);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                ILogger iLogger = AdjustFactory.getLogger();
                Object[] arrobject = new Object[]{illegalArgumentException.getMessage()};
                iLogger.error("Referrer decoding failed due to IllegalArgumentException. Message: (%s)", arrobject);
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                ILogger iLogger = AdjustFactory.getLogger();
                Object[] arrobject = new Object[]{unsupportedEncodingException.getMessage()};
                iLogger.error("Referrer decoding failed due to UnsupportedEncodingException. Message: (%s)", arrobject);
            }
            AdjustFactory.getLogger().verbose("Referrer to parse (%s)", string2);
            UrlQuerySanitizer urlQuerySanitizer = new UrlQuerySanitizer();
            urlQuerySanitizer.setUnregisteredParameterValueSanitizer(UrlQuerySanitizer.getAllButNulLegal());
            urlQuerySanitizer.setAllowUnregisteredParamaters(true);
            urlQuerySanitizer.parseQuery(string2);
            PackageBuilder packageBuilder = PackageFactory.queryStringClickPackageBuilder((List<UrlQuerySanitizer.ParameterValuePair>)urlQuerySanitizer.getParameterList(), activityState, adjustConfig, a2, sessionParameters);
            if (packageBuilder == null) {
                return null;
            }
            packageBuilder.referrer = string2;
            packageBuilder.clickTimeInMilliseconds = l2;
            packageBuilder.rawReferrer = string;
            return packageBuilder.buildClickPackage("reftag");
        }
        return null;
    }

    private static PackageBuilder queryStringClickPackageBuilder(List<UrlQuerySanitizer.ParameterValuePair> list, ActivityState activityState, AdjustConfig adjustConfig, a a2, SessionParameters sessionParameters) {
        if (list == null) {
            return null;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        AdjustAttribution adjustAttribution = new AdjustAttribution();
        for (UrlQuerySanitizer.ParameterValuePair parameterValuePair : list) {
            PackageFactory.readQueryString(parameterValuePair.mParameter, parameterValuePair.mValue, (Map<String, String>)linkedHashMap, adjustAttribution);
        }
        long l2 = System.currentTimeMillis();
        String string = (String)linkedHashMap.remove((Object)"reftag");
        if (activityState != null) {
            activityState.lastInterval = l2 - activityState.lastActivity;
        }
        PackageBuilder packageBuilder = new PackageBuilder(adjustConfig, a2, activityState, sessionParameters, l2);
        packageBuilder.extraParameters = linkedHashMap;
        packageBuilder.attribution = adjustAttribution;
        packageBuilder.reftag = string;
        return packageBuilder;
    }

    private static boolean readQueryString(String string, String string2, Map<String, String> map, AdjustAttribution adjustAttribution) {
        if (string != null) {
            if (string2 == null) {
                return false;
            }
            if (!string.startsWith(ADJUST_PREFIX)) {
                return false;
            }
            String string3 = string.substring(7);
            if (string3.length() == 0) {
                return false;
            }
            if (string2.length() == 0) {
                return false;
            }
            if (!PackageFactory.tryToSetAttribution(adjustAttribution, string3, string2)) {
                map.put((Object)string3, (Object)string2);
            }
            return true;
        }
        return false;
    }

    private static boolean tryToSetAttribution(AdjustAttribution adjustAttribution, String string, String string2) {
        if (string.equals((Object)"tracker")) {
            adjustAttribution.trackerName = string2;
            return true;
        }
        if (string.equals((Object)"campaign")) {
            adjustAttribution.campaign = string2;
            return true;
        }
        if (string.equals((Object)"adgroup")) {
            adjustAttribution.adgroup = string2;
            return true;
        }
        if (string.equals((Object)"creative")) {
            adjustAttribution.creative = string2;
            return true;
        }
        return false;
    }
}

