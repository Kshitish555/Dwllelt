/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.location.Location
 *  android.location.LocationManager
 *  java.lang.Object
 *  java.lang.String
 *  org.osmdroid.util.constants.UtilConstants
 */
package org.osmdroid.util;

import android.location.Location;
import android.location.LocationManager;
import org.osmdroid.util.constants.UtilConstants;

public class LocationUtils
implements UtilConstants {
    private LocationUtils() {
    }

    public static Location getLastKnownLocation(LocationManager locationManager) {
        if (locationManager == null) {
            return null;
        }
        Location location = locationManager.getLastKnownLocation("gps");
        Location location2 = locationManager.getLastKnownLocation("network");
        if (location == null) {
            return location2;
        }
        if (location2 == null) {
            return location;
        }
        if (location2.getTime() > 20000L + location.getTime()) {
            return location2;
        }
        return location;
    }
}

