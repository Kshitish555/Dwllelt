/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Rect
 *  android.text.method.TransformationMethod
 *  android.view.View
 *  androidx.annotation.p0
 *  androidx.annotation.p0$a
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 */
package b.a.d;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Rect;
import android.text.method.TransformationMethod;
import android.view.View;
import androidx.annotation.p0;
import java.util.Locale;

@p0(value={p0.a.f})
public class a
implements TransformationMethod {
    private Locale c;

    public a(Context context) {
        this.c = context.getResources().getConfiguration().locale;
    }

    public CharSequence getTransformation(CharSequence charSequence, View view) {
        if (charSequence != null) {
            return charSequence.toString().toUpperCase(this.c);
        }
        return null;
    }

    public void onFocusChanged(View view, CharSequence charSequence, boolean bl, int n2, Rect rect) {
    }
}

