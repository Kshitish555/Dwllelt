/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.osmdroid.views.util;

public class MyMath {
    private MyMath() {
    }

    public static int getNextSquareNumberAbove(float f2) {
        int n2 = 1;
        int n3 = 1;
        int n4 = 0;
        while (!((float)n2 > f2)) {
            n2 *= 2;
            int n5 = n3 + 1;
            n4 = n3;
            n3 = n5;
        }
        return n4;
    }
}

