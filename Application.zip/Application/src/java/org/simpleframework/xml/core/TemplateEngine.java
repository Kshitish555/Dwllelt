/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Template;
import org.simpleframework.xml.filter.Filter;

class TemplateEngine {
    private Filter filter;
    private Template name = new Template();
    private int off;
    private Template source = new Template();
    private Template text = new Template();

    public TemplateEngine(Filter filter) {
        this.filter = filter;
    }

    private void name() {
        do {
            int n = this.off;
            Template template = this.source;
            if (n >= template.count) break;
            char[] arrc = template.buf;
            this.off = n + 1;
            char c2 = arrc[n];
            if (c2 == '}') {
                this.replace();
                break;
            }
            this.name.append(c2);
        } while (true);
        if (this.name.length() > 0) {
            this.text.append("${");
            this.text.append(this.name);
        }
    }

    private void parse() {
        do {
            int n;
            int n2 = this.off;
            Template template = this.source;
            int n3 = template.count;
            if (n2 >= n3) break;
            char[] arrc = template.buf;
            this.off = n = n2 + 1;
            char c2 = arrc[n2];
            if (c2 == '$' && n < n3) {
                int n4;
                this.off = n4 = n + 1;
                if (arrc[n] == '{') {
                    this.name();
                    continue;
                }
                this.off = n4 - 1;
            }
            this.text.append(c2);
        } while (true);
    }

    private void replace() {
        if (this.name.length() > 0) {
            this.replace(this.name);
        }
        this.name.clear();
    }

    private void replace(String string) {
        String string2 = this.filter.replace(string);
        if (string2 == null) {
            this.text.append("${");
            this.text.append(string);
            this.text.append("}");
            return;
        }
        this.text.append(string2);
    }

    private void replace(Template template) {
        this.replace(template.toString());
    }

    public void clear() {
        this.name.clear();
        this.text.clear();
        this.source.clear();
        this.off = 0;
    }

    public String process(String string) {
        if (string.indexOf(36) < 0) {
            return string;
        }
        try {
            this.source.append(string);
            this.parse();
            String string2 = this.text.toString();
            return string2;
        }
        finally {
            this.clear();
        }
    }
}

