/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Constructor
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.ParameterContact;
import org.simpleframework.xml.core.TemplateParameter;
import org.simpleframework.xml.core.TextLabel;
import org.simpleframework.xml.stream.Format;

class TextParameter
extends TemplateParameter {
    private final Contact contact;
    private final Expression expression;
    private final int index;
    private final Object key;
    private final Label label;
    private final String name;
    private final String path;
    private final Class type;

    public TextParameter(Constructor constructor, Text text, Format format, int n2) throws Exception {
        ParameterContact<Text> parameterContact = new ParameterContact<Text>(text, constructor, n2){

            @Override
            public String getName() {
                return "";
            }
        };
        this.contact = parameterContact;
        TextLabel textLabel = new TextLabel(parameterContact, text, format);
        this.label = textLabel;
        this.expression = textLabel.getExpression();
        this.path = this.label.getPath();
        this.type = this.label.getType();
        this.name = this.label.getName();
        this.key = this.label.getKey();
        this.index = n2;
    }

    public Annotation getAnnotation() {
        return this.contact.getAnnotation();
    }

    public Expression getExpression() {
        return this.expression;
    }

    public int getIndex() {
        return this.index;
    }

    public Object getKey() {
        return this.key;
    }

    public String getName() {
        return this.name;
    }

    public String getName(Context context) {
        return this.getName();
    }

    public String getPath() {
        return this.path;
    }

    public String getPath(Context context) {
        return this.getPath();
    }

    public Class getType() {
        return this.type;
    }

    public boolean isPrimitive() {
        return this.type.isPrimitive();
    }

    public boolean isRequired() {
        return this.label.isRequired();
    }

    @Override
    public boolean isText() {
        return true;
    }

    public String toString() {
        return this.contact.toString();
    }

}

