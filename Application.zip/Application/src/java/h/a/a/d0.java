/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.github.classgraph.utils.s
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.AutoCloseable
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 *  java.util.List
 */
package h.a.a;

import h.a.a.e0;
import io.github.classgraph.utils.s;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

public class d0
implements Closeable {
    private static Class<?> d = s.a((String)"java.util.stream.Collector");
    private static Object f;
    private final AutoCloseable c;

    static {
        Class class_ = s.a((String)"java.util.stream.Collectors");
        if (class_ != null) {
            f = s.b((Class)class_, (String)"toList", (boolean)true);
        }
    }

    d0(e0 e02) throws IOException {
        block3 : {
            try {
                AutoCloseable autoCloseable;
                this.c = autoCloseable = (AutoCloseable)s.b((Object)e02.n(), (String)"open", (boolean)true);
                if (autoCloseable == null) break block3;
                return;
            }
            catch (SecurityException securityException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Could not open module ");
                stringBuilder.append(e02.k());
                throw new IOException(stringBuilder.toString(), (Throwable)securityException);
            }
        }
        throw new IllegalArgumentException("moduleReference.open() should not return null");
    }

    public List<String> a() throws IOException, SecurityException {
        if (f != null) {
            Object object = s.b((Object)this.c, (String)"list", (boolean)true);
            if (object != null) {
                Object object2 = s.a((Object)object, (String)"collect", d, (Object)f, (boolean)true);
                if (object2 != null) {
                    return (List)object2;
                }
                throw new IllegalArgumentException("Could not call moduleReader.list().collect(Collectors.toList())");
            }
            throw new IllegalArgumentException("Could not call moduleReader.list()");
        }
        throw new IllegalArgumentException("Could not call Collectors.toList()");
    }

    public void a(ByteBuffer byteBuffer) {
        s.a((Object)this.c, (String)"release", ByteBuffer.class, (Object)byteBuffer, (boolean)true);
    }

    public InputStream b(String string) throws IOException, SecurityException {
        Object object = s.a((Object)this.c, (String)"open", String.class, (Object)string, (boolean)true);
        if (object != null) {
            Object object2 = s.b((Object)object, (String)"get", (boolean)true);
            if (object2 != null) {
                return (InputStream)object2;
            }
            throw new IllegalArgumentException("Could not call moduleReader.open(name).get()");
        }
        throw new IllegalArgumentException("Could not call moduleReader.open(name)");
    }

    public void close() {
        try {
            this.c.close();
        }
        catch (Exception exception) {}
    }

    public ByteBuffer d(String string) throws IOException, SecurityException, OutOfMemoryError {
        Object object = s.a((Object)this.c, (String)"read", String.class, (Object)string, (boolean)true);
        if (object != null) {
            Object object2 = s.b((Object)object, (String)"get", (boolean)true);
            if (object2 != null) {
                return (ByteBuffer)object2;
            }
            throw new IllegalArgumentException("Could not call moduleReader.read(name).get()");
        }
        throw new IllegalArgumentException("Could not call moduleReader.open(name)");
    }
}

