/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Object
 *  java.lang.String
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.util;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StreamUtils {
    public static final int IO_BUFFER_SIZE = 8192;
    private static final Logger logger = LoggerFactory.getLogger(StreamUtils.class);

    private StreamUtils() {
    }

    public static void closeStream(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
                return;
            }
            catch (IOException iOException) {
                logger.error("IO", (Object)"Could not close stream", (Object)iOException);
            }
        }
    }

    public static long copy(InputStream inputStream, OutputStream outputStream) throws IOException {
        int n2;
        byte[] arrby = new byte[8192];
        long l2 = 0L;
        while ((n2 = inputStream.read(arrby)) != -1) {
            outputStream.write(arrby, 0, n2);
            l2 += (long)n2;
        }
        return l2;
    }
}

