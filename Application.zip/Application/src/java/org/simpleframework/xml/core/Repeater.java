/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  org.simpleframework.xml.core.Converter
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.stream.InputNode;

interface Repeater
extends Converter {
    public Object read(InputNode var1, Object var2) throws Exception;
}

