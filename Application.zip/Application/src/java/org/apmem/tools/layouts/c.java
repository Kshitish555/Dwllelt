/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.apmem.tools.layouts;

public final class c {
    private c() {
    }

    public static final class a {
        public static final int debugDraw = 2130968813;
        public static final int layoutDirection = 2130969012;
        public static final int layout_newLine = 2130969073;
        public static final int layout_weight = 2130969077;
        public static final int weightDefault = 2130969508;

        private a() {
        }
    }

    public static final class b {
        public static final int ltr = 2131297210;
        public static final int rtl = 2131297545;

        private b() {
        }
    }

    public static final class c {
        public static final int[] FlowLayout = new int[]{16842927, 16842948, 2130968813, 2130968994, 2130969012, 2130969081, 2130969508};
        public static final int[] FlowLayout_LayoutParams = new int[]{16842931, 2130969073, 2130969077};
        public static final int FlowLayout_LayoutParams_android_layout_gravity = 0;
        public static final int FlowLayout_LayoutParams_layout_newLine = 1;
        public static final int FlowLayout_LayoutParams_layout_weight = 2;
        public static final int FlowLayout_android_gravity = 0;
        public static final int FlowLayout_android_orientation = 1;
        public static final int FlowLayout_debugDraw = 2;
        public static final int FlowLayout_itemSpacing = 3;
        public static final int FlowLayout_layoutDirection = 4;
        public static final int FlowLayout_lineSpacing = 5;
        public static final int FlowLayout_weightDefault = 6;

        private c() {
        }
    }

}

