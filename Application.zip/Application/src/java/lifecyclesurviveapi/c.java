/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 *  lifecyclesurviveapi.q
 *  rx.functions.Func1
 */
package lifecyclesurviveapi;

import lifecyclesurviveapi.q;
import rx.functions.Func1;

public final class c
implements Func1 {
    public static final /* synthetic */ c c;

    static /* synthetic */ {
        c = new c();
    }

    private /* synthetic */ c() {
    }

    public final Object call(Object object) {
        return q.a.a((Throwable)object);
    }
}

