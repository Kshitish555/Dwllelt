/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Type
 *  java.util.Collections
 *  java.util.List
 *  l.a.h.k.c
 *  l.a.i.i.a
 *  l.a.i.i.a$b
 *  l.a.i.i.c
 *  l.a.i.i.d
 *  l.a.i.i.d$a
 *  l.a.j.e
 *  l.a.j.e$b
 *  l.a.j.e$c
 *  l.a.j.e$g
 *  l.a.j.k$a
 *  l.a.j.k$b
 *  l.a.j.k$b$a
 *  l.a.j.k$c
 *  l.a.j.p.c
 *  l.a.j.p.c$b
 *  l.a.j.p.c$b$c
 *  l.a.j.p.c$f
 *  l.a.j.p.c$h
 *  l.a.j.p.c$h$a
 *  l.a.j.p.f.s
 *  l.a.j.p.f.s$b
 *  l.a.j.q.b
 *  l.a.j.q.i.a
 */
package l.a.j;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;
import l.a.i.i.a;
import l.a.i.i.d;
import l.a.j.e;
import l.a.j.k;
import l.a.j.p.c;
import l.a.j.p.f.s;

/*
 * Exception performing whole class analysis.
 */
public class k
implements e.b {
    private final b c;
    private final List<s.b<?>> d;
    private final c.b f;
    private final c.h h;
    private final l.a.j.q.i.a o;

    protected k(b b2, List<s.b<?>> list, c.b b3) {
        this(b2, list, b3, (c.h)c.h.a.c, l.a.j.q.i.a.w0);
    }

    private k(b b2, List<s.b<?>> list, c.b b3, c.h h2, l.a.j.q.i.a a2) {
        this.c = b2;
        this.d = list;
        this.h = h2;
        this.f = b3;
        this.o = a2;
    }

    public static c a() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static k a(Object object, String string) {
        return k.a().a(object, string);
    }

    public static k a(Object object, String string, d.a a2) {
        return k.a().a(object, string, a2);
    }

    public static k a(Object object, Type type) {
        return k.a().a(object, type);
    }

    public static k a(Object object, Type type, String string) {
        return k.a().a(object, type, string);
    }

    public static k a(Object object, Type type, String string, d.a a2) {
        return k.a().a(object, type, string, a2);
    }

    public static k a(Object object, Type type, d.a a2) {
        return k.a().a(object, type, a2);
    }

    public static k a(Object object, d.a a2) {
        return k.a().a(object, a2);
    }

    public static k a(String string) {
        return k.a().a(string);
    }

    public static k a(String string, a.b b2) {
        return k.a().a(string, b2);
    }

    public static k a(String string, a.b b2, d.a a2) {
        return k.a().a(string, b2, a2);
    }

    public static k a(String string, d.a a2) {
        return k.a().a(string, a2);
    }

    public static c b() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static k b(Class<?> class_) {
        return k.a().a(class_);
    }

    public static k b(Object object) {
        return k.a().b(object);
    }

    public static k c(Class<?> class_) {
        return k.a().b(class_);
    }

    public static k c(l.a.h.k.c c2) {
        return k.a().a(c2);
    }

    public static k d(l.a.h.k.c c2) {
        return k.a().b(c2);
    }

    public l.a.i.i.c a(l.a.i.i.c c2) {
        return this.c.a(c2);
    }

    public e.b a(l.a.j.q.i.a a2) {
        k k2 = new k(this.c, this.d, this.f, this.h, a2);
        return k2;
    }

    public e a(e e2) {
        e[] arre = new e[2];
        k k2 = new k(this.c, this.d, this.f, (c.h)c.h.a.d, this.o);
        arre[0] = k2;
        arre[1] = e2;
        return new e.c(arre);
    }

    public l.a.j.q.b a(e.g g2) {
        a a2 = this.c.a(g2.c());
        a a3 = new /* Unavailable Anonymous Inner Class!! */;
        return a3;
    }

    protected boolean a(Object object) {
        return object instanceof k;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof k)) {
            return false;
        }
        k k2 = (k)object;
        if (!k2.a(this)) {
            return false;
        }
        b b2 = this.c;
        b b3 = k2.c;
        if (b2 == null ? b3 != null : !b2.equals((Object)b3)) {
            return false;
        }
        List<s.b<?>> list = this.d;
        List<s.b<?>> list2 = k2.d;
        if (list == null ? list2 != null : !list.equals(list2)) {
            return false;
        }
        c.b b4 = this.f;
        c.b b5 = k2.f;
        if (b4 == null ? b5 != null : !b4.equals((Object)b5)) {
            return false;
        }
        c.h h2 = this.h;
        c.h h3 = k2.h;
        if (h2 == null ? h3 != null : !h2.equals((Object)h3)) {
            return false;
        }
        l.a.j.q.i.a a2 = this.o;
        l.a.j.q.i.a a3 = k2.o;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public int hashCode() {
        b b2 = this.c;
        int n2 = 43;
        int n3 = b2 == null ? 43 : b2.hashCode();
        int n4 = n3 + 59;
        List<s.b<?>> list = this.d;
        int n5 = n4 * 59;
        int n6 = list == null ? 43 : list.hashCode();
        int n7 = n5 + n6;
        c.b b3 = this.f;
        int n8 = n7 * 59;
        int n9 = b3 == null ? 43 : b3.hashCode();
        int n10 = n8 + n9;
        c.h h2 = this.h;
        int n11 = n10 * 59;
        int n12 = h2 == null ? 43 : h2.hashCode();
        int n13 = n11 + n12;
        l.a.j.q.i.a a2 = this.o;
        int n14 = n13 * 59;
        if (a2 != null) {
            n2 = a2.hashCode();
        }
        return n14 + n2;
    }
}

