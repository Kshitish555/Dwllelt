/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.Callable
 *  l.a.h.g.a
 *  l.a.h.i.a
 *  l.a.h.i.a$b
 *  l.a.h.i.a$c
 *  l.a.h.k.c
 *  l.a.i.i.a
 *  l.a.i.i.a$b
 *  l.a.i.i.a$c
 *  l.a.i.i.a$c$a
 *  l.a.i.i.c
 *  l.a.i.i.d
 *  l.a.i.i.d$a
 *  l.a.j.e
 *  l.a.j.e$b
 *  l.a.j.e$c
 *  l.a.j.e$g
 *  l.a.j.j$b
 *  l.a.j.j$c
 *  l.a.j.j$c$a
 *  l.a.j.j$c$e
 *  l.a.j.j$c$g
 *  l.a.j.j$c$h
 *  l.a.j.j$c$h$a
 *  l.a.j.j$c$j
 *  l.a.j.j$c$j$a
 *  l.a.j.j$c$k
 *  l.a.j.j$c$k$a
 *  l.a.j.j$c$m
 *  l.a.j.j$c$o
 *  l.a.j.j$c$o$a
 *  l.a.j.j$c$o$b
 *  l.a.j.j$c$p
 *  l.a.j.j$c$p$a
 *  l.a.j.j$c$p$b
 *  l.a.j.j$c$q
 *  l.a.j.j$c$t
 *  l.a.j.j$c$t$a
 *  l.a.j.j$d
 *  l.a.j.j$d$a
 *  l.a.j.j$e
 *  l.a.j.j$e$a
 *  l.a.j.j$e$b
 *  l.a.j.j$e$c
 *  l.a.j.j$f
 *  l.a.j.j$f$a
 *  l.a.j.j$g
 *  l.a.j.j$h
 *  l.a.j.q.b
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 *  l.a.l.r
 *  l.a.n.a
 *  l.a.n.b
 */
package l.a.j;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import l.a.h.i.a;
import l.a.i.i.a;
import l.a.i.i.d;
import l.a.j.e;
import l.a.j.j;
import l.a.j.q.i.a;
import l.a.l.r;

/*
 * Exception performing whole class analysis.
 * Exception performing whole class analysis ignored.
 */
public class j
implements e.b {
    protected final e c;
    protected final f d;
    protected final List<a> f;
    protected final d h;
    protected final g o;
    protected final l.a.j.q.i.a s;
    protected final a.d t;

    protected j(e e2, f f2, List<a> list, d d2, g g2, l.a.j.q.i.a a2, a.d d3) {
        this.c = e2;
        this.d = f2;
        this.f = list;
        this.h = d2;
        this.o = g2;
        this.s = a2;
        this.t = d3;
    }

    public static e.b a(Runnable runnable) {
        try {
            e.b b2 = j.a(Runnable.class.getMethod("run", new Class[0])).a((Object)runnable, Runnable.class).a(l.a.j.q.i.a.w0, a.d.f);
            return b2;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new IllegalStateException("Could not locate Runnable::run method", (Throwable)noSuchMethodException);
        }
    }

    public static e.b a(Callable<?> callable) {
        try {
            e.b b2 = j.a(Callable.class.getMethod("call", new Class[0])).a(callable, Callable.class).a(l.a.j.q.i.a.w0, a.d.f);
            return b2;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new IllegalStateException("Could not locate Callable::call method", (Throwable)noSuchMethodException);
        }
    }

    public static h a(Method method) {
        return j.b((l.a.h.i.a)new a.c(method));
    }

    public static h a(e e2) {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static h a(r<? super l.a.h.i.a> r2) {
        return j.a(r2, d.a.q0);
    }

    public static h a(r<? super l.a.h.i.a> r2, d.a a2) {
        return j.a(new a(r2, a2));
    }

    public static j a(Constructor<?> constructor) {
        return j.a((l.a.h.i.a)new a.b(constructor));
    }

    public static j a(l.a.h.i.a a2) {
        if (a2.p1()) {
            j j2 = new j(new b(a2), a.c, (List<a>)Collections.emptyList(), a.c, g.c, l.a.j.q.i.a.w0, a.d.d);
            return j2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Not a constructor: ");
        stringBuilder.append((Object)a2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static h b(Constructor<?> constructor) {
        return j.b((l.a.h.i.a)new a.b(constructor));
    }

    public static h b(l.a.h.i.a a2) {
        return j.a(new b(a2));
    }

    public static h d() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public static j e() {
        return j.d().g();
    }

    public l.a.i.i.c a(l.a.i.i.c c2) {
        Iterator iterator = this.f.iterator();
        while (iterator.hasNext()) {
            c2 = ((a)iterator.next()).a(c2);
        }
        return this.d.a(c2);
    }

    public e.b a(l.a.j.q.i.a a2, a.d d2) {
        j j2 = new j(this.c, this.d, this.f, this.h, this.o, a2, d2);
        return j2;
    }

    public l.a.j.e a(l.a.j.e e2) {
        l.a.j.e[] arre = new l.a.j.e[2];
        j j2 = new j(this.c, this.d, this.f, this.h, g.d, this.s, this.t);
        arre[0] = j2;
        arre[1] = e2;
        return new e.c(arre);
    }

    public j a() {
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (Object)o.b.c), this.h, this.o, this.s, this.t);
        return j2;
    }

    public j a(int n2, int n3) {
        return this.a(n2, 0, n3);
    }

    public j a(int n2, int n3, int n4) {
        IllegalArgumentException illegalArgumentException;
        if (n2 >= 0) {
            if (n3 >= 0) {
                if (n4 == 0) {
                    return this;
                }
                if (n4 >= 0) {
                    ArrayList arrayList = new ArrayList(n4);
                    for (int i2 = 0; i2 < n4; ++i2) {
                        arrayList.add((Object)new p.b(n2, n3 + i2));
                    }
                    j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
                    return j2;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Size cannot be negative: ");
                stringBuilder.append(n4);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("An array index cannot be negative: ");
            stringBuilder.append(n3);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("A parameter index cannot be negative: ");
        stringBuilder.append(n2);
        illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
        throw illegalArgumentException;
    }

    public /* varargs */ j a(a.b b2, String ... arrstring) {
        ArrayList arrayList = new ArrayList(arrstring.length);
        int n2 = arrstring.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new h.a(arrstring[i2], b2));
        }
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
        return j2;
    }

    public /* varargs */ j a(int ... arrn) {
        ArrayList arrayList = new ArrayList(arrn.length);
        for (int n2 : arrn) {
            if (n2 >= 0) {
                arrayList.add((Object)new o.a(n2));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Negative index: ");
            stringBuilder.append(n2);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
        return j2;
    }

    public /* varargs */ j a(Object ... arrobject) {
        ArrayList arrayList = new ArrayList(arrobject.length);
        int n2 = arrobject.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)j.a.b((Object)arrobject[i2]));
        }
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
        return j2;
    }

    public /* varargs */ j a(String ... arrstring) {
        return this.a((a.b)a.c.a.c, arrstring);
    }

    public /* varargs */ j a(l.a.h.g.a ... arra) {
        ArrayList arrayList = new ArrayList(arra.length);
        int n2 = arra.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new g(arra[i2]));
        }
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
        return j2;
    }

    public /* varargs */ j a(l.a.h.k.c ... arrc) {
        ArrayList arrayList = new ArrayList(arrc.length);
        int n2 = arrc.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new e(arrc[i2]));
        }
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
        return j2;
    }

    public /* varargs */ j a(l.a.n.b ... arrb) {
        ArrayList arrayList = new ArrayList(arrb.length);
        int n2 = arrb.length;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new m(arrb[i2]));
        }
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
        return j2;
    }

    public l.a.j.q.b a(e.g g2) {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    protected boolean a(Object object) {
        return object instanceof j;
    }

    public j b() {
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (Object)k.a.c), this.h, this.o, this.s, this.t);
        return j2;
    }

    public j b(int n2) {
        if (n2 >= 0) {
            j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (Object)new p.a(n2)), this.h, this.o, this.s, this.t);
            return j2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("A parameter index cannot be negative: ");
        stringBuilder.append(n2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public /* varargs */ j b(Object ... arrobject) {
        ArrayList arrayList = new ArrayList(arrobject.length);
        for (Object object : arrobject) {
            Object object2 = object == null ? q.c : new j.a(object);
            arrayList.add(object2);
        }
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (List)arrayList), this.h, this.o, this.s, this.t);
        return j2;
    }

    public j c() {
        j j2 = new j(this.c, this.d, (List<a>)l.a.n.a.a(this.f, (Object)t.a.c), this.h, this.o, this.s, this.t);
        return j2;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof j)) {
            return false;
        }
        j j2 = (j)object;
        if (!j2.a((Object)this)) {
            return false;
        }
        e e2 = this.c;
        e e3 = j2.c;
        if (e2 == null ? e3 != null : !e2.equals((Object)e3)) {
            return false;
        }
        f f2 = this.d;
        f f3 = j2.d;
        if (f2 == null ? f3 != null : !f2.equals((Object)f3)) {
            return false;
        }
        List<a> list = this.f;
        List<a> list2 = j2.f;
        if (list == null ? list2 != null : !list.equals(list2)) {
            return false;
        }
        d d2 = this.h;
        d d3 = j2.h;
        if (d2 == null ? d3 != null : !d2.equals((Object)d3)) {
            return false;
        }
        g g2 = this.o;
        g g3 = j2.o;
        if (g2 == null ? g3 != null : !g2.equals((Object)g3)) {
            return false;
        }
        l.a.j.q.i.a a2 = this.s;
        l.a.j.q.i.a a3 = j2.s;
        if (a2 == null ? a3 != null : !a2.equals((Object)a3)) {
            return false;
        }
        a.d d4 = this.t;
        a.d d5 = j2.t;
        return !(d4 == null ? d5 != null : !d4.equals((Object)d5));
    }

    public int hashCode() {
        e e2 = this.c;
        int n2 = 43;
        int n3 = e2 == null ? 43 : e2.hashCode();
        int n4 = n3 + 59;
        f f2 = this.d;
        int n5 = n4 * 59;
        int n6 = f2 == null ? 43 : f2.hashCode();
        int n7 = n5 + n6;
        List<a> list = this.f;
        int n8 = n7 * 59;
        int n9 = list == null ? 43 : list.hashCode();
        int n10 = n8 + n9;
        d d2 = this.h;
        int n11 = n10 * 59;
        int n12 = d2 == null ? 43 : d2.hashCode();
        int n13 = n11 + n12;
        g g2 = this.o;
        int n14 = n13 * 59;
        int n15 = g2 == null ? 43 : g2.hashCode();
        int n16 = n14 + n15;
        l.a.j.q.i.a a2 = this.s;
        int n17 = n16 * 59;
        int n18 = a2 == null ? 43 : a2.hashCode();
        int n19 = n17 + n18;
        a.d d3 = this.t;
        int n20 = n19 * 59;
        if (d3 != null) {
            n2 = d3.hashCode();
        }
        return n20 + n2;
    }
}

