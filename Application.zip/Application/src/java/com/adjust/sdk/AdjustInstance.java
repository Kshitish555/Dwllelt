/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  com.adjust.sdk.AdjustInstance$b
 *  com.adjust.sdk.AdjustInstance$c
 *  com.adjust.sdk.AdjustInstance$d
 *  com.adjust.sdk.AdjustInstance$e
 *  com.adjust.sdk.AdjustInstance$f
 *  com.adjust.sdk.AdjustInstance$g
 *  java.lang.Boolean
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.List
 */
package com.adjust.sdk;

import android.content.Context;
import android.net.Uri;
import com.adjust.sdk.AdjustAttribution;
import com.adjust.sdk.AdjustConfig;
import com.adjust.sdk.AdjustEvent;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.AdjustInstance;
import com.adjust.sdk.AdjustTestOptions;
import com.adjust.sdk.BackoffStrategy;
import com.adjust.sdk.IActivityHandler;
import com.adjust.sdk.IRunActivityHandler;
import com.adjust.sdk.SharedPreferencesManager;
import com.adjust.sdk.Util;
import java.util.ArrayList;
import java.util.List;

public class AdjustInstance {
    private IActivityHandler activityHandler;
    private String basePath;
    private String gdprPath;
    private List<IRunActivityHandler> preLaunchActionsArray;
    private String pushToken;
    private Boolean startEnabled = null;
    private boolean startOffline = false;

    private boolean checkActivityHandler() {
        return this.checkActivityHandler(null);
    }

    private boolean checkActivityHandler(String string) {
        if (this.activityHandler == null) {
            if (string != null) {
                AdjustFactory.getLogger().warn("Adjust not initialized, but %s saved for launch", string);
                return false;
            }
            AdjustFactory.getLogger().error("Adjust not initialized correctly", new Object[0]);
            return false;
        }
        return true;
    }

    private boolean checkActivityHandler(boolean bl, String string, String string2) {
        if (bl) {
            return this.checkActivityHandler(string);
        }
        return this.checkActivityHandler(string2);
    }

    private boolean isInstanceEnabled() {
        Boolean bl = this.startEnabled;
        return bl == null || bl.booleanValue();
        {
        }
    }

    private void saveGdprForgetMe(final Context context) {
        Util.runInBackground(new Runnable(){

            public void run() {
                new SharedPreferencesManager(context).setGdprForgetMe();
            }
        });
    }

    private void savePushToken(final String string, final Context context) {
        Util.runInBackground(new Runnable(){

            public void run() {
                new SharedPreferencesManager(context).savePushToken(string);
            }
        });
    }

    private void saveRawReferrer(final String string, final long l2, final Context context) {
        Runnable runnable = new Runnable(){

            public void run() {
                new SharedPreferencesManager(context).saveRawReferrer(string, l2);
            }
        };
        Util.runInBackground(runnable);
    }

    private void setSendingReferrersAsNotSent(final Context context) {
        Util.runInBackground(new Runnable(){

            public void run() {
                new SharedPreferencesManager(context).setSendingReferrersAsNotSent();
            }
        });
    }

    public void addSessionCallbackParameter(String string, String string2) {
        if (this.checkActivityHandler("adding session callback parameter")) {
            this.activityHandler.addSessionCallbackParameter(string, string2);
            return;
        }
        if (this.preLaunchActionsArray == null) {
            this.preLaunchActionsArray = new ArrayList();
        }
        this.preLaunchActionsArray.add((Object)new b(this, string, string2));
    }

    public void addSessionPartnerParameter(String string, String string2) {
        if (this.checkActivityHandler("adding session partner parameter")) {
            this.activityHandler.addSessionPartnerParameter(string, string2);
            return;
        }
        if (this.preLaunchActionsArray == null) {
            this.preLaunchActionsArray = new ArrayList();
        }
        this.preLaunchActionsArray.add((Object)new c(this, string, string2));
    }

    public void appWillOpenUrl(Uri uri) {
        if (!this.checkActivityHandler()) {
            return;
        }
        long l2 = System.currentTimeMillis();
        this.activityHandler.readOpenUrl(uri, l2);
    }

    public void appWillOpenUrl(Uri uri, Context context) {
        long l2 = System.currentTimeMillis();
        if (!this.checkActivityHandler()) {
            new SharedPreferencesManager(context).saveDeeplink(uri, l2);
            return;
        }
        this.activityHandler.readOpenUrl(uri, l2);
    }

    public void gdprForgetMe(Context context) {
        this.saveGdprForgetMe(context);
        if (this.checkActivityHandler("gdpr") && this.activityHandler.isEnabled()) {
            this.activityHandler.gdprForgetMe();
        }
    }

    public String getAdid() {
        if (!this.checkActivityHandler()) {
            return null;
        }
        return this.activityHandler.getAdid();
    }

    public AdjustAttribution getAttribution() {
        if (!this.checkActivityHandler()) {
            return null;
        }
        return this.activityHandler.getAttribution();
    }

    public String getSdkVersion() {
        return Util.getSdkVersion();
    }

    public boolean isEnabled() {
        if (!this.checkActivityHandler()) {
            return this.isInstanceEnabled();
        }
        return this.activityHandler.isEnabled();
    }

    public void onCreate(AdjustConfig adjustConfig) {
        if (adjustConfig == null) {
            AdjustFactory.getLogger().error("AdjustConfig missing", new Object[0]);
            return;
        }
        if (!adjustConfig.isValid()) {
            AdjustFactory.getLogger().error("AdjustConfig not initialized correctly", new Object[0]);
            return;
        }
        if (this.activityHandler != null) {
            AdjustFactory.getLogger().error("Adjust already initialized", new Object[0]);
            return;
        }
        adjustConfig.preLaunchActionsArray = this.preLaunchActionsArray;
        adjustConfig.pushToken = this.pushToken;
        adjustConfig.startEnabled = this.startEnabled;
        adjustConfig.startOffline = this.startOffline;
        adjustConfig.basePath = this.basePath;
        adjustConfig.gdprPath = this.gdprPath;
        this.activityHandler = AdjustFactory.getActivityHandler(adjustConfig);
        this.setSendingReferrersAsNotSent(adjustConfig.context);
    }

    public void onPause() {
        if (!this.checkActivityHandler()) {
            return;
        }
        this.activityHandler.onPause();
    }

    public void onResume() {
        if (!this.checkActivityHandler()) {
            return;
        }
        this.activityHandler.onResume();
    }

    public void removeSessionCallbackParameter(String string) {
        if (this.checkActivityHandler("removing session callback parameter")) {
            this.activityHandler.removeSessionCallbackParameter(string);
            return;
        }
        if (this.preLaunchActionsArray == null) {
            this.preLaunchActionsArray = new ArrayList();
        }
        this.preLaunchActionsArray.add((Object)new d(this, string));
    }

    public void removeSessionPartnerParameter(String string) {
        if (this.checkActivityHandler("removing session partner parameter")) {
            this.activityHandler.removeSessionPartnerParameter(string);
            return;
        }
        if (this.preLaunchActionsArray == null) {
            this.preLaunchActionsArray = new ArrayList();
        }
        this.preLaunchActionsArray.add((Object)new e(this, string));
    }

    public void resetSessionCallbackParameters() {
        if (this.checkActivityHandler("resetting session callback parameters")) {
            this.activityHandler.resetSessionCallbackParameters();
            return;
        }
        if (this.preLaunchActionsArray == null) {
            this.preLaunchActionsArray = new ArrayList();
        }
        this.preLaunchActionsArray.add((Object)new f(this));
    }

    public void resetSessionPartnerParameters() {
        if (this.checkActivityHandler("resetting session partner parameters")) {
            this.activityHandler.resetSessionPartnerParameters();
            return;
        }
        if (this.preLaunchActionsArray == null) {
            this.preLaunchActionsArray = new ArrayList();
        }
        this.preLaunchActionsArray.add((Object)new g(this));
    }

    public void sendFirstPackages() {
        if (!this.checkActivityHandler()) {
            return;
        }
        this.activityHandler.sendFirstPackages();
    }

    public void sendReferrer(String string, Context context) {
        long l2 = System.currentTimeMillis();
        if (string != null) {
            if (string.length() == 0) {
                return;
            }
            this.saveRawReferrer(string, l2, context);
            if (this.checkActivityHandler("referrer") && this.activityHandler.isEnabled()) {
                this.activityHandler.sendReftagReferrer();
            }
        }
    }

    public void setEnabled(boolean bl) {
        this.startEnabled = bl;
        if (this.checkActivityHandler(bl, "enabled mode", "disabled mode")) {
            this.activityHandler.setEnabled(bl);
        }
    }

    public void setOfflineMode(boolean bl) {
        if (!this.checkActivityHandler(bl, "offline mode", "online mode")) {
            this.startOffline = bl;
            return;
        }
        this.activityHandler.setOfflineMode(bl);
    }

    public void setPushToken(String string) {
        if (!this.checkActivityHandler("push token")) {
            this.pushToken = string;
            return;
        }
        this.activityHandler.setPushToken(string, false);
    }

    public void setPushToken(String string, Context context) {
        this.savePushToken(string, context);
        if (this.checkActivityHandler("push token") && this.activityHandler.isEnabled()) {
            this.activityHandler.setPushToken(string, true);
        }
    }

    public void setTestOptions(AdjustTestOptions adjustTestOptions) {
        Long l2;
        String string;
        Boolean bl;
        Long l3;
        Boolean bl2;
        String string2;
        Long l4;
        String string3;
        String string4 = adjustTestOptions.basePath;
        if (string4 != null) {
            this.basePath = string4;
        }
        if ((string = adjustTestOptions.gdprPath) != null) {
            this.gdprPath = string;
        }
        if ((string2 = adjustTestOptions.baseUrl) != null) {
            AdjustFactory.setBaseUrl(string2);
        }
        if ((string3 = adjustTestOptions.gdprUrl) != null) {
            AdjustFactory.setGdprUrl(string3);
        }
        if ((bl2 = adjustTestOptions.useTestConnectionOptions) != null && bl2.booleanValue()) {
            AdjustFactory.useTestConnectionOptions();
        }
        if ((l3 = adjustTestOptions.timerIntervalInMilliseconds) != null) {
            AdjustFactory.setTimerInterval(l3);
        }
        if (adjustTestOptions.timerStartInMilliseconds != null) {
            AdjustFactory.setTimerStart(adjustTestOptions.timerIntervalInMilliseconds);
        }
        if ((l4 = adjustTestOptions.sessionIntervalInMilliseconds) != null) {
            AdjustFactory.setSessionInterval(l4);
        }
        if ((l2 = adjustTestOptions.subsessionIntervalInMilliseconds) != null) {
            AdjustFactory.setSubsessionInterval(l2);
        }
        if ((bl = adjustTestOptions.tryInstallReferrer) != null) {
            AdjustFactory.setTryInstallReferrer(bl);
        }
        if (adjustTestOptions.noBackoffWait != null) {
            AdjustFactory.setPackageHandlerBackoffStrategy(BackoffStrategy.NO_WAIT);
            AdjustFactory.setSdkClickBackoffStrategy(BackoffStrategy.NO_WAIT);
        }
    }

    public void teardown() {
        if (!this.checkActivityHandler()) {
            return;
        }
        this.activityHandler.teardown();
        this.activityHandler = null;
    }

    public void trackEvent(AdjustEvent adjustEvent) {
        if (!this.checkActivityHandler()) {
            return;
        }
        this.activityHandler.trackEvent(adjustEvent);
    }

}

