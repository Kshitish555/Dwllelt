/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

class Comparer {
    private static final String NAME = "name";
    private final String[] ignore;

    public Comparer() {
        this(NAME);
    }

    public /* varargs */ Comparer(String ... arrstring) {
        this.ignore = arrstring;
    }

    private boolean isIgnore(Method method) {
        String string2 = method.getName();
        String[] arrstring = this.ignore;
        if (arrstring != null) {
            int n2 = arrstring.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                if (!string2.equals((Object)arrstring[i2])) continue;
                return true;
            }
        }
        return false;
    }

    public boolean equals(Annotation annotation, Annotation annotation2) throws Exception {
        Class class_ = annotation.annotationType();
        Class class_2 = annotation2.annotationType();
        Method[] arrmethod = class_.getDeclaredMethods();
        if (class_.equals((Object)class_2)) {
            for (Method method : arrmethod) {
                if (this.isIgnore(method) || method.invoke((Object)annotation, new Object[0]).equals(method.invoke((Object)annotation2, new Object[0]))) continue;
                return false;
            }
            return true;
        }
        return false;
    }
}

