/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.location.Location
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package org.osmdroid.api;

import android.location.Location;
import android.os.Bundle;

public interface IMyLocationOverlay {
    public void disableCompass();

    public void disableMyLocation();

    public boolean enableCompass();

    public boolean enableMyLocation();

    public Location getLastFix();

    public float getOrientation();

    public boolean isCompassEnabled();

    public boolean isMyLocationEnabled();

    public void onStatusChanged(String var1, int var2, Bundle var3);

    public boolean runOnFirstFix(Runnable var1);
}

