/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package org.simpleframework.xml.core;

public class PersistenceException
extends Exception {
    public /* varargs */ PersistenceException(String string2, Object ... arrobject) {
        super(String.format((String)string2, (Object[])arrobject));
    }

    public /* varargs */ PersistenceException(Throwable throwable, String string2, Object ... arrobject) {
        super(String.format((String)string2, (Object[])arrobject), throwable);
    }
}

