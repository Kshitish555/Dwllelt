/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.simpleframework.xml.Order
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Caller
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Function
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.ParameterMap
 *  org.simpleframework.xml.core.Policy
 *  org.simpleframework.xml.core.Section
 *  org.simpleframework.xml.core.Signature
 */
package org.simpleframework.xml.core;

import java.util.List;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.Caller;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Function;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.ParameterMap;
import org.simpleframework.xml.core.Policy;
import org.simpleframework.xml.core.Section;
import org.simpleframework.xml.core.Signature;

interface Scanner
extends Policy {
    public Caller getCaller(Context var1);

    public Function getCommit();

    public Function getComplete();

    public Decorator getDecorator();

    public Instantiator getInstantiator();

    public String getName();

    public Order getOrder();

    public ParameterMap getParameters();

    public Function getPersist();

    public Function getReplace();

    public Function getResolve();

    public Version getRevision();

    public Section getSection();

    public Signature getSignature();

    public List<Signature> getSignatures();

    public Label getText();

    public Class getType();

    public Function getValidate();

    public Label getVersion();

    public boolean isEmpty();

    public boolean isPrimitive();

    public boolean isStrict();
}

