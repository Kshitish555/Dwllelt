/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.osmdroid.contributor.util.constants;

public interface OpenStreetMapContributorConstants {
    public static final int MINDIAGONALMETERS_FOR_OSM_CONTRIBUTION = 300;
    public static final int MINGEOPOINTS_FOR_OSM_CONTRIBUTION = 100;
    public static final int NOT_SET = Integer.MIN_VALUE;
    public static final String OSM_CREATOR_INFO = "AndNav - http://www.andnav.org - Android Navigation System";
    public static final String OSM_PASSWORD = "PUT_YOUR_PASSWORD_HERE";
    public static final String OSM_USERNAME = "PUT_YOUR_USERNAME_HERE";
}

