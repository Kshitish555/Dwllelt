/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Array
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.GenericArrayType
 *  java.lang.reflect.Method
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

final class Reflector {
    Reflector() {
    }

    private static Class getArrayClass(Type type) {
        Class class_ = Reflector.getClass(((GenericArrayType)type).getGenericComponentType());
        if (class_ != null) {
            return Array.newInstance((Class)class_, (int)0).getClass();
        }
        return null;
    }

    private static Class getClass(ParameterizedType parameterizedType) {
        Type[] arrtype = parameterizedType.getActualTypeArguments();
        if (arrtype.length > 0) {
            return Reflector.getClass(arrtype[0]);
        }
        return null;
    }

    private static Class getClass(Type type) {
        if (type instanceof Class) {
            return (Class)type;
        }
        return Reflector.getGenericClass(type);
    }

    private static Class[] getClasses(ParameterizedType parameterizedType) {
        Type[] arrtype = parameterizedType.getActualTypeArguments();
        Class[] arrclass = new Class[arrtype.length];
        for (int i2 = 0; i2 < arrtype.length; ++i2) {
            arrclass[i2] = Reflector.getClass(arrtype[i2]);
        }
        return arrclass;
    }

    public static Class getDependent(Field field) {
        ParameterizedType parameterizedType = Reflector.getType(field);
        if (parameterizedType != null) {
            return Reflector.getClass(parameterizedType);
        }
        return Object.class;
    }

    public static Class[] getDependents(Field field) {
        ParameterizedType parameterizedType = Reflector.getType(field);
        if (parameterizedType != null) {
            return Reflector.getClasses(parameterizedType);
        }
        return new Class[0];
    }

    private static Class getGenericClass(Type type) {
        if (type instanceof GenericArrayType) {
            return Reflector.getArrayClass(type);
        }
        return Object.class;
    }

    public static String getName(String string2) {
        if (string2.length() > 0) {
            char[] arrc = string2.toCharArray();
            char c2 = arrc[0];
            if (!Reflector.isAcronym(arrc)) {
                arrc[0] = Reflector.toLowerCase(c2);
            }
            return new String(arrc);
        }
        return string2;
    }

    public static Class getParameterDependent(Constructor constructor, int n2) {
        ParameterizedType parameterizedType = Reflector.getParameterType(constructor, n2);
        if (parameterizedType != null) {
            return Reflector.getClass(parameterizedType);
        }
        return Object.class;
    }

    public static Class getParameterDependent(Method method, int n2) {
        ParameterizedType parameterizedType = Reflector.getParameterType(method, n2);
        if (parameterizedType != null) {
            return Reflector.getClass(parameterizedType);
        }
        return Object.class;
    }

    public static Class[] getParameterDependents(Constructor constructor, int n2) {
        ParameterizedType parameterizedType = Reflector.getParameterType(constructor, n2);
        if (parameterizedType != null) {
            return Reflector.getClasses(parameterizedType);
        }
        return new Class[0];
    }

    public static Class[] getParameterDependents(Method method, int n2) {
        ParameterizedType parameterizedType = Reflector.getParameterType(method, n2);
        if (parameterizedType != null) {
            return Reflector.getClasses(parameterizedType);
        }
        return new Class[0];
    }

    private static ParameterizedType getParameterType(Constructor constructor, int n2) {
        Type type;
        Type[] arrtype = constructor.getGenericParameterTypes();
        if (arrtype.length > n2 && (type = arrtype[n2]) instanceof ParameterizedType) {
            return (ParameterizedType)type;
        }
        return null;
    }

    private static ParameterizedType getParameterType(Method method, int n2) {
        Type type;
        Type[] arrtype = method.getGenericParameterTypes();
        if (arrtype.length > n2 && (type = arrtype[n2]) instanceof ParameterizedType) {
            return (ParameterizedType)type;
        }
        return null;
    }

    public static Class getReturnDependent(Method method) {
        ParameterizedType parameterizedType = Reflector.getReturnType(method);
        if (parameterizedType != null) {
            return Reflector.getClass(parameterizedType);
        }
        return Object.class;
    }

    public static Class[] getReturnDependents(Method method) {
        ParameterizedType parameterizedType = Reflector.getReturnType(method);
        if (parameterizedType != null) {
            return Reflector.getClasses(parameterizedType);
        }
        return new Class[0];
    }

    private static ParameterizedType getReturnType(Method method) {
        Type type = method.getGenericReturnType();
        if (type instanceof ParameterizedType) {
            return (ParameterizedType)type;
        }
        return null;
    }

    private static ParameterizedType getType(Field field) {
        Type type = field.getGenericType();
        if (type instanceof ParameterizedType) {
            return (ParameterizedType)type;
        }
        return null;
    }

    private static boolean isAcronym(char[] arrc) {
        if (arrc.length < 2) {
            return false;
        }
        if (!Reflector.isUpperCase(arrc[0])) {
            return false;
        }
        return Reflector.isUpperCase(arrc[1]);
    }

    private static boolean isUpperCase(char c2) {
        return Character.isUpperCase((char)c2);
    }

    private static char toLowerCase(char c2) {
        return Character.toLowerCase((char)c2);
    }
}

