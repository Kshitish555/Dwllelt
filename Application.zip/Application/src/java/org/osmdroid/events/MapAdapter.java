/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.osmdroid.events.MapListener
 */
package org.osmdroid.events;

import org.osmdroid.events.MapListener;
import org.osmdroid.events.ScrollEvent;
import org.osmdroid.events.ZoomEvent;

public abstract class MapAdapter
implements MapListener {
    public boolean onScroll(ScrollEvent scrollEvent) {
        return false;
    }

    public boolean onZoom(ZoomEvent zoomEvent) {
        return false;
    }
}

