/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  androidx.annotation.i0
 *  androidx.fragment.app.Fragment
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  lifecyclesurviveapi.ComponentControllerFragment$a
 *  lifecyclesurviveapi.h
 *  lifecyclesurviveapi.j
 *  lifecyclesurviveapi.k
 */
package lifecyclesurviveapi;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.i0;
import androidx.fragment.app.Fragment;
import lifecyclesurviveapi.ComponentControllerFragment;
import lifecyclesurviveapi.h;
import lifecyclesurviveapi.j;
import lifecyclesurviveapi.k;

public abstract class ComponentControllerFragment<C>
extends Fragment {
    public k<C> componentFactory = new a(this);
    private h mComponentCache;
    private j<C> mComponentDelegate = new j();

    public C getComponent() {
        return (C)this.mComponentDelegate.a();
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof h) {
            this.mComponentCache = (h)context;
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getClass().getSimpleName());
        stringBuilder.append(" must be attached to an Activity that implements ");
        stringBuilder.append(h.class.getSimpleName());
        throw new RuntimeException(stringBuilder.toString());
    }

    public void onCreate(@i0 Bundle bundle) {
        super.onCreate(bundle);
        this.mComponentDelegate.a(this.mComponentCache, bundle, this.componentFactory);
    }

    protected abstract C onCreateNonConfigurationComponent();

    public void onDestroy() {
        super.onDestroy();
        this.mComponentDelegate.b();
    }

    public void onResume() {
        super.onResume();
        this.mComponentDelegate.c();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.mComponentDelegate.a(bundle);
    }

    public void setComponentFactory(k<C> k2) {
        this.componentFactory = k2;
    }
}

