/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Caller
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.Schema
 *  org.simpleframework.xml.core.Section
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.Caller;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.Schema;
import org.simpleframework.xml.core.Section;

class ClassSchema
implements Schema {
    private final Caller caller;
    private final Decorator decorator;
    private final Instantiator factory;
    private final boolean primitive;
    private final Version revision;
    private final Section section;
    private final Label text;
    private final Class type;
    private final Label version;

    public ClassSchema(Scanner scanner, Context context) throws Exception {
        this.caller = scanner.getCaller(context);
        this.factory = scanner.getInstantiator();
        this.revision = scanner.getRevision();
        this.decorator = scanner.getDecorator();
        this.primitive = scanner.isPrimitive();
        this.version = scanner.getVersion();
        this.section = scanner.getSection();
        this.text = scanner.getText();
        this.type = scanner.getType();
    }

    public Caller getCaller() {
        return this.caller;
    }

    public Decorator getDecorator() {
        return this.decorator;
    }

    public Instantiator getInstantiator() {
        return this.factory;
    }

    public Version getRevision() {
        return this.revision;
    }

    public Section getSection() {
        return this.section;
    }

    public Label getText() {
        return this.text;
    }

    public Label getVersion() {
        return this.version;
    }

    public boolean isPrimitive() {
        return this.primitive;
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.type};
        return String.format((String)"schema for %s", (Object[])arrobject);
    }
}

