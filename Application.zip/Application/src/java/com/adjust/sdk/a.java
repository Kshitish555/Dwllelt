/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.DisplayMetrics
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.Date
 *  java.util.Locale
 */
package com.adjust.sdk;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.Util;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

class a {
    String A;
    String B;
    String C;
    String a;
    String b;
    Boolean c;
    private boolean d = false;
    String e;
    String f;
    String g;
    String h;
    String i;
    String j;
    String k;
    String l;
    String m;
    String n;
    String o;
    String p;
    String q;
    String r;
    String s;
    String t;
    String u;
    String v;
    String w;
    String x;
    String y;
    String z;

    a(Context context, String string) {
        Resources resources = context.getResources();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        Configuration configuration = resources.getConfiguration();
        Locale locale = Util.getLocale(configuration);
        int n2 = configuration.screenLayout;
        context.getContentResolver();
        this.j = this.g(context);
        this.k = this.e(context);
        this.l = this.a(n2);
        this.m = this.e();
        this.n = this.d();
        this.o = this.g();
        this.p = this.h();
        this.q = this.b();
        this.r = this.b(locale);
        this.s = this.a(locale);
        this.t = this.c(n2);
        this.u = this.b(n2);
        this.v = this.c(displayMetrics);
        this.w = this.b(displayMetrics);
        this.x = this.a(displayMetrics);
        this.i = this.a(string);
        this.h = this.f(context);
        this.y = this.f();
        this.z = this.a();
        this.A = this.c();
        this.B = this.c(context);
        this.C = this.d(context);
    }

    private String a() {
        String[] arrstring = Util.getSupportedAbis();
        if (arrstring != null && arrstring.length != 0) {
            return arrstring[0];
        }
        return Util.getCpuAbi();
    }

    private String a(int n2) {
        int n3 = n2 & 15;
        if (n3 != 1 && n3 != 2) {
            if (n3 != 3 && n3 != 4) {
                return null;
            }
            return "tablet";
        }
        return "phone";
    }

    private String a(Context context, boolean bl) {
        if (!bl) {
            if (!Util.checkPermission(context, "android.permission.ACCESS_WIFI_STATE")) {
                AdjustFactory.getLogger().warn("Missing permission: ACCESS_WIFI_STATE", new Object[0]);
            }
            return Util.getMacAddress(context);
        }
        return null;
    }

    private String a(DisplayMetrics displayMetrics) {
        return String.valueOf((int)displayMetrics.heightPixels);
    }

    private String a(String string) {
        if (string == null) {
            return "android4.17.0";
        }
        return Util.formatString("%s@%s", string, "android4.17.0");
    }

    private String a(Locale locale) {
        return locale.getCountry();
    }

    private String b() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("");
        stringBuilder.append(Build.VERSION.SDK_INT);
        return stringBuilder.toString();
    }

    private String b(int n2) {
        int n3 = n2 & 48;
        if (n3 != 16) {
            if (n3 != 32) {
                return null;
            }
            return "long";
        }
        return "normal";
    }

    private String b(DisplayMetrics displayMetrics) {
        return String.valueOf((int)displayMetrics.widthPixels);
    }

    private String b(String string) {
        if (string == null) {
            return null;
        }
        return Util.sha1(string);
    }

    private String b(Locale locale) {
        return locale.getLanguage();
    }

    private String c() {
        return Build.ID;
    }

    private String c(int n2) {
        int n3 = n2 & 15;
        if (n3 != 1) {
            if (n3 != 2) {
                if (n3 != 3) {
                    if (n3 != 4) {
                        return null;
                    }
                    return "xlarge";
                }
                return "large";
            }
            return "normal";
        }
        return "small";
    }

    private String c(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 4096);
            String string = Util.dateFormatter.format(new Date(packageInfo.firstInstallTime));
            return string;
        }
        catch (Exception exception) {
            return null;
        }
    }

    private String c(DisplayMetrics displayMetrics) {
        int n2 = displayMetrics.densityDpi;
        if (n2 == 0) {
            return null;
        }
        if (n2 < 140) {
            return "low";
        }
        if (n2 > 200) {
            return "high";
        }
        return "medium";
    }

    private String c(String string) {
        if (string == null) {
            return null;
        }
        return Util.md5(string.replaceAll(":", ""));
    }

    private String d() {
        return Build.MANUFACTURER;
    }

    private String d(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 4096);
            String string = Util.dateFormatter.format(new Date(packageInfo.lastUpdateTime));
            return string;
        }
        catch (Exception exception) {
            return null;
        }
    }

    private String e() {
        return Build.MODEL;
    }

    private String e(Context context) {
        try {
            String string = context.getPackageManager().getPackageInfo((String)context.getPackageName(), (int)0).versionName;
            return string;
        }
        catch (Exception exception) {
            return null;
        }
    }

    private String f() {
        return Build.DISPLAY;
    }

    private String f(Context context) {
        Cursor cursor;
        block5 : {
            block4 : {
                try {
                    cursor = context.getContentResolver().query(Uri.parse((String)"content://com.facebook.katana.provider.AttributionIdProvider"), new String[]{"aid"}, null, null, null);
                    if (cursor != null) break block4;
                    return null;
                }
                catch (Exception exception) {
                    return null;
                }
            }
            if (cursor.moveToFirst()) break block5;
            cursor.close();
            return null;
        }
        String string = cursor.getString(cursor.getColumnIndex("aid"));
        cursor.close();
        return string;
    }

    private String g() {
        return "android";
    }

    private String g(Context context) {
        return context.getPackageName();
    }

    private String h() {
        return Build.VERSION.RELEASE;
    }

    void a(Context context) {
        if (this.d) {
            return;
        }
        if (!Util.checkPermission(context, "android.permission.ACCESS_WIFI_STATE")) {
            AdjustFactory.getLogger().warn("Missing permission: ACCESS_WIFI_STATE", new Object[0]);
        }
        String string = Util.getMacAddress(context);
        this.e = this.b(string);
        this.f = this.c(string);
        this.g = Util.getAndroidId(context);
        this.d = true;
    }

    /*
     * Exception decompiling
     */
    void b(Context var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl55.1 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }
}

