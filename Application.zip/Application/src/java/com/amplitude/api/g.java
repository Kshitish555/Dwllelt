/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.sqlite.SQLiteDatabase
 *  java.lang.Object
 */
package com.amplitude.api;

import android.database.sqlite.SQLiteDatabase;

public interface g {
    public void a(SQLiteDatabase var1);
}

