/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Reader
 *  java.io.StringReader
 *  java.io.Writer
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  org.simpleframework.xml.Serializer
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Session
 *  org.simpleframework.xml.core.SessionManager
 *  org.simpleframework.xml.core.Traverser
 *  org.simpleframework.xml.filter.Filter
 *  org.simpleframework.xml.filter.PlatformFilter
 *  org.simpleframework.xml.strategy.Strategy
 *  org.simpleframework.xml.stream.Format
 *  org.simpleframework.xml.stream.NodeBuilder
 *  org.simpleframework.xml.transform.Matcher
 */
package org.simpleframework.xml.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.EmptyMatcher;
import org.simpleframework.xml.core.Session;
import org.simpleframework.xml.core.SessionManager;
import org.simpleframework.xml.core.Source;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.core.Traverser;
import org.simpleframework.xml.filter.Filter;
import org.simpleframework.xml.filter.PlatformFilter;
import org.simpleframework.xml.strategy.Strategy;
import org.simpleframework.xml.strategy.TreeStrategy;
import org.simpleframework.xml.stream.Format;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.NodeBuilder;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.transform.Matcher;

public class Persister
implements Serializer {
    private final Format format;
    private final SessionManager manager;
    private final Strategy strategy;
    private final Support support;

    public Persister() {
        this((Map)new HashMap());
    }

    public Persister(Map map) {
        this((Filter)new PlatformFilter(map));
    }

    public Persister(Map map, Format format) {
        this((Filter)new PlatformFilter(map));
    }

    public Persister(Filter filter) {
        this((Strategy)new TreeStrategy(), filter);
    }

    public Persister(Filter filter, Format format) {
        this((Strategy)new TreeStrategy(), filter, format);
    }

    public Persister(Filter filter, Matcher matcher) {
        this((Strategy)new TreeStrategy(), filter, matcher);
    }

    public Persister(Filter filter, Matcher matcher, Format format) {
        this(new TreeStrategy(), filter, matcher, format);
    }

    public Persister(Strategy strategy) {
        this(strategy, (Map)new HashMap());
    }

    public Persister(Strategy strategy, Map map) {
        this(strategy, (Filter)new PlatformFilter(map));
    }

    public Persister(Strategy strategy, Map map, Format format) {
        this(strategy, (Filter)new PlatformFilter(map), format);
    }

    public Persister(Strategy strategy, Filter filter) {
        this(strategy, filter, new Format());
    }

    public Persister(Strategy strategy, Filter filter, Format format) {
        this(strategy, filter, new EmptyMatcher(), format);
    }

    public Persister(Strategy strategy, Filter filter, Matcher matcher) {
        this(strategy, filter, matcher, new Format());
    }

    public Persister(Strategy strategy, Filter filter, Matcher matcher, Format format) {
        this.support = new Support(filter, matcher, format);
        this.manager = new SessionManager();
        this.strategy = strategy;
        this.format = format;
    }

    public Persister(Strategy strategy, Format format) {
        this(strategy, (Map)new HashMap(), format);
    }

    public Persister(Strategy strategy, Matcher matcher) {
        this(strategy, (Filter)new PlatformFilter(), matcher);
    }

    public Persister(Strategy strategy, Matcher matcher, Format format) {
        this(strategy, (Filter)new PlatformFilter(), matcher, format);
    }

    public Persister(Format format) {
        this((Strategy)new TreeStrategy(), format);
    }

    public Persister(Matcher matcher) {
        this((Strategy)new TreeStrategy(), matcher);
    }

    public Persister(Matcher matcher, Format format) {
        this((Strategy)new TreeStrategy(), matcher, format);
    }

    private <T> T read(Class<? extends T> class_, InputNode inputNode, Context context) throws Exception {
        return (T)new Traverser(context).read(inputNode, class_);
    }

    private <T> T read(Class<? extends T> class_, InputNode inputNode, Session session) throws Exception {
        return (T)this.read((T)class_, inputNode, (Context)new Source(this.strategy, this.support, session));
    }

    private <T> T read(T t, InputNode inputNode, Context context) throws Exception {
        return (T)new Traverser(context).read(inputNode, t);
    }

    private <T> T read(T t, InputNode inputNode, Session session) throws Exception {
        return this.read(t, inputNode, (Context)new Source(this.strategy, this.support, session));
    }

    private boolean validate(Class class_, InputNode inputNode, Context context) throws Exception {
        return new Traverser(context).validate(inputNode, class_);
    }

    private boolean validate(Class class_, InputNode inputNode, Session session) throws Exception {
        return this.validate(class_, inputNode, new Source(this.strategy, this.support, session));
    }

    private void write(Object object, OutputNode outputNode, Context context) throws Exception {
        new Traverser(context).write(outputNode, object);
    }

    private void write(Object object, OutputNode outputNode, Session session) throws Exception {
        this.write(object, outputNode, new Source(this.strategy, this.support, session));
    }

    public <T> T read(Class<? extends T> class_, File file) throws Exception {
        return (T)this.read((T)class_, file, true);
    }

    public <T> T read(Class<? extends T> class_, File file, boolean bl) throws Exception {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            Class<? extends T> class_2 = this.read((T)class_, (InputStream)fileInputStream, bl);
            return (T)class_2;
        }
        finally {
            fileInputStream.close();
        }
    }

    public <T> T read(Class<? extends T> class_, InputStream inputStream) throws Exception {
        return (T)this.read((T)class_, inputStream, true);
    }

    public <T> T read(Class<? extends T> class_, InputStream inputStream, boolean bl) throws Exception {
        return (T)this.read((T)class_, NodeBuilder.read((InputStream)inputStream), bl);
    }

    public <T> T read(Class<? extends T> class_, Reader reader) throws Exception {
        return (T)this.read((T)class_, reader, true);
    }

    public <T> T read(Class<? extends T> class_, Reader reader, boolean bl) throws Exception {
        return (T)this.read((T)class_, NodeBuilder.read((Reader)reader), bl);
    }

    public <T> T read(Class<? extends T> class_, String string2) throws Exception {
        return (T)this.read((T)class_, string2, true);
    }

    public <T> T read(Class<? extends T> class_, String string2, boolean bl) throws Exception {
        return (T)this.read((T)class_, (Reader)new StringReader(string2), bl);
    }

    public <T> T read(Class<? extends T> class_, InputNode inputNode) throws Exception {
        return (T)this.read((T)class_, inputNode, true);
    }

    public <T> T read(Class<? extends T> class_, InputNode inputNode, boolean bl) throws Exception {
        Session session = this.manager.open(bl);
        try {
            Class<? extends T> class_2 = this.read((T)class_, inputNode, session);
            return (T)class_2;
        }
        finally {
            this.manager.close();
        }
    }

    public <T> T read(T t, File file) throws Exception {
        return this.read(t, file, true);
    }

    public <T> T read(T t, File file, boolean bl) throws Exception {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            T t2 = this.read(t, (InputStream)fileInputStream, bl);
            return t2;
        }
        finally {
            fileInputStream.close();
        }
    }

    public <T> T read(T t, InputStream inputStream) throws Exception {
        return this.read(t, inputStream, true);
    }

    public <T> T read(T t, InputStream inputStream, boolean bl) throws Exception {
        return this.read(t, NodeBuilder.read((InputStream)inputStream), bl);
    }

    public <T> T read(T t, Reader reader) throws Exception {
        return this.read(t, reader, true);
    }

    public <T> T read(T t, Reader reader, boolean bl) throws Exception {
        return this.read(t, NodeBuilder.read((Reader)reader), bl);
    }

    public <T> T read(T t, String string2) throws Exception {
        return this.read(t, string2, true);
    }

    public <T> T read(T t, String string2, boolean bl) throws Exception {
        return this.read(t, (Reader)new StringReader(string2), bl);
    }

    public <T> T read(T t, InputNode inputNode) throws Exception {
        return this.read(t, inputNode, true);
    }

    public <T> T read(T t, InputNode inputNode, boolean bl) throws Exception {
        Session session = this.manager.open(bl);
        try {
            T t2 = this.read(t, inputNode, session);
            return t2;
        }
        finally {
            this.manager.close();
        }
    }

    public boolean validate(Class class_, File file) throws Exception {
        return this.validate(class_, file, true);
    }

    public boolean validate(Class class_, File file, boolean bl) throws Exception {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            boolean bl2 = this.validate(class_, (InputStream)fileInputStream, bl);
            return bl2;
        }
        finally {
            fileInputStream.close();
        }
    }

    public boolean validate(Class class_, InputStream inputStream) throws Exception {
        return this.validate(class_, inputStream, true);
    }

    public boolean validate(Class class_, InputStream inputStream, boolean bl) throws Exception {
        return this.validate(class_, NodeBuilder.read((InputStream)inputStream), bl);
    }

    public boolean validate(Class class_, Reader reader) throws Exception {
        return this.validate(class_, reader, true);
    }

    public boolean validate(Class class_, Reader reader, boolean bl) throws Exception {
        return this.validate(class_, NodeBuilder.read((Reader)reader), bl);
    }

    public boolean validate(Class class_, String string2) throws Exception {
        return this.validate(class_, string2, true);
    }

    public boolean validate(Class class_, String string2, boolean bl) throws Exception {
        return this.validate(class_, (Reader)new StringReader(string2), bl);
    }

    public boolean validate(Class class_, InputNode inputNode) throws Exception {
        return this.validate(class_, inputNode, true);
    }

    public boolean validate(Class class_, InputNode inputNode, boolean bl) throws Exception {
        Session session = this.manager.open(bl);
        try {
            boolean bl2 = this.validate(class_, inputNode, session);
            return bl2;
        }
        finally {
            this.manager.close();
        }
    }

    public void write(Object object, File file) throws Exception {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        try {
            this.write(object, (OutputStream)fileOutputStream);
            return;
        }
        finally {
            fileOutputStream.close();
        }
    }

    public void write(Object object, OutputStream outputStream) throws Exception {
        this.write(object, outputStream, "utf-8");
    }

    public void write(Object object, OutputStream outputStream, String string2) throws Exception {
        this.write(object, (Writer)new OutputStreamWriter(outputStream, string2));
    }

    public void write(Object object, Writer writer) throws Exception {
        this.write(object, NodeBuilder.write((Writer)writer, (Format)this.format));
    }

    public void write(Object object, OutputNode outputNode) throws Exception {
        Session session = this.manager.open();
        try {
            this.write(object, outputNode, session);
            return;
        }
        finally {
            this.manager.close();
        }
    }
}

