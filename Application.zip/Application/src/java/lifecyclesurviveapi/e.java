/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  d.g
 *  d.l.i
 *  j.a.c
 *  java.lang.Object
 *  lifecyclesurviveapi.d
 *  lifecyclesurviveapi.g
 *  lifecyclesurviveapi.r.a
 *  lifecyclesurviveapi.r.b
 *  lifecyclesurviveapi.r.c
 */
package lifecyclesurviveapi;

import d.l.i;
import lifecyclesurviveapi.d;
import lifecyclesurviveapi.g;
import lifecyclesurviveapi.r.a;
import lifecyclesurviveapi.r.b;
import lifecyclesurviveapi.r.c;

public final class e<T>
implements d.g<d<T>> {
    private final j.a.c<c> c;
    private final j.a.c<a> d;
    private final j.a.c<b> f;

    public e(j.a.c<c> c2, j.a.c<a> c3, j.a.c<b> c4) {
        this.c = c2;
        this.d = c3;
        this.f = c4;
    }

    public static <T> d.g<d<T>> a(j.a.c<c> c2, j.a.c<a> c3, j.a.c<b> c4) {
        return new e<T>(c2, c3, c4);
    }

    @i(value="lifecyclesurviveapi.AuthorizedPresenter.mAccountStorageWrapper")
    public static <T> void a(d<T> d2, a a2) {
        d2.mAccountStorageWrapper = a2;
    }

    @i(value="lifecyclesurviveapi.AuthorizedPresenter.mAuthenticatedApplicationWrapper")
    public static <T> void a(d<T> d2, b b2) {
        d2.mAuthenticatedApplicationWrapper = b2;
    }

    public void a(d<T> d2) {
        g.a(d2, (c)((c)this.c.get()));
        e.a(d2, (a)this.d.get());
        e.a(d2, (b)this.f.get());
    }
}

