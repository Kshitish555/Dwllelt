/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 *  org.simpleframework.xml.core.Creator
 *  org.simpleframework.xml.core.Criteria
 *  org.simpleframework.xml.core.Parameter
 *  org.simpleframework.xml.core.Signature
 */
package org.simpleframework.xml.core;

import java.util.Iterator;
import java.util.List;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Creator;
import org.simpleframework.xml.core.Criteria;
import org.simpleframework.xml.core.Parameter;
import org.simpleframework.xml.core.Signature;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.core.Variable;

class SignatureCreator
implements Creator {
    private final List<Parameter> list;
    private final Signature signature;
    private final Class type;

    public SignatureCreator(Signature signature) {
        this.type = signature.getType();
        this.list = signature.getAll();
        this.signature = signature;
    }

    private double getAdjustment(double d) {
        double d2 = this.list.size();
        Double.isNaN((double)d2);
        double d3 = d2 / 1000.0;
        if (d > 0.0) {
            double d4 = this.list.size();
            Double.isNaN((double)d4);
            return d3 + d / d4;
        }
        double d5 = this.list.size();
        Double.isNaN((double)d5);
        return d / d5;
    }

    private double getPercentage(Criteria criteria) throws Exception {
        Iterator iterator = this.list.iterator();
        double d = 0.0;
        while (iterator.hasNext()) {
            Parameter parameter = (Parameter)iterator.next();
            if (criteria.get(parameter.getKey()) == null) {
                if (parameter.isRequired()) {
                    return -1.0;
                }
                if (!parameter.isPrimitive()) continue;
                return -1.0;
            }
            d += 1.0;
        }
        return this.getAdjustment(d);
    }

    private Object getVariable(Criteria criteria, int n) throws Exception {
        Variable variable = criteria.remove(((Parameter)this.list.get(n)).getKey());
        if (variable != null) {
            return variable.getValue();
        }
        return null;
    }

    public Object getInstance() throws Exception {
        return this.signature.create();
    }

    public Object getInstance(Criteria criteria) throws Exception {
        Object[] arrobject = this.list.toArray();
        for (int i = 0; i < this.list.size(); ++i) {
            arrobject[i] = this.getVariable(criteria, i);
        }
        return this.signature.create(arrobject);
    }

    public double getScore(Criteria criteria) throws Exception {
        Signature signature = this.signature.copy();
        for (Object object : criteria) {
            Parameter parameter = signature.get(object);
            Variable variable = criteria.get(object);
            Contact contact = variable.getContact();
            if (parameter != null && !Support.isAssignable(variable.getValue().getClass(), parameter.getType())) {
                return -1.0;
            }
            if (!contact.isReadOnly() || parameter != null) continue;
            return -1.0;
        }
        return this.getPercentage(criteria);
    }

    public Signature getSignature() {
        return this.signature;
    }

    public Class getType() {
        return this.type;
    }

    public String toString() {
        return this.signature.toString();
    }
}

