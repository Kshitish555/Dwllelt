/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.Throwable
 *  o.e.v.c
 *  o.e.y.d.e
 */
package org.mockito.internal.exceptions.d;

import java.io.Serializable;
import o.e.v.c;
import o.e.y.d.e;
import org.mockito.internal.exceptions.d.d;

public class a
implements Serializable {
    private static final long f = -8085849703510292641L;
    private final c c = new e();
    private final d d = new d();

    public void a(Throwable throwable) {
        if (!this.c.b()) {
            return;
        }
        throwable.setStackTrace(this.d.a(throwable.getStackTrace(), true));
    }
}

