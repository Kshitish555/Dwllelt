/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package h.b;

public final class a
extends Enum<a> {
    public static final /* enum */ a c;
    public static final /* enum */ a d;
    public static final /* enum */ a f;
    private static final /* synthetic */ a[] h;

    static {
        a a2;
        c = new a();
        d = new a();
        f = a2 = new a();
        a[] arra = new a[]{c, d, a2};
        h = arra;
    }

    public static a valueOf(String string) {
        return (a)Enum.valueOf(a.class, (String)string);
    }

    public static a[] values() {
        return (a[])h.clone();
    }
}

