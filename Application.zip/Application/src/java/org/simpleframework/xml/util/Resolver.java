/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.AbstractSet
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  org.simpleframework.xml.util.Resolver$Cache
 */
package org.simpleframework.xml.util;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.simpleframework.xml.util.Match;
import org.simpleframework.xml.util.Resolver;

/*
 * Exception performing whole class analysis.
 */
public class Resolver<M extends Match>
extends AbstractSet<M> {
    protected final Resolver<M> cache;
    protected final Resolver<M> stack;

    public Resolver() {
        this.stack = new Stack();
        this.cache = new /* Unavailable Anonymous Inner Class!! */;
    }

    private boolean match(char[] arrc, int n, char[] arrc2, int n2) {
        while (n2 < arrc2.length && n < arrc.length) {
            if (arrc2[n2] == '*') {
                while (arrc2[n2] == '*') {
                    if (++n2 < arrc2.length) continue;
                    return true;
                }
                if (arrc2[n2] == '?' && ++n2 >= arrc2.length) {
                    return true;
                }
                while (n < arrc.length) {
                    if (arrc[n] == arrc2[n2] || arrc2[n2] == '?') {
                        if (arrc2[n2 - 1] == '?') break;
                        if (this.match(arrc, n, arrc2, n2)) {
                            return true;
                        }
                    }
                    ++n;
                }
                if (arrc.length == n) {
                    return false;
                }
            }
            int n3 = n + 1;
            char c2 = arrc[n];
            int n4 = n2 + 1;
            if (c2 != arrc2[n2] && arrc2[n4 - 1] != '?') {
                return false;
            }
            n = n3;
            n2 = n4;
        }
        if (arrc2.length == n2) {
            int n5 = arrc.length;
            boolean bl = false;
            if (n5 == n) {
                bl = true;
            }
            return bl;
        }
        while (arrc2[n2] == '*') {
            if (++n2 < arrc2.length) continue;
            return true;
        }
        return false;
    }

    private boolean match(char[] arrc, char[] arrc2) {
        return this.match(arrc, 0, arrc2, 0);
    }

    private List<M> resolveAll(String string, char[] arrc) {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.stack.iterator();
        while (iterator.hasNext()) {
            Match match = (Match)iterator.next();
            if (!this.match(arrc, match.getPattern().toCharArray())) continue;
            this.cache.put((Object)string, (Object)arrayList);
            arrayList.add((Object)match);
        }
        return arrayList;
    }

    public boolean add(M m) {
        ((Stack)((Object)this.stack)).push(m);
        return true;
    }

    public void clear() {
        this.cache.clear();
        this.stack.clear();
    }

    public Iterator<M> iterator() {
        return ((Stack)((Object)this.stack)).sequence();
    }

    public boolean remove(M m) {
        this.cache.clear();
        return this.stack.remove(m);
    }

    public M resolve(String string) {
        List<M> list = (List<M>)this.cache.get((Object)string);
        if (list == null) {
            list = this.resolveAll(string);
        }
        if (list.isEmpty()) {
            return null;
        }
        return (M)((Match)list.get(0));
    }

    public List<M> resolveAll(String string) {
        List list = (List)this.cache.get((Object)string);
        if (list != null) {
            return list;
        }
        char[] arrc = string.toCharArray();
        if (arrc == null) {
            return null;
        }
        return this.resolveAll(string, arrc);
    }

    public int size() {
        return this.stack.size();
    }

    private class Stack
    extends LinkedList<M> {
        private Stack() {
        }

        public void purge(int n) {
            Resolver.this.cache.clear();
            this.remove(n);
        }

        public void push(M m) {
            Resolver.this.cache.clear();
            this.addFirst(m);
        }

        public Iterator<M> sequence() {
            return new Sequence();
        }

        private class Sequence
        implements Iterator<M> {
            private int cursor;

            public Sequence() {
                this.cursor = Stack.this.size();
            }

            public boolean hasNext() {
                return this.cursor > 0;
            }

            public M next() {
                if (this.hasNext()) {
                    int n;
                    Stack stack = Stack.this;
                    this.cursor = n = -1 + this.cursor;
                    return (M)((Match)stack.get(n));
                }
                return null;
            }

            public void remove() {
                Stack.this.purge(this.cursor);
            }
        }

    }

}

