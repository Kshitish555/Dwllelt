/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.osmdroid.util.constants.UtilConstants
 */
package org.osmdroid.util;

import org.osmdroid.util.constants.UtilConstants;

public class NetworkLocationIgnorer
implements UtilConstants {
    private long mLastGps = 0L;

    public boolean shouldIgnore(String string2, long l) {
        if ("gps".equals((Object)string2)) {
            this.mLastGps = l;
        } else if (l < 20000L + this.mLastGps) {
            return true;
        }
        return false;
    }
}

