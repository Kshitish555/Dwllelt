/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.TreeMap
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Factory
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.strategy.Value
 */
package org.simpleframework.xml.core;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.ConversionInstance;
import org.simpleframework.xml.core.Factory;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.InstantiationException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.stream.InputNode;

class MapFactory
extends Factory {
    public MapFactory(Context context, Type type) {
        super(context, type);
    }

    private boolean isMap(Class class_) {
        return Map.class.isAssignableFrom(class_);
    }

    public Class getConversion(Class class_) throws Exception {
        if (class_.isAssignableFrom(HashMap.class)) {
            return HashMap.class;
        }
        if (class_.isAssignableFrom(TreeMap.class)) {
            return TreeMap.class;
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Cannot instantiate %s for %s", arrobject);
    }

    public Object getInstance() throws Exception {
        Class class_ = this.getType();
        Class class_2 = !Factory.isInstantiable((Class)class_) ? this.getConversion(class_) : class_;
        if (this.isMap(class_2)) {
            return class_2.newInstance();
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Invalid map %s for %s", arrobject);
    }

    public Instance getInstance(Value value) throws Exception {
        Class class_ = value.getType();
        if (!Factory.isInstantiable((Class)class_)) {
            class_ = this.getConversion(class_);
        }
        if (this.isMap(class_)) {
            return new ConversionInstance(this.context, value, class_);
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Invalid map %s for %s", arrobject);
    }

    public Instance getInstance(InputNode inputNode) throws Exception {
        Value value = this.getOverride(inputNode);
        Class class_ = this.getType();
        if (value != null) {
            return this.getInstance(value);
        }
        if (!Factory.isInstantiable((Class)class_)) {
            class_ = this.getConversion(class_);
        }
        if (this.isMap(class_)) {
            return this.context.getInstance(class_);
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Invalid map %s for %s", arrobject);
    }
}

