/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  l.a.h.h.a
 *  l.a.h.h.a$c
 *  l.a.h.i.a
 *  l.a.h.i.a$c
 *  l.a.h.i.a$d
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.l.a
 *  l.a.j.q.l.c
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import l.a.h.h.a;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.k.l;
import l.a.j.q.l.c;
import l.a.k.a.r;

public class d
implements e {
    private final a.c c;

    public d(a.c c2) {
        this.c = c2;
    }

    public e.c a(r r2, e.d d2) {
        try {
            e[] arre = new e[]{l.a.j.q.k.a.c(this.c.e()), new l(this.c.d()), c.a((a.d)new a.c(Class.class.getMethod("getDeclaredField", new Class[]{String.class})))};
            e.c c2 = new e.a(arre).a(r2, d2);
            return c2;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new IllegalStateException("Cannot locate Class::getDeclaredField", (Throwable)noSuchMethodException);
        }
    }

    protected boolean b(Object object) {
        return object instanceof d;
    }

    public e cached() {
        return new a(this);
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof d)) {
            return false;
        }
        d d2 = (d)object;
        if (!d2.b(this)) {
            return false;
        }
        a.c c2 = this.c;
        a.c c3 = d2.c;
        return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
    }

    public int hashCode() {
        a.c c2 = this.c;
        int n2 = c2 == null ? 43 : c2.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }

    protected static class a
    implements e {
        private final e c;

        public a(e e2) {
            this.c = e2;
        }

        public e.c a(r r2, e.d d2) {
            return l.a.j.q.l.a.a((a.c)d2.a(this.c, (l.a.h.k.c)new c.d(Field.class))).read().a(r2, d2);
        }

        protected boolean b(Object object) {
            return object instanceof a;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof a)) {
                return false;
            }
            a a2 = (a)object;
            if (!a2.b(this)) {
                return false;
            }
            e e2 = this.c;
            e e3 = a2.c;
            return !(e2 == null ? e3 != null : !e2.equals((Object)e3));
        }

        public int hashCode() {
            e e2 = this.c;
            int n2 = e2 == null ? 43 : e2.hashCode();
            return 59 + n2;
        }

        public boolean x() {
            return this.c.x();
        }
    }

}

