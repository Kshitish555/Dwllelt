/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Looper
 *  android.os.Parcel
 *  android.os.RemoteException
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.InterruptedException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.LinkedBlockingQueue
 */
package com.adjust.sdk;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;

public class GooglePlayServicesClient {
    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static GooglePlayServicesInfo getGooglePlayServicesInfo(Context context) throws Exception {
        Throwable throwable2222;
        if (Looper.myLooper() == Looper.getMainLooper()) throw new IllegalStateException("Google Play Services info can't be accessed from the main thread");
        context.getPackageManager().getPackageInfo("com.android.vending", 0);
        b b2 = new b();
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        if (!context.bindService(intent, (ServiceConnection)b2, 1)) throw new IOException("Google Play connection failed");
        c c2 = new c(b2.a());
        GooglePlayServicesInfo googlePlayServicesInfo = new GooglePlayServicesInfo(c2.l0(), c2.k(true));
        context.unbindService((ServiceConnection)b2);
        return googlePlayServicesInfo;
        {
            catch (Throwable throwable2222) {
            }
            catch (Exception exception) {}
            {
                throw exception;
            }
        }
        context.unbindService((ServiceConnection)b2);
        throw throwable2222;
    }

    public static final class GooglePlayServicesInfo {
        private final String gpsAdid;
        private final Boolean trackingEnabled;

        GooglePlayServicesInfo(String string, Boolean bl) {
            this.gpsAdid = string;
            this.trackingEnabled = bl;
        }

        public String getGpsAdid() {
            return this.gpsAdid;
        }

        public Boolean isTrackingEnabled() {
            return this.trackingEnabled;
        }
    }

    private static final class b
    implements ServiceConnection {
        boolean b = false;
        private final LinkedBlockingQueue<IBinder> c = new LinkedBlockingQueue(1);

        private b() {
        }

        public IBinder a() throws InterruptedException {
            if (!this.b) {
                this.b = true;
                return (IBinder)this.c.take();
            }
            throw new IllegalStateException();
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            try {
                this.c.put((Object)iBinder);
            }
            catch (InterruptedException interruptedException) {}
        }

        public void onServiceDisconnected(ComponentName componentName) {
        }
    }

    private static final class c
    implements IInterface {
        private IBinder c;

        public c(IBinder iBinder) {
            this.c = iBinder;
        }

        public IBinder asBinder() {
            return this.c;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public Boolean k(boolean bl) throws RemoteException {
            Parcel parcel;
            Parcel parcel2;
            block4 : {
                parcel = Parcel.obtain();
                parcel2 = Parcel.obtain();
                parcel.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                int n2 = bl ? 1 : 0;
                parcel.writeInt(n2);
                this.c.transact(2, parcel, parcel2, 0);
                parcel2.readException();
                int n3 = parcel2.readInt();
                boolean bl2 = false;
                if (n3 != 0) {
                    bl2 = true;
                }
                Boolean bl3 = bl2;
                if (bl3 == null) break block4;
                return true ^ bl3;
            }
            return null;
            finally {
                parcel2.recycle();
                parcel.recycle();
            }
        }

        public String l0() throws RemoteException {
            Parcel parcel = Parcel.obtain();
            Parcel parcel2 = Parcel.obtain();
            try {
                parcel.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                this.c.transact(1, parcel, parcel2, 0);
                parcel2.readException();
                String string = parcel2.readString();
                return string;
            }
            finally {
                parcel2.recycle();
                parcel.recycle();
            }
        }
    }

}

