/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.OutputStream
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  l.a.h.i.a
 *  l.a.h.i.a$b
 *  l.a.h.i.a$c
 *  l.a.h.i.a$d
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.l.c
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.j.e;
import l.a.j.q.c;
import l.a.j.q.e;
import l.a.j.q.h;
import l.a.j.q.k.j;
import l.a.j.q.k.l;
import l.a.k.a.r;

public class k
implements e {
    private static final String d = "ISO-8859-1";
    private final String c;

    protected k(String string) {
        this.c = string;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static e a(Serializable serializable) {
        ByteArrayOutputStream byteArrayOutputStream;
        ObjectOutputStream objectOutputStream;
        if (serializable == null) {
            return j.d;
        }
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            objectOutputStream = new ObjectOutputStream((OutputStream)byteArrayOutputStream);
        }
        catch (IOException iOException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot serialize ");
            stringBuilder.append((Object)serializable);
            throw new IllegalStateException(stringBuilder.toString(), (Throwable)iOException);
        }
        objectOutputStream.writeObject((Object)serializable);
        {
            catch (Throwable throwable) {
                objectOutputStream.close();
                throw throwable;
            }
        }
        objectOutputStream.close();
        return new k(byteArrayOutputStream.toString(d));
    }

    public e.c a(r r2, e.d d2) {
        try {
            e[] arre = new e[]{h.c((l.a.h.k.c)new c.d(ObjectInputStream.class)), c.h, h.c((l.a.h.k.c)new c.d(ByteArrayInputStream.class)), c.h, new l(this.c), new l(d), l.a.j.q.l.c.a((a.d)new a.c(String.class.getMethod("getBytes", new Class[]{String.class}))), l.a.j.q.l.c.a((a.d)new a.b(ByteArrayInputStream.class.getConstructor(new Class[]{byte[].class}))), l.a.j.q.l.c.a((a.d)new a.b(ObjectInputStream.class.getConstructor(new Class[]{InputStream.class}))), l.a.j.q.l.c.a((a.d)new a.c(ObjectInputStream.class.getMethod("readObject", new Class[0])))};
            e.c c2 = new e.a(arre).a(r2, d2);
            return c2;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new IllegalStateException("Could not locate Java API method", (Throwable)noSuchMethodException);
        }
    }

    protected boolean b(Object object) {
        return object instanceof k;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof k)) {
            return false;
        }
        k k2 = (k)object;
        if (!k2.b(this)) {
            return false;
        }
        String string = this.c;
        String string2 = k2.c;
        return !(string == null ? string2 != null : !string.equals((Object)string2));
    }

    public int hashCode() {
        String string = this.c;
        int n2 = string == null ? 43 : string.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }
}

