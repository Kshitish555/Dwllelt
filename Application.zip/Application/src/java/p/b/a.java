/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.b0
 *  h.b.w0.g
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.i2.t.i0
 *  kotlin.i2.t.v
 *  o.c.a.d
 *  o.c.a.e
 *  profile.dto.EmailDto
 *  profile.dto.IdentificationItem
 *  profile.dto.NicknameResponseDto
 *  profile.dto.PriorityPackageDto
 *  profile.dto.SmsNotificationDto
 *  profile.dto.SmsNotificationUpdateDto
 *  rx.Observable
 *  rx.functions.Action1
 */
package p.b;

import g.a.a.a.k;
import h.b.b0;
import java.util.List;
import kotlin.Metadata;
import kotlin.i2.t.i0;
import kotlin.i2.t.v;
import p.b.a;
import profile.dto.EmailDto;
import profile.dto.IdentificationItem;
import profile.dto.NicknameResponseDto;
import profile.dto.PriorityPackageDto;
import profile.dto.SmsNotificationDto;
import profile.dto.SmsNotificationUpdateDto;
import rx.Observable;
import rx.functions.Action1;

/*
 * Exception performing whole class analysis.
 */
@Metadata(bv={1, 0, 3}, d1={"\u0000V\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0016\u0018\u00002\u00020\u0001:\u0001\u001bB\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\n\u0010\t\u001a\u0004\u0018\u00010\nH\u0016J\b\u0010\u000b\u001a\u0004\u0018\u00010\fJ\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u000eJ\u0014\u0010\u000f\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u00100\u000eJ\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u000eJ\u000e\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00150\u000eH\u0016J\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00170\u000eJ\u0014\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00170\u000e2\u0006\u0010\u0019\u001a\u00020\u001aR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001c"}, d2={"Lprofile/model/ProfileModel;", "", "api", "Lprofile/api/ProfileApi;", "cache", "Lprofile/model/WalletUserCache;", "(Lprofile/api/ProfileApi;Lprofile/model/WalletUserCache;)V", "cachedModel", "Lprofile/model/ProfileModel$Cache;", "accountName", "", "getCachedEmail", "Lprofile/dto/EmailDto;", "getEmail", "Lio/reactivex/Observable;", "getIdentificationStatus", "", "Lprofile/dto/IdentificationItem;", "getNickname", "Lprofile/dto/NicknameResponseDto;", "getPriority", "Lprofile/dto/PriorityPackageDto;", "getSmsSettings", "Lprofile/dto/SmsNotificationDto;", "updateSmsSettings", "enable", "", "Cache", "profile_release"}, k=1, mv={1, 1, 15})
public class a {
    private final a a;
    private final p.a.b b;
    private final p.b.b c;

    public a(@o.c.a.d p.a.b b2, @o.c.a.d p.b.b b3) {
        i0.f((Object)b2, (String)"api");
        i0.f((Object)b3, (String)"cache");
        this.b = b2;
        this.c = b3;
        this.a = new a();
    }

    public static final /* synthetic */ p.b.b a(a a2) {
        return a2.c;
    }

    public static final /* synthetic */ a b(a a2) {
        return a2.a;
    }

    @o.c.a.d
    public final b0<SmsNotificationDto> a(boolean bl) {
        b0 b02 = this.b.a(this.a(), new SmsNotificationUpdateDto(bl, null, 2, null)).f(}
    java.lang.IllegalStateException: Inner class got unexpected class file - revert this change
    
    