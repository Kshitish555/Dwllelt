/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import org.simpleframework.xml.core.AnnotationFactory;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.GetPart;
import org.simpleframework.xml.core.MethodException;
import org.simpleframework.xml.core.MethodName;
import org.simpleframework.xml.core.MethodPart;
import org.simpleframework.xml.core.MethodType;
import org.simpleframework.xml.core.Reflector;
import org.simpleframework.xml.core.SetPart;
import org.simpleframework.xml.core.Support;

class MethodPartFactory {
    private final AnnotationFactory factory;

    public MethodPartFactory(Detail detail, Support support) {
        this.factory = new AnnotationFactory(detail, support);
    }

    private Annotation getAnnotation(Method method) throws Exception {
        Class[] arrclass = this.getDependents(method);
        Class class_ = this.getType(method);
        if (class_ != null) {
            return this.factory.getInstance(class_, arrclass);
        }
        return null;
    }

    private Class[] getDependents(Method method) throws Exception {
        MethodType methodType = this.getMethodType(method);
        if (methodType == MethodType.SET) {
            return Reflector.getParameterDependents(method, 0);
        }
        if (methodType == MethodType.GET) {
            return Reflector.getReturnDependents(method);
        }
        if (methodType == MethodType.IS) {
            return Reflector.getReturnDependents(method);
        }
        return null;
    }

    private MethodType getMethodType(Method method) {
        String string2 = method.getName();
        if (string2.startsWith("get")) {
            return MethodType.GET;
        }
        if (string2.startsWith("is")) {
            return MethodType.IS;
        }
        if (string2.startsWith("set")) {
            return MethodType.SET;
        }
        return MethodType.NONE;
    }

    private MethodName getName(Method method, Annotation annotation) throws Exception {
        MethodType methodType = this.getMethodType(method);
        if (methodType == MethodType.GET) {
            return this.getRead(method, methodType);
        }
        if (methodType == MethodType.IS) {
            return this.getRead(method, methodType);
        }
        if (methodType == MethodType.SET) {
            return this.getWrite(method, methodType);
        }
        throw new MethodException("Annotation %s must mark a set or get method", new Object[]{annotation});
    }

    private Class getParameterType(Method method) throws Exception {
        if (method.getParameterTypes().length == 1) {
            return method.getParameterTypes()[0];
        }
        return null;
    }

    private MethodName getRead(Method method, MethodType methodType) throws Exception {
        Class[] arrclass = method.getParameterTypes();
        String string2 = method.getName();
        if (arrclass.length == 0) {
            String string3 = this.getTypeName(string2, methodType);
            if (string3 != null) {
                return new MethodName(method, methodType, string3);
            }
            throw new MethodException("Could not get name for %s", new Object[]{method});
        }
        throw new MethodException("Get method %s is not a valid property", new Object[]{method});
    }

    private Class getReturnType(Method method) throws Exception {
        if (method.getParameterTypes().length == 0) {
            return method.getReturnType();
        }
        return null;
    }

    private String getTypeName(String string2, MethodType methodType) {
        int n2 = methodType.getPrefix();
        int n3 = string2.length();
        if (n3 > n2) {
            string2 = string2.substring(n2, n3);
        }
        return Reflector.getName(string2);
    }

    private MethodName getWrite(Method method, MethodType methodType) throws Exception {
        Class[] arrclass = method.getParameterTypes();
        String string2 = method.getName();
        if (arrclass.length == 1) {
            String string3 = this.getTypeName(string2, methodType);
            if (string3 != null) {
                return new MethodName(method, methodType, string3);
            }
            throw new MethodException("Could not get name for %s", new Object[]{method});
        }
        throw new MethodException("Set method %s is not a valid property", new Object[]{method});
    }

    public MethodPart getInstance(Method method, Annotation annotation, Annotation[] arrannotation) throws Exception {
        MethodName methodName = this.getName(method, annotation);
        if (methodName.getType() == MethodType.SET) {
            return new SetPart(methodName, annotation, arrannotation);
        }
        return new GetPart(methodName, annotation, arrannotation);
    }

    public MethodPart getInstance(Method method, Annotation[] arrannotation) throws Exception {
        Annotation annotation = this.getAnnotation(method);
        if (annotation != null) {
            return this.getInstance(method, annotation, arrannotation);
        }
        return null;
    }

    public Class getType(Method method) throws Exception {
        MethodType methodType = this.getMethodType(method);
        if (methodType == MethodType.SET) {
            return this.getParameterType(method);
        }
        if (methodType == MethodType.GET) {
            return this.getReturnType(method);
        }
        if (methodType == MethodType.IS) {
            return this.getReturnType(method);
        }
        return null;
    }
}

