/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.v
 *  h.a.a.w$a
 *  java.lang.FunctionalInterface
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package h.a.a;

import h.a.a.v;
import h.a.a.w;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class w
extends ArrayList<v> {
    static final w c = new a();

    w() {
    }

    w(int n2) {
        super(n2);
    }

    w(Collection<v> collection) {
        super(collection);
    }

    public w a(b b2) {
        w w2 = new w();
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            v v2 = (v)iterator.next();
            if (!b2.a(v2)) continue;
            w2.add((Object)v2);
        }
        return w2;
    }

    public boolean a(String string) {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            if (!((v)iterator.next()).n().equals((Object)string)) continue;
            return true;
        }
        return false;
    }

    public List<String> b() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((v)iterator.next()).toString());
        }
        return arrayList;
    }

    public List<String> c() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((v)iterator.next()).n());
        }
        return arrayList;
    }

    public v get(String string) {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            v v2 = (v)iterator.next();
            if (!v2.n().equals((Object)string)) continue;
            return v2;
        }
        return null;
    }

    @FunctionalInterface
    public static interface b {
        public boolean a(v var1);
    }

}

