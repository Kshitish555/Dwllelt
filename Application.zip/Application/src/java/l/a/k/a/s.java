/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuffer
 *  l.a.k.a.a
 *  l.a.k.a.c
 *  l.a.k.a.d
 *  l.a.k.a.e
 *  l.a.k.a.j
 *  l.a.k.a.m
 *  l.a.k.a.n
 *  l.a.k.a.o
 *  l.a.k.a.p
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.u
 *  l.a.k.a.v
 */
package l.a.k.a;

import l.a.k.a.a;
import l.a.k.a.b;
import l.a.k.a.c;
import l.a.k.a.d;
import l.a.k.a.e;
import l.a.k.a.g;
import l.a.k.a.i;
import l.a.k.a.j;
import l.a.k.a.m;
import l.a.k.a.n;
import l.a.k.a.o;
import l.a.k.a.p;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.u;
import l.a.k.a.v;

class s
extends r {
    private int A5;
    private final int B5;
    private q C5;
    private q D5;
    private q E5;
    private int F5;
    private int G5;
    int P4;
    int Q4;
    int R4;
    int[] S4;
    private d T4;
    private b U4;
    private b V4;
    private b W4;
    private b X4;
    private b[] Y4;
    private b[] Z4;
    private int a5;
    private c b5;
    private d c5 = new d();
    private int d5;
    private int e5;
    final g f;
    private int f5;
    private int g5;
    private int h;
    private d h5;
    private int i5;
    private int[] j5;
    private int[] k5;
    private int l5;
    private o m5;
    private o n5;
    private final int o;
    private int o5;
    private d p5;
    private int q5;
    private d r5;
    private final int s;
    private int s5;
    private final String t;
    private d t5;
    private int u5;
    private d v5;
    String w;
    private int w5;
    private b x5;
    private b y5;
    private c z5;

    s(g g2, int n2, String string, String string2, String string3, String[] arrstring, int n3) {
        super(327680);
        if (g2.r5 == null) {
            g2.r5 = this;
        } else {
            g2.s5.d = this;
        }
        g2.s5 = this;
        this.f = g2;
        this.h = n2;
        if ("<init>".equals((Object)string)) {
            this.h = 524288 | this.h;
        }
        this.o = g2.e(string);
        this.s = g2.e(string2);
        this.t = string2;
        this.w = string3;
        if (arrstring != null && arrstring.length > 0) {
            int n4;
            this.R4 = n4 = arrstring.length;
            this.S4 = new int[n4];
            for (int i2 = 0; i2 < this.R4; ++i2) {
                this.S4[i2] = g2.c(arrstring[i2]);
            }
        }
        this.B5 = n3;
        if (n3 != 3) {
            q q2;
            int n5 = u.b((String)this.t) >> 2;
            if ((n2 & 8) != 0) {
                --n5;
            }
            this.e5 = n5;
            this.f5 = n5;
            this.C5 = q2 = new q();
            q2.b = 8 | q2.b;
            this.a(q2);
        }
    }

    private int a(int n2, int n3, int n4) {
        int n5 = n4 + (n3 + 3);
        int[] arrn = this.k5;
        if (arrn == null || arrn.length < n5) {
            this.k5 = new int[n5];
        }
        int[] arrn2 = this.k5;
        arrn2[0] = n2;
        arrn2[1] = n3;
        arrn2[2] = n4;
        return 3;
    }

    private void a(m m2) {
        int[] arrn = m2.b;
        int[] arrn2 = m2.c;
        int n2 = 0;
        int n3 = 0;
        for (int i2 = 0; i2 < arrn.length; ++i2) {
            int n4 = arrn[i2];
            ++n3;
            if (n4 != 16777216) {
                n2 += n3;
                n3 = 0;
            }
            if (n4 != 16777220 && n4 != 16777219) continue;
            ++i2;
        }
        int n5 = 0;
        for (int i3 = 0; i3 < arrn2.length; ++i3) {
            int n6 = arrn2[i3];
            ++n5;
            if (n6 != 16777220 && n6 != 16777219) continue;
            ++i3;
        }
        int n7 = this.a(m2.a.d, n2, n5);
        int n8 = 0;
        do {
            if (n2 <= 0) break;
            int n9 = arrn[n8];
            int[] arrn3 = this.k5;
            int n10 = n7 + 1;
            arrn3[n7] = n9;
            if (n9 == 16777220 || n9 == 16777219) {
                ++n8;
            }
            ++n8;
            --n2;
            n7 = n10;
        } while (true);
        for (int i4 = 0; i4 < arrn2.length; ++i4) {
            int n11 = arrn2[i4];
            int[] arrn4 = this.k5;
            int n12 = n7 + 1;
            arrn4[n7] = n11;
            if (n11 == 16777220 || n11 == 16777219) {
                ++i4;
            }
            n7 = n12;
        }
        this.f();
    }

    private void a(q q2, q[] arrq) {
        q q3 = this.E5;
        if (q3 != null) {
            int n2 = this.B5;
            if (n2 == 0) {
                q3.i.a(171, 0, null, null);
                this.c(0, q2);
                q q4 = q2.a();
                q4.b = 16 | q4.b;
                for (int i2 = 0; i2 < arrq.length; ++i2) {
                    this.c(0, arrq[i2]);
                    q q5 = arrq[i2].a();
                    q5.b = 16 | q5.b;
                }
            } else {
                int n3;
                this.F5 = n3 = -1 + this.F5;
                this.c(n3, q2);
                for (int i3 = 0; i3 < arrq.length; ++i3) {
                    this.c(this.F5, arrq[i3]);
                }
            }
            this.h();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void b(Object object) {
        int n2;
        d d2;
        if (object instanceof String) {
            d2 = this.h5.a(7);
            n2 = this.f.c((String)object);
        } else {
            if (object instanceof Integer) {
                this.h5.a(((Integer)object).intValue());
                return;
            }
            d2 = this.h5.a(8);
            n2 = ((q)object).d;
        }
        d2.c(n2);
    }

    private void c(int n2, q q2) {
        j j2 = new j();
        j2.a = n2;
        j2.b = q2;
        q q3 = this.E5;
        j2.c = q3.k;
        q3.k = j2;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void e(int n2, int n3) {
        do {
            block20 : {
                d d2;
                int n4;
                block21 : {
                    int n5;
                    int n6;
                    int n7;
                    block17 : {
                        int n8;
                        block18 : {
                            block19 : {
                                if (n2 >= n3) {
                                    return;
                                }
                                n5 = this.k5[n2];
                                n6 = -268435456 & n5;
                                if (n6 != 0) break block17;
                                n8 = n5 & 1048575;
                                int n9 = n5 & 267386880;
                                if (n9 == 24117248) break block18;
                                if (n9 == 25165824) break block19;
                                this.h5.a(n8);
                                break block20;
                            }
                            d2 = this.h5.a(8);
                            n4 = this.f.T4[n8].c;
                            break block21;
                        }
                        d2 = this.h5.a(7);
                        g g2 = this.f;
                        n4 = g2.c(g2.T4[n8].e);
                        break block21;
                    }
                    StringBuffer stringBuffer = new StringBuffer();
                    int n10 = n6 >> 28;
                    do {
                        int n11 = n10 - 1;
                        if (n10 <= 0) break;
                        stringBuffer.append('[');
                        n10 = n11;
                    } while (true);
                    if ((n5 & 267386880) == 24117248) {
                        stringBuffer.append('L');
                        stringBuffer.append(this.f.T4[n5 & 1048575].e);
                        n7 = 59;
                    } else {
                        int n12 = n5 & 15;
                        if (n12 != 1) {
                            if (n12 != 2) {
                                if (n12 != 3) {
                                    switch (n12) {
                                        default: {
                                            n7 = 74;
                                            break;
                                        }
                                        case 12: {
                                            n7 = 83;
                                            break;
                                        }
                                        case 11: {
                                            n7 = 67;
                                            break;
                                        }
                                        case 10: {
                                            n7 = 66;
                                            break;
                                        }
                                        case 9: {
                                            n7 = 90;
                                            break;
                                        }
                                    }
                                } else {
                                    n7 = 68;
                                }
                            } else {
                                n7 = 70;
                            }
                        } else {
                            n7 = 73;
                        }
                    }
                    stringBuffer.append((char)n7);
                    d2 = this.h5.a(7);
                    n4 = this.f.c(stringBuffer.toString());
                }
                d2.c(n4);
            }
            ++n2;
        } while (true);
    }

    private void f() {
        if (this.j5 != null) {
            if (this.h5 == null) {
                this.h5 = new d();
            }
            this.g();
            this.g5 = 1 + this.g5;
        }
        this.j5 = this.k5;
        this.k5 = null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void g() {
        block21 : {
            block20 : {
                var1_1 = this.k5;
                var2_2 = var1_1[1];
                var3_3 = var1_1[2];
                var4_4 = 65535 & this.f.h;
                var5_5 = 0;
                if (var4_4 < 50) {
                    this.h5.c(var1_1[0]).c(var2_2);
                    var22_6 = var2_2 + 3;
                    this.e(3, var22_6);
                    this.h5.c(var3_3);
                    this.e(var22_6, var3_3 + var22_6);
                    return;
                }
                var6_7 = this.j5;
                var7_8 = var6_7[1];
                var8_9 = this.g5 == 0 ? var1_1[0] : var1_1[0] - var6_7[0] - 1;
                if (var3_3 != 0) break block20;
                var9_10 = var2_2 - var7_8;
                switch (var9_10) {
                    default: {
                        ** GOTO lbl42
                    }
                    case 1: 
                    case 2: 
                    case 3: {
                        var10_11 = 252;
                        ** break;
                    }
                    case 0: {
                        if (var8_9 < 64) {
                            var10_11 = 0;
                            ** break;
                        }
                        var10_11 = 251;
                        ** break;
                    }
                    case -3: 
                    case -2: 
                    case -1: {
                        var7_8 = var2_2;
                        var10_11 = 248;
                        ** break;
lbl34: // 4 sources:
                        break;
                    }
                }
                break block21;
            }
            if (var2_2 == var7_8 && var3_3 == 1) {
                var10_11 = var8_9 < 63 ? 64 : 247;
                var9_10 = 0;
            } else {
                var9_10 = 0;
lbl42: // 2 sources:
                var10_11 = 255;
            }
        }
        if (var10_11 != 255) {
            var20_12 = 3;
            while (var5_5 < var7_8) {
                if (this.k5[var20_12] != this.j5[var20_12]) {
                    var10_11 = 255;
                    break;
                }
                ++var20_12;
                ++var5_5;
            }
        }
        if (var10_11 == 0) {
            this.h5.a(var8_9);
            return;
        }
        if (var10_11 != 64) {
            if (var10_11 != 247) {
                if (var10_11 != 248) {
                    if (var10_11 != 251) {
                        if (var10_11 != 252) {
                            this.h5.a(255).c(var8_9).c(var2_2);
                            var18_13 = var2_2 + 3;
                            this.e(3, var18_13);
                            this.h5.c(var3_3);
                            this.e(var18_13, var3_3 + var18_13);
                            return;
                        }
                        this.h5.a(var9_10 + 251).c(var8_9);
                        this.e(var7_8 + 3, var2_2 + 3);
                        return;
                    }
                    var14_14 = this.h5.a(251);
                } else {
                    var14_14 = this.h5.a(var9_10 + 251);
                }
                var14_14.c(var8_9);
                return;
            }
            this.h5.a(247).c(var8_9);
        } else {
            this.h5.a(var8_9 + 64);
        }
        this.e(var2_2 + 3, var2_2 + 4);
    }

    private void h() {
        if (this.B5 == 0) {
            m m2;
            q q2 = new q();
            q2.i = m2 = new m();
            m2.a = q2;
            d d2 = this.c5;
            q2.a(this, d2.b, d2.a);
            this.D5.j = q2;
            this.D5 = q2;
        } else {
            this.E5.h = this.G5;
        }
        if (this.B5 != 1) {
            this.E5 = null;
        }
    }

    /*
     * Exception decompiling
     */
    private void i() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:478)
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:61)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:372)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public a a() {
        d d2;
        this.T4 = d2 = new d();
        b b2 = new b(this.f, false, d2, null, 0);
        return b2;
    }

    public a a(int n2, String string, boolean bl) {
        d d2 = new d();
        if ("Ljava/lang/Synthetic;".equals((Object)string)) {
            this.a5 = Math.max((int)this.a5, (int)(n2 + 1));
            b b2 = new b(this.f, false, d2, null, 0);
            return b2;
        }
        d2.c(this.f.e(string)).c(0);
        b b3 = new b(this.f, true, d2, d2, 2);
        if (bl) {
            if (this.Y4 == null) {
                this.Y4 = new b[u.a((String)this.t).length];
            }
            b[] arrb = this.Y4;
            b3.i = arrb[n2];
            arrb[n2] = b3;
            return b3;
        }
        if (this.Z4 == null) {
            this.Z4 = new b[u.a((String)this.t).length];
        }
        b[] arrb = this.Z4;
        b3.i = arrb[n2];
        arrb[n2] = b3;
        return b3;
    }

    public a a(int n2, v v2, String string, boolean bl) {
        d d2 = new d();
        b.a(n2 & -16776961 | this.w5 << 8, v2, d2);
        d2.c(this.f.e(string)).c(0);
        b b2 = new b(this.f, true, d2, d2, -2 + d2.b);
        if (bl) {
            b2.i = this.x5;
            this.x5 = b2;
            return b2;
        }
        b2.i = this.y5;
        this.y5 = b2;
        return b2;
    }

    public a a(int n2, v v2, q[] arrq, q[] arrq2, int[] arrn, String string, boolean bl) {
        d d2 = new d();
        d2.a(n2 >>> 24).c(arrq.length);
        for (int i2 = 0; i2 < arrq.length; ++i2) {
            d2.c(arrq[i2].d).c(arrq2[i2].d - arrq[i2].d).c(arrn[i2]);
        }
        if (v2 == null) {
            d2.a(0);
        } else {
            byte[] arrby = v2.a;
            int n3 = v2.b;
            d2.a(arrby, n3, 1 + 2 * arrby[n3]);
        }
        d2.c(this.f.e(string)).c(0);
        b b2 = new b(this.f, true, d2, d2, -2 + d2.b);
        if (bl) {
            b2.i = this.x5;
            this.x5 = b2;
            return b2;
        }
        b2.i = this.y5;
        this.y5 = b2;
        return b2;
    }

    public a a(String string, boolean bl) {
        d d2 = new d();
        d2.c(this.f.e(string)).c(0);
        b b2 = new b(this.f, true, d2, d2, 2);
        if (bl) {
            b2.i = this.U4;
            this.U4 = b2;
            return b2;
        }
        b2.i = this.V4;
        this.V4 = b2;
        return b2;
    }

    public void a(int n2) {
        d d2 = this.c5;
        this.w5 = d2.b;
        d2.a(n2);
        if (this.E5 != null) {
            int n3 = this.B5;
            if (n3 != 0 && n3 != 1) {
                int n4 = this.F5 + m.i[n2];
                if (n4 > this.G5) {
                    this.G5 = n4;
                }
                this.F5 = n4;
            } else {
                this.E5.i.a(n2, 0, null, null);
            }
            if (n2 >= 172 && n2 <= 177 || n2 == 191) {
                this.h();
            }
        }
    }

    public void a(int n2, int n3) {
        int n4;
        int n5;
        this.w5 = this.c5.b;
        if (this.E5 != null && ((n5 = this.B5) == 0 || n5 == 1)) {
            this.E5.i.a(132, n2, null, null);
        }
        if (this.B5 != 3 && (n4 = n2 + 1) > this.e5) {
            this.e5 = n4;
        }
        if (n2 <= 255 && n3 <= 127 && n3 >= -128) {
            this.c5.a(132).a(n2, n3);
            return;
        }
        this.c5.a(196).b(132, n2).c(n3);
    }

    public /* varargs */ void a(int n2, int n3, q q2, q ... arrq) {
        int n4;
        d d2 = this.c5;
        this.w5 = n4 = d2.b;
        d2.a(170);
        d d3 = this.c5;
        int n5 = (4 - d3.b % 4) % 4;
        d3.a(null, 0, n5);
        q2.a(this, this.c5, n4, true);
        this.c5.b(n2).b(n3);
        for (int i2 = 0; i2 < arrq.length; ++i2) {
            arrq[i2].a(this, this.c5, n4, true);
        }
        this.a(q2, arrq);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(int var1_1, int var2_2, Object[] var3_3, int var4_4, Object[] var5_5) {
        block23 : {
            block24 : {
                block29 : {
                    block25 : {
                        block26 : {
                            block30 : {
                                block27 : {
                                    block28 : {
                                        block22 : {
                                            var6_6 = this.B5;
                                            if (var6_6 == 0) {
                                                return;
                                            }
                                            if (var6_6 != 1) break block22;
                                            var32_7 = this.E5;
                                            var33_8 = var32_7.i;
                                            if (var33_8 == null) {
                                                var32_7.i = new i();
                                                var34_9 = this.E5;
                                                var35_10 = var34_9.i;
                                                var35_10.a = var34_9;
                                                var35_10.a(this.f, this.h, u.a((String)this.t), var2_2);
                                                this.i();
                                            } else {
                                                if (var1_1 == -1) {
                                                    var33_8.a(this.f, var2_2, var3_3, var4_4, var5_5);
                                                }
                                                this.a(this.E5.i);
                                            }
                                            break block23;
                                        }
                                        var7_11 = 0;
                                        if (var1_1 == -1) break block24;
                                        if (this.h5 == null) {
                                            this.h5 = new d();
                                            var8_24 = this.c5.b;
                                        } else {
                                            var8_24 = this.c5.b - this.i5 - 1;
                                            if (var8_24 < 0) {
                                                if (var1_1 != 3) throw new IllegalStateException();
                                                return;
                                            }
                                        }
                                        if (var1_1 == 0) break block25;
                                        if (var1_1 == 1) break block26;
                                        var13_25 = 251;
                                        if (var1_1 == 2) break block27;
                                        if (var1_1 == 3) break block28;
                                        if (var1_1 == 4) {
                                            var17_26 = this.h5;
                                            if (var8_24 < 64) {
                                                var17_26.a(var8_24 + 64);
                                            } else {
                                                var17_26.a(247).c(var8_24);
                                            }
                                            this.b(var5_5[0]);
                                        }
                                        break block29;
                                    }
                                    var14_27 = this.h5;
                                    if (var8_24 >= 64) break block30;
                                    var14_27.a(var8_24);
                                    break block29;
                                }
                                this.f5 -= var2_2;
                                var14_27 = this.h5;
                                var13_25 -= var2_2;
                            }
                            var14_27.a(var13_25).c(var8_24);
                            break block29;
                        }
                        this.f5 = var2_2 + this.f5;
                        this.h5.a(var2_2 + 251).c(var8_24);
                        while (var7_11 < var2_2) {
                            this.b(var3_3[var7_11]);
                            ++var7_11;
                        }
                        break block29;
                    }
                    this.f5 = var2_2;
                    this.h5.a(255).c(var8_24).c(var2_2);
                    for (var10_28 = 0; var10_28 < var2_2; ++var10_28) {
                        this.b(var3_3[var10_28]);
                    }
                    this.h5.c(var4_4);
                    while (var7_11 < var4_4) {
                        this.b(var5_5[var7_11]);
                        ++var7_11;
                    }
                }
                this.i5 = this.c5.b;
                this.g5 = 1 + this.g5;
                break block23;
            }
            if (this.j5 == null) {
                this.i();
            }
            this.f5 = var2_2;
            var20_12 = this.a(this.c5.b, var2_2, var4_4);
            var21_13 = 0;
            do {
                block31 : {
                    if (var21_13 >= var2_2) break;
                    if (!(var3_3[var21_13] instanceof String)) break block31;
                    var31_19 = this.k5;
                    var30_18 = var20_12 + 1;
                    var31_19[var20_12] = 24117248 | this.f.b((String)var3_3[var21_13]);
                    ** GOTO lbl97
                }
                if (var3_3[var21_13] instanceof Integer) {
                    var29_17 = this.k5;
                    var30_18 = var20_12 + 1;
                    var29_17[var20_12] = (Integer)var3_3[var21_13];
lbl97: // 2 sources:
                    var20_12 = var30_18;
                } else {
                    var27_15 = this.k5;
                    var28_16 = var20_12 + 1;
                    var27_15[var20_12] = 25165824 | this.f.a("", ((q)var3_3[var21_13]).d);
                    var20_12 = var28_16;
                }
                ++var21_13;
            } while (true);
            for (var22_14 = 0; var22_14 < var4_4; ++var22_14) {
                if (var5_5[var22_14] instanceof String) {
                    var26_23 = this.k5;
                    var24_21 = var20_12 + 1;
                    var26_23[var20_12] = 24117248 | this.f.b((String)var5_5[var22_14]);
                } else if (var5_5[var22_14] instanceof Integer) {
                    var25_22 = this.k5;
                    var24_21 = var20_12 + 1;
                    var25_22[var20_12] = (Integer)var5_5[var22_14];
                } else {
                    var23_20 = this.k5;
                    var24_21 = var20_12 + 1;
                    var23_20[var20_12] = 25165824 | this.f.a("", ((q)var5_5[var22_14]).d);
                }
                var20_12 = var24_21;
            }
            this.f();
        }
        this.d5 = Math.max((int)this.d5, (int)var4_4);
        this.e5 = Math.max((int)this.e5, (int)this.f5);
    }

    public void a(int n2, String string) {
        this.w5 = this.c5.b;
        p p2 = this.f.a(string);
        if (this.E5 != null) {
            int n3 = this.B5;
            if (n3 != 0 && n3 != 1) {
                if (n2 == 187) {
                    int n4 = 1 + this.F5;
                    if (n4 > this.G5) {
                        this.G5 = n4;
                    }
                    this.F5 = n4;
                }
            } else {
                this.E5.i.a(n2, this.c5.b, this.f, p2);
            }
        }
        this.c5.b(n2, p2.a);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(int var1_1, String var2_2, String var3_3, String var4_4) {
        block13 : {
            block14 : {
                block16 : {
                    block15 : {
                        this.w5 = this.c5.b;
                        var5_5 = this.f.b(var2_2, var3_3, var4_4);
                        if (this.E5 == null) break block13;
                        var7_6 = this.B5;
                        if (var7_6 == 0 || var7_6 == (var8_7 = 1)) break block14;
                        var9_8 = var4_4.charAt(0);
                        var10_9 = -2;
                        switch (var1_1) {
                            default: {
                                var13_10 = this.F5;
                                if (var9_8 == 'D' || var9_8 == 'J') {
                                    break;
                                }
                                break block15;
                            }
                            case 180: {
                                var14_11 = this.F5;
                                if (var9_8 == 'D') ** GOTO lbl19
                                var15_12 = 0;
                                if (var9_8 != 'J') ** GOTO lbl20
lbl19: // 2 sources:
                                var15_12 = 1;
lbl20: // 2 sources:
                                var12_13 = var14_11 + var15_12;
                                break block16;
                            }
                            case 179: {
                                var13_10 = this.F5;
                                if (var9_8 != 'D' && var9_8 != 'J') {
                                    var10_9 = -1;
                                }
                                break block15;
                            }
                            case 178: {
                                var11_14 = this.F5;
                                if (var9_8 == 'D' || var9_8 == 'J') {
                                    var8_7 = 2;
                                }
                                var12_13 = var11_14 + var8_7;
                                break block16;
                            }
                        }
                        var10_9 = -3;
                    }
                    var12_13 = var10_9 + var13_10;
                }
                if (var12_13 > this.G5) {
                    this.G5 = var12_13;
                }
                this.F5 = var12_13;
                break block13;
            }
            this.E5.i.a(var1_1, 0, this.f, var5_5);
        }
        this.c5.b(var1_1, var5_5.a);
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        this.w5 = this.c5.b;
        p p2 = this.f.a(string, string2, string3, bl);
        int n3 = p2.c;
        if (this.E5 != null) {
            int n4 = this.B5;
            if (n4 != 0 && n4 != 1) {
                int n5;
                if (n3 == 0) {
                    p2.c = n3 = u.b((String)string3);
                }
                if ((n5 = n2 == 184 ? 1 + (this.F5 - (n3 >> 2) + (n3 & 3)) : this.F5 - (n3 >> 2) + (n3 & 3)) > this.G5) {
                    this.G5 = n5;
                }
                this.F5 = n5;
            } else {
                this.E5.i.a(n2, 0, this.f, p2);
            }
        }
        if (n2 == 185) {
            if (n3 == 0) {
                p2.c = n3 = u.b((String)string3);
            }
            this.c5.b(185, p2.a).a(n3 >> 2, 0);
            return;
        }
        this.c5.b(n2, p2.a);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(int var1_1, q var2_2) {
        block16 : {
            var3_3 = 200;
            var4_4 = var1_1 >= var3_3;
            if (var4_4) {
                var1_1 -= 33;
            }
            this.w5 = this.c5.b;
            var5_5 = this.E5;
            var6_6 = null;
            if (var5_5 != null) {
                var20_7 = this.B5;
                if (var20_7 == 0) {
                    var5_5.i.a(var1_1, 0, null, null);
                    var24_8 = var2_2.a();
                    var24_8.b = 16 | var24_8.b;
                    this.c(0, var2_2);
                    var6_6 = null;
                    if (var1_1 != 167) {
                        var6_6 = new q();
                    }
                } else if (var20_7 == 1) {
                    var5_5.i.a(var1_1, 0, null, null);
                    var6_6 = null;
                } else if (var1_1 == 168) {
                    var22_9 = var2_2.b;
                    if ((var22_9 & 512) == 0) {
                        var2_2.b = var22_9 | 512;
                        this.A5 = 1 + this.A5;
                    }
                    var23_10 = this.E5;
                    var23_10.b = 128 | var23_10.b;
                    this.c(1 + this.F5, var2_2);
                    var6_6 = new q();
                } else {
                    this.F5 = var21_11 = this.F5 + m.i[var1_1];
                    this.c(var21_11, var2_2);
                }
            }
            if ((2 & var2_2.b) == 0) break block16;
            var12_12 = var2_2.d;
            var13_13 = this.c5;
            if (var12_12 - var13_13.b >= -32768) break block16;
            if (var1_1 == 167) ** GOTO lbl42
            if (var1_1 == 168) {
                var3_3 = 201;
lbl42: // 2 sources:
                var13_13.a(var3_3);
            } else {
                if (var6_6 != null) {
                    var6_6.b = 16 | var6_6.b;
                }
                var14_14 = this.c5;
                var15_15 = var1_1 <= 166 ? (1 ^ var1_1 + 1) - 1 : var1_1 ^ 1;
                var14_14.a(var15_15);
                this.c5.c(8);
                this.c5.a(var3_3);
            }
            ** GOTO lbl56
        }
        var7_16 = this.c5;
        if (var4_4) {
            var7_16.a(var1_1 + 33);
lbl56: // 3 sources:
            var11_17 = this.c5;
            var2_2.a(this, var11_17, var11_17.b - 1, true);
        } else {
            var7_16.a(var1_1);
            var9_18 = this.c5;
            var2_2.a(this, var9_18, var9_18.b - 1, false);
        }
        if (this.E5 == null) return;
        if (var6_6 != null) {
            this.a(var6_6);
        }
        if (var1_1 != 167) return;
        this.h();
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Object object) {
        d d2;
        int n2;
        this.w5 = this.c5.b;
        p p2 = this.f.a(object);
        if (this.E5 != null) {
            int n3 = this.B5;
            if (n3 != 0 && n3 != 1) {
                int n4 = p2.b;
                int n5 = n4 != 5 && n4 != 6 ? 1 + this.F5 : 2 + this.F5;
                if (n5 > this.G5) {
                    this.G5 = n5;
                }
                this.F5 = n5;
            } else {
                this.E5.i.a(18, 0, this.f, p2);
            }
        }
        int n6 = p2.a;
        int n7 = p2.b;
        if (n7 != 5 && n7 != 6) {
            if (n6 < 256) {
                this.c5.a(18, n6);
                return;
            }
            d2 = this.c5;
            n2 = 19;
        } else {
            d2 = this.c5;
            n2 = 20;
        }
        d2.b(n2, n6);
    }

    public void a(String string, int n2) {
        this.w5 = this.c5.b;
        p p2 = this.f.a(string);
        if (this.E5 != null) {
            int n3 = this.B5;
            if (n3 != 0 && n3 != 1) {
                this.F5 += 1 - n2;
            } else {
                this.E5.i.a(197, n2, this.f, p2);
            }
        }
        this.c5.b(197, p2.a).a(n2);
    }

    public void a(String string, String string2, String string3, q q2, q q3, int n2) {
        int n3 = 1;
        if (string3 != null) {
            if (this.t5 == null) {
                this.t5 = new d();
            }
            this.s5 = n3 + this.s5;
            this.t5.c(q2.d).c(q3.d - q2.d).c(this.f.e(string)).c(this.f.e(string3)).c(n2);
        }
        if (this.r5 == null) {
            this.r5 = new d();
        }
        this.q5 = n3 + this.q5;
        this.r5.c(q2.d).c(q3.d - q2.d).c(this.f.e(string)).c(this.f.e(string2)).c(n2);
        if (this.B5 != 3) {
            int n4;
            char c2 = string2.charAt(0);
            if (c2 == 'J' || c2 == 'D') {
                n3 = 2;
            }
            if ((n4 = n2 + n3) > this.e5) {
                this.e5 = n4;
            }
        }
    }

    public /* varargs */ void a(String string, String string2, n n2, Object ... arrobject) {
        this.w5 = this.c5.b;
        p p2 = this.f.a(string, string2, n2, arrobject);
        int n3 = p2.c;
        if (this.E5 != null) {
            int n4 = this.B5;
            if (n4 != 0 && n4 != 1) {
                int n5;
                if (n3 == 0) {
                    p2.c = n3 = u.b((String)string2);
                }
                if ((n5 = 1 + (this.F5 - (n3 >> 2) + (n3 & 3))) > this.G5) {
                    this.G5 = n5;
                }
                this.F5 = n5;
            } else {
                this.E5.i.a(186, 0, this.f, p2);
            }
        }
        this.c5.b(186, p2.a);
        this.c5.c(0);
    }

    public void a(c c2) {
        if (c2.c()) {
            c2.c = this.z5;
            this.z5 = c2;
            return;
        }
        c2.c = this.b5;
        this.b5 = c2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    final void a(d var1_1) {
        var2_2 = this.h;
        var1_1.c(var2_2 & (-1 ^ (917504 | (var2_2 & 262144) / 64))).c(this.o).c(this.s);
        var4_3 = this.P4;
        if (var4_3 != 0) {
            var1_1.a(this.f.f.a, var4_3, this.Q4);
            return;
        }
        var5_4 = this.c5.b > 0 ? 1 : 0;
        if (this.R4 > 0) {
            ++var5_4;
        }
        if (((var6_5 = this.h) & 4096) != 0 && ((65535 & this.f.h) < 49 || (var6_5 & 262144) != 0)) {
            ++var5_4;
        }
        if ((131072 & this.h) != 0) {
            ++var5_4;
        }
        if (this.w != null) {
            ++var5_4;
        }
        if (this.p5 != null) {
            ++var5_4;
        }
        if (this.T4 != null) {
            ++var5_4;
        }
        if (this.U4 != null) {
            ++var5_4;
        }
        if (this.V4 != null) {
            ++var5_4;
        }
        if (this.W4 != null) {
            ++var5_4;
        }
        if (this.X4 != null) {
            ++var5_4;
        }
        if (this.Y4 != null) {
            ++var5_4;
        }
        if (this.Z4 != null) {
            ++var5_4;
        }
        if ((var7_6 = this.b5) != null) {
            var5_4 += var7_6.a();
        }
        var1_1.c(var5_4);
        var9_7 = this.c5.b;
        if (var9_7 <= 0) ** GOTO lbl-1000
        var35_8 = var9_7 + 12 + 8 * this.l5;
        var36_9 = this.r5;
        if (var36_9 != null) {
            var35_8 += 8 + var36_9.b;
        }
        if ((var37_10 = this.t5) != null) {
            var35_8 += 8 + var37_10.b;
        }
        if ((var38_11 = this.v5) != null) {
            var35_8 += 8 + var38_11.b;
        }
        if ((var39_12 = this.h5) != null) {
            var35_8 += 8 + var39_12.b;
        }
        if ((var40_13 = this.x5) != null) {
            var35_8 += 8 + var40_13.b();
        }
        if ((var41_14 = this.y5) != null) {
            var35_8 += 8 + var41_14.b();
        }
        if ((var42_15 = this.z5) != null) {
            var82_16 = this.f;
            var83_17 = this.c5;
            var35_8 += var42_15.a(var82_16, var83_17.a, var83_17.b, this.d5, this.e5);
        }
        var1_1.c(this.f.e("Code")).b(var35_8);
        var1_1.c(this.d5).c(this.e5);
        var45_18 = var1_1.b(this.c5.b);
        var46_19 = this.c5;
        var45_18.a(var46_19.a, 0, var46_19.b);
        var1_1.c(this.l5);
        if (this.l5 > 0) {
            var80_20 = this.m5;
            while (var80_20 != null) {
                var1_1.c(var80_20.a.d).c(var80_20.b.d).c(var80_20.c.d).c(var80_20.e);
                var80_20 = var80_20.f;
            }
        }
        var49_21 = this.r5 != null ? 1 : 0;
        if (this.t5 != null) {
            ++var49_21;
        }
        if (this.v5 != null) {
            ++var49_21;
        }
        if (this.h5 != null) {
            ++var49_21;
        }
        if (this.x5 != null) {
            ++var49_21;
        }
        if (this.y5 != null) {
            ++var49_21;
        }
        if ((var50_22 = this.z5) != null) {
            var49_21 += var50_22.a();
        }
        var1_1.c(var49_21);
        if (this.r5 != null) {
            var1_1.c(this.f.e("LocalVariableTable"));
            var1_1.b(2 + this.r5.b).c(this.q5);
            var78_23 = this.r5;
            var1_1.a(var78_23.a, 0, var78_23.b);
        }
        if (this.t5 != null) {
            var1_1.c(this.f.e("LocalVariableTypeTable"));
            var1_1.b(2 + this.t5.b).c(this.s5);
            var74_24 = this.t5;
            var1_1.a(var74_24.a, 0, var74_24.b);
        }
        if (this.v5 != null) {
            var1_1.c(this.f.e("LineNumberTable"));
            var1_1.b(2 + this.v5.b).c(this.u5);
            var70_25 = this.v5;
            var1_1.a(var70_25.a, 0, var70_25.b);
        }
        if (this.h5 != null) {
            var61_26 = (65535 & this.f.h) >= 50;
            var62_27 = this.f;
            var63_28 = var61_26 != false ? "StackMapTable" : "StackMap";
            var1_1.c(var62_27.e(var63_28));
            var1_1.b(2 + this.h5.b).c(this.g5);
            var66_29 = this.h5;
            var1_1.a(var66_29.a, 0, var66_29.b);
        }
        if (this.x5 != null) {
            var1_1.c(this.f.e("RuntimeVisibleTypeAnnotations"));
            this.x5.a(var1_1);
        }
        if (this.y5 != null) {
            var1_1.c(this.f.e("RuntimeInvisibleTypeAnnotations"));
            this.y5.a(var1_1);
        }
        if ((var52_30 = this.z5) != null) {
            var53_31 = this.f;
            var54_32 = this.c5;
            var55_33 = var54_32.a;
            var56_34 = var54_32.b;
            var57_35 = this.e5;
            var58_36 = this.d5;
            var11_37 = 2;
            var10_38 = "RuntimeVisibleTypeAnnotations";
            var52_30.a(var53_31, var55_33, var56_34, var57_35, var58_36, var1_1);
        } else lbl-1000: // 2 sources:
        {
            var10_38 = "RuntimeVisibleTypeAnnotations";
            var11_37 = 2;
        }
        if (this.R4 > 0) {
            var1_1.c(this.f.e("Exceptions")).b(var11_37 + 2 * this.R4);
            var1_1.c(this.R4);
            for (var33_39 = 0; var33_39 < this.R4; ++var33_39) {
                var1_1.c(this.S4[var33_39]);
            }
        }
        if (((var12_40 = this.h) & 4096) != 0 && ((65535 & this.f.h) < 49 || (var12_40 & 262144) != 0)) {
            var1_1.c(this.f.e("Synthetic")).b(0);
        }
        if ((131072 & this.h) != 0) {
            var1_1.c(this.f.e("Deprecated")).b(0);
        }
        if (this.w != null) {
            var1_1.c(this.f.e("Signature")).b(var11_37).c(this.f.e(this.w));
        }
        if (this.p5 != null) {
            var1_1.c(this.f.e("MethodParameters"));
            var1_1.b(1 + this.p5.b).a(this.o5);
            var26_41 = this.p5;
            var1_1.a(var26_41.a, 0, var26_41.b);
        }
        if (this.T4 != null) {
            var1_1.c(this.f.e("AnnotationDefault"));
            var1_1.b(this.T4.b);
            var22_42 = this.T4;
            var1_1.a(var22_42.a, 0, var22_42.b);
        }
        if (this.U4 != null) {
            var1_1.c(this.f.e("RuntimeVisibleAnnotations"));
            this.U4.a(var1_1);
        }
        if (this.V4 != null) {
            var1_1.c(this.f.e("RuntimeInvisibleAnnotations"));
            this.V4.a(var1_1);
        }
        if (this.W4 != null) {
            var1_1.c(this.f.e(var10_38));
            this.W4.a(var1_1);
        }
        if (this.X4 != null) {
            var1_1.c(this.f.e("RuntimeInvisibleTypeAnnotations"));
            this.X4.a(var1_1);
        }
        if (this.Y4 != null) {
            var1_1.c(this.f.e("RuntimeVisibleParameterAnnotations"));
            b.a(this.Y4, this.a5, var1_1);
        }
        if (this.Z4 != null) {
            var1_1.c(this.f.e("RuntimeInvisibleParameterAnnotations"));
            b.a(this.Z4, this.a5, var1_1);
        }
        if ((var13_43 = this.b5) == null) return;
        var13_43.a(this.f, null, 0, -1, -1, var1_1);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(q q2) {
        block14 : {
            block15 : {
                q q3;
                int n2;
                block13 : {
                    g g2 = this.f;
                    boolean bl = g2.u5;
                    d d2 = this.c5;
                    g2.u5 = bl | q2.a(this, d2.b, d2.a);
                    int n3 = q2.b;
                    if ((n3 & 1) != 0) {
                        return;
                    }
                    n2 = this.B5;
                    if (n2 != 0) break block13;
                    q q4 = this.E5;
                    if (q4 != null) {
                        if (q2.d == q4.d) {
                            q4.b |= n3 & 16;
                            q2.i = q4.i;
                            return;
                        }
                        this.c(0, q2);
                    }
                    this.E5 = q2;
                    if (q2.i == null) {
                        m m2;
                        q2.i = m2 = new m();
                        m2.a = q2;
                    }
                    if ((q3 = this.D5) == null) break block14;
                    if (q2.d == q3.d) {
                        q3.b |= 16 & q2.b;
                        q2.i = q3.i;
                        this.E5 = q3;
                        return;
                    }
                    break block15;
                }
                if (n2 == 1) {
                    q q5 = this.E5;
                    if (q5 == null) {
                        this.E5 = q2;
                        return;
                    }
                    q5.i.a = q2;
                    return;
                }
                if (n2 != 2) {
                    return;
                }
                q q6 = this.E5;
                if (q6 != null) {
                    q6.h = this.G5;
                    this.c(this.F5, q2);
                }
                this.E5 = q2;
                this.F5 = 0;
                this.G5 = 0;
                q3 = this.D5;
                if (q3 == null) break block14;
            }
            q3.j = q2;
        }
        this.D5 = q2;
    }

    public void a(q q2, q q3, q q4, String string) {
        this.l5 = 1 + this.l5;
        o o2 = new o();
        o2.a = q2;
        o2.b = q3;
        o2.c = q4;
        o2.d = string;
        int n2 = string != null ? this.f.c(string) : 0;
        o2.e = n2;
        o o3 = this.n5;
        if (o3 == null) {
            this.m5 = o2;
        } else {
            o3.f = o2;
        }
        this.n5 = o2;
    }

    public void a(q q2, int[] arrn, q[] arrq) {
        int n2;
        d d2 = this.c5;
        this.w5 = n2 = d2.b;
        d2.a(171);
        d d3 = this.c5;
        int n3 = (4 - d3.b % 4) % 4;
        d3.a(null, 0, n3);
        q2.a(this, this.c5, n2, true);
        this.c5.b(arrq.length);
        for (int i2 = 0; i2 < arrq.length; ++i2) {
            this.c5.b(arrn[i2]);
            arrq[i2].a(this, this.c5, n2, true);
        }
        this.a(q2, arrq);
    }

    public a b(int n2, v v2, String string, boolean bl) {
        d d2 = new d();
        b.a(n2, v2, d2);
        d2.c(this.f.e(string)).c(0);
        b b2 = new b(this.f, true, d2, d2, -2 + d2.b);
        if (bl) {
            b2.i = this.x5;
            this.x5 = b2;
            return b2;
        }
        b2.i = this.y5;
        this.y5 = b2;
        return b2;
    }

    public void b() {
    }

    public void b(int n2, int n3) {
        this.w5 = this.c5.b;
        if (this.E5 != null) {
            int n4 = this.B5;
            if (n4 != 0 && n4 != 1) {
                if (n2 != 188) {
                    int n5 = 1 + this.F5;
                    if (n5 > this.G5) {
                        this.G5 = n5;
                    }
                    this.F5 = n5;
                }
            } else {
                this.E5.i.a(n2, n3, null, null);
            }
        }
        if (n2 == 17) {
            this.c5.b(n2, n3);
            return;
        }
        this.c5.a(n2, n3);
    }

    public void b(int n2, q q2) {
        if (this.v5 == null) {
            this.v5 = new d();
        }
        this.u5 = 1 + this.u5;
        this.v5.c(q2.d);
        this.v5.c(n2);
    }

    public void b(String string, int n2) {
        if (this.p5 == null) {
            this.p5 = new d();
        }
        this.o5 = 1 + this.o5;
        d d2 = this.p5;
        int n3 = string == null ? 0 : this.f.e(string);
        d2.c(n3).c(n2);
    }

    public a c(int n2, v v2, String string, boolean bl) {
        d d2 = new d();
        b.a(n2, v2, d2);
        d2.c(this.f.e(string)).c(0);
        b b2 = new b(this.f, true, d2, d2, -2 + d2.b);
        if (bl) {
            b2.i = this.W4;
            this.W4 = b2;
            return b2;
        }
        b2.i = this.X4;
        this.X4 = b2;
        return b2;
    }

    public void c(int n2, int n3) {
        int n4 = this.B5;
        int n5 = 0;
        if (n4 == 0) {
            String string;
            o o2 = this.m5;
            do {
                string = "java/lang/Throwable";
                if (o2 == null) break;
                q q2 = o2.a.a();
                q q3 = o2.c.a();
                q q4 = o2.b.a();
                String string2 = o2.d;
                if (string2 != null) {
                    string = string2;
                }
                int n6 = 24117248 | this.f.b(string);
                q3.b = 16 | q3.b;
                while (q2 != q4) {
                    j j2 = new j();
                    j2.a = n6;
                    j2.b = q3;
                    j2.c = q2.k;
                    q2.k = j2;
                    q2 = q2.j;
                }
                o2 = o2.f;
            } while (true);
            m m2 = this.C5.i;
            m2.a(this.f, this.h, u.a((String)this.t), this.e5);
            this.a(m2);
            q q5 = this.C5;
            int n7 = 0;
            while (q5 != null) {
                q q6 = q5.l;
                q5.l = null;
                m m3 = q5.i;
                int n8 = q5.b;
                if ((n8 & 16) != 0) {
                    q5.b = n8 | 32;
                }
                q5.b = 64 | q5.b;
                int n9 = m3.c.length + q5.h;
                if (n9 > n7) {
                    n7 = n9;
                }
                j j3 = q5.k;
                while (j3 != null) {
                    q q7 = j3.b.a();
                    if (m3.a(this.f, q7.i, j3.a) && q7.l == null) {
                        q7.l = q6;
                        q6 = q7;
                    }
                    j3 = j3.c;
                }
                q5 = q6;
            }
            q q8 = this.C5;
            while (q8 != null) {
                int n10;
                int n11;
                int n12;
                q q9;
                m m4 = q8.i;
                if ((32 & q8.b) != 0) {
                    this.a(m4);
                }
                if ((64 & q8.b) == 0 && (n11 = (n12 = (q9 = q8.j) == null ? this.c5.b : q9.d) - 1) >= (n10 = q8.d)) {
                    n7 = Math.max((int)n7, (int)1);
                    for (int i2 = n10; i2 < n11; ++i2) {
                        this.c5.a[i2] = 0;
                    }
                    this.c5.a[n11] = -65;
                    int n13 = this.a(n10, 0, 1);
                    this.k5[n13] = 24117248 | this.f.b(string);
                    this.f();
                    this.m5 = o.a((o)this.m5, (q)q8, (q)q9);
                }
                q8 = q8.j;
            }
            o o3 = this.m5;
            this.l5 = 0;
            while (o3 != null) {
                this.l5 = 1 + this.l5;
                o3 = o3.f;
            }
            this.d5 = n7;
            return;
        }
        if (n4 == 2) {
            o o4 = this.m5;
            while (o4 != null) {
                q q10 = o4.a;
                q q11 = o4.c;
                q q12 = o4.b;
                while (q10 != q12) {
                    j j4 = new j();
                    j4.a = Integer.MAX_VALUE;
                    j4.b = q11;
                    if ((128 & q10.b) == 0) {
                        j4.c = q10.k;
                        q10.k = j4;
                    } else {
                        j j5 = q10.k;
                        j4.c = j5.c.c;
                        j5.c.c = j4;
                    }
                    q10 = q10.j;
                }
                o4 = o4.f;
            }
            int n14 = this.A5;
            if (n14 > 0) {
                this.C5.a(null, 1L, n14);
                q q13 = this.C5;
                int n15 = 0;
                while (q13 != null) {
                    if ((128 & q13.b) != 0) {
                        q q14 = q13.k.c.b;
                        if ((1024 & q14.b) == 0) {
                            q14.a(null, (long)(++n15) / 32L << 32 | 1L << n15 % 32, this.A5);
                        }
                    }
                    q13 = q13.j;
                }
                q q15 = this.C5;
                while (q15 != null) {
                    if ((128 & q15.b) != 0) {
                        q q16 = this.C5;
                        while (q16 != null) {
                            q16.b = -2049 & q16.b;
                            q16 = q16.j;
                        }
                        q15.k.c.b.a(q15, 0L, this.A5);
                    }
                    q15 = q15.j;
                }
            }
            q q17 = this.C5;
            while (q17 != null) {
                q q18 = q17.l;
                int n16 = q17.g;
                int n17 = n16 + q17.h;
                if (n17 > n5) {
                    n5 = n17;
                }
                j j6 = q17.k;
                if ((128 & q17.b) != 0) {
                    j6 = j6.c;
                }
                q17 = q18;
                while (j6 != null) {
                    q q19 = j6.b;
                    if ((8 & q19.b) == 0) {
                        int n18 = j6.a;
                        int n19 = n18 == Integer.MAX_VALUE ? 1 : n18 + n16;
                        q19.g = n19;
                        q19.b = 8 | q19.b;
                        q19.l = q17;
                        q17 = q19;
                    }
                    j6 = j6.c;
                }
            }
            this.d5 = Math.max((int)n2, (int)n5);
            return;
        }
        this.d5 = n2;
        this.e5 = n3;
    }

    public void d() {
    }

    public void d(int n2, int n3) {
        this.w5 = this.c5.b;
        q q2 = this.E5;
        if (q2 != null) {
            int n4 = this.B5;
            if (n4 != 0 && n4 != 1) {
                if (n2 == 169) {
                    q2.b = 256 | q2.b;
                    q2.g = this.F5;
                    this.h();
                } else {
                    int n5 = this.F5 + m.i[n2];
                    if (n5 > this.G5) {
                        this.G5 = n5;
                    }
                    this.F5 = n5;
                }
            } else {
                this.E5.i.a(n2, n3, null, null);
            }
        }
        if (this.B5 != 3) {
            int n6 = n2 != 22 && n2 != 24 && n2 != 55 && n2 != 57 ? n3 + 1 : n3 + 2;
            if (n6 > this.e5) {
                this.e5 = n6;
            }
        }
        if (n3 < 4 && n2 != 169) {
            int n7 = n2 < 54 ? 26 + (n2 - 21 << 2) : 59 + (n2 - 54 << 2);
            int n8 = n7 + n3;
            this.c5.a(n8);
        } else {
            d d2 = this.c5;
            if (n3 >= 256) {
                d2.a(196).b(n2, n3);
            } else {
                d2.a(n2, n3);
            }
        }
        if (n2 >= 54 && this.B5 == 0 && this.l5 > 0) {
            this.a(new q());
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    final int e() {
        int n2;
        int n3;
        c c2;
        if (this.P4 != 0) {
            return 6 + this.Q4;
        }
        int n4 = this.c5.b;
        if (n4 > 0) {
            c c3;
            if (n4 > 65535) throw new RuntimeException("Method code too large!");
            this.f.e("Code");
            n3 = 8 + (18 + this.c5.b + 8 * this.l5);
            if (this.r5 != null) {
                this.f.e("LocalVariableTable");
                n3 += 8 + this.r5.b;
            }
            if (this.t5 != null) {
                this.f.e("LocalVariableTypeTable");
                n3 += 8 + this.t5.b;
            }
            if (this.v5 != null) {
                this.f.e("LineNumberTable");
                n3 += 8 + this.v5.b;
            }
            if (this.h5 != null) {
                boolean bl = (65535 & this.f.h) >= 50;
                g g2 = this.f;
                String string = bl ? "StackMapTable" : "StackMap";
                g2.e(string);
                n3 += 8 + this.h5.b;
            }
            if (this.x5 != null) {
                this.f.e("RuntimeVisibleTypeAnnotations");
                n3 += 8 + this.x5.b();
            }
            if (this.y5 != null) {
                this.f.e("RuntimeInvisibleTypeAnnotations");
                n3 += 8 + this.y5.b();
            }
            if ((c3 = this.z5) != null) {
                g g3 = this.f;
                d d2 = this.c5;
                n3 += c3.a(g3, d2.a, d2.b, this.d5, this.e5);
            }
        } else {
            n3 = 8;
        }
        if (this.R4 > 0) {
            this.f.e("Exceptions");
            n3 += 8 + 2 * this.R4;
        }
        if (((n2 = this.h) & 4096) != 0 && ((65535 & this.f.h) < 49 || (262144 & n2) != 0)) {
            this.f.e("Synthetic");
            n3 += 6;
        }
        if ((131072 & this.h) != 0) {
            this.f.e("Deprecated");
            n3 += 6;
        }
        if (this.w != null) {
            this.f.e("Signature");
            this.f.e(this.w);
            n3 += 8;
        }
        if (this.p5 != null) {
            this.f.e("MethodParameters");
            n3 += 7 + this.p5.b;
        }
        if (this.T4 != null) {
            this.f.e("AnnotationDefault");
            n3 += 6 + this.T4.b;
        }
        if (this.U4 != null) {
            this.f.e("RuntimeVisibleAnnotations");
            n3 += 8 + this.U4.b();
        }
        if (this.V4 != null) {
            this.f.e("RuntimeInvisibleAnnotations");
            n3 += 8 + this.V4.b();
        }
        if (this.W4 != null) {
            this.f.e("RuntimeVisibleTypeAnnotations");
            n3 += 8 + this.W4.b();
        }
        if (this.X4 != null) {
            this.f.e("RuntimeInvisibleTypeAnnotations");
            n3 += 8 + this.X4.b();
        }
        if (this.Y4 != null) {
            this.f.e("RuntimeVisibleParameterAnnotations");
            b[] arrb = this.Y4;
            n3 += 7 + 2 * (arrb.length - this.a5);
            for (int i2 = arrb.length - 1; i2 >= this.a5; --i2) {
                b[] arrb2 = this.Y4;
                int n5 = arrb2[i2] == null ? 0 : arrb2[i2].b();
                n3 += n5;
            }
        }
        if (this.Z4 != null) {
            this.f.e("RuntimeInvisibleParameterAnnotations");
            b[] arrb = this.Z4;
            n3 += 7 + 2 * (arrb.length - this.a5);
            for (int i3 = arrb.length - 1; i3 >= this.a5; --i3) {
                b[] arrb3 = this.Z4;
                int n6 = arrb3[i3] == null ? 0 : arrb3[i3].b();
                n3 += n6;
            }
        }
        if ((c2 = this.b5) == null) return n3;
        n3 += c2.a(this.f, null, 0, -1, -1);
        return n3;
    }
}

