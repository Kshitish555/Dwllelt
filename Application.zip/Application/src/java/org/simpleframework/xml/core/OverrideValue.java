/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  org.simpleframework.xml.strategy.Value
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.strategy.Value;

class OverrideValue
implements Value {
    private final Class type;
    private final Value value;

    public OverrideValue(Value value, Class class_) {
        this.value = value;
        this.type = class_;
    }

    public int getLength() {
        return this.value.getLength();
    }

    public Class getType() {
        return this.type;
    }

    public Object getValue() {
        return this.value.getValue();
    }

    public boolean isReference() {
        return this.value.isReference();
    }

    public void setValue(Object object) {
        this.value.setValue(object);
    }
}

