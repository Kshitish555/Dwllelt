/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.amplitude.api;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import com.amplitude.api.c;
import com.amplitude.api.d;

class b
implements Application.ActivityLifecycleCallbacks {
    public static final String d = "com.amplitude.api.AmplitudeCallbacks";
    private static final String f = "Need to initialize AmplitudeCallbacks with AmplitudeClient instance";
    private static d h = d.a();
    private c c = null;

    public b(c c2) {
        if (c2 == null) {
            h.b(d, f);
            return;
        }
        this.c = c2;
        c2.r();
    }

    protected long a() {
        return System.currentTimeMillis();
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
        c c2 = this.c;
        if (c2 == null) {
            h.b(d, f);
            return;
        }
        c2.b(this.a());
    }

    public void onActivityResumed(Activity activity) {
        c c2 = this.c;
        if (c2 == null) {
            h.b(d, f);
            return;
        }
        c2.a(this.a());
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }
}

