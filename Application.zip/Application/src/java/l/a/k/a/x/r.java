/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  l.a.k.a.a
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.v
 *  l.a.k.a.x.n
 */
package l.a.k.a.x;

import l.a.k.a.a;
import l.a.k.a.q;
import l.a.k.a.v;
import l.a.k.a.x.k;
import l.a.k.a.x.n;
import l.a.k.a.x.o;

public class r
extends k {
    protected final n P4;

    protected r(int n2, int n3, String string, l.a.k.a.r r2, n n4) {
        super(n2, n3, string, r2);
        this.P4 = n4;
    }

    public r(int n2, String string, l.a.k.a.r r2, n n3) {
        this(327680, n2, string, r2, n3);
    }

    private Object[] a(int n2, Object[] arrobject) {
        for (int i2 = 0; i2 < n2; ++i2) {
            if (!(arrobject[i2] instanceof String)) continue;
            Object[] arrobject2 = new Object[n2];
            if (i2 > 0) {
                System.arraycopy((Object)arrobject, (int)0, (Object)arrobject2, (int)0, (int)i2);
            }
            do {
                Object object = arrobject[i2];
                int n3 = i2 + 1;
                if (object instanceof String) {
                    object = this.P4.d((String)object);
                }
                arrobject2[i2] = object;
                if (n3 >= n2) {
                    return arrobject2;
                }
                i2 = n3;
            } while (true);
        }
        return arrobject;
    }

    private void b(int n2, String string, String string2, String string3, boolean bl) {
        l.a.k.a.r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, this.P4.d(string), this.P4.b(string, string2, string3), this.P4.c(string3), bl);
        }
    }

    public a a() {
        a a2 = l.a.k.a.r.super.a();
        if (a2 == null) {
            return a2;
        }
        return new o(a2, this.P4);
    }

    public a a(int n2, String string, boolean bl) {
        a a2 = l.a.k.a.r.super.a(n2, this.P4.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new o(a2, this.P4);
    }

    public a a(int n2, v v2, String string, boolean bl) {
        a a2 = l.a.k.a.r.super.a(n2, v2, this.P4.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new o(a2, this.P4);
    }

    @Override
    public a a(int n2, v v2, q[] arrq, q[] arrq2, int[] arrn, String string, boolean bl) {
        a a2 = super.a(n2, v2, arrq, arrq2, arrn, this.P4.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new o(a2, this.P4);
    }

    public a a(String string, boolean bl) {
        a a2 = l.a.k.a.r.super.a(this.P4.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new o(a2, this.P4);
    }

    @Override
    public void a(int n2, int n3, Object[] arrobject, int n4, Object[] arrobject2) {
        super.a(n2, n3, this.a(n3, arrobject), n4, this.a(n4, arrobject2));
    }

    public void a(int n2, String string) {
        l.a.k.a.r.super.a(n2, this.P4.d(string));
    }

    public void a(int n2, String string, String string2, String string3) {
        l.a.k.a.r.super.a(n2, this.P4.d(string), this.P4.a(string, string2, string3), this.P4.b(string3));
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            l.a.k.a.r.super.a(n2, string, string2, string3, bl);
            return;
        }
        this.b(n2, string, string2, string3, bl);
    }

    public void a(Object object) {
        l.a.k.a.r.super.a(this.P4.a(object));
    }

    public void a(String string, int n2) {
        l.a.k.a.r.super.a(this.P4.b(string), n2);
    }

    @Override
    public void a(String string, String string2, String string3, q q2, q q3, int n2) {
        super.a(string, this.P4.b(string2), this.P4.a(string3, true), q2, q3, n2);
    }

    public /* varargs */ void a(String string, String string2, l.a.k.a.n n2, Object ... arrobject) {
        for (int i2 = 0; i2 < arrobject.length; ++i2) {
            arrobject[i2] = this.P4.a(arrobject[i2]);
        }
        l.a.k.a.r.super.a(this.P4.a(string, string2), this.P4.c(string2), (l.a.k.a.n)this.P4.a((Object)n2), arrobject);
    }

    public void a(q q2, q q3, q q4, String string) {
        String string2 = string == null ? null : this.P4.d(string);
        l.a.k.a.r.super.a(q2, q3, q4, string2);
    }

    public a b(int n2, v v2, String string, boolean bl) {
        a a2 = l.a.k.a.r.super.b(n2, v2, this.P4.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new o(a2, this.P4);
    }

    public void b(int n2, String string, String string2, String string3) {
        if (this.c >= 327680) {
            l.a.k.a.r.super.b(n2, string, string2, string3);
            return;
        }
        boolean bl = n2 == 185;
        this.b(n2, string, string2, string3, bl);
    }

    public a c(int n2, v v2, String string, boolean bl) {
        a a2 = l.a.k.a.r.super.c(n2, v2, this.P4.b(string), bl);
        if (a2 == null) {
            return a2;
        }
        return new o(a2, this.P4);
    }
}

