/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;

public final class e
extends Enum<e>
implements l.a.j.q.e {
    public static final /* enum */ e d;
    public static final /* enum */ e f;
    public static final /* enum */ e h;
    private static final e.c o;
    private static final /* synthetic */ e[] s;
    private final int c;

    static {
        e e2;
        d = new e(11);
        f = new e(12);
        h = e2 = new e(13);
        e[] arre = new e[]{d, f, e2};
        s = arre;
        o = f.f.f();
    }

    private e(int n3) {
        this.c = n3;
    }

    public static l.a.j.q.e a(float f2) {
        if (f2 == 0.0f) {
            return d;
        }
        if (f2 == 1.0f) {
            return f;
        }
        if (f2 == 2.0f) {
            return h;
        }
        return new a(f2);
    }

    public static e valueOf(String string) {
        return (e)Enum.valueOf(e.class, (String)string);
    }

    public static e[] values() {
        return (e[])s.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.c);
        return o;
    }

    public boolean x() {
        return true;
    }

    protected static class a
    implements l.a.j.q.e {
        private final float c;

        protected a(float f2) {
            this.c = f2;
        }

        public e.c a(r r2, e.d d2) {
            r2.a((Object)Float.valueOf((float)this.c));
            return o;
        }

        protected boolean b(Object object) {
            return object instanceof a;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof a)) {
                return false;
            }
            a a2 = (a)object;
            if (!a2.b(this)) {
                return false;
            }
            return Float.compare((float)this.c, (float)a2.c) == 0;
        }

        public int hashCode() {
            return 59 + Float.floatToIntBits((float)this.c);
        }

        public boolean x() {
            return true;
        }
    }

}

