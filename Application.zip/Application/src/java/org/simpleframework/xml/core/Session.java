/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Set
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

final class Session
implements Map {
    private final Map map = new HashMap();
    private final boolean strict;

    public Session() {
        this(true);
    }

    public Session(boolean bl) {
        this.strict = bl;
    }

    public void clear() {
        this.map.clear();
    }

    public boolean containsKey(Object object) {
        return this.map.containsKey(object);
    }

    public boolean containsValue(Object object) {
        return this.map.containsValue(object);
    }

    public Set entrySet() {
        return this.map.entrySet();
    }

    public Object get(Object object) {
        return this.map.get(object);
    }

    public Map getMap() {
        return this.map;
    }

    public boolean isEmpty() {
        return this.map.isEmpty();
    }

    public boolean isStrict() {
        return this.strict;
    }

    public Set keySet() {
        return this.map.keySet();
    }

    public Object put(Object object, Object object2) {
        return this.map.put(object, object2);
    }

    public void putAll(Map map) {
        this.map.putAll(map);
    }

    public Object remove(Object object) {
        return this.map.remove(object);
    }

    public int size() {
        return this.map.size();
    }

    public Collection values() {
        return this.map.values();
    }
}

