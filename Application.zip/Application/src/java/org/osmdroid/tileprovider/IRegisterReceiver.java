/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Intent
 *  android.content.IntentFilter
 *  java.lang.Object
 */
package org.osmdroid.tileprovider;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;

public interface IRegisterReceiver {
    public Intent registerReceiver(BroadcastReceiver var1, IntentFilter var2);

    public void unregisterReceiver(BroadcastReceiver var1);
}

