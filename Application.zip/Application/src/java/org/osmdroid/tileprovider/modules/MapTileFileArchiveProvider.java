/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  org.osmdroid.tileprovider.IRegisterReceiver
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.osmdroid.tileprovider.modules.ArchiveFileFactory
 *  org.osmdroid.tileprovider.modules.IArchiveFile
 *  org.osmdroid.tileprovider.modules.MapTileFileArchiveProvider$1
 *  org.osmdroid.tileprovider.modules.MapTileFileArchiveProvider$TileLoader
 *  org.osmdroid.tileprovider.modules.MapTileFileStorageProviderBase
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import org.osmdroid.tileprovider.IRegisterReceiver;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.osmdroid.tileprovider.modules.ArchiveFileFactory;
import org.osmdroid.tileprovider.modules.IArchiveFile;
import org.osmdroid.tileprovider.modules.MapTileFileArchiveProvider;
import org.osmdroid.tileprovider.modules.MapTileFileStorageProviderBase;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Exception performing whole class analysis.
 */
public class MapTileFileArchiveProvider
extends MapTileFileStorageProviderBase {
    private static final Logger logger;
    private final ArrayList<IArchiveFile> mArchiveFiles;
    private final boolean mSpecificArchivesProvided;
    protected ITileSource mTileSource;

    static {
        logger = LoggerFactory.getLogger(MapTileFileArchiveProvider.class);
    }

    public MapTileFileArchiveProvider(IRegisterReceiver iRegisterReceiver, ITileSource iTileSource) {
        this(iRegisterReceiver, iTileSource, null);
    }

    public MapTileFileArchiveProvider(IRegisterReceiver iRegisterReceiver, ITileSource iTileSource, IArchiveFile[] arriArchiveFile) {
        super(iRegisterReceiver, 8, 40);
        this.mArchiveFiles = new ArrayList();
        this.mTileSource = iTileSource;
        if (arriArchiveFile == null) {
            this.mSpecificArchivesProvided = false;
            this.findArchiveFiles();
            return;
        }
        this.mSpecificArchivesProvided = true;
        for (int i2 = arriArchiveFile.length - 1; i2 >= 0; --i2) {
            this.mArchiveFiles.add((Object)arriArchiveFile[i2]);
        }
    }

    static /* synthetic */ InputStream access$100(MapTileFileArchiveProvider mapTileFileArchiveProvider, MapTile mapTile) {
        return mapTileFileArchiveProvider.getInputStream(mapTile);
    }

    static /* synthetic */ Logger access$200() {
        return logger;
    }

    private void findArchiveFiles() {
        this.mArchiveFiles.clear();
        if (!this.getSdCardAvailable()) {
            return;
        }
        File[] arrfile = OpenStreetMapTileProviderConstants.OSMDROID_PATH.listFiles();
        if (arrfile != null) {
            int n2 = arrfile.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                IArchiveFile iArchiveFile = ArchiveFileFactory.getArchiveFile((File)arrfile[i2]);
                if (iArchiveFile == null) continue;
                this.mArchiveFiles.add((Object)iArchiveFile);
            }
        }
    }

    private InputStream getInputStream(MapTile mapTile) {
        MapTileFileArchiveProvider mapTileFileArchiveProvider = this;
        synchronized (mapTileFileArchiveProvider) {
            InputStream inputStream;
            try {
                Iterator iterator = this.mArchiveFiles.iterator();
                while (iterator.hasNext()) {
                    inputStream = ((IArchiveFile)iterator.next()).getInputStream(this.mTileSource, mapTile);
                    if (inputStream == null) continue;
                }
            }
            catch (Throwable throwable) {}
            {
                throw throwable;
            }
            return inputStream;
            return null;
        }
    }

    public void detach() {
        while (!this.mArchiveFiles.isEmpty()) {
            this.mArchiveFiles.remove(0);
        }
        super.detach();
    }

    public int getMaximumZoomLevel() {
        ITileSource iTileSource = this.mTileSource;
        if (iTileSource != null) {
            return iTileSource.getMaximumZoomLevel();
        }
        return 22;
    }

    public int getMinimumZoomLevel() {
        ITileSource iTileSource = this.mTileSource;
        if (iTileSource != null) {
            return iTileSource.getMinimumZoomLevel();
        }
        return 0;
    }

    protected String getName() {
        return "File Archive Provider";
    }

    protected String getThreadGroupName() {
        return "filearchive";
    }

    protected Runnable getTileLoader() {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public boolean getUsesDataConnection() {
        return false;
    }

    protected void onMediaMounted() {
        if (!this.mSpecificArchivesProvided) {
            this.findArchiveFiles();
        }
    }

    protected void onMediaUnmounted() {
        if (!this.mSpecificArchivesProvided) {
            this.findArchiveFiles();
        }
    }

    public void setTileSource(ITileSource iTileSource) {
        this.mTileSource = iTileSource;
    }
}

