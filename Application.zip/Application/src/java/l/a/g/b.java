/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  l.a.h.k.c
 *  l.a.i.b
 *  l.a.i.b$a
 *  l.a.l.r
 */
package l.a.g;

import l.a.h.k.c;
import l.a.i.b;
import l.a.l.r;

public interface b
extends r<c> {
    public b.a<?> a(b.a<?> var1, c var2);
}

