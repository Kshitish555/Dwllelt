/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Point
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$bitmap
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IProjection
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IProjection;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;

public class DirectedLocationOverlay
extends Overlay {
    protected final Bitmap DIRECTION_ARROW;
    private final float DIRECTION_ARROW_CENTER_X;
    private final float DIRECTION_ARROW_CENTER_Y;
    private final int DIRECTION_ARROW_HEIGHT;
    private final int DIRECTION_ARROW_WIDTH;
    private final Matrix directionRotater = new Matrix();
    private int mAccuracy = 0;
    protected final Paint mAccuracyPaint = new Paint();
    protected float mBearing;
    protected GeoPoint mLocation;
    protected final Paint mPaint = new Paint();
    private boolean mShowAccuracy = true;
    private final Point screenCoords = new Point();

    public DirectedLocationOverlay(Context context) {
        this(context, new DefaultResourceProxyImpl(context));
    }

    public DirectedLocationOverlay(Context context, ResourceProxy resourceProxy) {
        Bitmap bitmap2;
        super(resourceProxy);
        this.DIRECTION_ARROW = bitmap2 = this.mResourceProxy.getBitmap(ResourceProxy.bitmap.direction_arrow);
        this.DIRECTION_ARROW_CENTER_X = (float)(bitmap2.getWidth() / 2) - 0.5f;
        this.DIRECTION_ARROW_CENTER_Y = (float)(this.DIRECTION_ARROW.getHeight() / 2) - 0.5f;
        this.DIRECTION_ARROW_HEIGHT = this.DIRECTION_ARROW.getHeight();
        this.DIRECTION_ARROW_WIDTH = this.DIRECTION_ARROW.getWidth();
        this.mAccuracyPaint.setStrokeWidth(2.0f);
        this.mAccuracyPaint.setColor(-16776961);
        this.mAccuracyPaint.setAntiAlias(true);
    }

    @Override
    public void draw(Canvas canvas, MapView mapView, boolean bl) {
        if (bl) {
            return;
        }
        if (this.mLocation != null) {
            float f2;
            int n2;
            IProjection iProjection = mapView.getProjection();
            iProjection.toMapPixels(this.mLocation, this.screenCoords);
            if (this.mShowAccuracy && (n2 = this.mAccuracy) > 10 && (f2 = iProjection.metersToEquatorPixels(n2)) > 8.0f) {
                this.mAccuracyPaint.setAntiAlias(false);
                this.mAccuracyPaint.setAlpha(30);
                this.mAccuracyPaint.setStyle(Paint.Style.FILL);
                Point point = this.screenCoords;
                canvas.drawCircle((float)point.x, (float)point.y, f2, this.mAccuracyPaint);
                this.mAccuracyPaint.setAntiAlias(true);
                this.mAccuracyPaint.setAlpha(150);
                this.mAccuracyPaint.setStyle(Paint.Style.STROKE);
                Point point2 = this.screenCoords;
                canvas.drawCircle((float)point2.x, (float)point2.y, f2, this.mAccuracyPaint);
            }
            this.directionRotater.setRotate(this.mBearing, this.DIRECTION_ARROW_CENTER_X, this.DIRECTION_ARROW_CENTER_Y);
            Bitmap bitmap2 = Bitmap.createBitmap((Bitmap)this.DIRECTION_ARROW, (int)0, (int)0, (int)this.DIRECTION_ARROW_WIDTH, (int)this.DIRECTION_ARROW_HEIGHT, (Matrix)this.directionRotater, (boolean)false);
            canvas.drawBitmap(bitmap2, (float)(this.screenCoords.x - bitmap2.getWidth() / 2), (float)(this.screenCoords.y - bitmap2.getHeight() / 2), this.mPaint);
        }
    }

    public GeoPoint getLocation() {
        return this.mLocation;
    }

    public void setAccuracy(int n2) {
        this.mAccuracy = n2;
    }

    public void setBearing(float f2) {
        this.mBearing = f2;
    }

    public void setLocation(GeoPoint geoPoint) {
        this.mLocation = geoPoint;
    }

    public void setShowAccuracy(boolean bl) {
        this.mShowAccuracy = bl;
    }
}

