/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  l.a.k.a.a
 *  l.a.k.a.x.n
 */
package l.a.k.a.x;

import l.a.k.a.a;
import l.a.k.a.x.n;

public class c
extends a {
    protected final n c;

    protected c(int n2, a a2, n n3) {
        super(n2, a2);
        this.c = n3;
    }

    public c(a a2, n n2) {
        this(327680, a2, n2);
    }

    public a a(String string) {
        a a2 = this.b.a(string);
        if (a2 == null) {
            return null;
        }
        if (a2 == this.b) {
            return this;
        }
        return new c(a2, this.c);
    }

    public a a(String string, String string2) {
        a a2 = this.b.a(string, this.c.b(string2));
        if (a2 == null) {
            return null;
        }
        if (a2 == this.b) {
            return this;
        }
        return new c(a2, this.c);
    }

    public void a(String string, Object object) {
        this.b.a(string, this.c.a(object));
    }

    public void a(String string, String string2, String string3) {
        this.b.a(string, this.c.b(string2), string3);
    }
}

