/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.database.Cursor
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteException
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.modules.IArchiveFile
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.modules.IArchiveFile;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DatabaseFileArchive
implements IArchiveFile {
    private static final Logger logger = LoggerFactory.getLogger(DatabaseFileArchive.class);
    private final SQLiteDatabase mDatabase;

    private DatabaseFileArchive(SQLiteDatabase sQLiteDatabase) {
        this.mDatabase = sQLiteDatabase;
    }

    public static DatabaseFileArchive getDatabaseFileArchive(File file) throws SQLiteException {
        return new DatabaseFileArchive(SQLiteDatabase.openOrCreateDatabase((File)file, null));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public InputStream getInputStream(ITileSource iTileSource, MapTile mapTile) {
        String[] arrstring = new String[]{"tile"};
        long l = mapTile.getX();
        long l2 = mapTile.getY();
        long l3 = mapTile.getZoomLevel();
        int n = (int)l3;
        long l4 = l2 + (l + (l3 << n) << n);
        try {
            ByteArrayInputStream byteArrayInputStream;
            SQLiteDatabase sQLiteDatabase = this.mDatabase;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("key = ");
            stringBuilder.append(l4);
            stringBuilder.append(" and provider = '");
            stringBuilder.append(iTileSource.name());
            stringBuilder.append("'");
            Cursor cursor = sQLiteDatabase.query("tiles", arrstring, stringBuilder.toString(), null, null, null, null);
            if (cursor.getCount() != 0) {
                cursor.moveToFirst();
                byteArrayInputStream = new ByteArrayInputStream(cursor.getBlob(0));
            } else {
                byteArrayInputStream = null;
            }
            cursor.close();
            if (byteArrayInputStream == null) return null;
            return byteArrayInputStream;
        }
        catch (Throwable throwable) {
            Logger logger = DatabaseFileArchive.logger;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error getting db stream: ");
            stringBuilder.append((Object)mapTile);
            logger.warn(stringBuilder.toString(), throwable);
        }
        return null;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DatabaseFileArchive [mDatabase=");
        stringBuilder.append(this.mDatabase.getPath());
        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}

