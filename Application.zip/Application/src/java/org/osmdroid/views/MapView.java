/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Point
 *  android.graphics.Rect
 *  android.os.Handler
 *  android.util.AttributeSet
 *  android.view.GestureDetector
 *  android.view.GestureDetector$OnDoubleTapListener
 *  android.view.GestureDetector$OnGestureListener
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.Animation
 *  android.view.animation.ScaleAnimation
 *  android.widget.Scroller
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.List
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.atomic.AtomicInteger
 *  microsoft.mappoint.TileSystem
 *  net.wigle.wigleandroid.ZoomButtonsController
 *  net.wigle.wigleandroid.ZoomButtonsController$OnZoomListener
 *  org.metalev.multitouch.controller.MultiTouchController
 *  org.metalev.multitouch.controller.MultiTouchController$MultiTouchObjectCanvas
 *  org.metalev.multitouch.controller.MultiTouchController$PointInfo
 *  org.metalev.multitouch.controller.MultiTouchController$PositionAndScale
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IMapController
 *  org.osmdroid.api.IMapView
 *  org.osmdroid.api.IProjection
 *  org.osmdroid.events.MapListener
 *  org.osmdroid.tileprovider.IMapTileProviderCallback
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.tileprovider.util.SimpleInvalidationHandler
 *  org.osmdroid.util.constants.GeoConstants
 *  org.osmdroid.views.MapView$1
 *  org.osmdroid.views.MapView$LayoutParams
 *  org.osmdroid.views.MapView$MapViewDoubleClickListener
 *  org.osmdroid.views.MapView$MapViewGestureDetectorListener
 *  org.osmdroid.views.overlay.OverlayManager
 *  org.osmdroid.views.overlay.TilesOverlay
 *  org.osmdroid.views.util.constants.MapViewConstants
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Scroller;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import microsoft.mappoint.TileSystem;
import net.wigle.wigleandroid.ZoomButtonsController;
import org.metalev.multitouch.controller.MultiTouchController;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IMapController;
import org.osmdroid.api.IMapView;
import org.osmdroid.api.IProjection;
import org.osmdroid.events.MapListener;
import org.osmdroid.events.ScrollEvent;
import org.osmdroid.events.ZoomEvent;
import org.osmdroid.tileprovider.IMapTileProviderCallback;
import org.osmdroid.tileprovider.MapTileProviderBase;
import org.osmdroid.tileprovider.MapTileProviderBasic;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.util.SimpleInvalidationHandler;
import org.osmdroid.util.BoundingBoxE6;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.constants.GeoConstants;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.OverlayManager;
import org.osmdroid.views.overlay.TilesOverlay;
import org.osmdroid.views.util.constants.MapViewConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Exception performing whole class analysis.
 */
public class MapView
extends ViewGroup
implements IMapView,
MapViewConstants,
MultiTouchController.MultiTouchObjectCanvas<Object> {
    private static final double ZOOM_LOG_BASE_INV = 0.0;
    private static final double ZOOM_SENSITIVITY = 1.3;
    private static final Logger logger;
    private final MapController mController;
    private boolean mEnableZoomController;
    private final GestureDetector mGestureDetector;
    private final AtomicBoolean mIsAnimating;
    protected MapListener mListener;
    private final TilesOverlay mMapOverlay;
    private final Matrix mMatrix;
    private MultiTouchController<Object> mMultiTouchController;
    private float mMultiTouchScale;
    private final OverlayManager mOverlayManager;
    private final Point mPoint;
    private Projection mProjection;
    private final ResourceProxy mResourceProxy;
    private final Scroller mScroller;
    private final AtomicInteger mTargetZoomLevel;
    private final MapTileProviderBase mTileProvider;
    private final Handler mTileRequestCompleteHandler;
    private final ZoomButtonsController mZoomController;
    private final ScaleAnimation mZoomInAnimation;
    private int mZoomLevel;
    private final ScaleAnimation mZoomOutAnimation;

    static {
        logger = LoggerFactory.getLogger(MapView.class);
        ZOOM_LOG_BASE_INV = 1.0 / Math.log((double)1.5384615384615383);
    }

    public MapView(Context context, int n) {
        this(context, n, new DefaultResourceProxyImpl(context));
    }

    public MapView(Context context, int n, ResourceProxy resourceProxy) {
        this(context, n, resourceProxy, null);
    }

    public MapView(Context context, int n, ResourceProxy resourceProxy, MapTileProviderBase mapTileProviderBase) {
        this(context, n, resourceProxy, mapTileProviderBase, null);
    }

    public MapView(Context context, int n, ResourceProxy resourceProxy, MapTileProviderBase mapTileProviderBase, Handler handler) {
        this(context, n, resourceProxy, mapTileProviderBase, handler, null);
    }

    protected MapView(Context context, int n, ResourceProxy resourceProxy, MapTileProviderBase mapTileProviderBase, Handler handler, AttributeSet attributeSet) {
        ScaleAnimation scaleAnimation;
        GestureDetector gestureDetector;
        ScaleAnimation scaleAnimation2;
        ZoomButtonsController zoomButtonsController;
        super(context, attributeSet);
        this.mZoomLevel = 0;
        this.mTargetZoomLevel = new AtomicInteger();
        this.mIsAnimating = new AtomicBoolean(false);
        this.mEnableZoomController = false;
        this.mMultiTouchScale = 1.0f;
        this.mMatrix = new Matrix();
        this.mPoint = new Point();
        this.mResourceProxy = resourceProxy;
        this.mController = new MapController(this);
        this.mScroller = new Scroller(context);
        TileSystem.setTileSize((int)n);
        IMapTileProviderCallback iMapTileProviderCallback = mapTileProviderBase == null ? new MapTileProviderBasic(context, this.getTileSourceFromAttributes(attributeSet)) : mapTileProviderBase;
        Object object = handler == null ? new SimpleInvalidationHandler((View)this) : handler;
        this.mTileRequestCompleteHandler = object;
        this.mTileProvider = iMapTileProviderCallback;
        iMapTileProviderCallback.setTileRequestCompleteHandler((Handler)object);
        this.mMapOverlay = new TilesOverlay(this.mTileProvider, this.mResourceProxy);
        this.mOverlayManager = new OverlayManager(this.mMapOverlay);
        this.mZoomController = zoomButtonsController = new ZoomButtonsController((View)this);
        zoomButtonsController.setOnZoomListener((ZoomButtonsController.OnZoomListener)new MapViewZoomListener());
        this.mZoomInAnimation = scaleAnimation = new ScaleAnimation(1.0f, 2.0f, 1.0f, 2.0f, 1, 0.5f, 1, 0.5f);
        this.mZoomOutAnimation = scaleAnimation2 = new ScaleAnimation(1.0f, 0.5f, 1.0f, 0.5f, 1, 0.5f, 1, 0.5f);
        this.mZoomInAnimation.setDuration(500L);
        this.mZoomOutAnimation.setDuration(500L);
        this.mGestureDetector = gestureDetector = new GestureDetector(context, (GestureDetector.OnGestureListener)new /* Unavailable Anonymous Inner Class!! */);
        gestureDetector.setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)new /* Unavailable Anonymous Inner Class!! */);
    }

    public MapView(Context context, AttributeSet attributeSet) {
        this(context, 256, new DefaultResourceProxyImpl(context), null, null, attributeSet);
    }

    static /* synthetic */ boolean access$500(MapView mapView) {
        return mapView.mEnableZoomController;
    }

    static /* synthetic */ ZoomButtonsController access$600(MapView mapView) {
        return mapView.mZoomController;
    }

    static /* synthetic */ Scroller access$700(MapView mapView) {
        return mapView.mScroller;
    }

    static /* synthetic */ MultiTouchController access$800(MapView mapView) {
        return mapView.mMultiTouchController;
    }

    private void checkZoomButtons() {
        this.mZoomController.setZoomInEnabled(this.canZoomIn());
        this.mZoomController.setZoomOutEnabled(this.canZoomOut());
    }

    /*
     * Exception decompiling
     */
    private ITileSource getTileSourceFromAttributes(AttributeSet var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl54 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean canZoomIn() {
        int n = this.getMaxZoomLevel();
        if (this.mZoomLevel >= n) {
            return false;
        }
        boolean bl = this.mIsAnimating.get();
        boolean bl2 = this.mTargetZoomLevel.get() >= n;
        return !(bl2 & bl);
    }

    public boolean canZoomOut() {
        int n = this.getMinZoomLevel();
        if (this.mZoomLevel <= n) {
            return false;
        }
        return !this.mIsAnimating.get() || this.mTargetZoomLevel.get() > n;
    }

    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public void computeScroll() {
        if (this.mScroller.computeScrollOffset()) {
            if (this.mScroller.isFinished()) {
                this.setZoomLevel(this.mZoomLevel);
            } else {
                this.scrollTo(this.mScroller.getCurrX(), this.mScroller.getCurrY());
            }
            this.postInvalidate();
        }
    }

    protected void dispatchDraw(Canvas canvas) {
        System.currentTimeMillis();
        this.mProjection = new Projection();
        canvas.save();
        if (this.mMultiTouchScale == 1.0f) {
            canvas.translate((float)(this.getWidth() / 2), (float)(this.getHeight() / 2));
        } else {
            canvas.getMatrix(this.mMatrix);
            this.mMatrix.postTranslate((float)(this.getWidth() / 2), (float)(this.getHeight() / 2));
            Matrix matrix = this.mMatrix;
            float f = this.mMultiTouchScale;
            matrix.preScale(f, f, (float)this.getScrollX(), (float)this.getScrollY());
            canvas.setMatrix(this.mMatrix);
        }
        this.getOverlayManager().onDraw(canvas, this);
        canvas.restore();
        super.dispatchDraw(canvas);
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (this.mZoomController.isVisible() && this.mZoomController.onTouch((View)this, motionEvent)) {
            return true;
        }
        if (this.getOverlayManager().onTouchEvent(motionEvent, this)) {
            return true;
        }
        MultiTouchController<Object> multiTouchController = this.mMultiTouchController;
        if (multiTouchController != null && multiTouchController.onTouchEvent(motionEvent)) {
            return true;
        }
        boolean bl = super.dispatchTouchEvent(motionEvent);
        if (this.mGestureDetector.onTouchEvent(motionEvent)) {
            return true;
        }
        return bl;
    }

    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams = new /* Unavailable Anonymous Inner Class!! */;
        return layoutParams;
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    public BoundingBoxE6 getBoundingBox() {
        return this.getBoundingBox(this.getWidth(), this.getHeight());
    }

    public BoundingBoxE6 getBoundingBox(int n, int n2) {
        int n3 = TileSystem.MapSize((int)this.mZoomLevel) / 2;
        Rect rect = this.getScreenRect(null);
        rect.offset(n3, n3);
        GeoPoint geoPoint = TileSystem.PixelXYToLatLong((int)rect.right, (int)rect.top, (int)this.mZoomLevel, null);
        GeoPoint geoPoint2 = TileSystem.PixelXYToLatLong((int)rect.left, (int)rect.bottom, (int)this.mZoomLevel, null);
        return new BoundingBoxE6(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6(), geoPoint2.getLatitudeE6(), geoPoint2.getLongitudeE6());
    }

    public MapController getController() {
        return this.mController;
    }

    public Object getDraggableObjectAtPoint(MultiTouchController.PointInfo pointInfo) {
        return this;
    }

    public int getLatitudeSpan() {
        return this.getBoundingBox().getLatitudeSpanE6();
    }

    public int getLongitudeSpan() {
        return this.getBoundingBox().getLongitudeSpanE6();
    }

    public IGeoPoint getMapCenter() {
        int n = TileSystem.MapSize((int)this.mZoomLevel) / 2;
        Rect rect = this.getScreenRect(null);
        rect.offset(n, n);
        return TileSystem.PixelXYToLatLong((int)rect.centerX(), (int)rect.centerY(), (int)this.mZoomLevel, null);
    }

    public int getMaxZoomLevel() {
        return this.mMapOverlay.getMaximumZoomLevel();
    }

    public int getMinZoomLevel() {
        return this.mMapOverlay.getMinimumZoomLevel();
    }

    public OverlayManager getOverlayManager() {
        return this.mOverlayManager;
    }

    public List<Overlay> getOverlays() {
        return this.getOverlayManager();
    }

    public void getPositionAndScale(Object object, MultiTouchController.PositionAndScale positionAndScale) {
        positionAndScale.set(0.0f, 0.0f, true, this.mMultiTouchScale, false, 0.0f, 0.0f, false, 0.0f);
    }

    public Projection getProjection() {
        if (this.mProjection == null) {
            this.mProjection = new Projection();
        }
        return this.mProjection;
    }

    public ResourceProxy getResourceProxy() {
        return this.mResourceProxy;
    }

    public Rect getScreenRect(Rect rect) {
        if (rect == null) {
            rect = new Rect();
        }
        rect.set(this.getScrollX() - this.getWidth() / 2, this.getScrollY() - this.getHeight() / 2, this.getScrollX() + this.getWidth() / 2, this.getScrollY() + this.getHeight() / 2);
        return rect;
    }

    public Scroller getScroller() {
        return this.mScroller;
    }

    public MapTileProviderBase getTileProvider() {
        return this.mTileProvider;
    }

    public Handler getTileRequestCompleteHandler() {
        return this.mTileRequestCompleteHandler;
    }

    public int getZoomLevel() {
        return this.getZoomLevel(true);
    }

    public int getZoomLevel(boolean bl) {
        if (bl && this.isAnimating()) {
            return this.mTargetZoomLevel.get();
        }
        return this.mZoomLevel;
    }

    public boolean isAnimating() {
        return this.mIsAnimating.get();
    }

    protected void onAnimationEnd() {
        this.mIsAnimating.set(false);
        this.clearAnimation();
        this.setZoomLevel(this.mTargetZoomLevel.get());
        super.onAnimationEnd();
    }

    protected void onAnimationStart() {
        this.mIsAnimating.set(true);
        super.onAnimationStart();
    }

    public void onDetach() {
        this.getOverlayManager().onDetach(this);
    }

    protected void onDetachedFromWindow() {
        this.mZoomController.setVisible(false);
        this.onDetach();
        super.onDetachedFromWindow();
    }

    public boolean onKeyDown(int n, KeyEvent keyEvent) {
        return this.getOverlayManager().onKeyDown(n, keyEvent, this) || super.onKeyDown(n, keyEvent);
        {
        }
    }

    public boolean onKeyUp(int n, KeyEvent keyEvent) {
        return this.getOverlayManager().onKeyUp(n, keyEvent, this) || super.onKeyUp(n, keyEvent);
        {
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onLayout(boolean var1_1, int var2_2, int var3_3, int var4_4, int var5_5) {
        var6_6 = this.getChildCount();
        var7_7 = 0;
        while (var7_7 < var6_6) {
            block12 : {
                block13 : {
                    block14 : {
                        var8_8 = this.getChildAt(var7_7);
                        if (var8_8.getVisibility() == 8) break block12;
                        var9_9 = var8_8.getLayoutParams();
                        var10_10 = var8_8.getMeasuredHeight();
                        var11_11 = var8_8.getMeasuredWidth();
                        this.getProjection().toMapPixels(var9_9.geoPoint, this.mPoint);
                        var13_12 = this.mPoint.x + this.getWidth() / 2;
                        var14_13 = this.mPoint.y + this.getHeight() / 2;
                        switch (var9_9.alignment) {
                            default: {
                                break block13;
                            }
                            case 9: {
                                var13_12 = var13_12 + this.getPaddingLeft() - var11_11;
                                var20_19 = this.getPaddingTop();
                                ** GOTO lbl26
                            }
                            case 8: {
                                var13_12 = var13_12 + this.getPaddingLeft() - var11_11 / 2;
                                var20_19 = this.getPaddingTop();
                                ** GOTO lbl26
                            }
                            case 7: {
                                var13_12 += this.getPaddingLeft();
                                var20_19 = this.getPaddingTop();
lbl26: // 3 sources:
                                var14_13 = var20_19 + var14_13 - var10_10;
                                break block13;
                            }
                            case 6: {
                                var13_12 = var13_12 + this.getPaddingLeft() - var11_11;
                                var18_17 = var14_13 + this.getPaddingTop();
                                var19_18 = var10_10 / 2;
                                ** GOTO lbl42
                            }
                            case 5: {
                                var13_12 = var13_12 + this.getPaddingLeft() - var11_11 / 2;
                                var18_17 = var14_13 + this.getPaddingTop();
                                var19_18 = var10_10 / 2;
                                ** GOTO lbl42
                            }
                            case 4: {
                                var13_12 += this.getPaddingLeft();
                                var18_17 = var14_13 + this.getPaddingTop();
                                var19_18 = var10_10 / 2;
lbl42: // 3 sources:
                                var14_13 = var18_17 - var19_18;
                                break block13;
                            }
                            case 3: {
                                var13_12 = var13_12 + this.getPaddingLeft() - var11_11;
                                var15_14 = this.getPaddingTop();
                                break block14;
                            }
                            case 2: {
                                var13_12 = var13_12 + this.getPaddingLeft() - var11_11 / 2;
                                var15_14 = this.getPaddingTop();
                                break block14;
                            }
                            case 1: 
                        }
                        var13_12 += this.getPaddingLeft();
                        var15_14 = this.getPaddingTop();
                    }
                    var14_13 += var15_14;
                }
                var16_15 = var13_12 + var9_9.offsetX;
                var17_16 = var14_13 + var9_9.offsetY;
                var8_8.layout(var16_15, var17_16, var11_11 + var16_15, var10_10 + var17_16);
            }
            ++var7_7;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected void onMeasure(int var1_1, int var2_2) {
        var3_3 = this.getChildCount();
        this.measureChildren(var1_1, var2_2);
        var4_4 = 0;
        var5_5 = 0;
        var6_6 = 0;
        do {
            block12 : {
                if (var4_4 >= var3_3) {
                    var7_15 = var5_5 + (this.getPaddingLeft() + this.getPaddingRight());
                    var8_16 = Math.max((int)(var6_6 + (this.getPaddingTop() + this.getPaddingBottom())), (int)this.getSuggestedMinimumHeight());
                    this.setMeasuredDimension(ViewGroup.resolveSize((int)Math.max((int)var7_15, (int)this.getSuggestedMinimumWidth()), (int)var1_1), ViewGroup.resolveSize((int)var8_16, (int)var2_2));
                    return;
                }
                var9_7 = this.getChildAt(var4_4);
                if (var9_7.getVisibility() == 8) break block12;
                var10_8 = var9_7.getLayoutParams();
                var11_9 = var9_7.getMeasuredHeight();
                var12_10 = var9_7.getMeasuredWidth();
                this.getProjection().toMapPixels(var10_8.geoPoint, this.mPoint);
                var14_11 = this.mPoint.x + this.getWidth() / 2;
                var15_12 = this.mPoint.y + this.getHeight() / 2;
                switch (var10_8.alignment) {
                    default: {
                        ** break;
                    }
                    case 8: {
                        var12_10 /= 2;
                    }
                    case 7: {
                        var14_11 += var12_10;
                        ** GOTO lbl38
                    }
                    case 6: {
                        var11_9 /= 2;
                        ** GOTO lbl38
                    }
                    case 5: {
                        var14_11 += var12_10 / 2;
                        var11_9 /= 2;
                        ** GOTO lbl38
                    }
                    case 4: {
                        var14_11 += var12_10;
                        var11_9 /= 2;
                    }
lbl38: // 5 sources:
                    case 9: {
                        var15_12 += var11_9;
                        ** break;
                    }
                    case 2: {
                        var12_10 /= 2;
                    }
                    case 1: 
                }
                var14_11 += var12_10;
lbl45: // 3 sources:
                var16_13 = var14_11 + var10_8.offsetX;
                var17_14 = var15_12 + var10_8.offsetY;
                var5_5 = Math.max((int)var5_5, (int)var16_13);
                var6_6 = Math.max((int)var6_6, (int)var17_14);
            }
            ++var4_4;
        } while (true);
    }

    public boolean onTrackballEvent(MotionEvent motionEvent) {
        if (this.getOverlayManager().onTrackballEvent(motionEvent, this)) {
            return true;
        }
        this.scrollBy((int)(25.0f * motionEvent.getX()), (int)(25.0f * motionEvent.getY()));
        return super.onTrackballEvent(motionEvent);
    }

    public void scrollTo(int n, int n2) {
        int n3;
        int n4 = TileSystem.MapSize((int)this.mZoomLevel) / 2;
        while (n < (n3 = -n4)) {
            n += n4 * 2;
        }
        while (n > n4) {
            n -= n4 * 2;
        }
        while (n2 < n3) {
            n2 += n4 * 2;
        }
        while (n2 > n4) {
            n2 -= n4 * 2;
        }
        super.scrollTo(n, n2);
        if (this.mListener != null) {
            ScrollEvent scrollEvent = new ScrollEvent(this, n, n2);
            this.mListener.onScroll(scrollEvent);
        }
    }

    public void selectObject(Object object, MultiTouchController.PointInfo pointInfo) {
        float f;
        if (object == null && (f = this.mMultiTouchScale) != 1.0f) {
            this.setZoomLevel(Math.round((float)((float)(Math.log((double)f) * ZOOM_LOG_BASE_INV))) + this.mZoomLevel);
        }
        this.mMultiTouchScale = 1.0f;
    }

    public void setBackgroundColor(int n) {
        this.mMapOverlay.setLoadingBackgroundColor(n);
        this.invalidate();
    }

    public void setBuiltInZoomControls(boolean bl) {
        this.mEnableZoomController = bl;
        this.checkZoomButtons();
    }

    void setMapCenter(int n, int n2) {
        double d = n;
        Double.isNaN((double)d);
        double d2 = d / 1000000.0;
        double d3 = n2;
        Double.isNaN((double)d3);
        Point point = TileSystem.LatLongToPixelXY((double)d2, (double)(d3 / 1000000.0), (int)this.getZoomLevel(), null);
        int n3 = TileSystem.MapSize((int)this.mZoomLevel) / 2;
        if (this.getAnimation() == null || this.getAnimation().hasEnded()) {
            logger.debug("StartScroll");
            this.mScroller.startScroll(this.getScrollX(), this.getScrollY(), point.x - n3 - this.getScrollX(), point.y - n3 - this.getScrollY(), 500);
            this.postInvalidate();
        }
    }

    void setMapCenter(IGeoPoint iGeoPoint) {
        this.setMapCenter(iGeoPoint.getLatitudeE6(), iGeoPoint.getLongitudeE6());
    }

    public void setMapListener(MapListener mapListener) {
        this.mListener = mapListener;
    }

    public void setMultiTouchControls(boolean bl) {
        MultiTouchController multiTouchController = bl ? new MultiTouchController((MultiTouchController.MultiTouchObjectCanvas)this, false) : null;
        this.mMultiTouchController = multiTouchController;
    }

    public boolean setPositionAndScale(Object object, MultiTouchController.PositionAndScale positionAndScale, MultiTouchController.PointInfo pointInfo) {
        float f;
        float f2 = positionAndScale.getScale();
        if (f2 > (f = 1.0f) && !this.canZoomIn()) {
            f2 = 1.0f;
        }
        if (!(f2 < f) || this.canZoomOut()) {
            f = f2;
        }
        this.mMultiTouchScale = f;
        this.invalidate();
        return true;
    }

    public void setTileSource(ITileSource iTileSource) {
        this.mTileProvider.setTileSource(iTileSource);
        TileSystem.setTileSize((int)iTileSource.getTileSizePixels());
        this.checkZoomButtons();
        this.setZoomLevel(this.mZoomLevel);
        this.postInvalidate();
    }

    public void setUseDataConnection(boolean bl) {
        this.mMapOverlay.setUseDataConnection(bl);
    }

    int setZoomLevel(int n) {
        int n2 = Math.max((int)this.getMinZoomLevel(), (int)Math.min((int)this.getMaxZoomLevel(), (int)n));
        int n3 = this.mZoomLevel;
        this.mZoomLevel = n2;
        this.checkZoomButtons();
        if (n2 > n3) {
            int n4 = TileSystem.MapSize((int)n3) / 2;
            int n5 = TileSystem.MapSize((int)n2) / 2;
            GeoPoint geoPoint = TileSystem.PixelXYToLatLong((int)(n4 + this.getScrollX()), (int)(n4 + this.getScrollY()), (int)n3, null);
            double d = geoPoint.getLatitudeE6();
            Double.isNaN((double)d);
            double d2 = d / 1000000.0;
            double d3 = geoPoint.getLongitudeE6();
            Double.isNaN((double)d3);
            Point point = TileSystem.LatLongToPixelXY((double)d2, (double)(d3 / 1000000.0), (int)n2, null);
            this.scrollTo(point.x - n5, point.y - n5);
        } else if (n2 < n3) {
            int n6 = this.getScrollX();
            int n7 = n3 - n2;
            this.scrollTo(n6 >> n7, this.getScrollY() >> n7);
        }
        Point point = new Point();
        this.mProjection = new Projection();
        if (this.getOverlayManager().onSnapToItem(this.getScrollX(), this.getScrollY(), point, (IMapView)this)) {
            this.scrollTo(point.x, point.y);
        }
        this.mTileProvider.rescaleCache(n2, n3, this.getScreenRect(null));
        if (n2 != n3 && this.mListener != null) {
            ZoomEvent zoomEvent = new ZoomEvent(this, n2);
            this.mListener.onZoom(zoomEvent);
        }
        return this.mZoomLevel;
    }

    public boolean useDataConnection() {
        return this.mMapOverlay.useDataConnection();
    }

    boolean zoomIn() {
        if (this.canZoomIn()) {
            if (this.mIsAnimating.get()) {
                return false;
            }
            this.mTargetZoomLevel.set(1 + this.mZoomLevel);
            this.mIsAnimating.set(true);
            this.startAnimation((Animation)this.mZoomInAnimation);
            return true;
        }
        return false;
    }

    boolean zoomInFixing(int n, int n2) {
        this.setMapCenter(n, n2);
        return this.zoomIn();
    }

    boolean zoomInFixing(IGeoPoint iGeoPoint) {
        this.setMapCenter(iGeoPoint);
        return this.zoomIn();
    }

    boolean zoomOut() {
        if (this.canZoomOut()) {
            if (this.mIsAnimating.get()) {
                return false;
            }
            this.mTargetZoomLevel.set(this.mZoomLevel - 1);
            this.mIsAnimating.set(true);
            this.startAnimation((Animation)this.mZoomOutAnimation);
            return true;
        }
        return false;
    }

    boolean zoomOutFixing(int n, int n2) {
        this.setMapCenter(n, n2);
        return this.zoomOut();
    }

    boolean zoomOutFixing(IGeoPoint iGeoPoint) {
        this.setMapCenter(iGeoPoint);
        return this.zoomOut();
    }

    public void zoomToBoundingBox(BoundingBoxE6 boundingBoxE6) {
        double d;
        double d2;
        BoundingBoxE6 boundingBoxE62 = this.getBoundingBox();
        if (this.mZoomLevel == this.getMaxZoomLevel()) {
            d2 = boundingBoxE62.getLatitudeSpanE6();
        } else {
            double d3 = boundingBoxE62.getLatitudeSpanE6();
            double d4 = Math.pow((double)2.0, (double)(this.getMaxZoomLevel() - this.mZoomLevel));
            Double.isNaN((double)d3);
            d2 = d3 / d4;
        }
        double d5 = this.getMaxZoomLevel();
        double d6 = boundingBoxE6.getLatitudeSpanE6();
        Double.isNaN((double)d6);
        double d7 = Math.ceil((double)(Math.log((double)(d6 / d2)) / Math.log((double)2.0)));
        Double.isNaN((double)d5);
        double d8 = d5 - d7;
        int n = this.mZoomLevel;
        int n2 = this.getMaxZoomLevel();
        int n3 = boundingBoxE62.getLongitudeSpanE6();
        if (n == n2) {
            d = n3;
        } else {
            double d9 = n3;
            double d10 = Math.pow((double)2.0, (double)(this.getMaxZoomLevel() - this.mZoomLevel));
            Double.isNaN((double)d9);
            d = d9 / d10;
        }
        double d11 = this.getMaxZoomLevel();
        double d12 = boundingBoxE6.getLongitudeSpanE6();
        Double.isNaN((double)d12);
        double d13 = Math.ceil((double)(Math.log((double)(d12 / d)) / Math.log((double)2.0)));
        Double.isNaN((double)d11);
        double d14 = d11 - d13;
        IMapController iMapController = this.getController();
        if (!(d8 < d14)) {
            d8 = d14;
        }
        iMapController.setZoom((int)d8);
        IMapController iMapController2 = this.getController();
        double d15 = boundingBoxE6.getCenter().getLatitudeE6();
        Double.isNaN((double)d15);
        double d16 = d15 / 1000000.0;
        double d17 = boundingBoxE6.getCenter().getLongitudeE6();
        Double.isNaN((double)d17);
        iMapController2.setCenter(new GeoPoint(d16, d17 / 1000000.0));
    }

    private class MapViewZoomListener
    implements ZoomButtonsController.OnZoomListener {
        private MapViewZoomListener() {
        }

        public void onVisibilityChanged(boolean bl) {
        }

        public void onZoom(boolean bl) {
            if (bl) {
                MapView.this.getController().zoomIn();
                return;
            }
            MapView.this.getController().zoomOut();
        }
    }

    public class Projection
    implements IProjection,
    GeoConstants {
        private final BoundingBoxE6 mBoundingBoxProjection;
        private final Rect mScreenRectProjection;
        private final int mZoomLevelProjection;
        private final int offsetX;
        private final int offsetY;
        private final int viewHeight_2;
        private final int viewWidth_2;
        private final int worldSize_2;

        private Projection() {
            int n;
            this.viewWidth_2 = MapView.this.getWidth() / 2;
            this.viewHeight_2 = MapView.this.getHeight() / 2;
            this.worldSize_2 = n = TileSystem.MapSize((int)MapView.this.mZoomLevel) / 2;
            this.offsetX = -n;
            this.offsetY = -n;
            this.mZoomLevelProjection = MapView.this.mZoomLevel;
            this.mBoundingBoxProjection = MapView.this.getBoundingBox();
            this.mScreenRectProjection = MapView.this.getScreenRect(null);
        }

        public Point fromMapPixels(int n, int n2, Point point) {
            if (point == null) {
                point = new Point();
            }
            point.set(n - this.viewWidth_2, n2 - this.viewHeight_2);
            point.offset(MapView.this.getScrollX(), MapView.this.getScrollY());
            return point;
        }

        public IGeoPoint fromPixels(float f, float f2) {
            Rect rect = this.getScreenRect();
            int n = rect.left + (int)f;
            int n2 = this.worldSize_2;
            return TileSystem.PixelXYToLatLong((int)(n + n2), (int)(n2 + (rect.top + (int)f2)), (int)this.mZoomLevelProjection, null);
        }

        public IGeoPoint fromPixels(int n, int n2) {
            return this.fromPixels((float)n, (float)n2);
        }

        public Rect fromPixelsToProjected(Rect rect) {
            Rect rect2 = new Rect();
            int n = 22 - this.getZoomLevel();
            int n2 = rect.left;
            int n3 = this.offsetX;
            int n4 = n2 - n3 << n;
            int n5 = rect.right - n3 << n;
            int n6 = rect.bottom;
            int n7 = this.offsetY;
            int n8 = n6 - n7 << n;
            int n9 = rect.top - n7 << n;
            rect2.set(Math.min((int)n4, (int)n5), Math.min((int)n8, (int)n9), Math.max((int)n4, (int)n5), Math.max((int)n8, (int)n9));
            return rect2;
        }

        public BoundingBoxE6 getBoundingBox() {
            return this.mBoundingBoxProjection;
        }

        @Deprecated
        public Point getCenterMapTileCoords() {
            Rect rect = this.getScreenRect();
            return TileSystem.PixelXYToTileXY((int)rect.centerX(), (int)rect.centerY(), null);
        }

        public Rect getScreenRect() {
            return this.mScreenRectProjection;
        }

        @Deprecated
        public int getTileSizePixels() {
            return TileSystem.getTileSize();
        }

        @Deprecated
        public Point getUpperLeftCornerOfCenterMapTile() {
            Point point = this.getCenterMapTileCoords();
            return TileSystem.TileXYToPixelXY((int)point.x, (int)point.y, null);
        }

        public int getZoomLevel() {
            return this.mZoomLevelProjection;
        }

        public float metersToEquatorPixels(float f) {
            return f / (float)TileSystem.GroundResolution((double)0.0, (int)this.mZoomLevelProjection);
        }

        public Point toMapPixels(IGeoPoint iGeoPoint, Point point) {
            if (point == null) {
                point = new Point();
            }
            double d = iGeoPoint.getLatitudeE6();
            Double.isNaN((double)d);
            double d2 = d / 1000000.0;
            double d3 = iGeoPoint.getLongitudeE6();
            Double.isNaN((double)d3);
            Point point2 = TileSystem.LatLongToPixelXY((double)d2, (double)(d3 / 1000000.0), (int)this.getZoomLevel(), null);
            point.set(point2.x, point2.y);
            point.offset(this.offsetX, this.offsetY);
            return point;
        }

        public Point toMapPixelsProjected(int n, int n2, Point point) {
            if (point == null) {
                point = new Point();
            }
            double d = n;
            Double.isNaN((double)d);
            double d2 = d / 1000000.0;
            double d3 = n2;
            Double.isNaN((double)d3);
            TileSystem.LatLongToPixelXY((double)d2, (double)(d3 / 1000000.0), (int)22, (Point)point);
            return point;
        }

        public Point toMapPixelsTranslated(Point point, Point point2) {
            if (point2 == null) {
                point2 = new Point();
            }
            int n = 22 - this.getZoomLevel();
            point2.set((point.x >> n) + this.offsetX, (point.y >> n) + this.offsetY);
            return point2;
        }

        @Deprecated
        public Point toPixels(int n, int n2, Point point) {
            return TileSystem.TileXYToPixelXY((int)n, (int)n2, (Point)point);
        }

        @Deprecated
        public Point toPixels(Point point, Point point2) {
            return this.toPixels(point.x, point.y, point2);
        }

        public Point toPixels(IGeoPoint iGeoPoint, Point point) {
            return this.toMapPixels(iGeoPoint, point);
        }

        public Rect toPixels(BoundingBoxE6 boundingBoxE6) {
            Rect rect = new Rect();
            Point point = new Point();
            this.toMapPixels(new GeoPoint(boundingBoxE6.getLatNorthE6(), boundingBoxE6.getLonWestE6()), point);
            rect.left = point.x;
            rect.top = point.y;
            this.toMapPixels(new GeoPoint(boundingBoxE6.getLatSouthE6(), boundingBoxE6.getLonEastE6()), point);
            rect.right = point.x;
            rect.bottom = point.y;
            return rect;
        }
    }

}

