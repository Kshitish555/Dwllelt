/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.adjust.sdk.scheduler.SingleThreadFutureScheduler
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.text.DecimalFormat
 *  java.util.concurrent.ScheduledFuture
 *  java.util.concurrent.TimeUnit
 */
package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.Util;
import com.adjust.sdk.scheduler.FutureScheduler;
import com.adjust.sdk.scheduler.SingleThreadFutureScheduler;
import java.text.DecimalFormat;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class TimerCycle {
    private Runnable command;
    private long cycleDelay;
    private long initialDelay;
    private boolean isPaused;
    private ILogger logger;
    private String name;
    private FutureScheduler scheduler;
    private ScheduledFuture waitingTask;

    public TimerCycle(Runnable runnable, long l2, long l3, String string) {
        this.scheduler = new SingleThreadFutureScheduler(string, true);
        this.name = string;
        this.command = runnable;
        this.initialDelay = l2;
        this.cycleDelay = l3;
        this.isPaused = true;
        this.logger = AdjustFactory.getLogger();
        DecimalFormat decimalFormat = Util.SecondsDisplayFormat;
        double d2 = l3;
        Double.isNaN((double)d2);
        String string2 = decimalFormat.format(d2 / 1000.0);
        DecimalFormat decimalFormat2 = Util.SecondsDisplayFormat;
        double d3 = l2;
        Double.isNaN((double)d3);
        String string3 = decimalFormat2.format(d3 / 1000.0);
        this.logger.verbose("%s configured to fire after %s seconds of starting and cycles every %s seconds", string, string3, string2);
    }

    private void cancel(boolean bl) {
        ScheduledFuture scheduledFuture = this.waitingTask;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(bl);
        }
        this.waitingTask = null;
    }

    public void start() {
        if (!this.isPaused) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{this.name};
            iLogger.verbose("%s is already started", arrobject);
            return;
        }
        ILogger iLogger = this.logger;
        Object[] arrobject = new Object[]{this.name};
        iLogger.verbose("%s starting", arrobject);
        this.waitingTask = this.scheduler.scheduleFutureWithFixedDelay(new Runnable(){

            public void run() {
                ILogger iLogger = TimerCycle.this.logger;
                Object[] arrobject = new Object[]{TimerCycle.this.name};
                iLogger.verbose("%s fired", arrobject);
                TimerCycle.this.command.run();
            }
        }, this.initialDelay, this.cycleDelay);
        this.isPaused = false;
    }

    public void suspend() {
        if (this.isPaused) {
            ILogger iLogger = this.logger;
            Object[] arrobject = new Object[]{this.name};
            iLogger.verbose("%s is already suspended", arrobject);
            return;
        }
        this.initialDelay = this.waitingTask.getDelay(TimeUnit.MILLISECONDS);
        this.waitingTask.cancel(false);
        DecimalFormat decimalFormat = Util.SecondsDisplayFormat;
        double d2 = this.initialDelay;
        Double.isNaN((double)d2);
        String string = decimalFormat.format(d2 / 1000.0);
        ILogger iLogger = this.logger;
        Object[] arrobject = new Object[]{this.name, string};
        iLogger.verbose("%s suspended with %s seconds left", arrobject);
        this.isPaused = true;
    }

    public void teardown() {
        this.cancel(true);
        FutureScheduler futureScheduler = this.scheduler;
        if (futureScheduler != null) {
            futureScheduler.teardown();
        }
        this.scheduler = null;
    }

}

