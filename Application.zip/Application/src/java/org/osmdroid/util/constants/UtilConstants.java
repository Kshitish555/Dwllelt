/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.osmdroid.util.constants;

public interface UtilConstants {
    public static final long GPS_WAIT_TIME = 20000L;
}

