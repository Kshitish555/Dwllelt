/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnShowListener
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.LinearLayout
 *  androidx.fragment.app.DialogFragment
 *  c.g.a.b.a
 *  c.g.b.b
 *  c.g.b.b$h
 *  c.g.b.b$k
 *  c.g.b.b$m
 *  com.google.android.material.bottomsheet.BottomSheetDialog
 *  com.google.android.material.bottomsheet.BottomSheetDialogFragment
 *  com.qiwi.kit.ui.widget.bottomsheet.QiwiBottomSheet$a
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  kotlin.Metadata
 *  kotlin.TypeCastException
 *  kotlin.i2.t.i0
 *  o.c.a.d
 *  o.c.a.e
 */
package com.qiwi.kit.ui.widget.bottomsheet;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.fragment.app.DialogFragment;
import c.g.b.b;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.qiwi.kit.ui.widget.bottomsheet.QiwiBottomSheet;
import java.util.HashMap;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.i2.t.i0;
import o.c.a.d;
import o.c.a.e;

@Metadata(bv={1, 0, 3}, d1={"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b&\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0005\u001a\u00020\u0006H&J\b\u0010\u0007\u001a\u00020\u0004H\u0016J\u0012\u0010\b\u001a\u00020\t2\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016J\u0012\u0010\f\u001a\u00020\r2\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016J&\u0010\u000e\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u00122\b\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0016J\b\u0010\u0013\u001a\u00020\u0014H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082D\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0015"}, d2={"Lcom/qiwi/kit/ui/widget/bottomsheet/QiwiBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "()V", "TOP_MARGIN", "", "getContentView", "Landroid/view/View;", "getMaxHeight", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreateDialog", "Landroid/app/Dialog;", "onCreateView", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "useFullHeight", "", "kit_release"}, k=1, mv={1, 1, 16})
public abstract class QiwiBottomSheet
extends BottomSheetDialogFragment {
    private final int c = 72;
    private HashMap d;

    public int E1() {
        return Resources.getSystem().getDisplayMetrics().heightPixels - (int)c.g.a.b.a.a((int)this.c);
    }

    public boolean L1() {
        return false;
    }

    @d
    public abstract View getContentView();

    public View i(int n2) {
        View view;
        if (this.d == null) {
            this.d = new HashMap();
        }
        if ((view = (View)this.d.get((Object)n2)) == null) {
            View view2 = this.getView();
            if (view2 == null) {
                return null;
            }
            view = view2.findViewById(n2);
            this.d.put((Object)n2, (Object)view);
        }
        return view;
    }

    public void onCreate(@e Bundle bundle) {
        DialogFragment.super.onCreate(bundle);
        this.setStyle(0, b.m.CustomBottomSheetDialogTheme);
    }

    @d
    public Dialog onCreateDialog(@e Bundle bundle) {
        Dialog dialog = super.onCreateDialog(bundle);
        if (dialog != null) {
            BottomSheetDialog bottomSheetDialog = (BottomSheetDialog)dialog;
            bottomSheetDialog.setOnShowListener((DialogInterface.OnShowListener)new a(this));
            return bottomSheetDialog;
        }
        throw new TypeCastException("null cannot be cast to non-null type com.google.android.material.bottomsheet.BottomSheetDialog");
    }

    @e
    public View onCreateView(@d LayoutInflater layoutInflater, @e ViewGroup viewGroup, @e Bundle bundle) {
        i0.f((Object)layoutInflater, (String)"inflater");
        View view = LayoutInflater.from((Context)this.getContext()).inflate(b.k.bottom_sheet_container, null);
        ((LinearLayout)view.findViewById(b.h.contentContainer)).addView(this.getContentView());
        return view;
    }

    public /* synthetic */ void onDestroyView() {
        DialogFragment.super.onDestroyView();
        this.z1();
    }

    public void z1() {
        HashMap hashMap = this.d;
        if (hashMap != null) {
            hashMap.clear();
        }
    }
}

