/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 */
package org.simpleframework.xml.core;

interface Expression
extends Iterable<String> {
    public String getAttribute(String var1);

    public String getElement(String var1);

    public String getFirst();

    public int getIndex();

    public String getLast();

    public String getPath();

    public Expression getPath(int var1);

    public Expression getPath(int var1, int var2);

    public String getPrefix();

    public boolean isAttribute();

    public boolean isEmpty();

    public boolean isPath();

    public String toString();
}

