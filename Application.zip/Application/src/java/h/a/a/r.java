/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.s
 *  h.a.a.t
 *  h.a.a.u
 *  io.github.classgraph.utils.g
 *  io.github.classgraph.utils.k
 *  io.github.classgraph.utils.p
 *  io.github.classgraph.utils.q
 *  io.github.classgraph.utils.z
 *  java.io.File
 *  java.io.IOException
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.concurrent.ConcurrentLinkedQueue
 */
package h.a.a;

import h.a.a.e0;
import h.a.a.h0;
import h.a.a.l;
import h.a.a.l0;
import h.a.a.q;
import h.a.a.s;
import h.a.a.t;
import h.a.a.u;
import io.github.classgraph.utils.g;
import io.github.classgraph.utils.k;
import io.github.classgraph.utils.p;
import io.github.classgraph.utils.z;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

abstract class r {
    final g a;
    List<String> b;
    boolean c;
    List<g> d;
    final l0 e;
    protected List<h0> f;
    protected List<h0> g;
    protected Map<File, Long> h;

    r(g g2, l0 l02) {
        this.a = g2;
        this.e = l02;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    static r a(g g2, l0 l02, io.github.classgraph.utils.q q2, z<g> z2, p p2) {
        boolean bl;
        p p3;
        t t2;
        boolean bl2;
        block13 : {
            Object object;
            String string;
            try {
                string = g2.d();
                bl = g2.c() != null;
                bl2 = false;
                if (!bl) {
                    bl2 = g2.c(p2);
                }
                p3 = null;
                if (p2 == null) break block13;
            }
            catch (IOException iOException) {
                if (p2 != null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Exception while trying to canonicalize path ");
                    stringBuilder.append(g2.d());
                    p2.a(stringBuilder.toString(), (Throwable)iOException);
                }
                return null;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Scanning ");
            String string2 = bl ? "module " : (bl2 ? "directory " : "jarfile ");
            stringBuilder.append(string2);
            if (bl) {
                String string3;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append((Object)g2.c());
                if (g2.c().i() == null) {
                    string3 = "";
                } else {
                    StringBuilder stringBuilder3 = new StringBuilder();
                    stringBuilder3.append(" -> ");
                    stringBuilder3.append(g2.c().i());
                    string3 = stringBuilder3.toString();
                }
                stringBuilder2.append(string3);
                object = stringBuilder2.toString();
            } else {
                object = g2;
            }
            stringBuilder.append(object);
            p3 = p2.a(string, stringBuilder.toString());
        }
        if (bl) {
            t2 = new t(g2, l02, q2, p3);
        } else if (bl2) {
            t2 = new s(g2, l02, p3);
        } else {
            u u2 = new u(g2, l02, q2, z2, p3);
            t2 = u2;
        }
        if (p3 != null) {
            p3.a();
        }
        return t2;
    }

    File a(p p2) {
        if (this.a.c() != null) {
            return null;
        }
        try {
            File file = this.a.b(p2);
            return file;
        }
        catch (IOException iOException) {
            throw new RuntimeException((Throwable)iOException);
        }
    }

    abstract void a();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    void a(int var1_1, int var2_2, ConcurrentLinkedQueue<l> var3_3, p var4_4) throws Exception {
        while (var1_1 < var2_2) {
            block10 : {
                var5_6 = (h0)this.g.get(var1_1);
                if (var4_4 != null) break block10;
                var6_8 = null;
                ** GOTO lbl13
            }
            try {
                var21_7 = var5_6.getPath();
                var22_9 = new StringBuilder();
                var22_9.append("Parsing classfile ");
                var22_9.append((Object)var5_6);
                var6_8 = var4_4.a(var21_7, var22_9.toString());
lbl13: // 2 sources:
                var19_5 = new q().a(this, var5_6.getPath(), var5_6.s(), this.e, var6_8);
                if (var19_5 != null) {
                    var3_3.add((Object)var19_5);
                    var19_5.a(var6_8);
                }
                if (var6_8 != null) {
                    var6_8.a();
                }
            }
            catch (Throwable var14_12) {
                if (var4_4 == null) throw var14_12;
                try {
                    var15_13 = new StringBuilder();
                    var15_13.append("Exception while parsing classfile ");
                    var15_13.append((Object)var5_6);
                    var4_4.a(var15_13.toString(), var14_12);
                    throw var14_12;
                    catch (IOException var7_10) {
                        if (var4_4 != null) {
                            var8_11 = new StringBuilder();
                            var8_11.append("IOException while attempting to read classfile ");
                            var8_11.append((Object)var5_6);
                            var8_11.append(" -- skipping");
                            var4_4.a(var8_11.toString(), (Throwable)var7_10);
                        }
                    }
                }
                finally {
                    var5_6.close();
                }
            }
            ++var1_1;
        }
    }

    void a(int n2, HashSet<String> hashSet, p p2) {
        IllegalArgumentException illegalArgumentException;
        if (this.e.l) {
            HashSet hashSet2 = new HashSet();
            Iterator iterator = this.g.iterator();
            while (iterator.hasNext()) {
                String string = ((h0)iterator.next()).getPath();
                if (string.equals((Object)"module-info.class") || string.endsWith("/module-info.class") || hashSet.add((Object)string)) continue;
                hashSet2.add((Object)string);
            }
            if (!hashSet2.isEmpty()) {
                ArrayList arrayList = new ArrayList();
                for (h0 h02 : this.g) {
                    String string = h02.getPath();
                    if (!hashSet2.contains((Object)string)) {
                        arrayList.add((Object)h02);
                        continue;
                    }
                    if (p2 == null) continue;
                    Object[] arrobject = new Object[]{n2};
                    String string2 = String.format((String)"%06d-1", (Object[])arrobject);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Ignoring duplicate (masked) class ");
                    stringBuilder.append(string.substring(0, -6 + string.length()).replace('/', '.'));
                    stringBuilder.append(" for classpath element ");
                    stringBuilder.append((Object)h02);
                    p2.a(string2, stringBuilder.toString());
                }
                this.g = arrayList;
            }
            return;
        }
        illegalArgumentException = new IllegalArgumentException("performScan is false");
        throw illegalArgumentException;
    }

    abstract void b(p var1);

    ClassLoader[] b() {
        return this.a.a();
    }

    e0 c() {
        return this.a.c();
    }

    String d() {
        return "";
    }

    int e() {
        List<h0> list = this.g;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public String toString() {
        return this.a.toString();
    }
}

