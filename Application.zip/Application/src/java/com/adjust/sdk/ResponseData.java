/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.adjust.sdk.AttributionResponseData
 *  com.adjust.sdk.EventResponseData
 *  com.adjust.sdk.SdkClickResponseData
 *  com.adjust.sdk.SessionResponseData
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import com.adjust.sdk.ActivityKind;
import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.AdjustAttribution;
import com.adjust.sdk.AttributionResponseData;
import com.adjust.sdk.EventResponseData;
import com.adjust.sdk.SdkClickResponseData;
import com.adjust.sdk.SessionResponseData;
import com.adjust.sdk.TrackingState;
import com.adjust.sdk.Util;
import org.json.JSONObject;

public class ResponseData {
    public ActivityKind activityKind;
    public String adid;
    public AdjustAttribution attribution;
    public JSONObject jsonResponse;
    public String message;
    public boolean success;
    public String timestamp;
    public TrackingState trackingState;
    public boolean willRetry;

    protected ResponseData() {
    }

    public static ResponseData buildResponseData(ActivityPackage activityPackage) {
        Object object;
        ActivityKind activityKind;
        block4 : {
            SessionResponseData sessionResponseData;
            block5 : {
                block0 : {
                    block1 : {
                        block2 : {
                            block3 : {
                                activityKind = activityPackage.getActivityKind();
                                int n2 = a.a[activityKind.ordinal()];
                                if (n2 == 1) break block0;
                                if (n2 == 2) break block1;
                                if (n2 == 3) break block2;
                                if (n2 == 4) break block3;
                                object = new ResponseData();
                                break block4;
                            }
                            sessionResponseData = new EventResponseData(activityPackage);
                            break block5;
                        }
                        object = new AttributionResponseData();
                        break block4;
                    }
                    object = new SdkClickResponseData();
                    break block4;
                }
                sessionResponseData = new SessionResponseData(activityPackage);
            }
            object = sessionResponseData;
        }
        object.activityKind = activityKind;
        return object;
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.message, this.timestamp, this.jsonResponse};
        return Util.formatString("message:%s timestamp:%s json:%s", arrobject);
    }

}

