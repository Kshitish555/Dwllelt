/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  edu.umd.cs.findbugs.annotations.SuppressFBWarnings
 *  java.io.Serializable
 *  java.lang.AbstractMethodError
 *  java.lang.Class
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Type
 *  l.a.a
 *  l.a.b
 *  l.a.h.h.a
 *  l.a.h.h.a$c
 *  l.a.h.h.b
 *  l.a.h.i.a
 *  l.a.h.i.a$d
 *  l.a.h.i.b
 *  l.a.h.j.f
 *  l.a.h.j.f$b
 *  l.a.h.j.f$d
 *  l.a.h.j.g
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.i.b
 *  l.a.i.b$a
 *  l.a.i.b$a$c$c
 *  l.a.i.b$a$c$d$c
 *  l.a.i.b$a$c$e
 *  l.a.i.e
 *  l.a.j.e$g
 *  l.a.j.i
 *  l.a.j.o.a
 *  l.a.j.o.d$f
 *  l.a.j.o.d$g
 *  l.a.j.o.d$h
 *  l.a.j.q.c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.g
 *  l.a.j.q.h
 *  l.a.j.q.l.a
 *  l.a.j.q.l.c
 *  l.a.j.q.l.e
 *  l.a.k.a.r
 *  l.a.l.r
 *  l.a.l.r$a
 *  l.a.l.s
 *  l.a.l.x
 */
package l.a.j.o;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import java.io.Serializable;
import java.lang.reflect.Type;
import l.a.h.h.a;
import l.a.h.i.a;
import l.a.h.j.f;
import l.a.h.k.c;
import l.a.i.b;
import l.a.j.e;
import l.a.j.i;
import l.a.j.o.d;
import l.a.j.q.e;
import l.a.l.r;
import l.a.l.s;
import l.a.l.x;

/*
 * Exception performing whole class analysis.
 */
public class d
implements l.a.j.o.a {
    public static final String s = "make";
    public static final String t = "target";
    private final l.a.h.k.c c;
    private final e.g d;
    private final f f;
    private final boolean h;
    private final boolean o;

    public d(l.a.h.k.c c2, e.g g2, f f2, boolean bl, boolean bl2) {
        this.c = c2;
        this.d = g2;
        this.f = f2;
        this.h = bl;
        this.o = bl2;
    }

    static /* synthetic */ e.g a(d d2) {
        return d2.d;
    }

    static /* synthetic */ l.a.h.k.c b(d d2) {
        return d2.c;
    }

    static /* synthetic */ f c(d d2) {
        return d2.f;
    }

    public l.a.i.b a(String string, l.a.b b2, i i2) {
        l.a.a a2 = new l.a.a(b2);
        r.a a3 = this.h ? s.o() : s.M();
        b.a a4 = a2.a((r)a3).a((l.a.h.k.b)this.c).b(string).a(l.a.j.o.a.t0);
        Class[] arrclass = this.o ? new Class[]{Serializable.class} : new Class[]{};
        b.a.c.e e2 = a4.b((Type[])arrclass).a((r)s.a()).a((e)new /* Unavailable Anonymous Inner Class!! */);
        f.b[] arrb = new f.b[]{l.a.h.j.g.f};
        return e2.a(s, l.a.i.e.class, arrb).a((e)h.c).a();
    }

    protected boolean a(Object object) {
        return object instanceof d;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof d)) {
            return false;
        }
        d d2 = (d)object;
        if (!d2.a(this)) {
            return false;
        }
        l.a.h.k.c c2 = this.c;
        l.a.h.k.c c3 = d2.c;
        if (c2 == null ? c3 != null : !c2.equals((Object)c3)) {
            return false;
        }
        e.g g2 = this.d;
        e.g g3 = d2.d;
        if (g2 == null ? g3 != null : !g2.equals((Object)g3)) {
            return false;
        }
        f f2 = this.f;
        f f3 = d2.f;
        if (f2 == null ? f3 != null : !f2.equals((Object)f3)) {
            return false;
        }
        if (this.h != d2.h) {
            return false;
        }
        return this.o == d2.o;
    }

    public int hashCode() {
        l.a.h.k.c c2 = this.c;
        int n2 = 43;
        int n3 = c2 == null ? 43 : c2.hashCode();
        int n4 = n3 + 59;
        e.g g2 = this.d;
        int n5 = n4 * 59;
        int n6 = g2 == null ? 43 : g2.hashCode();
        int n7 = n5 + n6;
        f f2 = this.f;
        int n8 = n7 * 59;
        if (f2 != null) {
            n2 = f2.hashCode();
        }
        int n9 = 59 * (n8 + n2);
        boolean bl = this.h;
        int n10 = 79;
        int n11 = bl ? 79 : 97;
        int n12 = 59 * (n9 + n11);
        if (!this.o) {
            n10 = 97;
        }
        return n12 + n10;
    }

    protected static final class b
    extends Enum<b>
    implements l.a.j.q.e {
        public static final /* enum */ b d;
        private static final /* synthetic */ b[] f;
        private final l.a.j.q.e c;

        static {
            b b2;
            d = b2 = new b();
            f = new b[]{b2};
        }

        @SuppressFBWarnings(justification="Fields of enumerations are never serialized", value={"SE_BAD_FIELD_STORE"})
        private b() {
            c.d d2 = new c.d(AbstractMethodError.class);
            l.a.h.i.a a2 = (l.a.h.i.a)((l.a.h.i.b)d2.u().b((r)s.g().a((r)s.a((int)0)))).b1();
            l.a.j.q.e[] arre = new l.a.j.q.e[]{l.a.j.q.h.c((l.a.h.k.c)d2), l.a.j.q.c.h, l.a.j.q.l.c.a((l.a.h.i.a)a2), l.a.j.q.g.c};
            this.c = new e.a(arre);
        }

        public static b valueOf(String string) {
            return (b)Enum.valueOf(b.class, (String)string);
        }

        public static b[] values() {
            return (b[])f.clone();
        }

        public e.c a(l.a.k.a.r r2, e.d d2) {
            return this.c.a(r2, d2);
        }

        public boolean x() {
            return this.c.x();
        }
    }

    public static class c
    implements l.a.j.q.e {
        private final l.a.h.k.c c;
        private final e.g d;
        private final boolean f;

        public c(l.a.h.k.c c2, e.g g2, boolean bl) {
            this.c = c2;
            this.d = g2;
            this.f = bl;
        }

        public e.c a(l.a.k.a.r r2, e.d d2) {
            d d3 = new d(this.c, this.d, a.d, true, this.f);
            l.a.h.k.c c2 = d2.a(d3);
            l.a.j.q.e[] arre = new l.a.j.q.e[]{l.a.j.q.h.c((l.a.h.k.c)c2), l.a.j.q.c.h, l.a.j.q.l.c.a((a.d)((a.d)((l.a.h.i.b)c2.u().b((r)s.g())).b1())), l.a.j.q.c.h, l.a.j.q.l.e.c(), l.a.j.q.l.a.a((a.c)((a.c)((l.a.h.h.b)c2.q().b((r)s.m((String)d.t))).b1())).a()};
            return new e.a(arre).a(r2, d2);
        }

        protected boolean b(Object object) {
            return object instanceof c;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof c)) {
                return false;
            }
            c c2 = (c)object;
            if (!c2.b(this)) {
                return false;
            }
            l.a.h.k.c c3 = this.c;
            l.a.h.k.c c4 = c2.c;
            if (c3 == null ? c4 != null : !c3.equals((Object)c4)) {
                return false;
            }
            e.g g2 = this.d;
            e.g g3 = c2.d;
            if (g2 == null ? g3 != null : !g2.equals((Object)g3)) {
                return false;
            }
            return this.f == c2.f;
        }

        public int hashCode() {
            l.a.h.k.c c2 = this.c;
            int n2 = 43;
            int n3 = c2 == null ? 43 : c2.hashCode();
            int n4 = n3 + 59;
            e.g g2 = this.d;
            int n5 = n4 * 59;
            if (g2 != null) {
                n2 = g2.hashCode();
            }
            int n6 = 59 * (n5 + n2);
            int n7 = this.f ? 79 : 97;
            return n6 + n7;
        }

        public boolean x() {
            return true;
        }
    }

}

