/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Type
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import org.simpleframework.xml.core.CollectionFactory;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.Primitive;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;

class PrimitiveList
implements Converter {
    private final Type entry;
    private final CollectionFactory factory;
    private final String parent;
    private final Primitive root;

    public PrimitiveList(Context context, Type type, Type type2, String string2) {
        this.factory = new CollectionFactory(context, type);
        this.root = new Primitive(context, type2);
        this.parent = string2;
        this.entry = type2;
    }

    private boolean isOverridden(OutputNode outputNode, Object object) throws Exception {
        return this.factory.setOverride(this.entry, object, outputNode);
    }

    private Object populate(InputNode inputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        InputNode inputNode2;
        while ((inputNode2 = inputNode.getNext()) != null) {
            collection.add(this.root.read(inputNode2));
        }
        return collection;
    }

    private boolean validate(InputNode inputNode, Class class_) throws Exception {
        InputNode inputNode2;
        while ((inputNode2 = inputNode.getNext()) != null) {
            this.root.validate(inputNode2);
        }
        return true;
    }

    public Object read(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        Object object = instance.getInstance();
        if (!instance.isReference()) {
            return this.populate(inputNode, object);
        }
        return object;
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (instance.isReference()) {
            return instance.getInstance();
        }
        instance.setInstance(object);
        if (object != null) {
            return this.populate(inputNode, object);
        }
        return object;
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Instance instance = this.factory.getInstance(inputNode);
        if (!instance.isReference()) {
            instance.setInstance(null);
            return this.validate(inputNode, instance.getType());
        }
        return true;
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        for (Object object2 : (Collection)object) {
            OutputNode outputNode2;
            if (object2 == null || this.isOverridden(outputNode2 = outputNode.getChild(this.parent), object2)) continue;
            this.root.write(outputNode2, object2);
        }
    }
}

