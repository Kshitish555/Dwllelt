/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.reflect.Method
 *  java.util.Map
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Method;
import java.util.Map;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Session;

class Function {
    private final boolean contextual;
    private final Method method;

    public Function(Method method) {
        this(method, false);
    }

    public Function(Method method, boolean bl) {
        this.contextual = bl;
        this.method = method;
    }

    public Object call(Context context, Object object) throws Exception {
        if (object != null) {
            Map map = context.getSession().getMap();
            if (this.contextual) {
                return this.method.invoke(object, new Object[]{map});
            }
            return this.method.invoke(object, new Object[0]);
        }
        return null;
    }
}

