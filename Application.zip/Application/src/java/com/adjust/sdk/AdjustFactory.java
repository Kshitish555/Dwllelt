/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.adjust.sdk.ActivityHandler
 *  com.adjust.sdk.AdjustFactory$a
 *  com.adjust.sdk.AttributionHandler
 *  com.adjust.sdk.Logger
 *  com.adjust.sdk.PackageHandler
 *  com.adjust.sdk.RequestHandler
 *  com.adjust.sdk.SdkClickHandler
 *  com.adjust.sdk.UtilNetworking$a
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.net.URL
 *  java.net.URLConnection
 *  javax.net.ssl.HttpsURLConnection
 */
package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.ActivityHandler;
import com.adjust.sdk.AdjustConfig;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.AttributionHandler;
import com.adjust.sdk.BackoffStrategy;
import com.adjust.sdk.IActivityHandler;
import com.adjust.sdk.IAttributionHandler;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.IPackageHandler;
import com.adjust.sdk.IRequestHandler;
import com.adjust.sdk.ISdkClickHandler;
import com.adjust.sdk.Logger;
import com.adjust.sdk.PackageHandler;
import com.adjust.sdk.RequestHandler;
import com.adjust.sdk.SdkClickHandler;
import com.adjust.sdk.UtilNetworking;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import javax.net.ssl.HttpsURLConnection;

public class AdjustFactory {
    private static IActivityHandler activityHandler;
    private static IAttributionHandler attributionHandler;
    private static String baseUrl = "https://app.adjust.com";
    private static UtilNetworking.IConnectionOptions connectionOptions;
    private static String gdprUrl = "https://gdpr.adjust.com";
    private static HttpsURLConnection httpsURLConnection;
    private static ILogger logger;
    private static long maxDelayStart = -1L;
    private static IPackageHandler packageHandler;
    private static BackoffStrategy packageHandlerBackoffStrategy;
    private static IRequestHandler requestHandler;
    private static BackoffStrategy sdkClickBackoffStrategy;
    private static ISdkClickHandler sdkClickHandler;
    private static long sessionInterval = -1L;
    private static long subsessionInterval = -1L;
    private static long timerInterval = -1L;
    private static long timerStart = -1L;
    private static boolean tryInstallReferrer = true;

    static /* synthetic */ String access$000(byte[] arrby) {
        return AdjustFactory.byte2HexFormatted(arrby);
    }

    private static String byte2HexFormatted(byte[] arrby) {
        StringBuilder stringBuilder = new StringBuilder(2 * arrby.length);
        for (int i2 = 0; i2 < arrby.length; ++i2) {
            String string = Integer.toHexString((int)arrby[i2]);
            int n2 = string.length();
            if (n2 == 1) {
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("0");
                stringBuilder2.append(string);
                string = stringBuilder2.toString();
            }
            if (n2 > 2) {
                string = string.substring(n2 - 2, n2);
            }
            stringBuilder.append(string.toUpperCase());
        }
        return stringBuilder.toString();
    }

    public static IActivityHandler getActivityHandler(AdjustConfig adjustConfig) {
        IActivityHandler iActivityHandler = activityHandler;
        if (iActivityHandler == null) {
            return ActivityHandler.getInstance((AdjustConfig)adjustConfig);
        }
        iActivityHandler.init(adjustConfig);
        return activityHandler;
    }

    public static IAttributionHandler getAttributionHandler(IActivityHandler iActivityHandler, boolean bl) {
        IAttributionHandler iAttributionHandler = attributionHandler;
        if (iAttributionHandler == null) {
            return new AttributionHandler(iActivityHandler, bl);
        }
        iAttributionHandler.init(iActivityHandler, bl);
        return attributionHandler;
    }

    public static String getBaseUrl() {
        String string = baseUrl;
        if (string == null) {
            string = "https://app.adjust.com";
        }
        return string;
    }

    public static UtilNetworking.IConnectionOptions getConnectionOptions() {
        UtilNetworking.IConnectionOptions iConnectionOptions = connectionOptions;
        if (iConnectionOptions == null) {
            iConnectionOptions = new UtilNetworking.a();
        }
        return iConnectionOptions;
    }

    public static String getGdprUrl() {
        String string = gdprUrl;
        if (string == null) {
            string = "https://gdpr.adjust.com";
        }
        return string;
    }

    public static HttpsURLConnection getHttpsURLConnection(URL uRL) throws IOException {
        HttpsURLConnection httpsURLConnection = AdjustFactory.httpsURLConnection;
        if (httpsURLConnection == null) {
            return (HttpsURLConnection)uRL.openConnection();
        }
        return httpsURLConnection;
    }

    public static ILogger getLogger() {
        if (logger == null) {
            logger = new Logger();
        }
        return logger;
    }

    public static long getMaxDelayStart() {
        long l2 = maxDelayStart;
        if (l2 == -1L) {
            l2 = 10000L;
        }
        return l2;
    }

    public static IPackageHandler getPackageHandler(IActivityHandler iActivityHandler, Context context, boolean bl) {
        IPackageHandler iPackageHandler = packageHandler;
        if (iPackageHandler == null) {
            return new PackageHandler(iActivityHandler, context, bl);
        }
        iPackageHandler.init(iActivityHandler, context, bl);
        return packageHandler;
    }

    public static BackoffStrategy getPackageHandlerBackoffStrategy() {
        BackoffStrategy backoffStrategy = packageHandlerBackoffStrategy;
        if (backoffStrategy == null) {
            backoffStrategy = BackoffStrategy.LONG_WAIT;
        }
        return backoffStrategy;
    }

    public static IRequestHandler getRequestHandler(IActivityHandler iActivityHandler, IPackageHandler iPackageHandler) {
        IRequestHandler iRequestHandler = requestHandler;
        if (iRequestHandler == null) {
            return new RequestHandler(iActivityHandler, iPackageHandler);
        }
        iRequestHandler.init(iActivityHandler, iPackageHandler);
        return requestHandler;
    }

    public static BackoffStrategy getSdkClickBackoffStrategy() {
        BackoffStrategy backoffStrategy = sdkClickBackoffStrategy;
        if (backoffStrategy == null) {
            backoffStrategy = BackoffStrategy.SHORT_WAIT;
        }
        return backoffStrategy;
    }

    public static ISdkClickHandler getSdkClickHandler(IActivityHandler iActivityHandler, boolean bl) {
        ISdkClickHandler iSdkClickHandler = sdkClickHandler;
        if (iSdkClickHandler == null) {
            return new SdkClickHandler(iActivityHandler, bl);
        }
        iSdkClickHandler.init(iActivityHandler, bl);
        return sdkClickHandler;
    }

    public static long getSessionInterval() {
        long l2 = sessionInterval;
        if (l2 == -1L) {
            l2 = 1800000L;
        }
        return l2;
    }

    public static long getSubsessionInterval() {
        long l2 = subsessionInterval;
        if (l2 == -1L) {
            l2 = 1000L;
        }
        return l2;
    }

    public static long getTimerInterval() {
        long l2 = timerInterval;
        if (l2 == -1L) {
            l2 = 60000L;
        }
        return l2;
    }

    public static long getTimerStart() {
        long l2 = timerStart;
        if (l2 == -1L) {
            l2 = 60000L;
        }
        return l2;
    }

    public static boolean getTryInstallReferrer() {
        return tryInstallReferrer;
    }

    public static void setActivityHandler(IActivityHandler iActivityHandler) {
        activityHandler = iActivityHandler;
    }

    public static void setAttributionHandler(IAttributionHandler iAttributionHandler) {
        attributionHandler = iAttributionHandler;
    }

    public static void setBaseUrl(String string) {
        baseUrl = string;
    }

    public static void setGdprUrl(String string) {
        gdprUrl = string;
    }

    public static void setHttpsURLConnection(HttpsURLConnection httpsURLConnection) {
        AdjustFactory.httpsURLConnection = httpsURLConnection;
    }

    public static void setLogger(ILogger iLogger) {
        logger = iLogger;
    }

    public static void setPackageHandler(IPackageHandler iPackageHandler) {
        packageHandler = iPackageHandler;
    }

    public static void setPackageHandlerBackoffStrategy(BackoffStrategy backoffStrategy) {
        packageHandlerBackoffStrategy = backoffStrategy;
    }

    public static void setRequestHandler(IRequestHandler iRequestHandler) {
        requestHandler = iRequestHandler;
    }

    public static void setSdkClickBackoffStrategy(BackoffStrategy backoffStrategy) {
        sdkClickBackoffStrategy = backoffStrategy;
    }

    public static void setSdkClickHandler(ISdkClickHandler iSdkClickHandler) {
        sdkClickHandler = iSdkClickHandler;
    }

    public static void setSessionInterval(long l2) {
        sessionInterval = l2;
    }

    public static void setSubsessionInterval(long l2) {
        subsessionInterval = l2;
    }

    public static void setTimerInterval(long l2) {
        timerInterval = l2;
    }

    public static void setTimerStart(long l2) {
        timerStart = l2;
    }

    public static void setTryInstallReferrer(boolean bl) {
        tryInstallReferrer = bl;
    }

    public static void teardown(Context context) {
        if (context != null) {
            ActivityHandler.deleteState((Context)context);
            PackageHandler.deleteState((Context)context);
        }
        packageHandler = null;
        requestHandler = null;
        attributionHandler = null;
        activityHandler = null;
        logger = null;
        httpsURLConnection = null;
        sdkClickHandler = null;
        timerInterval = -1L;
        timerStart = -1L;
        sessionInterval = -1L;
        subsessionInterval = -1L;
        sdkClickBackoffStrategy = null;
        packageHandlerBackoffStrategy = null;
        maxDelayStart = -1L;
        baseUrl = "https://app.adjust.com";
        gdprUrl = "https://gdpr.adjust.com";
        connectionOptions = null;
        tryInstallReferrer = true;
    }

    public static void useTestConnectionOptions() {
        connectionOptions = new a();
    }

    public static class URLGetConnection {
        HttpsURLConnection httpsURLConnection;
        URL url;

        URLGetConnection(HttpsURLConnection httpsURLConnection, URL uRL) {
            this.httpsURLConnection = httpsURLConnection;
            this.url = uRL;
        }
    }

}

