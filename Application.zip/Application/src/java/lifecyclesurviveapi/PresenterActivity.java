/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.FragmentActivity
 *  java.lang.Object
 *  lifecyclesurviveapi.ComponentCacheActivity
 *  lifecyclesurviveapi.PresenterActivity$a
 *  lifecyclesurviveapi.h
 *  lifecyclesurviveapi.j
 *  lifecyclesurviveapi.k
 *  lifecyclesurviveapi.l
 *  lifecyclesurviveapi.m
 *  lifecyclesurviveapi.p
 */
package lifecyclesurviveapi;

import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import lifecyclesurviveapi.ComponentCacheActivity;
import lifecyclesurviveapi.PresenterActivity;
import lifecyclesurviveapi.h;
import lifecyclesurviveapi.j;
import lifecyclesurviveapi.k;
import lifecyclesurviveapi.l;
import lifecyclesurviveapi.m;
import lifecyclesurviveapi.p;

public abstract class PresenterActivity<C extends l<P>, P extends m>
extends ComponentCacheActivity {
    private j<C> f = new j();
    private p<P> h = new p();
    private k<C> o = new a(this);

    public C R1() {
        return (C)((l)this.f.a());
    }

    protected abstract C S1();

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f.a((h)this, bundle, this.o);
        this.h.a(this.R1().q0(), bundle);
    }

    protected void onDestroy() {
        AppCompatActivity.super.onDestroy();
        this.h.a(this.isFinishing());
        this.f.b();
    }

    protected void onResume() {
        FragmentActivity.super.onResume();
        this.f.c();
        this.h.c();
        this.h.a((Object)((Object)this));
        if (Build.VERSION.SDK_INT == 14) {
            this.supportInvalidateOptionsMenu();
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.f.a(bundle);
        this.h.a(bundle);
    }

    protected void onStop() {
        AppCompatActivity.super.onStop();
        this.h.b();
    }

    public P q0() {
        return (P)this.h.a();
    }
}

