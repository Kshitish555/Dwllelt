/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Set
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Group
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Group;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.Repeater;
import org.simpleframework.xml.core.UnionException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Style;

class CompositeListUnion
implements Repeater {
    private final Context context;
    private final LabelMap elements;
    private final Group group;
    private final Expression path;
    private final Style style;
    private final Type type;

    public CompositeListUnion(Context context, Group group, Expression expression, Type type) throws Exception {
        this.elements = group.getElements();
        this.style = context.getStyle();
        this.context = context;
        this.group = group;
        this.type = type;
        this.path = expression;
    }

    private Object readElement(InputNode inputNode) throws Exception {
        String string2 = inputNode.getName();
        String string3 = this.path.getElement(string2);
        return ((Label)this.elements.get((Object)string3)).getConverter(this.context).read(inputNode);
    }

    private Object readElement(InputNode inputNode, Object object) throws Exception {
        String string2 = inputNode.getName();
        String string3 = this.path.getElement(string2);
        return ((Label)this.elements.get((Object)string3)).getConverter(this.context).read(inputNode, object);
    }

    private Object readText(InputNode inputNode) throws Exception {
        return this.group.getText().getConverter(this.context).read(inputNode);
    }

    private Object readText(InputNode inputNode, Object object) throws Exception {
        return this.group.getText().getConverter(this.context).read(inputNode.getParent(), object);
    }

    private void write(OutputNode outputNode, Object object, Label label) throws Exception {
        Converter converter = label.getConverter(this.context);
        Set set = Collections.singleton((Object)object);
        if (!label.isInline()) {
            String string2 = label.getName();
            String string3 = this.style.getElement(string2);
            if (!outputNode.isCommitted()) {
                outputNode.setName(string3);
            }
        }
        converter.write(outputNode, (Object)set);
    }

    private void write(OutputNode outputNode, Collection collection) throws Exception {
        for (Object object : collection) {
            if (object == null) continue;
            Class class_ = object.getClass();
            Label label = this.group.getLabel(class_);
            if (label != null) {
                this.write(outputNode, object, label);
                continue;
            }
            Object[] arrobject = new Object[]{class_, this.type, this.group};
            throw new UnionException("Entry of %s not declared in %s with annotation %s", arrobject);
        }
    }

    public Object read(InputNode inputNode) throws Exception {
        if (this.group.getText() == null) {
            return this.readElement(inputNode);
        }
        return this.readText(inputNode);
    }

    @Override
    public Object read(InputNode inputNode, Object object) throws Exception {
        Object object2 = this.readElement(inputNode, object);
        if (this.group.getText() != null) {
            return this.readText(inputNode, object);
        }
        return object2;
    }

    public boolean validate(InputNode inputNode) throws Exception {
        String string2 = inputNode.getName();
        String string3 = this.path.getElement(string2);
        return ((Label)this.elements.get((Object)string3)).getConverter(this.context).validate(inputNode);
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Collection collection = (Collection)object;
        if (this.group.isInline()) {
            if (!collection.isEmpty()) {
                this.write(outputNode, collection);
                return;
            }
            if (!outputNode.isCommitted()) {
                outputNode.remove();
                return;
            }
        } else {
            this.write(outputNode, collection);
        }
    }
}

