/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collections
 *  java.util.Map
 *  java.util.Set
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Group
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 */
package org.simpleframework.xml.core;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Group;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.Repeater;
import org.simpleframework.xml.core.UnionException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Style;

class CompositeMapUnion
implements Repeater {
    private final Context context;
    private final LabelMap elements;
    private final Group group;
    private final Expression path;
    private final Style style;
    private final Type type;

    public CompositeMapUnion(Context context, Group group, Expression expression, Type type) throws Exception {
        this.elements = group.getElements();
        this.style = context.getStyle();
        this.context = context;
        this.group = group;
        this.type = type;
        this.path = expression;
    }

    private void write(OutputNode outputNode, Object object, Object object2, Label label) throws Exception {
        Converter converter = label.getConverter(this.context);
        Map map = Collections.singletonMap((Object)object, (Object)object2);
        if (!label.isInline()) {
            String string2 = label.getName();
            String string3 = this.style.getElement(string2);
            if (!outputNode.isCommitted()) {
                outputNode.setName(string3);
            }
        }
        converter.write(outputNode, (Object)map);
    }

    private void write(OutputNode outputNode, Map map) throws Exception {
        for (Object object : map.keySet()) {
            Object object2 = map.get(object);
            if (object2 == null) continue;
            Class class_ = object2.getClass();
            Label label = this.group.getLabel(class_);
            if (label != null) {
                this.write(outputNode, object, object2, label);
                continue;
            }
            Object[] arrobject = new Object[]{class_, this.type, this.group};
            throw new UnionException("Value of %s not declared in %s with annotation %s", arrobject);
        }
    }

    public Object read(InputNode inputNode) throws Exception {
        String string2 = inputNode.getName();
        String string3 = this.path.getElement(string2);
        return ((Label)this.elements.get((Object)string3)).getConverter(this.context).read(inputNode);
    }

    @Override
    public Object read(InputNode inputNode, Object object) throws Exception {
        String string2 = inputNode.getName();
        String string3 = this.path.getElement(string2);
        return ((Label)this.elements.get((Object)string3)).getConverter(this.context).read(inputNode, object);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        String string2 = inputNode.getName();
        String string3 = this.path.getElement(string2);
        return ((Label)this.elements.get((Object)string3)).getConverter(this.context).validate(inputNode);
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Map map = (Map)object;
        if (this.group.isInline()) {
            if (!map.isEmpty()) {
                this.write(outputNode, map);
                return;
            }
            if (!outputNode.isCommitted()) {
                outputNode.remove();
                return;
            }
        } else {
            this.write(outputNode, map);
        }
    }
}

