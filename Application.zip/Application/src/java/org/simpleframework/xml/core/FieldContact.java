/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Field
 *  java.lang.reflect.Modifier
 *  org.simpleframework.xml.core.Reflector
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Reflector;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.ConcurrentCache;

class FieldContact
implements Contact {
    private final Cache<Annotation> cache = new ConcurrentCache<Annotation>();
    private final Field field;
    private final Annotation label;
    private final Annotation[] list;
    private final int modifier;
    private final String name;

    public FieldContact(Field field, Annotation annotation, Annotation[] arrannotation) {
        this.modifier = field.getModifiers();
        this.name = field.getName();
        this.label = annotation;
        this.field = field;
        this.list = arrannotation;
    }

    private <T extends Annotation> T getCache(Class<T> class_) {
        if (this.cache.isEmpty()) {
            for (Annotation annotation : this.list) {
                Class class_2 = annotation.annotationType();
                this.cache.cache((Object)class_2, annotation);
            }
        }
        return (T)this.cache.fetch(class_);
    }

    @Override
    public Object get(Object object) throws Exception {
        return this.field.get(object);
    }

    @Override
    public Annotation getAnnotation() {
        return this.label;
    }

    @Override
    public <T extends Annotation> T getAnnotation(Class<T> class_) {
        if (class_ == this.label.annotationType()) {
            return (T)this.label;
        }
        return this.getCache(class_);
    }

    @Override
    public Class getDeclaringClass() {
        return this.field.getDeclaringClass();
    }

    @Override
    public Class getDependent() {
        return Reflector.getDependent((Field)this.field);
    }

    @Override
    public Class[] getDependents() {
        return Reflector.getDependents((Field)this.field);
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Class getType() {
        return this.field.getType();
    }

    public boolean isFinal() {
        return Modifier.isFinal((int)this.modifier);
    }

    @Override
    public boolean isReadOnly() {
        return !this.isStatic() && this.isFinal();
    }

    public boolean isStatic() {
        return Modifier.isStatic((int)this.modifier);
    }

    @Override
    public void set(Object object, Object object2) throws Exception {
        if (!this.isFinal()) {
            this.field.set(object, object2);
        }
    }

    @Override
    public String toString() {
        Object[] arrobject = new Object[]{this.getName(), this.field.toString()};
        return String.format((String)"field '%s' %s", (Object[])arrobject);
    }
}

