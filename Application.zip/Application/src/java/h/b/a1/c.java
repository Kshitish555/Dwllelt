/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.a1.b
 *  h.b.t0.f
 *  java.lang.Object
 */
package h.b.a1;

import h.b.a1.b;
import h.b.t0.f;

public interface c<T, R> {
    @f
    public R a(@f b<T> var1);
}

