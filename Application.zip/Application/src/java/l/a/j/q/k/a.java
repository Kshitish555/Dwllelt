/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.Void
 *  java.lang.reflect.Type
 *  l.a.b
 *  l.a.h.k.c
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 *  l.a.k.a.u
 */
package l.a.j.q.k;

import java.lang.reflect.Type;
import l.a.b;
import l.a.h.k.c;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;
import l.a.k.a.u;

public final class a
extends Enum<a>
implements e {
    public static final /* enum */ a P4;
    public static final /* enum */ a Q4;
    private static final e.c R4;
    private static final String S4 = "TYPE";
    private static final String T4 = "Ljava/lang/Class;";
    private static final /* synthetic */ a[] U4;
    public static final /* enum */ a d;
    public static final /* enum */ a f;
    public static final /* enum */ a h;
    public static final /* enum */ a o;
    public static final /* enum */ a s;
    public static final /* enum */ a t;
    public static final /* enum */ a w;
    private final String c;

    static {
        a a2;
        d = new a(Void.class);
        f = new a(Boolean.class);
        h = new a(Byte.class);
        o = new a(Short.class);
        s = new a(Character.class);
        t = new a(Integer.class);
        w = new a(Long.class);
        P4 = new a(Float.class);
        Q4 = a2 = new a(Double.class);
        a[] arra = new a[]{d, f, h, o, s, t, w, P4, a2};
        U4 = arra;
        R4 = f.f.f();
    }

    private a(Class<?> class_) {
        this.c = u.b(class_);
    }

    public static e c(c c2) {
        if (c2.a((Type)Void.TYPE)) {
            return d;
        }
        if (c2.a((Type)Boolean.TYPE)) {
            return f;
        }
        if (c2.a((Type)Byte.TYPE)) {
            return h;
        }
        if (c2.a((Type)Short.TYPE)) {
            return o;
        }
        if (c2.a((Type)Character.TYPE)) {
            return s;
        }
        if (c2.a((Type)Integer.TYPE)) {
            return t;
        }
        if (c2.a((Type)Long.TYPE)) {
            return w;
        }
        if (c2.a((Type)Float.TYPE)) {
            return P4;
        }
        if (c2.a((Type)Double.TYPE)) {
            return Q4;
        }
        return new a(c2);
    }

    public static a valueOf(String string) {
        return (a)Enum.valueOf(a.class, (String)string);
    }

    public static a[] values() {
        return (a[])U4.clone();
    }

    public e.c a(r r2, e.d d2) {
        r2.a(178, this.c, S4, T4);
        return R4;
    }

    public boolean x() {
        return true;
    }

    protected static class a
    implements e {
        private final c c;

        protected a(c c2) {
            this.c = c2;
        }

        public e.c a(r r2, e.d d2) {
            if (d2.f().b(b.t) && this.c.e(d2.c())) {
                r2.a((Object)u.f((String)this.c.getDescriptor()));
            } else {
                r2.a((Object)this.c.getName());
                r2.a(184, "java/lang/Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;", false);
            }
            return R4;
        }

        protected boolean b(Object object) {
            return object instanceof a;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof a)) {
                return false;
            }
            a a2 = (a)object;
            if (!a2.b(this)) {
                return false;
            }
            c c2 = this.c;
            c c3 = a2.c;
            return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
        }

        public int hashCode() {
            c c2 = this.c;
            int n2 = c2 == null ? 43 : c2.hashCode();
            return 59 + n2;
        }

        public boolean x() {
            return true;
        }
    }

}

