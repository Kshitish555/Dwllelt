/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Void
 *  java.lang.reflect.Type
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.j.q.e
 *  l.a.j.q.i.a
 *  l.a.j.q.i.a$d
 */
package l.a.j.q.i.c;

import java.lang.reflect.Type;
import l.a.h.k.b;
import l.a.h.k.c;
import l.a.j.q.d;
import l.a.j.q.e;
import l.a.j.q.i.a;

public class e
implements a {
    private final a c;

    public e(a a2) {
        this.c = a2;
    }

    public l.a.j.q.e a(c.f f2, c.f f3, a.d d2) {
        if (f2.a((Type)Void.TYPE) && f3.a((Type)Void.TYPE)) {
            return e.d.c;
        }
        if (f2.a((Type)Void.TYPE)) {
            if (d2.c()) {
                return l.a.j.q.k.b.a((b)f3);
            }
            return e.b.c;
        }
        if (f3.a((Type)Void.TYPE)) {
            return d.a((b)f2);
        }
        return this.c.a(f2, f3, d2);
    }

    protected boolean a(Object object) {
        return object instanceof e;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof e)) {
            return false;
        }
        e e2 = (e)object;
        if (!e2.a(this)) {
            return false;
        }
        a a2 = this.c;
        a a3 = e2.c;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public int hashCode() {
        a a2 = this.c;
        int n2 = a2 == null ? 43 : a2.hashCode();
        return 59 + n2;
    }
}

