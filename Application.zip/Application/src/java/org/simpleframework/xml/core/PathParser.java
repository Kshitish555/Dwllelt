/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Character
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.Format
 *  org.simpleframework.xml.stream.Style
 *  org.simpleframework.xml.util.Cache
 */
package org.simpleframework.xml.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.PathException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.Format;
import org.simpleframework.xml.stream.Style;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.ConcurrentCache;

class PathParser
implements Expression {
    protected boolean attribute;
    protected Cache<String> attributes = new ConcurrentCache<String>();
    protected StringBuilder builder = new StringBuilder();
    protected String cache;
    protected int count;
    protected char[] data;
    protected Cache<String> elements = new ConcurrentCache<String>();
    protected List<Integer> indexes = new ArrayList();
    protected String location;
    protected List<String> names = new ArrayList();
    protected int off;
    protected String path;
    protected List<String> prefixes = new ArrayList();
    protected int start;
    protected Style style;
    protected Type type;

    public PathParser(String string2, Type type, Format format) throws Exception {
        this.style = format.getStyle();
        this.type = type;
        this.path = string2;
        this.parse(string2);
    }

    private void align() throws Exception {
        if (this.names.size() > this.indexes.size()) {
            this.indexes.add((Object)1);
        }
    }

    private void attribute() throws Exception {
        PathException pathException;
        int n;
        int n2;
        this.off = n = 1 + this.off;
        while ((n2 = this.off) < this.count) {
            char[] arrc = this.data;
            this.off = n2 + 1;
            char c = arrc[n2];
            if (this.isValid(c)) continue;
            Object[] arrobject = new Object[]{Character.valueOf((char)c), this.path, this.type};
            throw new PathException("Illegal character '%s' in attribute for '%s' in %s", arrobject);
        }
        if (n2 > n) {
            this.attribute = true;
            this.attribute(n, n2 - n);
            return;
        }
        Object[] arrobject = new Object[]{this.path, this.type};
        pathException = new PathException("Attribute reference in '%s' for %s is empty", arrobject);
        throw pathException;
    }

    private void attribute(int n, int n2) {
        String string2 = new String(this.data, n, n2);
        if (n2 > 0) {
            this.attribute(string2);
        }
    }

    private void attribute(String string2) {
        String string3 = this.style.getAttribute(string2);
        this.prefixes.add(null);
        this.names.add((Object)string3);
    }

    private void build() {
        int n = this.names.size();
        int n2 = n - 1;
        for (int i = 0; i < n; ++i) {
            String string2 = (String)this.prefixes.get(i);
            String string3 = (String)this.names.get(i);
            int n3 = (Integer)this.indexes.get(i);
            if (i > 0) {
                this.builder.append('/');
            }
            if (this.attribute && i == n2) {
                this.builder.append('@');
                this.builder.append(string3);
                continue;
            }
            if (string2 != null) {
                this.builder.append(string2);
                this.builder.append(':');
            }
            this.builder.append(string3);
            this.builder.append('[');
            this.builder.append(n3);
            this.builder.append(']');
        }
        this.location = this.builder.toString();
    }

    private void element() throws Exception {
        int n;
        int n2 = this.off;
        int n3 = 0;
        while ((n = this.off) < this.count) {
            char[] arrc = this.data;
            this.off = n + 1;
            char c = arrc[n];
            if (!this.isValid(c)) {
                if (c == '@') {
                    --this.off;
                    break;
                }
                if (c == '[') {
                    this.index();
                    break;
                }
                if (c == '/') break;
                Object[] arrobject = new Object[]{Character.valueOf((char)c), this.path, this.type};
                throw new PathException("Illegal character '%s' in element for '%s' in %s", arrobject);
            }
            ++n3;
        }
        this.element(n2, n3);
    }

    private void element(int n, int n2) {
        String string2 = new String(this.data, n, n2);
        if (n2 > 0) {
            this.element(string2);
        }
    }

    private void element(String string2) {
        String string3;
        int n = string2.indexOf(58);
        if (n > 0) {
            string3 = string2.substring(0, n);
            string2 = string2.substring(n + 1);
        } else {
            string3 = null;
        }
        String string4 = this.style.getElement(string2);
        this.prefixes.add((Object)string3);
        this.names.add((Object)string4);
    }

    private void index() throws Exception {
        PathException pathException;
        int n;
        if (this.data[this.off - 1] == '[') {
            int n2;
            n = 0;
            while ((n2 = this.off) < this.count) {
                char[] arrc = this.data;
                this.off = n2 + 1;
                char c = arrc[n2];
                if (this.isDigit(c)) {
                    n = -48 + (c + n * 10);
                    continue;
                }
                break;
            }
        } else {
            n = 0;
        }
        char[] arrc = this.data;
        int n3 = this.off;
        this.off = n3 + 1;
        if (arrc[n3 - 1] == ']') {
            this.indexes.add((Object)n);
            return;
        }
        Object[] arrobject = new Object[]{this.path, this.type};
        pathException = new PathException("Invalid index for path '%s' in %s", arrobject);
        throw pathException;
    }

    private boolean isDigit(char c) {
        return Character.isDigit((char)c);
    }

    private boolean isEmpty(String string2) {
        return string2 == null || string2.length() == 0;
        {
        }
    }

    private boolean isLetter(char c) {
        return Character.isLetterOrDigit((char)c);
    }

    private boolean isSpecial(char c) {
        return c == '_' || c == '-' || c == ':';
        {
        }
    }

    private boolean isValid(char c) {
        return this.isLetter(c) || this.isSpecial(c);
        {
        }
    }

    private void parse(String string2) throws Exception {
        if (string2 != null) {
            int n;
            this.count = n = string2.length();
            char[] arrc = new char[n];
            this.data = arrc;
            string2.getChars(0, n, arrc, 0);
        }
        this.path();
    }

    private void path() throws Exception {
        PathException pathException;
        char[] arrc = this.data;
        int n = this.off;
        if (arrc[n] != '/') {
            if (arrc[n] == '.') {
                this.skip();
            }
            while (this.off < this.count) {
                if (!this.attribute) {
                    this.segment();
                    continue;
                }
                Object[] arrobject = new Object[]{this.path, this.type};
                throw new PathException("Path '%s' in %s references an invalid attribute", arrobject);
            }
            this.truncate();
            this.build();
            return;
        }
        Object[] arrobject = new Object[]{this.path, this.type};
        pathException = new PathException("Path '%s' in %s references document root", arrobject);
        throw pathException;
    }

    private void segment() throws Exception {
        char c = this.data[this.off];
        if (c != '/') {
            if (c == '@') {
                this.attribute();
            } else {
                this.element();
            }
            this.align();
            return;
        }
        Object[] arrobject = new Object[]{this.path, this.type};
        throw new PathException("Invalid path expression '%s' in %s", arrobject);
    }

    private void skip() throws Exception {
        int n;
        char[] arrc = this.data;
        if (arrc.length > 1) {
            int n2 = this.off;
            if (arrc[n2 + 1] == '/') {
                this.off = n2 + 1;
            } else {
                Object[] arrobject = new Object[]{this.path, this.type};
                throw new PathException("Path '%s' in %s has an illegal syntax", arrobject);
            }
        }
        this.off = n = 1 + this.off;
        this.start = n;
    }

    private void truncate() throws Exception {
        int n = this.off;
        int n2 = n - 1;
        char[] arrc = this.data;
        if (n2 >= arrc.length) {
            this.off = n - 1;
            return;
        }
        if (arrc[n - 1] == '/') {
            this.off = n - 1;
        }
    }

    public String getAttribute(String string2) {
        if (!this.isEmpty(this.location)) {
            String string3 = (String)this.attributes.fetch((Object)string2);
            if (string3 == null && (string3 = this.getAttributePath(this.location, string2)) != null) {
                this.attributes.cache((Object)string2, (Object)string3);
            }
            return string3;
        }
        return this.style.getAttribute(string2);
    }

    protected String getAttributePath(String string2, String string3) {
        String string4 = this.style.getAttribute(string3);
        if (this.isEmpty(string2)) {
            return string4;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append("/@");
        stringBuilder.append(string4);
        return stringBuilder.toString();
    }

    public String getElement(String string2) {
        if (!this.isEmpty(this.location)) {
            String string3 = (String)this.elements.fetch((Object)string2);
            if (string3 == null && (string3 = this.getElementPath(this.location, string2)) != null) {
                this.elements.cache((Object)string2, (Object)string3);
            }
            return string3;
        }
        return this.style.getElement(string2);
    }

    protected String getElementPath(String string2, String string3) {
        String string4 = this.style.getElement(string3);
        if (this.isEmpty(string4)) {
            return string2;
        }
        if (this.isEmpty(string2)) {
            return string4;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append("/");
        stringBuilder.append(string4);
        stringBuilder.append("[1]");
        return stringBuilder.toString();
    }

    public String getFirst() {
        return (String)this.names.get(0);
    }

    public int getIndex() {
        return (Integer)this.indexes.get(0);
    }

    public String getLast() {
        int n = -1 + this.names.size();
        return (String)this.names.get(n);
    }

    public String getPath() {
        return this.location;
    }

    public Expression getPath(int n) {
        return this.getPath(n, 0);
    }

    public Expression getPath(int n, int n2) {
        int n3 = -1 + this.names.size() - n2;
        if (n3 >= n) {
            return new PathSection(n, n3);
        }
        return new PathSection(n, n);
    }

    public String getPrefix() {
        return (String)this.prefixes.get(0);
    }

    public boolean isAttribute() {
        return this.attribute;
    }

    public boolean isEmpty() {
        return this.isEmpty(this.location);
    }

    public boolean isPath() {
        return this.names.size() > 1;
    }

    public Iterator<String> iterator() {
        return this.names.iterator();
    }

    public String toString() {
        int n = this.off - this.start;
        if (this.cache == null) {
            this.cache = new String(this.data, this.start, n);
        }
        return this.cache;
    }

    private class PathSection
    implements Expression {
        private int begin;
        private List<String> cache = new ArrayList();
        private int end;
        private String path;
        private String section;

        public PathSection(int n, int n2) {
            this.begin = n;
            this.end = n2;
        }

        private String getCanonicalPath() {
            int n;
            int n2 = 0;
            for (n = 0; n < this.begin; ++n) {
                n2 = PathParser.this.location.indexOf(47, n2 + 1);
            }
            int n3 = n2;
            while (n <= this.end) {
                if ((n3 = PathParser.this.location.indexOf(47, n3 + 1)) == -1) {
                    n3 = PathParser.this.location.length();
                }
                ++n;
            }
            return PathParser.this.location.substring(n2 + 1, n3);
        }

        private String getFragment() {
            int n = PathParser.this.start;
            int n2 = 0;
            int n3 = 0;
            while (n2 <= this.end) {
                PathParser pathParser = PathParser.this;
                if (n >= pathParser.count) {
                    ++n;
                    break;
                }
                char[] arrc = pathParser.data;
                int n4 = n + 1;
                if (arrc[n] == '/' && ++n2 == this.begin) {
                    n3 = n = n4;
                    continue;
                }
                n = n4;
            }
            return new String(PathParser.this.data, n3, n - 1 - n3);
        }

        public String getAttribute(String string2) {
            String string3 = this.getPath();
            if (string3 != null) {
                string2 = PathParser.this.getAttributePath(string3, string2);
            }
            return string2;
        }

        public String getElement(String string2) {
            String string3 = this.getPath();
            if (string3 != null) {
                string2 = PathParser.this.getElementPath(string3, string2);
            }
            return string2;
        }

        public String getFirst() {
            return (String)PathParser.this.names.get(this.begin);
        }

        public int getIndex() {
            return (Integer)PathParser.this.indexes.get(this.begin);
        }

        public String getLast() {
            return (String)PathParser.this.names.get(this.end);
        }

        public String getPath() {
            if (this.section == null) {
                this.section = this.getCanonicalPath();
            }
            return this.section;
        }

        public Expression getPath(int n) {
            return this.getPath(n, 0);
        }

        public Expression getPath(int n, int n2) {
            return new PathSection(n + this.begin, this.end - n2);
        }

        public String getPrefix() {
            return (String)PathParser.this.prefixes.get(this.begin);
        }

        public boolean isAttribute() {
            PathParser pathParser = PathParser.this;
            boolean bl = pathParser.attribute;
            boolean bl2 = false;
            if (bl) {
                int n = this.end;
                int n2 = pathParser.names.size() - 1;
                bl2 = false;
                if (n >= n2) {
                    bl2 = true;
                }
            }
            return bl2;
        }

        public boolean isEmpty() {
            return this.begin == this.end;
        }

        public boolean isPath() {
            return this.end - this.begin >= 1;
        }

        public Iterator<String> iterator() {
            if (this.cache.isEmpty()) {
                for (int i = this.begin; i <= this.end; ++i) {
                    String string2 = (String)PathParser.this.names.get(i);
                    if (string2 == null) continue;
                    this.cache.add((Object)string2);
                }
            }
            return this.cache.iterator();
        }

        public String toString() {
            if (this.path == null) {
                this.path = this.getFragment();
            }
            return this.path;
        }
    }

}

