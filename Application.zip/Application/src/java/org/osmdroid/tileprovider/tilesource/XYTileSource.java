/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase
 *  org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
 */
package org.osmdroid.tileprovider.tilesource;

import org.osmdroid.ResourceProxy;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;

public class XYTileSource
extends OnlineTileSourceBase {
    public /* varargs */ XYTileSource(String string2, ResourceProxy.string string3, int n2, int n3, int n4, String string4, String ... arrstring) {
        super(string2, string3, n2, n3, n4, string4, arrstring);
    }

    public String getTileURLString(MapTile mapTile) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getBaseUrl());
        stringBuilder.append(mapTile.getZoomLevel());
        stringBuilder.append("/");
        stringBuilder.append(mapTile.getX());
        stringBuilder.append("/");
        stringBuilder.append(mapTile.getY());
        stringBuilder.append(((BitmapTileSourceBase)this).mImageFilenameEnding);
        return stringBuilder.toString();
    }
}

