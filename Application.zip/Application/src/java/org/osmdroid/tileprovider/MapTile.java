/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package org.osmdroid.tileprovider;

public class MapTile {
    public static final int MAPTILE_FAIL_ID = 1;
    public static final int MAPTILE_SUCCESS_ID;
    private final int x;
    private final int y;
    private final int zoomLevel;

    public MapTile(int n2, int n3, int n4) {
        this.zoomLevel = n2;
        this.x = n3;
        this.y = n4;
    }

    public boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (object == this) {
            return true;
        }
        if (!(object instanceof MapTile)) {
            return false;
        }
        MapTile mapTile = (MapTile)object;
        int n2 = this.zoomLevel;
        int n3 = mapTile.zoomLevel;
        boolean bl = false;
        if (n2 == n3) {
            int n4 = this.x;
            int n5 = mapTile.x;
            bl = false;
            if (n4 == n5) {
                int n6 = this.y;
                int n7 = mapTile.y;
                bl = false;
                if (n6 == n7) {
                    bl = true;
                }
            }
        }
        return bl;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getZoomLevel() {
        return this.zoomLevel;
    }

    public int hashCode() {
        return 17 * (37 + this.zoomLevel) * (37 + this.x) * (37 + this.y);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("/");
        stringBuilder.append(this.zoomLevel);
        stringBuilder.append("/");
        stringBuilder.append(this.x);
        stringBuilder.append("/");
        stringBuilder.append(this.y);
        return stringBuilder.toString();
    }
}

