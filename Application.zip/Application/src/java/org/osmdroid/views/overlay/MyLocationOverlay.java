/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Picture
 *  android.graphics.Point
 *  android.graphics.PointF
 *  android.graphics.drawable.Drawable
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.location.Location
 *  android.location.LocationListener
 *  android.location.LocationManager
 *  android.os.Bundle
 *  android.view.Display
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.MotionEvent
 *  android.view.WindowManager
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.util.Iterator
 *  java.util.LinkedList
 *  microsoft.mappoint.TileSystem
 *  org.osmdroid.LocationListenerProxy
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$bitmap
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.SensorEventListenerProxy
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IMapController
 *  org.osmdroid.api.IMapView
 *  org.osmdroid.api.IMyLocationOverlay
 *  org.osmdroid.api.IProjection
 *  org.osmdroid.views.overlay.IOverlayMenuProvider
 *  org.osmdroid.views.overlay.Overlay$Snappable
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.views.overlay;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Picture;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.WindowManager;
import java.util.Iterator;
import java.util.LinkedList;
import microsoft.mappoint.TileSystem;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.LocationListenerProxy;
import org.osmdroid.ResourceProxy;
import org.osmdroid.SensorEventListenerProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IMapController;
import org.osmdroid.api.IMapView;
import org.osmdroid.api.IMyLocationOverlay;
import org.osmdroid.api.IProjection;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.LocationUtils;
import org.osmdroid.util.NetworkLocationIgnorer;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.IOverlayMenuProvider;
import org.osmdroid.views.overlay.Overlay;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MyLocationOverlay
extends Overlay
implements IMyLocationOverlay,
IOverlayMenuProvider,
SensorEventListener,
LocationListener,
Overlay.Snappable {
    public static final int MENU_COMPASS;
    public static final int MENU_MY_LOCATION;
    private static final Logger logger;
    protected final float COMPASS_FRAME_CENTER_X;
    protected final float COMPASS_FRAME_CENTER_Y;
    protected final float COMPASS_ROSE_CENTER_X;
    protected final float COMPASS_ROSE_CENTER_Y;
    protected final Bitmap DIRECTION_ARROW;
    protected final float DIRECTION_ARROW_CENTER_X;
    protected final float DIRECTION_ARROW_CENTER_Y;
    protected final PointF PERSON_HOTSPOT;
    protected final Bitmap PERSON_ICON;
    private final Matrix directionRotater = new Matrix();
    private float mAzimuth = Float.NaN;
    protected final Paint mCirclePaint = new Paint();
    private float mCompassCenterX = 35.0f;
    private float mCompassCenterY = 35.0f;
    protected final Picture mCompassFrame = new Picture();
    private final Matrix mCompassMatrix = new Matrix();
    private final float mCompassRadius = 20.0f;
    protected final Picture mCompassRose = new Picture();
    private final Display mDisplay;
    protected boolean mDrawAccuracyEnabled = true;
    protected boolean mFollow = false;
    private final NetworkLocationIgnorer mIgnorer = new NetworkLocationIgnorer();
    private Location mLocation;
    public LocationListenerProxy mLocationListener = null;
    private final LocationManager mLocationManager;
    private float mLocationUpdateMinDistance = 0.0f;
    private long mLocationUpdateMinTime = 0L;
    private final MapController mMapController;
    private final Point mMapCoords = new Point();
    protected final MapView mMapView;
    private final Matrix mMatrix = new Matrix();
    private final float[] mMatrixValues = new float[9];
    private final GeoPoint mMyLocation = new GeoPoint(0, 0);
    private boolean mOptionsMenuEnabled = true;
    protected final Paint mPaint = new Paint();
    private final LinkedList<Runnable> mRunOnFirstFix = new LinkedList();
    public SensorEventListenerProxy mSensorListener = null;
    private final SensorManager mSensorManager;

    static {
        logger = LoggerFactory.getLogger(MyLocationOverlay.class);
        MENU_MY_LOCATION = Overlay.getSafeMenuId();
        MENU_COMPASS = Overlay.getSafeMenuId();
    }

    public MyLocationOverlay(Context context, MapView mapView) {
        this(context, mapView, new DefaultResourceProxyImpl(context));
    }

    public MyLocationOverlay(Context context, MapView mapView, ResourceProxy resourceProxy) {
        Bitmap bitmap2;
        super(resourceProxy);
        this.mMapView = mapView;
        this.mLocationManager = (LocationManager)context.getSystemService("location");
        this.mSensorManager = (SensorManager)context.getSystemService("sensor");
        this.mDisplay = ((WindowManager)context.getSystemService("window")).getDefaultDisplay();
        this.mMapController = mapView.getController();
        this.mCirclePaint.setARGB(0, 100, 100, 255);
        this.mCirclePaint.setAntiAlias(true);
        this.PERSON_ICON = this.mResourceProxy.getBitmap(ResourceProxy.bitmap.person);
        this.DIRECTION_ARROW = bitmap2 = this.mResourceProxy.getBitmap(ResourceProxy.bitmap.direction_arrow);
        this.DIRECTION_ARROW_CENTER_X = (float)(bitmap2.getWidth() / 2) - 0.5f;
        this.DIRECTION_ARROW_CENTER_Y = (float)(this.DIRECTION_ARROW.getHeight() / 2) - 0.5f;
        float f2 = this.mScale;
        this.PERSON_HOTSPOT = new PointF(0.5f + 24.0f * f2, 0.5f + f2 * 39.0f);
        this.createCompassFramePicture();
        this.createCompassRosePicture();
        this.COMPASS_FRAME_CENTER_X = (float)(this.mCompassFrame.getWidth() / 2) - 0.5f;
        this.COMPASS_FRAME_CENTER_Y = (float)(this.mCompassFrame.getHeight() / 2) - 0.5f;
        this.COMPASS_ROSE_CENTER_X = (float)(this.mCompassRose.getWidth() / 2) - 0.5f;
        this.COMPASS_ROSE_CENTER_Y = (float)(this.mCompassRose.getHeight() / 2) - 0.5f;
    }

    private Point calculatePointOnCircle(float f2, float f3, float f4, float f5) {
        double d2 = Math.toRadians((double)(90.0f + -f5));
        double d3 = f4;
        double d4 = Math.cos((double)d2);
        Double.isNaN((double)d3);
        int n2 = (int)(d4 * d3);
        double d5 = Math.sin((double)d2);
        Double.isNaN((double)d3);
        int n3 = (int)(d3 * d5);
        return new Point(n2 + (int)f2, (int)f3 - n3);
    }

    private void createCompassFramePicture() {
        Paint paint = new Paint();
        paint.setColor(-1);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(200);
        Paint paint2 = new Paint();
        paint2.setColor(-7829368);
        paint2.setAntiAlias(true);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeWidth(2.0f);
        paint2.setAlpha(200);
        Canvas canvas = this.mCompassFrame.beginRecording(50, 50);
        canvas.drawCircle(25.0f, 25.0f, 20.0f * this.mScale, paint);
        canvas.drawCircle(25.0f, 25.0f, 20.0f * this.mScale, paint2);
        this.drawTriangle(canvas, 25.0f, 25.0f, 20.0f * this.mScale, 0.0f, paint2);
        this.drawTriangle(canvas, 25.0f, 25.0f, 20.0f * this.mScale, 90.0f, paint2);
        this.drawTriangle(canvas, 25.0f, 25.0f, 20.0f * this.mScale, 180.0f, paint2);
        this.drawTriangle(canvas, 25.0f, 25.0f, 20.0f * this.mScale, 270.0f, paint2);
        this.mCompassFrame.endRecording();
    }

    private void createCompassRosePicture() {
        Paint paint = new Paint();
        paint.setColor(-6291456);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(220);
        Paint paint2 = new Paint();
        paint2.setColor(-16777216);
        paint2.setAntiAlias(true);
        paint2.setStyle(Paint.Style.FILL);
        paint2.setAlpha(220);
        Paint paint3 = new Paint();
        paint3.setColor(-1);
        paint3.setAntiAlias(true);
        paint3.setStyle(Paint.Style.FILL);
        paint3.setAlpha(220);
        Canvas canvas = this.mCompassRose.beginRecording(50, 50);
        Path path = new Path();
        path.moveTo(25.0f, 25.0f - 17.0f * this.mScale);
        path.lineTo(25.0f + 4.0f * this.mScale, 25.0f);
        path.lineTo(25.0f - 4.0f * this.mScale, 25.0f);
        path.lineTo(25.0f, 25.0f - 17.0f * this.mScale);
        path.close();
        canvas.drawPath(path, paint);
        Path path2 = new Path();
        path2.moveTo(25.0f, 25.0f + 17.0f * this.mScale);
        path2.lineTo(25.0f + 4.0f * this.mScale, 25.0f);
        path2.lineTo(25.0f - 4.0f * this.mScale, 25.0f);
        path2.lineTo(25.0f, 25.0f + 17.0f * this.mScale);
        path2.close();
        canvas.drawPath(path2, paint2);
        canvas.drawCircle(25.0f, 25.0f, 2.0f, paint3);
        this.mCompassRose.endRecording();
    }

    private void drawTriangle(Canvas canvas, float f2, float f3, float f4, float f5, Paint paint) {
        canvas.save();
        Point point = this.calculatePointOnCircle(f2, f3, f4, f5);
        canvas.rotate(f5, (float)point.x, (float)point.y);
        Path path = new Path();
        path.moveTo((float)point.x - 2.0f * this.mScale, (float)point.y);
        path.lineTo((float)point.x + 2.0f * this.mScale, (float)point.y);
        path.lineTo((float)point.x, (float)point.y - 5.0f * this.mScale);
        path.close();
        canvas.drawPath(path, paint);
        canvas.restore();
    }

    private int getDisplayOrientation() {
        int n2 = this.mDisplay.getOrientation();
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    return 0;
                }
                return 270;
            }
            return 180;
        }
        return 90;
    }

    public void disableCompass() {
        SensorEventListenerProxy sensorEventListenerProxy = this.mSensorListener;
        if (sensorEventListenerProxy != null) {
            sensorEventListenerProxy.stopListening();
        }
        this.mSensorListener = null;
        this.mAzimuth = Float.NaN;
        MapView mapView = this.mMapView;
        if (mapView != null) {
            mapView.postInvalidate();
        }
    }

    public void disableFollowLocation() {
        this.mFollow = false;
    }

    public void disableMyLocation() {
        LocationListenerProxy locationListenerProxy = this.mLocationListener;
        if (locationListenerProxy != null) {
            locationListenerProxy.stopListening();
        }
        this.mLocationListener = null;
        MapView mapView = this.mMapView;
        if (mapView != null) {
            mapView.postInvalidate();
        }
    }

    @Override
    public void draw(Canvas canvas, MapView mapView, boolean bl) {
        if (bl) {
            return;
        }
        Location location = this.mLocation;
        if (location != null) {
            this.mMyLocation.setCoordsE6((int)(1000000.0 * location.getLatitude()), (int)(1000000.0 * this.mLocation.getLongitude()));
            this.drawMyLocation(canvas, mapView, this.mLocation, this.mMyLocation);
        }
        if (this.isCompassEnabled() && !Float.isNaN((float)this.mAzimuth)) {
            this.drawCompass(canvas, this.mAzimuth + (float)this.getDisplayOrientation());
        }
    }

    protected void drawCompass(Canvas canvas, float f2) {
        float f3 = this.mCompassCenterX;
        float f4 = this.mScale;
        float f5 = f3 * f4;
        float f6 = f4 * this.mCompassCenterY + (float)(canvas.getHeight() - this.mMapView.getHeight());
        this.mCompassMatrix.setTranslate(-this.COMPASS_FRAME_CENTER_X, -this.COMPASS_FRAME_CENTER_Y);
        this.mCompassMatrix.postTranslate(f5, f6);
        canvas.save();
        canvas.setMatrix(this.mCompassMatrix);
        canvas.drawPicture(this.mCompassFrame);
        this.mCompassMatrix.setRotate(-f2, this.COMPASS_ROSE_CENTER_X, this.COMPASS_ROSE_CENTER_Y);
        this.mCompassMatrix.postTranslate(-this.COMPASS_ROSE_CENTER_X, -this.COMPASS_ROSE_CENTER_Y);
        this.mCompassMatrix.postTranslate(f5, f6);
        canvas.setMatrix(this.mCompassMatrix);
        canvas.drawPicture(this.mCompassRose);
        canvas.restore();
    }

    protected void drawMyLocation(Canvas canvas, MapView mapView, Location location, GeoPoint geoPoint) {
        mapView.getProjection().toMapPixels(this.mMyLocation, this.mMapCoords);
        if (this.mDrawAccuracyEnabled) {
            float f2 = location.getAccuracy() / (float)TileSystem.GroundResolution((double)location.getLatitude(), (int)mapView.getZoomLevel());
            this.mCirclePaint.setAlpha(50);
            this.mCirclePaint.setStyle(Paint.Style.FILL);
            Point point = this.mMapCoords;
            canvas.drawCircle((float)point.x, (float)point.y, f2, this.mCirclePaint);
            this.mCirclePaint.setAlpha(150);
            this.mCirclePaint.setStyle(Paint.Style.STROKE);
            Point point2 = this.mMapCoords;
            canvas.drawCircle((float)point2.x, (float)point2.y, f2, this.mCirclePaint);
        }
        canvas.getMatrix(this.mMatrix);
        this.mMatrix.getValues(this.mMatrixValues);
        if (location.hasBearing()) {
            this.directionRotater.setRotate(location.getBearing(), this.DIRECTION_ARROW_CENTER_X, this.DIRECTION_ARROW_CENTER_Y);
            this.directionRotater.postTranslate(-this.DIRECTION_ARROW_CENTER_X, -this.DIRECTION_ARROW_CENTER_Y);
            Matrix matrix = this.directionRotater;
            float[] arrf = this.mMatrixValues;
            matrix.postScale(1.0f / arrf[0], 1.0f / arrf[4]);
            Matrix matrix2 = this.directionRotater;
            Point point = this.mMapCoords;
            matrix2.postTranslate((float)point.x, (float)point.y);
            canvas.drawBitmap(this.DIRECTION_ARROW, this.directionRotater, this.mPaint);
            return;
        }
        Matrix matrix = this.directionRotater;
        PointF pointF = this.PERSON_HOTSPOT;
        matrix.setTranslate(-pointF.x, -pointF.y);
        Matrix matrix3 = this.directionRotater;
        float[] arrf = this.mMatrixValues;
        matrix3.postScale(1.0f / arrf[0], 1.0f / arrf[4]);
        Matrix matrix4 = this.directionRotater;
        Point point = this.mMapCoords;
        matrix4.postTranslate((float)point.x, (float)point.y);
        canvas.drawBitmap(this.PERSON_ICON, this.directionRotater, this.mPaint);
    }

    public boolean enableCompass() {
        boolean bl;
        if (this.mSensorListener == null) {
            SensorEventListenerProxy sensorEventListenerProxy;
            this.mSensorListener = sensorEventListenerProxy = new SensorEventListenerProxy(this.mSensorManager);
            bl = sensorEventListenerProxy.startListening((SensorEventListener)this, 3, 2);
        } else {
            bl = true;
        }
        MapView mapView = this.mMapView;
        if (mapView != null) {
            mapView.postInvalidate();
        }
        return bl;
    }

    public void enableFollowLocation() {
        MapView mapView;
        this.mFollow = true;
        if (this.isMyLocationEnabled()) {
            Location location;
            this.mLocation = location = LocationUtils.getLastKnownLocation(this.mLocationManager);
            if (location != null) {
                this.mMapController.animateTo(new GeoPoint(this.mLocation));
            }
        }
        if ((mapView = this.mMapView) != null) {
            mapView.postInvalidate();
        }
    }

    public boolean enableMyLocation() {
        MapView mapView;
        boolean bl;
        if (this.mLocationListener == null) {
            LocationListenerProxy locationListenerProxy;
            this.mLocationListener = locationListenerProxy = new LocationListenerProxy(this.mLocationManager);
            bl = locationListenerProxy.startListening((LocationListener)this, this.mLocationUpdateMinTime, this.mLocationUpdateMinDistance);
        } else {
            bl = true;
        }
        if (this.isFollowLocationEnabled()) {
            Location location;
            this.mLocation = location = LocationUtils.getLastKnownLocation(this.mLocationManager);
            if (location != null) {
                this.mMapController.animateTo(new GeoPoint(this.mLocation));
            }
        }
        if ((mapView = this.mMapView) != null) {
            mapView.postInvalidate();
        }
        return bl;
    }

    @Deprecated
    public void followLocation(boolean bl) {
        if (bl) {
            this.enableFollowLocation();
            return;
        }
        this.disableFollowLocation();
    }

    public Location getLastFix() {
        return this.mLocation;
    }

    public float getLocationUpdateMinDistance() {
        return this.mLocationUpdateMinDistance;
    }

    public long getLocationUpdateMinTime() {
        return this.mLocationUpdateMinTime;
    }

    public GeoPoint getMyLocation() {
        if (this.mLocation == null) {
            return null;
        }
        return new GeoPoint(this.mLocation);
    }

    public float getOrientation() {
        return this.mAzimuth;
    }

    public boolean isCompassEnabled() {
        return this.mSensorListener != null;
    }

    public boolean isDrawAccuracyEnabled() {
        return this.mDrawAccuracyEnabled;
    }

    public boolean isFollowLocationEnabled() {
        return this.mFollow;
    }

    public boolean isMyLocationEnabled() {
        return this.mLocationListener != null;
    }

    public boolean isOptionsMenuEnabled() {
        return this.mOptionsMenuEnabled;
    }

    public void onAccuracyChanged(Sensor sensor, int n2) {
    }

    public boolean onCreateOptionsMenu(Menu menu, int n2, MapView mapView) {
        menu.add(0, n2 + MENU_MY_LOCATION, 0, (CharSequence)this.mResourceProxy.getString(ResourceProxy.string.my_location)).setIcon(this.mResourceProxy.getDrawable(ResourceProxy.bitmap.ic_menu_mylocation));
        menu.add(0, n2 + MENU_COMPASS, 0, (CharSequence)this.mResourceProxy.getString(ResourceProxy.string.compass)).setIcon(this.mResourceProxy.getDrawable(ResourceProxy.bitmap.ic_menu_compass));
        return true;
    }

    public void onLocationChanged(Location location) {
        if (this.mIgnorer.shouldIgnore(location.getProvider(), System.currentTimeMillis())) {
            logger.debug("Ignore temporary non-gps location");
            return;
        }
        this.mLocation = location;
        if (this.mFollow) {
            this.mMapController.animateTo(location.getLatitude(), location.getLongitude());
        } else {
            this.mMapView.postInvalidate();
        }
        Iterator iterator = this.mRunOnFirstFix.iterator();
        while (iterator.hasNext()) {
            new Thread((Runnable)iterator.next()).start();
        }
        this.mRunOnFirstFix.clear();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem, int n2, MapView mapView) {
        int n3 = menuItem.getItemId() - n2;
        if (n3 == MENU_MY_LOCATION) {
            if (this.isMyLocationEnabled()) {
                this.disableFollowLocation();
                this.disableMyLocation();
                return true;
            }
            this.enableFollowLocation();
            this.enableMyLocation();
            return true;
        }
        if (n3 == MENU_COMPASS) {
            if (this.isCompassEnabled()) {
                this.disableCompass();
                return true;
            }
            this.enableCompass();
            return true;
        }
        return false;
    }

    public boolean onPrepareOptionsMenu(Menu menu, int n2, MapView mapView) {
        return false;
    }

    public void onProviderDisabled(String string2) {
    }

    public void onProviderEnabled(String string2) {
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        float[] arrf;
        if (sensorEvent.sensor.getType() == 3 && (arrf = sensorEvent.values) != null) {
            this.mAzimuth = arrf[0];
            this.mMapView.postInvalidate();
        }
    }

    public boolean onSnapToItem(int n2, int n3, Point point, IMapView iMapView) {
        Location location = this.mLocation;
        boolean bl = false;
        if (location != null) {
            iMapView.getProjection().toPixels((IGeoPoint)new GeoPoint(this.mLocation), this.mMapCoords);
            Point point2 = this.mMapCoords;
            point.x = point2.x;
            point.y = point2.y;
            double d2 = n2 - point2.x;
            double d3 = n3 - point2.y;
            Double.isNaN((double)d2);
            Double.isNaN((double)d2);
            double d4 = d2 * d2;
            Double.isNaN((double)d3);
            Double.isNaN((double)d3);
            double d5 = d4 + d3 * d3 DCMPG 64.0;
            bl = false;
            if (d5 < 0) {
                bl = true;
            }
        }
        return bl;
    }

    public void onStatusChanged(String string2, int n2, Bundle bundle) {
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent, MapView mapView) {
        if (motionEvent.getAction() == 2) {
            this.disableFollowLocation();
        }
        return super.onTouchEvent(motionEvent, mapView);
    }

    public boolean runOnFirstFix(Runnable runnable) {
        if (this.mLocationListener != null && this.mLocation != null) {
            new Thread(runnable).start();
            return true;
        }
        this.mRunOnFirstFix.addLast((Object)runnable);
        return false;
    }

    public void setCompassCenter(float f2, float f3) {
        this.mCompassCenterX = f2;
        this.mCompassCenterY = f3;
    }

    public void setDrawAccuracyEnabled(boolean bl) {
        this.mDrawAccuracyEnabled = bl;
    }

    public void setLocationUpdateMinDistance(float f2) {
        this.mLocationUpdateMinDistance = f2;
    }

    public void setLocationUpdateMinTime(long l2) {
        this.mLocationUpdateMinTime = l2;
    }

    public void setOptionsMenuEnabled(boolean bl) {
        this.mOptionsMenuEnabled = bl;
    }
}

