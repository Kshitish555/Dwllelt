/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.IRunActivityHandler;
import com.adjust.sdk.LogLevel;
import com.adjust.sdk.OnAttributionChangedListener;
import com.adjust.sdk.OnDeeplinkResponseListener;
import com.adjust.sdk.OnEventTrackingFailedListener;
import com.adjust.sdk.OnEventTrackingSucceededListener;
import com.adjust.sdk.OnSessionTrackingFailedListener;
import com.adjust.sdk.OnSessionTrackingSucceededListener;
import com.adjust.sdk.Util;
import java.util.List;

public class AdjustConfig {
    public static final String ENVIRONMENT_PRODUCTION = "production";
    public static final String ENVIRONMENT_SANDBOX = "sandbox";
    String appSecret;
    String appToken;
    String basePath;
    Context context;
    Class deepLinkComponent;
    String defaultTracker;
    Double delayStart;
    Boolean deviceKnown;
    String environment;
    boolean eventBufferingEnabled;
    String gdprPath;
    ILogger logger;
    OnAttributionChangedListener onAttributionChangedListener;
    OnDeeplinkResponseListener onDeeplinkResponseListener;
    OnEventTrackingFailedListener onEventTrackingFailedListener;
    OnEventTrackingSucceededListener onEventTrackingSucceededListener;
    OnSessionTrackingFailedListener onSessionTrackingFailedListener;
    OnSessionTrackingSucceededListener onSessionTrackingSucceededListener;
    List<IRunActivityHandler> preLaunchActionsArray;
    String processName;
    String pushToken;
    String sdkPrefix;
    String secretId;
    boolean sendInBackground;
    Boolean startEnabled;
    boolean startOffline;
    String userAgent;

    public AdjustConfig(Context context, String string, String string2) {
        this.init(context, string, string2, false);
    }

    public AdjustConfig(Context context, String string, String string2, boolean bl) {
        this.init(context, string, string2, bl);
    }

    private boolean checkAppToken(String string) {
        if (string == null) {
            this.logger.error("Missing App Token", new Object[0]);
            return false;
        }
        if (string.length() != 12) {
            this.logger.error("Malformed App Token '%s'", string);
            return false;
        }
        return true;
    }

    private boolean checkContext(Context context) {
        if (context == null) {
            this.logger.error("Missing context", new Object[0]);
            return false;
        }
        if (!Util.checkPermission(context, "android.permission.INTERNET")) {
            this.logger.error("Missing permission: INTERNET", new Object[0]);
            return false;
        }
        return true;
    }

    private boolean checkEnvironment(String string) {
        if (string == null) {
            this.logger.error("Missing environment", new Object[0]);
            return false;
        }
        if (string.equals((Object)ENVIRONMENT_SANDBOX)) {
            this.logger.warnInProduction("SANDBOX: Adjust is running in Sandbox mode. Use this setting for testing. Don't forget to set the environment to `production` before publishing!", new Object[0]);
            return true;
        }
        if (string.equals((Object)ENVIRONMENT_PRODUCTION)) {
            this.logger.warnInProduction("PRODUCTION: Adjust is running in Production mode. Use this setting only for the build that you want to publish. Set the environment to `sandbox` if you want to test your app!", new Object[0]);
            return true;
        }
        this.logger.error("Unknown environment '%s'", string);
        return false;
    }

    private void init(Context context, String string, String string2, boolean bl) {
        this.logger = AdjustFactory.getLogger();
        if (bl && ENVIRONMENT_PRODUCTION.equals((Object)string2)) {
            this.setLogLevel(LogLevel.SUPRESS, string2);
        } else {
            this.setLogLevel(LogLevel.INFO, string2);
        }
        if (context != null) {
            context = context.getApplicationContext();
        }
        this.context = context;
        this.appToken = string;
        this.environment = string2;
        this.eventBufferingEnabled = false;
        this.sendInBackground = false;
    }

    private void setLogLevel(LogLevel logLevel, String string) {
        this.logger.setLogLevel(logLevel, ENVIRONMENT_PRODUCTION.equals((Object)string));
    }

    public boolean isValid() {
        if (!this.checkAppToken(this.appToken)) {
            return false;
        }
        if (!this.checkEnvironment(this.environment)) {
            return false;
        }
        return this.checkContext(this.context);
    }

    public void setAppSecret(long l2, long l3, long l4, long l5, long l6) {
        Object[] arrobject = new Object[]{l2};
        this.secretId = Util.formatString("%d", arrobject);
        Object[] arrobject2 = new Object[]{l3, l4, l5, l6};
        this.appSecret = Util.formatString("%d%d%d%d", arrobject2);
    }

    public void setDeepLinkComponent(Class class_) {
        this.deepLinkComponent = class_;
    }

    public void setDefaultTracker(String string) {
        this.defaultTracker = string;
    }

    public void setDelayStart(double d2) {
        this.delayStart = d2;
    }

    public void setDeviceKnown(boolean bl) {
        this.deviceKnown = bl;
    }

    public void setEventBufferingEnabled(Boolean bl) {
        if (bl == null) {
            this.eventBufferingEnabled = false;
            return;
        }
        this.eventBufferingEnabled = bl;
    }

    public void setLogLevel(LogLevel logLevel) {
        this.setLogLevel(logLevel, this.environment);
    }

    public void setOnAttributionChangedListener(OnAttributionChangedListener onAttributionChangedListener) {
        this.onAttributionChangedListener = onAttributionChangedListener;
    }

    public void setOnDeeplinkResponseListener(OnDeeplinkResponseListener onDeeplinkResponseListener) {
        this.onDeeplinkResponseListener = onDeeplinkResponseListener;
    }

    public void setOnEventTrackingFailedListener(OnEventTrackingFailedListener onEventTrackingFailedListener) {
        this.onEventTrackingFailedListener = onEventTrackingFailedListener;
    }

    public void setOnEventTrackingSucceededListener(OnEventTrackingSucceededListener onEventTrackingSucceededListener) {
        this.onEventTrackingSucceededListener = onEventTrackingSucceededListener;
    }

    public void setOnSessionTrackingFailedListener(OnSessionTrackingFailedListener onSessionTrackingFailedListener) {
        this.onSessionTrackingFailedListener = onSessionTrackingFailedListener;
    }

    public void setOnSessionTrackingSucceededListener(OnSessionTrackingSucceededListener onSessionTrackingSucceededListener) {
        this.onSessionTrackingSucceededListener = onSessionTrackingSucceededListener;
    }

    public void setProcessName(String string) {
        this.processName = string;
    }

    @Deprecated
    public void setReadMobileEquipmentIdentity(boolean bl) {
        this.logger.warn("This method has been deprecated and shouldn't be used anymore", new Object[0]);
    }

    public void setSdkPrefix(String string) {
        this.sdkPrefix = string;
    }

    public void setSendInBackground(boolean bl) {
        this.sendInBackground = bl;
    }

    public void setUserAgent(String string) {
        this.userAgent = string;
    }
}

