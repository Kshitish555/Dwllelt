/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.drawable.Drawable
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.Random
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.tileprovider.ExpirableBitmapDrawable
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants
 *  org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase$LowMemoryException
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.tilesource;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import java.io.InputStream;
import java.util.Random;
import org.osmdroid.ResourceProxy;
import org.osmdroid.tileprovider.ExpirableBitmapDrawable;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.constants.OpenStreetMapTileProviderConstants;
import org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Exception performing whole class analysis.
 */
public abstract class BitmapTileSourceBase
implements ITileSource,
OpenStreetMapTileProviderConstants {
    private static int globalOrdinal;
    private static final Logger logger;
    protected final String mImageFilenameEnding;
    private final int mMaximumZoomLevel;
    private final int mMinimumZoomLevel;
    protected final String mName;
    private final int mOrdinal;
    private final ResourceProxy.string mResourceId;
    private final int mTileSizePixels;
    protected final Random random;

    static {
        logger = LoggerFactory.getLogger(BitmapTileSourceBase.class);
        globalOrdinal = 0;
    }

    public BitmapTileSourceBase(String string2, ResourceProxy.string string3, int n, int n2, int n3, String string4) {
        this.random = new Random();
        this.mResourceId = string3;
        int n4 = globalOrdinal;
        globalOrdinal = n4 + 1;
        this.mOrdinal = n4;
        this.mName = string2;
        this.mMinimumZoomLevel = n;
        this.mMaximumZoomLevel = n2;
        this.mTileSizePixels = n3;
        this.mImageFilenameEnding = string4;
    }

    public Drawable getDrawable(InputStream inputStream) throws LowMemoryException {
        block3 : {
            Bitmap bitmap2;
            try {
                bitmap2 = BitmapFactory.decodeStream((InputStream)inputStream);
                if (bitmap2 == null) break block3;
            }
            catch (OutOfMemoryError outOfMemoryError) {
                logger.error("OutOfMemoryError loading bitmap");
                System.gc();
                throw new /* Unavailable Anonymous Inner Class!! */;
            }
            ExpirableBitmapDrawable expirableBitmapDrawable = new ExpirableBitmapDrawable(bitmap2);
            return expirableBitmapDrawable;
        }
        return null;
    }

    /*
     * Exception decompiling
     */
    public Drawable getDrawable(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl60 : ACONST_NULL : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public int getMaximumZoomLevel() {
        return this.mMaximumZoomLevel;
    }

    public int getMinimumZoomLevel() {
        return this.mMinimumZoomLevel;
    }

    public String getTileRelativeFilenameString(MapTile mapTile) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.pathBase());
        stringBuilder.append('/');
        stringBuilder.append(mapTile.getZoomLevel());
        stringBuilder.append('/');
        stringBuilder.append(mapTile.getX());
        stringBuilder.append('/');
        stringBuilder.append(mapTile.getY());
        stringBuilder.append(this.imageFilenameEnding());
        return stringBuilder.toString();
    }

    public int getTileSizePixels() {
        return this.mTileSizePixels;
    }

    public String imageFilenameEnding() {
        return this.mImageFilenameEnding;
    }

    public String localizedName(ResourceProxy resourceProxy) {
        return resourceProxy.getString(this.mResourceId);
    }

    public String name() {
        return this.mName;
    }

    public int ordinal() {
        return this.mOrdinal;
    }

    public String pathBase() {
        return this.mName;
    }
}

