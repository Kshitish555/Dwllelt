/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.simpleframework.xml.util;

public interface Match {
    public String getPattern();
}

