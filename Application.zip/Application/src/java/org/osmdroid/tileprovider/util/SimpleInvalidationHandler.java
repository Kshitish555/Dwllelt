/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Message
 *  android.view.View
 */
package org.osmdroid.tileprovider.util;

import android.os.Handler;
import android.os.Message;
import android.view.View;

public class SimpleInvalidationHandler
extends Handler {
    private final View mView;

    public SimpleInvalidationHandler(View view) {
        this.mView = view;
    }

    public void handleMessage(Message message) {
        if (message.what != 0) {
            return;
        }
        this.mView.invalidate();
    }
}

