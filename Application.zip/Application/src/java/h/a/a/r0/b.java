/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.r0.a
 *  h.a.a.r0.c
 *  h.a.a.r0.d
 *  h.a.a.r0.e
 *  h.a.a.r0.f
 *  h.a.a.r0.g
 *  h.a.a.r0.h
 *  h.a.a.r0.i
 *  h.a.a.r0.j
 *  h.a.a.r0.k
 *  h.a.a.r0.l
 *  h.a.a.r0.m
 *  io.github.classgraph.utils.p
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.util.Arrays
 *  java.util.List
 */
package h.a.a.r0;

import h.a.a.m;
import h.a.a.r0.c;
import h.a.a.r0.d;
import h.a.a.r0.e;
import h.a.a.r0.f;
import h.a.a.r0.g;
import h.a.a.r0.h;
import h.a.a.r0.i;
import h.a.a.r0.j;
import h.a.a.r0.k;
import h.a.a.r0.l;
import io.github.classgraph.utils.p;
import java.lang.reflect.Constructor;
import java.util.Arrays;
import java.util.List;

public class b {
    public static final List<a> a;
    public static final a b;

    static {
        Object[] arrobject = new a[]{new a(h.a.a.r0.a.class), new a(c.class), new a(d.class), new a(f.class), new a(g.class), new a(k.class), new a(l.class), new a(h.a.a.r0.m.class), new a(i.class), new a(h.class), new a(j.class)};
        a = Arrays.asList((Object[])arrobject);
        b = new a(e.class);
    }

    public static class a {
        public final String[] a;
        public final Class<? extends m> b;

        public a(Class<? extends m> class_) {
            this.b = class_;
            try {
                this.a = ((m)class_.getDeclaredConstructor(new Class[0]).newInstance(new Object[0])).a();
                return;
            }
            catch (Exception exception) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Could not instantiate ");
                stringBuilder.append(class_.getName());
                throw new RuntimeException(stringBuilder.toString(), (Throwable)exception);
            }
        }

        public m a(p p2) {
            try {
                m m2 = (m)this.b.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                return m2;
            }
            catch (Exception exception) {
                if (p2 != null) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Could not instantiate ");
                    stringBuilder.append(this.b.getName());
                    p2.a(stringBuilder.toString(), (Throwable)exception);
                }
                return null;
            }
        }
    }

}

