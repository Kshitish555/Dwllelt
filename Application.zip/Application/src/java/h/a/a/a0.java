/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.a0$a
 *  h.a.a.z
 *  java.lang.FunctionalInterface
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 */
package h.a.a;

import h.a.a.a0;
import h.a.a.z;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class a0
extends ArrayList<z> {
    static final a0 c = new a();

    a0() {
    }

    a0(int n2) {
        super(n2);
    }

    a0(Collection<z> collection) {
        super(collection);
    }

    public a0 a(b b2) {
        a0 a02 = new a0();
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            z z2 = (z)iterator.next();
            if (!b2.a(z2)) continue;
            a02.add((Object)z2);
        }
        return a02;
    }

    public boolean a(String string) {
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            if (!((z)iterator.next()).m().equals((Object)string)) continue;
            return true;
        }
        return false;
    }

    public List<String> b() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((z)iterator.next()).toString());
        }
        return arrayList;
    }

    public z c(String string) {
        IllegalArgumentException illegalArgumentException;
        Iterator iterator = this.iterator();
        int n2 = 0;
        z z2 = null;
        while (iterator.hasNext()) {
            z z3 = (z)iterator.next();
            if (!z3.m().equals((Object)string)) continue;
            ++n2;
            z2 = z3;
        }
        if (n2 == 0) {
            return null;
        }
        if (n2 == 1) {
            return z2;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("There are multiple methods named \"");
        stringBuilder.append(string);
        stringBuilder.append("\" in class ");
        stringBuilder.append(((z)this.iterator().next()).m());
        illegalArgumentException = new IllegalArgumentException(stringBuilder.toString());
        throw illegalArgumentException;
    }

    public List<String> c() {
        if (this.isEmpty()) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(this.size());
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((z)iterator.next()).m());
        }
        return arrayList;
    }

    public a0 get(String string) {
        boolean bl;
        block3 : {
            Iterator iterator = this.iterator();
            while (iterator.hasNext()) {
                if (!((z)iterator.next()).m().equals((Object)string)) continue;
                bl = true;
                break block3;
            }
            bl = false;
        }
        if (!bl) {
            return c;
        }
        a0 a02 = new a0(2);
        Iterator iterator = this.iterator();
        while (iterator.hasNext()) {
            z z2 = (z)iterator.next();
            if (!z2.m().equals((Object)string)) continue;
            a02.add((Object)z2);
        }
        return a02;
    }

    @FunctionalInterface
    public static interface b {
        public boolean a(z var1);
    }

}

