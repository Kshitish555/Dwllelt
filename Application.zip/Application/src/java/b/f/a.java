/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b.f;

public final class a {
    private a() {
    }

    public static final class a {
        public static final int alpha = 2130968622;
        public static final int font = 2130968921;
        public static final int fontProviderAuthority = 2130968924;
        public static final int fontProviderCerts = 2130968925;
        public static final int fontProviderFetchStrategy = 2130968926;
        public static final int fontProviderFetchTimeout = 2130968927;
        public static final int fontProviderPackage = 2130968928;
        public static final int fontProviderQuery = 2130968929;
        public static final int fontStyle = 2130968930;
        public static final int fontVariationSettings = 2130968931;
        public static final int fontWeight = 2130968932;
        public static final int ttcIndex = 2130969476;

        private a() {
        }
    }

    public static final class b {
        public static final int notification_action_color_filter = 2131099843;
        public static final int notification_icon_bg_color = 2131099844;
        public static final int ripple_material_light = 2131099871;
        public static final int secondary_text_default_material_light = 2131099873;

        private b() {
        }
    }

    public static final class c {
        public static final int compat_button_inset_horizontal_material = 2131165295;
        public static final int compat_button_inset_vertical_material = 2131165296;
        public static final int compat_button_padding_horizontal_material = 2131165297;
        public static final int compat_button_padding_vertical_material = 2131165298;
        public static final int compat_control_corner_material = 2131165299;
        public static final int compat_notification_large_icon_max_height = 2131165300;
        public static final int compat_notification_large_icon_max_width = 2131165301;
        public static final int notification_action_icon_size = 2131165502;
        public static final int notification_action_text_size = 2131165503;
        public static final int notification_big_circle_margin = 2131165504;
        public static final int notification_content_margin_start = 2131165505;
        public static final int notification_large_icon_height = 2131165506;
        public static final int notification_large_icon_width = 2131165507;
        public static final int notification_main_column_padding_top = 2131165508;
        public static final int notification_media_narrow_margin = 2131165509;
        public static final int notification_right_icon_size = 2131165510;
        public static final int notification_right_side_padding_top = 2131165511;
        public static final int notification_small_icon_background_padding = 2131165512;
        public static final int notification_small_icon_size_as_large = 2131165513;
        public static final int notification_subtext_size = 2131165514;
        public static final int notification_top_pad = 2131165515;
        public static final int notification_top_pad_large_text = 2131165516;

        private c() {
        }
    }

    public static final class d {
        public static final int notification_action_background = 2131231422;
        public static final int notification_bg = 2131231424;
        public static final int notification_bg_low = 2131231425;
        public static final int notification_bg_low_normal = 2131231426;
        public static final int notification_bg_low_pressed = 2131231427;
        public static final int notification_bg_normal = 2131231428;
        public static final int notification_bg_normal_pressed = 2131231429;
        public static final int notification_icon_background = 2131231431;
        public static final int notification_template_icon_bg = 2131231432;
        public static final int notification_template_icon_low_bg = 2131231433;
        public static final int notification_tile_bg = 2131231434;
        public static final int notify_panel_notification_icon_bg = 2131231435;

        private d() {
        }
    }

    public static final class e {
        public static final int accessibility_action_clickable_span = 2131296270;
        public static final int accessibility_custom_action_0 = 2131296271;
        public static final int accessibility_custom_action_1 = 2131296272;
        public static final int accessibility_custom_action_10 = 2131296273;
        public static final int accessibility_custom_action_11 = 2131296274;
        public static final int accessibility_custom_action_12 = 2131296275;
        public static final int accessibility_custom_action_13 = 2131296276;
        public static final int accessibility_custom_action_14 = 2131296277;
        public static final int accessibility_custom_action_15 = 2131296278;
        public static final int accessibility_custom_action_16 = 2131296279;
        public static final int accessibility_custom_action_17 = 2131296280;
        public static final int accessibility_custom_action_18 = 2131296281;
        public static final int accessibility_custom_action_19 = 2131296282;
        public static final int accessibility_custom_action_2 = 2131296283;
        public static final int accessibility_custom_action_20 = 2131296284;
        public static final int accessibility_custom_action_21 = 2131296285;
        public static final int accessibility_custom_action_22 = 2131296286;
        public static final int accessibility_custom_action_23 = 2131296287;
        public static final int accessibility_custom_action_24 = 2131296288;
        public static final int accessibility_custom_action_25 = 2131296289;
        public static final int accessibility_custom_action_26 = 2131296290;
        public static final int accessibility_custom_action_27 = 2131296291;
        public static final int accessibility_custom_action_28 = 2131296292;
        public static final int accessibility_custom_action_29 = 2131296293;
        public static final int accessibility_custom_action_3 = 2131296294;
        public static final int accessibility_custom_action_30 = 2131296295;
        public static final int accessibility_custom_action_31 = 2131296296;
        public static final int accessibility_custom_action_4 = 2131296297;
        public static final int accessibility_custom_action_5 = 2131296298;
        public static final int accessibility_custom_action_6 = 2131296299;
        public static final int accessibility_custom_action_7 = 2131296300;
        public static final int accessibility_custom_action_8 = 2131296301;
        public static final int accessibility_custom_action_9 = 2131296302;
        public static final int action_container = 2131296312;
        public static final int action_divider = 2131296315;
        public static final int action_image = 2131296316;
        public static final int action_text = 2131296331;
        public static final int actions = 2131296332;
        public static final int async = 2131296374;
        public static final int blocking = 2131296442;
        public static final int chronometer = 2131296618;
        public static final int dialog_button = 2131296790;
        public static final int forever = 2131296971;
        public static final int icon = 2131297042;
        public static final int icon_group = 2131297045;
        public static final int info = 2131297093;
        public static final int italic = 2131297121;
        public static final int line1 = 2131297173;
        public static final int line3 = 2131297174;
        public static final int normal = 2131297291;
        public static final int notification_background = 2131297296;
        public static final int notification_main_column = 2131297299;
        public static final int notification_main_column_container = 2131297300;
        public static final int right_icon = 2131297541;
        public static final int right_side = 2131297542;
        public static final int tag_accessibility_actions = 2131297713;
        public static final int tag_accessibility_clickable_spans = 2131297714;
        public static final int tag_accessibility_heading = 2131297715;
        public static final int tag_accessibility_pane_title = 2131297716;
        public static final int tag_screen_reader_focusable = 2131297717;
        public static final int tag_transition_group = 2131297718;
        public static final int tag_unhandled_key_event_manager = 2131297719;
        public static final int tag_unhandled_key_listeners = 2131297720;
        public static final int text = 2131297731;
        public static final int text2 = 2131297733;
        public static final int time = 2131297765;
        public static final int title = 2131297767;

        private e() {
        }
    }

    public static final class f {
        public static final int status_bar_notification_info_maxnum = 2131361954;

        private f() {
        }
    }

    public static final class g {
        public static final int custom_dialog = 2131493025;
        public static final int notification_action = 2131493367;
        public static final int notification_action_tombstone = 2131493368;
        public static final int notification_template_custom_big = 2131493376;
        public static final int notification_template_icon_group = 2131493377;
        public static final int notification_template_part_chronometer = 2131493381;
        public static final int notification_template_part_time = 2131493382;

        private g() {
        }
    }

    public static final class h {
        public static final int status_bar_notification_info_overflow = 2131822049;

        private h() {
        }
    }

    public static final class i {
        public static final int TextAppearance_Compat_Notification = 2131886501;
        public static final int TextAppearance_Compat_Notification_Info = 2131886502;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131886504;
        public static final int TextAppearance_Compat_Notification_Time = 2131886507;
        public static final int TextAppearance_Compat_Notification_Title = 2131886509;
        public static final int Widget_Compat_NotificationActionContainer = 2131886716;
        public static final int Widget_Compat_NotificationActionText = 2131886717;

        private i() {
        }
    }

    public static final class j {
        public static final int[] ColorStateListItem = new int[]{16843173, 16843551, 2130968622};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = new int[]{2130968924, 2130968925, 2130968926, 2130968927, 2130968928, 2130968929};
        public static final int[] FontFamilyFont = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, 2130968921, 2130968930, 2130968931, 2130968932, 2130969476};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = new int[]{16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = new int[]{16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;

        private j() {
        }
    }

}

