/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Array
 *  java.lang.reflect.GenericArrayType
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.lang.reflect.TypeVariable
 *  java.lang.reflect.WildcardType
 */
package h.a.a.s0;

import h.a.a.s0.l;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;

class n {
    private final TypeVariable<?>[] a;
    Type[] b;

    n(ParameterizedType parameterizedType) {
        this.a = ((Class)parameterizedType.getRawType()).getTypeParameters();
        Type[] arrtype = parameterizedType.getActualTypeArguments();
        this.b = arrtype;
        if (arrtype.length == this.a.length) {
            return;
        }
        throw new IllegalArgumentException("Type parameter count mismatch");
    }

    Type a(Type type) {
        RuntimeException runtimeException;
        int n2;
        boolean bl = type instanceof Class;
        if (bl) {
            return type;
        }
        boolean bl2 = type instanceof ParameterizedType;
        if (bl2) {
            ParameterizedType parameterizedType = (ParameterizedType)type;
            Type[] arrtype = parameterizedType.getActualTypeArguments();
            Type[] arrtype2 = null;
            for (int i2 = 0; i2 < arrtype.length; ++i2) {
                Type type2 = this.a(arrtype[i2]);
                if (arrtype2 == null) {
                    if (type2.equals((Object)arrtype[i2])) continue;
                    arrtype2 = new Type[arrtype.length];
                    for (int i3 = 0; i3 < i2; ++i3) {
                        arrtype2[i3] = arrtype[i3];
                    }
                    arrtype2[i2] = type2;
                    continue;
                }
                arrtype2[i2] = type2;
            }
            if (arrtype2 == null) {
                return type;
            }
            return new l((Class)parameterizedType.getRawType(), arrtype2, parameterizedType.getOwnerType());
        }
        if (type instanceof TypeVariable) {
            TypeVariable<?>[] arrtypeVariable;
            TypeVariable typeVariable = (TypeVariable)type;
            for (n2 = 0; n2 < (arrtypeVariable = this.a).length; ++n2) {
                if (!arrtypeVariable[n2].getName().equals((Object)typeVariable.getName())) continue;
                return this.b[n2];
            }
            return type;
        }
        if (type instanceof GenericArrayType) {
            Type type3 = type;
            while (type3 instanceof GenericArrayType) {
                ++n2;
                type3 = ((GenericArrayType)type3).getGenericComponentType();
            }
            Type type4 = this.a(type3);
            if (type4 instanceof Class) {
                return Array.newInstance((Class)((Class)type4), (int[])((int[])Array.newInstance((Class)Integer.TYPE, (int)n2))).getClass();
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not resolve generic array type ");
            stringBuilder.append((Object)type);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        if (!(type instanceof WildcardType)) {
            if (bl) {
                return type;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Got unexpected type: ");
            stringBuilder.append((Object)type);
            throw new RuntimeException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WildcardType not yet supported: ");
        stringBuilder.append((Object)type);
        runtimeException = new RuntimeException(stringBuilder.toString());
        throw runtimeException;
    }

    public String toString() {
        if (this.a.length == 0) {
            return "{ }";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("{ ");
        for (int i2 = 0; i2 < this.a.length; ++i2) {
            if (i2 > 0) {
                stringBuilder.append(", ");
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(this.a[i2]);
            stringBuilder2.append(" => ");
            stringBuilder2.append((Object)this.b[i2]);
            stringBuilder.append(stringBuilder2.toString());
        }
        stringBuilder.append(" }");
        return stringBuilder.toString();
    }
}

