/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.github.classgraph.utils.m
 *  io.github.classgraph.utils.s
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.ClassLoader
 *  java.lang.Comparable
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.net.URI
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  java.util.Set
 */
package h.a.a;

import h.a.a.d0;
import io.github.classgraph.utils.m;
import io.github.classgraph.utils.s;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class e0
implements Comparable<e0> {
    private String P4;
    private final ClassLoader Q4;
    private final String c;
    private final Object d;
    private final Object f;
    private final Object h;
    private final List<String> o;
    private final URI s;
    private String t;
    private File w;

    public e0(Object object, Object object2) {
        if (object != null) {
            if (object2 != null) {
                Object object3;
                this.d = object;
                this.f = object2;
                this.h = object3 = s.b((Object)object, (String)"descriptor", (boolean)true);
                if (object3 != null) {
                    String string = (String)s.b((Object)object3, (String)"name", (boolean)true);
                    if (string == null) {
                        string = "";
                    }
                    this.c = string;
                    Set set = (Set)s.b((Object)this.h, (String)"packages", (boolean)true);
                    if (set != null) {
                        Object object4;
                        Boolean bl;
                        ArrayList arrayList;
                        this.o = arrayList = new ArrayList((Collection)set);
                        Collections.sort((List)arrayList);
                        Object object5 = s.b((Object)this.h, (String)"rawVersion", (boolean)true);
                        if (object5 != null && (bl = (Boolean)s.b((Object)object5, (String)"isPresent", (boolean)true)) != null && bl.booleanValue()) {
                            this.P4 = (String)s.b((Object)object5, (String)"get", (boolean)true);
                        }
                        if ((object4 = s.b((Object)object, (String)"location", (boolean)true)) != null) {
                            Object object6 = s.b((Object)object4, (String)"isPresent", (boolean)true);
                            if (object6 != null) {
                                if (((Boolean)object6).booleanValue()) {
                                    URI uRI;
                                    this.s = uRI = (URI)s.b((Object)object4, (String)"get", (boolean)true);
                                    if (uRI == null) {
                                        throw new IllegalArgumentException("moduleReference.location().get() should not return null");
                                    }
                                } else {
                                    this.s = null;
                                }
                                this.Q4 = (ClassLoader)s.a((Object)object2, (String)"findLoader", String.class, (Object)this.c, (boolean)true);
                                return;
                            }
                            throw new IllegalArgumentException("moduleReference.location().isPresent() should not return null");
                        }
                        throw new IllegalArgumentException("moduleReference.location() should not return null");
                    }
                    throw new IllegalArgumentException("moduleReference.descriptor().packages() should not return null");
                }
                throw new IllegalArgumentException("moduleReference.descriptor() should not return null");
            }
            throw new IllegalArgumentException("moduleLayer cannot be null");
        }
        throw new IllegalArgumentException("moduleReference cannot be null");
    }

    public int a(e0 e02) {
        int n2 = this.c.compareTo(e02.c);
        if (n2 != 0) {
            return n2;
        }
        return this.hashCode() - e02.hashCode();
    }

    public ClassLoader c() {
        return this.Q4;
    }

    public Object e() {
        return this.h;
    }

    public boolean equals(Object object) {
        if (!(object instanceof e0)) {
            return false;
        }
        e0 e02 = (e0)object;
        boolean bl = e02.d.equals(this.d);
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = e02.f.equals(this.f);
            bl2 = false;
            if (bl3) {
                bl2 = true;
            }
        }
        return bl2;
    }

    public Object f() {
        return this.f;
    }

    public URI g() {
        return this.s;
    }

    /*
     * Exception decompiling
     */
    public File h() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl18.1 : ACONST_NULL : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public int hashCode() {
        return this.d.hashCode() * this.f.hashCode();
    }

    public String i() {
        URI uRI;
        if (this.t == null && (uRI = this.s) != null) {
            this.t = uRI.toString();
        }
        return this.t;
    }

    public String k() {
        return this.c;
    }

    public List<String> l() {
        return this.o;
    }

    public String m() {
        return this.P4;
    }

    public Object n() {
        return this.d;
    }

    public boolean o() {
        if (this.s != null) {
            if (this.Q4 == null) {
                return true;
            }
            if (m.c((String)this.c)) {
                return true;
            }
            String string = this.s.getScheme();
            if (string == null) {
                return false;
            }
            return true ^ string.equalsIgnoreCase("file");
        }
        return true;
    }

    public d0 p() throws IOException {
        return new d0(this);
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.d.toString());
        stringBuilder.append("; ClassLoader ");
        stringBuilder.append((Object)this.Q4);
        return stringBuilder.toString();
    }
}

