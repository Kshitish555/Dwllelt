/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.simpleframework.xml.util;

public interface Cache<T> {
    public void cache(Object var1, T var2);

    public boolean contains(Object var1);

    public T fetch(Object var1);

    public boolean isEmpty();

    public T take(Object var1);
}

