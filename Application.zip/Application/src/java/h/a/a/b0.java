/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.c
 *  h.a.a.p0
 *  h.a.a.z
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package h.a.a;

import h.a.a.c;
import h.a.a.d;
import h.a.a.j0;
import h.a.a.l0;
import h.a.a.p0;
import h.a.a.z;

public class b0 {
    private final z a;
    final c[] b;
    private final int c;
    private final p0 d;
    private final p0 e;
    private final String f;
    private j0 g;

    b0(z z2, c[] arrc, int n2, p0 p02, p0 p03, String string) {
        this.a = z2;
        this.f = string;
        this.c = n2;
        this.d = p02;
        this.e = p03;
        this.b = arrc;
    }

    static void a(int n2, StringBuilder stringBuilder) {
        if ((n2 & 16) != 0) {
            stringBuilder.append("final ");
        }
        if ((n2 & 4096) != 0) {
            stringBuilder.append("synthetic ");
        }
        if ((n2 & 32768) != 0) {
            stringBuilder.append("mandated ");
        }
    }

    public d a() {
        IllegalArgumentException illegalArgumentException;
        if (this.g.c.t) {
            c[] arrc = this.b;
            if (arrc != null && arrc.length != 0) {
                d d2 = new d(this.b.length);
                c[] arrc2 = this.b;
                int n2 = arrc2.length;
                for (int i2 = 0; i2 < n2; ++i2) {
                    d2.add((Object)arrc2[i2]);
                }
                return d2;
            }
            return d.c;
        }
        illegalArgumentException = new IllegalArgumentException("Please call ClassGraph#enableAnnotationInfo() before #scan()");
        throw illegalArgumentException;
    }

    protected void a(j0 j02) {
        p0 p02;
        p0 p03;
        this.g = j02;
        c[] arrc = this.b;
        if (arrc != null) {
            int n2 = arrc.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                arrc[i2].a(j02);
            }
        }
        if ((p02 = this.d) != null) {
            p02.a(j02);
        }
        if ((p03 = this.e) != null) {
            p03.a(j02);
        }
    }

    public boolean a(String string) {
        return this.a().a(string);
    }

    public z b() {
        return this.a;
    }

    public int c() {
        return this.c;
    }

    public String d() {
        StringBuilder stringBuilder = new StringBuilder();
        b0.a(this.c, stringBuilder);
        return stringBuilder.toString();
    }

    public String e() {
        return this.f;
    }

    public p0 f() {
        return this.d;
    }

    public p0 g() {
        return this.e;
    }

    public p0 h() {
        p0 p02 = this.e;
        if (p02 != null) {
            return p02;
        }
        return this.d;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.b != null) {
            c[] arrc;
            for (int i2 = 0; i2 < (arrc = this.b).length; ++i2) {
                arrc[i2].a(stringBuilder);
                stringBuilder.append(' ');
            }
        }
        b0.a(this.c, stringBuilder);
        stringBuilder.append(this.h().toString());
        stringBuilder.append(' ');
        String string = this.f;
        if (string == null) {
            string = "_unnamed_param";
        }
        stringBuilder.append(string);
        return stringBuilder.toString();
    }
}

