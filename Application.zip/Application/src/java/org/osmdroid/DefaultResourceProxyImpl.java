/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.util.DisplayMetrics
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 *  org.osmdroid.DefaultResourceProxyImpl$1
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$bitmap
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.views.util.constants.MapViewConstants
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import java.lang.reflect.Field;
import org.osmdroid.DefaultResourceProxyImpl;
import org.osmdroid.ResourceProxy;
import org.osmdroid.views.util.constants.MapViewConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DefaultResourceProxyImpl
implements ResourceProxy,
MapViewConstants {
    private static final Logger logger = LoggerFactory.getLogger(DefaultResourceProxyImpl.class);
    private DisplayMetrics mDisplayMetrics;

    public DefaultResourceProxyImpl(Context context) {
        if (context != null) {
            this.mDisplayMetrics = context.getResources().getDisplayMetrics();
        }
    }

    private BitmapFactory.Options getBitmapOptions() {
        try {
            Field field = DisplayMetrics.class.getDeclaredField("DENSITY_DEFAULT");
            Field field2 = BitmapFactory.Options.class.getDeclaredField("inDensity");
            Field field3 = BitmapFactory.Options.class.getDeclaredField("inTargetDensity");
            Field field4 = DisplayMetrics.class.getDeclaredField("densityDpi");
            BitmapFactory.Options options = new BitmapFactory.Options();
            field2.setInt((Object)options, field.getInt(null));
            field3.setInt((Object)options, field4.getInt((Object)this.mDisplayMetrics));
            return options;
        }
        catch (IllegalAccessException | NoSuchFieldException throwable) {
            return null;
        }
    }

    /*
     * Exception decompiling
     */
    public Bitmap getBitmap(ResourceProxy.bitmap var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public float getDisplayMetricsDensity() {
        return this.mDisplayMetrics.density;
    }

    public Drawable getDrawable(ResourceProxy.bitmap bitmap2) {
        return new BitmapDrawable(this.getBitmap(bitmap2));
    }

    public String getString(ResourceProxy.string string2) {
        switch (1.$SwitchMap$org$osmdroid$ResourceProxy$string[string2.ordinal()]) {
            default: {
                throw new IllegalArgumentException();
            }
            case 25: {
                return "Map mode";
            }
            case 24: {
                return "Compass";
            }
            case 23: {
                return "My location";
            }
            case 22: {
                return "Offline mode";
            }
            case 21: {
                return "Online mode";
            }
            case 20: {
                return "%s ft";
            }
            case 19: {
                return "%s nm";
            }
            case 18: {
                return "%s mi";
            }
            case 17: {
                return "%s km";
            }
            case 16: {
                return "%s m";
            }
            case 15: {
                return "Unknown";
            }
            case 14: {
                return "Netherlands roads overlay";
            }
            case 13: {
                return "Netherlands base overlay";
            }
            case 12: {
                return "OpenFietsKaart overlay";
            }
            case 11: {
                return "Bing";
            }
            case 10: {
                return "Mapquest Aerial";
            }
            case 9: {
                return "Mapquest";
            }
            case 8: {
                return "CloudMade (small tiles)";
            }
            case 7: {
                return "CloudMade (Standard tiles)";
            }
            case 6: {
                return "Hills";
            }
            case 5: {
                return "Topographic";
            }
            case 4: {
                return "OSM base layer";
            }
            case 3: {
                return "Public transport";
            }
            case 2: {
                return "Cycle Map";
            }
            case 1: 
        }
        return "Mapnik";
    }

    public /* varargs */ String getString(ResourceProxy.string string2, Object ... arrobject) {
        return String.format((String)this.getString(string2), (Object[])arrobject);
    }
}

