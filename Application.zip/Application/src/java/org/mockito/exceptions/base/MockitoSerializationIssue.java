/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ObjectStreamException
 *  java.lang.Exception
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.Throwable
 */
package org.mockito.exceptions.base;

import java.io.ObjectStreamException;
import org.mockito.internal.exceptions.d.a;

public class MockitoSerializationIssue
extends ObjectStreamException {
    private StackTraceElement[] c;

    public MockitoSerializationIssue(String string2, Exception exception) {
        super(string2);
        this.initCause((Throwable)exception);
        this.b();
    }

    private void b() {
        this.c = super.getStackTrace();
        new a().a((Throwable)this);
    }

    public StackTraceElement[] a() {
        return this.c;
    }
}

