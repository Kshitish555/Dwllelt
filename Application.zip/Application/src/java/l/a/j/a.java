/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  l.a.h.i.a
 *  l.a.h.i.a$g
 *  l.a.h.k.b
 *  l.a.h.k.c
 *  l.a.h.k.c$f
 *  l.a.h.k.d
 *  l.a.h.k.d$e
 *  l.a.h.k.d$f
 *  l.a.j.e$g
 *  l.a.j.q.b
 *  l.a.j.q.b$c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.l.e
 *  l.a.k.a.r
 */
package l.a.j;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.h.k.d;
import l.a.i.i.c;
import l.a.j.e;
import l.a.j.q.b;
import l.a.j.q.e;
import l.a.j.q.l.d;
import l.a.j.q.l.e;
import l.a.k.a.r;

public class a
implements l.a.j.e {
    private final List<l.a.h.k.c> c;

    protected a(List<l.a.h.k.c> list) {
        this.c = list;
    }

    public static l.a.j.e a() {
        return new a((List<l.a.h.k.c>)Collections.emptyList());
    }

    public static l.a.j.e a(Iterable<? extends Class<?>> iterable) {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = iterable.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((Class)iterator.next()));
        }
        return a.a((Collection<? extends l.a.h.k.c>)new d.e((List)arrayList));
    }

    public static l.a.j.e a(Collection<? extends l.a.h.k.c> collection) {
        return new a((List<l.a.h.k.c>)new ArrayList(collection));
    }

    public static /* varargs */ l.a.j.e a(Class<?> ... arrclass) {
        return a.a((Collection<? extends l.a.h.k.c>)new d.e(arrclass));
    }

    public static /* varargs */ l.a.j.e a(l.a.h.k.c ... arrc) {
        return a.a((Collection<? extends l.a.h.k.c>)Arrays.asList((Object[])arrc));
    }

    private List<l.a.h.k.c> c(l.a.h.k.c c2) {
        ArrayList arrayList = new ArrayList(this.c.size());
        HashSet hashSet = new HashSet((Collection)c2.A0().m1());
        for (l.a.h.k.c c3 : this.c) {
            if (!hashSet.remove((Object)c3)) continue;
            arrayList.add((Object)c3);
        }
        return arrayList;
    }

    public c a(c c2) {
        return c2;
    }

    @Override
    public b a(e.g g2) {
        return new b(g2, this.c(g2.c())){
            private final e.g c;
            private final List<l.a.h.k.c> d;
            private final Set<l.a.h.k.c> f;
            {
                HashSet hashSet;
                this.c = g2;
                this.d = list;
                this.f = hashSet = new HashSet((Collection)g2.c().A0().m1());
                hashSet.removeAll(list);
            }

            private l.a.j.q.e a(l.a.h.i.a a2) {
                a.g g2 = a2.h();
                e.f f2 = e.f.b.c;
                for (l.a.h.k.c c2 : this.d) {
                    f2 = this.c.a(g2, c2);
                    if (!f2.x()) continue;
                    return f2;
                }
                for (l.a.h.k.c c3 : this.f) {
                    e.f f3 = this.c.a(g2, c3);
                    if (f2.x() && f3.x()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append((Object)a2);
                        stringBuilder.append(" has an ambiguous default method with ");
                        stringBuilder.append((Object)f3.i());
                        stringBuilder.append(" and ");
                        stringBuilder.append((Object)f2.i());
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    f2 = f3;
                }
                return f2;
            }

            public b.c a(r r2, e.d d2, l.a.h.i.a a2) {
                l.a.j.q.e e2 = this.a(a2);
                if (e2.x()) {
                    l.a.j.q.e[] arre = new l.a.j.q.e[]{e.a((l.a.h.i.a)a2).a(), e2, d.a((l.a.h.k.b)a2.getReturnType())};
                    return new b.c(new e.a(arre).a(r2, d2).a(), a2.l());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot invoke default method on ");
                stringBuilder.append((Object)a2);
                throw new IllegalStateException(stringBuilder.toString());
            }

            protected boolean a(Object object) {
                return object instanceof a;
            }

            public boolean equals(Object object) {
                if (object == this) {
                    return true;
                }
                if (!(object instanceof a)) {
                    return false;
                }
                a a2 = object;
                if (!a2.a(this)) {
                    return false;
                }
                e.g g2 = this.c;
                e.g g3 = a2.c;
                if (g2 == null ? g3 != null : !g2.equals((Object)g3)) {
                    return false;
                }
                List<l.a.h.k.c> list = this.d;
                List<l.a.h.k.c> list2 = a2.d;
                return !(list == null ? list2 != null : !list.equals(list2));
            }

            public int hashCode() {
                e.g g2 = this.c;
                int n2 = 43;
                int n3 = g2 == null ? 43 : g2.hashCode();
                int n4 = n3 + 59;
                List<l.a.h.k.c> list = this.d;
                int n5 = n4 * 59;
                if (list != null) {
                    n2 = list.hashCode();
                }
                return n5 + n2;
            }
        };
    }

    protected boolean a(Object object) {
        return object instanceof a;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof a)) {
            return false;
        }
        a a2 = (a)object;
        if (!a2.a(this)) {
            return false;
        }
        List<l.a.h.k.c> list = this.c;
        List<l.a.h.k.c> list2 = a2.c;
        return !(list == null ? list2 != null : !list.equals(list2));
    }

    public int hashCode() {
        List<l.a.h.k.c> list = this.c;
        int n2 = list == null ? 43 : list.hashCode();
        return 59 + n2;
    }

}

