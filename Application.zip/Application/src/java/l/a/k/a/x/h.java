/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.u
 */
package l.a.k.a.x;

import l.a.k.a.n;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.u;

public class h
extends r {
    public static final u f;
    static /* synthetic */ Class h;

    static {
        h.t();
        f = u.f((String)"Ljava/lang/Object;");
    }

    protected h(int n2, r r2) {
        super(n2, r2);
    }

    public h(r r2) {
        this(327680, r2);
        if (h.class == h) {
            return;
        }
        throw new IllegalStateException();
    }

    static /* synthetic */ Class a(String string) {
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new NoClassDefFoundError(classNotFoundException.getMessage());
        }
    }

    private void b(int n2, String string, String string2, String string3, boolean bl) {
        switch (n2) {
            default: {
                throw new IllegalArgumentException();
            }
            case 185: {
                this.c(string, string2, string3);
                return;
            }
            case 184: {
                this.b(string, string2, string3, bl);
                return;
            }
            case 183: {
                this.a(string, string2, string3, bl);
                return;
            }
            case 182: 
        }
        this.c(string, string2, string3, bl);
    }

    private static void t() {
        h = h.a("net.bytebuddy.jar.asm.commons.InstructionAdapter");
    }

    public void a(double d2) {
        long l2 = Double.doubleToLongBits((double)d2);
        if (l2 != 0L && l2 != 4607182418800017408L) {
            this.d.a((Object)new Double(d2));
            return;
        }
        this.d.a(14 + (int)d2);
    }

    public void a(float f2) {
        int n2 = Float.floatToIntBits((float)f2);
        if ((long)n2 != 0L && n2 != 1065353216 && n2 != 1073741824) {
            this.d.a((Object)new Float(f2));
            return;
        }
        this.d.a(11 + (int)f2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(int var1_1) {
        if (var1_1 == 190) {
            this.e();
            return;
        }
        if (var1_1 == 191) {
            this.f();
            return;
        }
        if (var1_1 == 194) {
            this.n();
            return;
        }
        if (var1_1 == 195) {
            this.o();
            return;
        }
        switch (var1_1) {
            default: {
                switch (var1_1) {
                    default: {
                        switch (var1_1) {
                            default: {
                                switch (var1_1) {
                                    default: {
                                        switch (var1_1) {
                                            default: {
                                                throw new IllegalArgumentException();
                                            }
                                            case 177: {
                                                var20_2 = u.q;
                                                ** break;
                                            }
                                            case 176: {
                                                var20_2 = h.f;
                                                ** break;
                                            }
                                            case 175: {
                                                var20_2 = u.y;
                                                ** break;
                                            }
                                            case 174: {
                                                var20_2 = u.w;
                                                ** break;
                                            }
                                            case 173: {
                                                var20_2 = u.x;
                                                ** break;
                                            }
                                            case 172: 
                                        }
                                        var20_2 = u.v;
lbl41: // 6 sources:
                                        this.e(var20_2);
                                        return;
                                    }
                                    case 152: {
                                        var19_3 = u.y;
                                        ** GOTO lbl51
                                    }
                                    case 151: {
                                        var18_4 = u.y;
                                        ** GOTO lbl55
                                    }
                                    case 150: {
                                        var19_3 = u.w;
lbl51: // 2 sources:
                                        this.h(var19_3);
                                        return;
                                    }
                                    case 149: {
                                        var18_4 = u.w;
lbl55: // 2 sources:
                                        this.i(var18_4);
                                        return;
                                    }
                                    case 148: {
                                        this.m();
                                        return;
                                    }
                                    case 147: {
                                        var16_5 = u.v;
                                        var17_6 = u.u;
                                        ** GOTO lbl111
                                    }
                                    case 146: {
                                        var16_5 = u.v;
                                        var17_6 = u.s;
                                        ** GOTO lbl111
                                    }
                                    case 145: {
                                        var16_5 = u.v;
                                        var17_6 = u.t;
                                        ** GOTO lbl111
                                    }
                                    case 144: {
                                        var16_5 = u.y;
                                        ** GOTO lbl106
                                    }
                                    case 143: {
                                        var16_5 = u.y;
                                        ** GOTO lbl110
                                    }
                                    case 142: {
                                        var16_5 = u.y;
                                        ** GOTO lbl98
                                    }
                                    case 141: {
                                        var16_5 = u.w;
                                        ** GOTO lbl102
                                    }
                                    case 140: {
                                        var16_5 = u.w;
                                        ** GOTO lbl110
                                    }
                                    case 139: {
                                        var16_5 = u.w;
                                        ** GOTO lbl98
                                    }
                                    case 138: {
                                        var16_5 = u.x;
                                        ** GOTO lbl102
                                    }
                                    case 137: {
                                        var16_5 = u.x;
                                        ** GOTO lbl106
                                    }
                                    case 136: {
                                        var16_5 = u.x;
lbl98: // 3 sources:
                                        var17_6 = u.v;
                                        ** GOTO lbl111
                                    }
                                    case 135: {
                                        var16_5 = u.v;
lbl102: // 3 sources:
                                        var17_6 = u.y;
                                        ** GOTO lbl111
                                    }
                                    case 134: {
                                        var16_5 = u.v;
lbl106: // 3 sources:
                                        var17_6 = u.w;
                                        ** GOTO lbl111
                                    }
                                    case 133: 
                                }
                                var16_5 = u.v;
lbl110: // 3 sources:
                                var17_6 = u.x;
lbl111: // 7 sources:
                                this.a(var16_5, var17_6);
                                return;
                            }
                            case 131: {
                                var15_7 = u.x;
                                ** GOTO lbl118
                            }
                            case 130: {
                                var15_7 = u.v;
lbl118: // 2 sources:
                                this.v(var15_7);
                                return;
                            }
                            case 129: {
                                var14_8 = u.x;
                                ** GOTO lbl125
                            }
                            case 128: {
                                var14_8 = u.v;
lbl125: // 2 sources:
                                this.o(var14_8);
                                return;
                            }
                            case 127: {
                                var13_9 = u.x;
                                ** GOTO lbl132
                            }
                            case 126: {
                                var13_9 = u.v;
lbl132: // 2 sources:
                                this.c(var13_9);
                                return;
                            }
                            case 125: {
                                var12_10 = u.x;
                                ** GOTO lbl139
                            }
                            case 124: {
                                var12_10 = u.v;
lbl139: // 2 sources:
                                this.u(var12_10);
                                return;
                            }
                            case 123: {
                                var11_11 = u.x;
                                ** GOTO lbl146
                            }
                            case 122: {
                                var11_11 = u.v;
lbl146: // 2 sources:
                                this.r(var11_11);
                                return;
                            }
                            case 121: {
                                var10_12 = u.x;
                                ** GOTO lbl153
                            }
                            case 120: {
                                var10_12 = u.v;
lbl153: // 2 sources:
                                this.q(var10_12);
                                return;
                            }
                            case 119: {
                                var9_13 = u.y;
                                ** GOTO lbl166
                            }
                            case 118: {
                                var9_13 = u.w;
                                ** GOTO lbl166
                            }
                            case 117: {
                                var9_13 = u.x;
                                ** GOTO lbl166
                            }
                            case 116: {
                                var9_13 = u.v;
lbl166: // 4 sources:
                                this.m(var9_13);
                                return;
                            }
                            case 115: {
                                var8_14 = u.y;
                                ** GOTO lbl179
                            }
                            case 114: {
                                var8_14 = u.w;
                                ** GOTO lbl179
                            }
                            case 113: {
                                var8_14 = u.x;
                                ** GOTO lbl179
                            }
                            case 112: {
                                var8_14 = u.v;
lbl179: // 4 sources:
                                this.p(var8_14);
                                return;
                            }
                            case 111: {
                                var7_15 = u.y;
                                ** GOTO lbl192
                            }
                            case 110: {
                                var7_15 = u.w;
                                ** GOTO lbl192
                            }
                            case 109: {
                                var7_15 = u.x;
                                ** GOTO lbl192
                            }
                            case 108: {
                                var7_15 = u.v;
lbl192: // 4 sources:
                                this.j(var7_15);
                                return;
                            }
                            case 107: {
                                var6_16 = u.y;
                                ** GOTO lbl205
                            }
                            case 106: {
                                var6_16 = u.w;
                                ** GOTO lbl205
                            }
                            case 105: {
                                var6_16 = u.x;
                                ** GOTO lbl205
                            }
                            case 104: {
                                var6_16 = u.v;
lbl205: // 4 sources:
                                this.l(var6_16);
                                return;
                            }
                            case 103: {
                                var5_17 = u.y;
                                ** GOTO lbl218
                            }
                            case 102: {
                                var5_17 = u.w;
                                ** GOTO lbl218
                            }
                            case 101: {
                                var5_17 = u.x;
                                ** GOTO lbl218
                            }
                            case 100: {
                                var5_17 = u.v;
lbl218: // 4 sources:
                                this.s(var5_17);
                                return;
                            }
                            case 99: {
                                var4_18 = u.y;
                                ** GOTO lbl231
                            }
                            case 98: {
                                var4_18 = u.w;
                                ** GOTO lbl231
                            }
                            case 97: {
                                var4_18 = u.x;
                                ** GOTO lbl231
                            }
                            case 96: {
                                var4_18 = u.v;
lbl231: // 4 sources:
                                this.a(var4_18);
                                return;
                            }
                            case 95: {
                                this.s();
                                return;
                            }
                            case 94: {
                                this.j();
                                return;
                            }
                            case 93: {
                                this.i();
                                return;
                            }
                            case 92: {
                                this.h();
                                return;
                            }
                            case 91: {
                                this.l();
                                return;
                            }
                            case 90: {
                                this.k();
                                return;
                            }
                            case 89: {
                                this.g();
                                return;
                            }
                            case 88: {
                                this.r();
                                return;
                            }
                            case 87: {
                                this.q();
                                return;
                            }
                            case 86: {
                                var3_19 = u.u;
                                ** GOTO lbl283
                            }
                            case 85: {
                                var3_19 = u.s;
                                ** GOTO lbl283
                            }
                            case 84: {
                                var3_19 = u.t;
                                ** GOTO lbl283
                            }
                            case 83: {
                                var3_19 = h.f;
                                ** GOTO lbl283
                            }
                            case 82: {
                                var3_19 = u.y;
                                ** GOTO lbl283
                            }
                            case 81: {
                                var3_19 = u.w;
                                ** GOTO lbl283
                            }
                            case 80: {
                                var3_19 = u.x;
                                ** GOTO lbl283
                            }
                            case 79: 
                        }
                        var3_19 = u.v;
lbl283: // 8 sources:
                        this.f(var3_19);
                        return;
                    }
                    case 53: {
                        var2_20 = u.u;
                        ** break;
                    }
                    case 52: {
                        var2_20 = u.s;
                        ** break;
                    }
                    case 51: {
                        var2_20 = u.t;
                        ** break;
                    }
                    case 50: {
                        var2_20 = h.f;
                        ** break;
                    }
                    case 49: {
                        var2_20 = u.y;
                        ** break;
                    }
                    case 48: {
                        var2_20 = u.w;
                        ** break;
                    }
                    case 47: {
                        var2_20 = u.x;
                        ** break;
                    }
                    case 46: 
                }
                var2_20 = u.v;
lbl308: // 8 sources:
                this.b(var2_20);
                return;
            }
            case 14: 
            case 15: {
                this.a((double)(var1_1 - 14));
                return;
            }
            case 11: 
            case 12: 
            case 13: {
                this.a((float)(var1_1 - 11));
                return;
            }
            case 9: 
            case 10: {
                this.a((long)(var1_1 - 9));
                return;
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: {
                this.b(var1_1 - 3);
                return;
            }
            case 1: {
                this.b((Object)null);
                return;
            }
            case 0: 
        }
        this.p();
    }

    public void a(int n2, int n3) {
        this.e(n2, n3);
    }

    public /* varargs */ void a(int n2, int n3, q q2, q ... arrq) {
        this.b(n2, n3, q2, arrq);
    }

    public void a(int n2, String string) {
        u u2 = u.d((String)string);
        if (n2 != 187) {
            if (n2 != 189) {
                if (n2 != 192) {
                    if (n2 == 193) {
                        this.k(u2);
                        return;
                    }
                    throw new IllegalArgumentException();
                }
                this.g(u2);
                return;
            }
            this.n(u2);
            return;
        }
        this.d(u2);
    }

    public void a(int n2, String string, String string2, String string3) {
        switch (n2) {
            default: {
                throw new IllegalArgumentException();
            }
            case 181: {
                this.g(string, string2, string3);
                return;
            }
            case 180: {
                this.a(string, string2, string3);
                return;
            }
            case 179: {
                this.h(string, string2, string3);
                return;
            }
            case 178: 
        }
        this.b(string, string2, string3);
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            super.a(n2, string, string2, string3, bl);
            return;
        }
        this.b(n2, string, string2, string3, bl);
    }

    public void a(int n2, q q2) {
        if (n2 != 198) {
            if (n2 != 199) {
                switch (n2) {
                    default: {
                        throw new IllegalArgumentException();
                    }
                    case 168: {
                        this.s(q2);
                        return;
                    }
                    case 167: {
                        this.b(q2);
                        return;
                    }
                    case 166: {
                        this.d(q2);
                        return;
                    }
                    case 165: {
                        this.c(q2);
                        return;
                    }
                    case 164: {
                        this.k(q2);
                        return;
                    }
                    case 163: {
                        this.j(q2);
                        return;
                    }
                    case 162: {
                        this.i(q2);
                        return;
                    }
                    case 161: {
                        this.l(q2);
                        return;
                    }
                    case 160: {
                        this.m(q2);
                        return;
                    }
                    case 159: {
                        this.h(q2);
                        return;
                    }
                    case 158: {
                        this.n(q2);
                        return;
                    }
                    case 157: {
                        this.g(q2);
                        return;
                    }
                    case 156: {
                        this.f(q2);
                        return;
                    }
                    case 155: {
                        this.o(q2);
                        return;
                    }
                    case 154: {
                        this.p(q2);
                        return;
                    }
                    case 153: 
                }
                this.e(q2);
                return;
            }
            this.q(q2);
            return;
        }
        this.r(q2);
    }

    public void a(int n2, u u2) {
        this.d.d(u2.a(21), n2);
    }

    public void a(long l2) {
        if (l2 != 0L && l2 != 1L) {
            this.d.a((Object)new Long(l2));
            return;
        }
        this.d.a(9 + (int)l2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(Object object) {
        block14 : {
            int n2;
            block10 : {
                block13 : {
                    block12 : {
                        block11 : {
                            block9 : {
                                if (!(object instanceof Integer)) break block9;
                                n2 = (Integer)object;
                                break block10;
                            }
                            if (!(object instanceof Byte)) break block11;
                            n2 = ((Byte)object).intValue();
                            break block10;
                        }
                        if (!(object instanceof Character)) break block12;
                        n2 = ((Character)object).charValue();
                        break block10;
                    }
                    if (!(object instanceof Short)) break block13;
                    n2 = ((Short)object).intValue();
                    break block10;
                }
                if (!(object instanceof Boolean)) break block14;
                n2 = ((Boolean)object).booleanValue() ? 1 : 0;
            }
            this.b(n2);
            return;
        }
        if (object instanceof Float) {
            this.a(((Float)object).floatValue());
            return;
        }
        if (object instanceof Long) {
            this.a((Long)object);
            return;
        }
        if (object instanceof Double) {
            this.a((Double)object);
            return;
        }
        if (object instanceof String) {
            this.b(object);
            return;
        }
        if (object instanceof u) {
            this.t((u)object);
            return;
        }
        if (object instanceof n) {
            this.a((n)object);
            return;
        }
        IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
        throw illegalArgumentException;
    }

    public void a(String string, int n2) {
        this.c(string, n2);
    }

    public void a(String string, String string2, String string3) {
        this.d.a(180, string, string2, string3);
    }

    public void a(String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            if (!bl) {
                this.d(string, string2, string3);
                return;
            }
            throw new IllegalArgumentException("INVOKESPECIAL on interfaces require ASM 5");
        }
        this.d.a(183, string, string2, string3, bl);
    }

    public /* varargs */ void a(String string, String string2, n n2, Object ... arrobject) {
        this.b(string, string2, n2, arrobject);
    }

    public void a(n n2) {
        this.d.a((Object)n2);
    }

    public void a(q q2) {
        this.t(q2);
    }

    public void a(q q2, int[] arrn, q[] arrq) {
        this.b(q2, arrn, arrq);
    }

    public void a(u u2) {
        this.d.a(u2.a(96));
    }

    /*
     * Enabled aggressive block sorting
     */
    public void a(u u2, u u3) {
        block2 : {
            int n2;
            r r2;
            block5 : {
                block18 : {
                    block17 : {
                        block16 : {
                            block15 : {
                                block14 : {
                                    block11 : {
                                        int n3;
                                        r r3;
                                        block7 : {
                                            block13 : {
                                                block12 : {
                                                    block8 : {
                                                        block10 : {
                                                            block9 : {
                                                                block3 : {
                                                                    block6 : {
                                                                        block4 : {
                                                                            if (u2 == u3) break block2;
                                                                            if (u2 != u.y) break block3;
                                                                            if (u3 != u.w) break block4;
                                                                            r2 = this.d;
                                                                            n2 = 144;
                                                                            break block5;
                                                                        }
                                                                        if (u3 != u.x) break block6;
                                                                        r2 = this.d;
                                                                        n2 = 143;
                                                                        break block5;
                                                                    }
                                                                    r3 = this.d;
                                                                    n3 = 142;
                                                                    break block7;
                                                                }
                                                                if (u2 != u.w) break block8;
                                                                if (u3 != u.y) break block9;
                                                                r2 = this.d;
                                                                n2 = 141;
                                                                break block5;
                                                            }
                                                            if (u3 != u.x) break block10;
                                                            r2 = this.d;
                                                            n2 = 140;
                                                            break block5;
                                                        }
                                                        r3 = this.d;
                                                        n3 = 139;
                                                        break block7;
                                                    }
                                                    if (u2 != u.x) break block11;
                                                    if (u3 != u.y) break block12;
                                                    r2 = this.d;
                                                    n2 = 138;
                                                    break block5;
                                                }
                                                if (u3 != u.w) break block13;
                                                r2 = this.d;
                                                n2 = 137;
                                                break block5;
                                            }
                                            r3 = this.d;
                                            n3 = 136;
                                        }
                                        r3.a(n3);
                                        this.a(u.v, u3);
                                        return;
                                    }
                                    if (u3 != u.t) break block14;
                                    r2 = this.d;
                                    n2 = 145;
                                    break block5;
                                }
                                if (u3 != u.s) break block15;
                                r2 = this.d;
                                n2 = 146;
                                break block5;
                            }
                            if (u3 != u.y) break block16;
                            r2 = this.d;
                            n2 = 135;
                            break block5;
                        }
                        if (u3 != u.w) break block17;
                        r2 = this.d;
                        n2 = 134;
                        break block5;
                    }
                    if (u3 != u.x) break block18;
                    r2 = this.d;
                    n2 = 133;
                    break block5;
                }
                if (u3 != u.u) break block2;
                r2 = this.d;
                n2 = 147;
            }
            r2.a(n2);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public void b(int n2) {
        block6 : {
            int n3;
            r r2;
            block5 : {
                block4 : {
                    if (n2 >= -1 && n2 <= 5) {
                        this.d.a(n2 + 3);
                        return;
                    }
                    if (n2 < -128 || n2 > 127) break block4;
                    r2 = this.d;
                    n3 = 16;
                    break block5;
                }
                if (n2 < -32768 || n2 > 32767) break block6;
                r2 = this.d;
                n3 = 17;
            }
            r2.b(n3, n2);
            return;
        }
        this.d.a((Object)new Integer(n2));
    }

    public void b(int n2, int n3) {
        if (n2 != 16 && n2 != 17) {
            if (n2 == 188) {
                u u2;
                switch (n3) {
                    default: {
                        throw new IllegalArgumentException();
                    }
                    case 11: {
                        u2 = u.x;
                        break;
                    }
                    case 10: {
                        u2 = u.v;
                        break;
                    }
                    case 9: {
                        u2 = u.u;
                        break;
                    }
                    case 8: {
                        u2 = u.t;
                        break;
                    }
                    case 7: {
                        u2 = u.y;
                        break;
                    }
                    case 6: {
                        u2 = u.w;
                        break;
                    }
                    case 5: {
                        u2 = u.s;
                        break;
                    }
                    case 4: {
                        u2 = u.r;
                    }
                }
                this.n(u2);
                return;
            }
            throw new IllegalArgumentException();
        }
        this.b(n3);
    }

    public /* varargs */ void b(int n2, int n3, q q2, q ... arrq) {
        this.d.a(n2, n3, q2, arrq);
    }

    public void b(int n2, String string, String string2, String string3) {
        if (this.c >= 327680) {
            super.b(n2, string, string2, string3);
            return;
        }
        boolean bl = n2 == 185;
        this.b(n2, string, string2, string3, bl);
    }

    public void b(int n2, u u2) {
        this.d.d(u2.a(54), n2);
    }

    public void b(Object object) {
        if (object == null) {
            this.d.a(1);
            return;
        }
        this.d.a(object);
    }

    public void b(String string, String string2, String string3) {
        this.d.a(178, string, string2, string3);
    }

    public void b(String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            if (!bl) {
                this.e(string, string2, string3);
                return;
            }
            throw new IllegalArgumentException("INVOKESTATIC on interfaces require ASM 5");
        }
        this.d.a(184, string, string2, string3, bl);
    }

    public void b(String string, String string2, n n2, Object[] arrobject) {
        this.d.a(string, string2, n2, arrobject);
    }

    public void b(q q2) {
        this.d.a(167, q2);
    }

    public void b(q q2, int[] arrn, q[] arrq) {
        this.d.a(q2, arrn, arrq);
    }

    public void b(u u2) {
        this.d.a(u2.a(46));
    }

    public void c(int n2) {
        this.d.d(169, n2);
    }

    public void c(String string, int n2) {
        this.d.a(string, n2);
    }

    public void c(String string, String string2, String string3) {
        this.d.a(185, string, string2, string3, true);
    }

    public void c(String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            if (!bl) {
                this.f(string, string2, string3);
                return;
            }
            throw new IllegalArgumentException("INVOKEVIRTUAL on interfaces require ASM 5");
        }
        this.d.a(182, string, string2, string3, bl);
    }

    public void c(q q2) {
        this.d.a(165, q2);
    }

    public void c(u u2) {
        this.d.a(u2.a(126));
    }

    public void d(int n2, int n3) {
        if (n2 != 169) {
            u u2;
            switch (n2) {
                default: {
                    u u3;
                    switch (n2) {
                        default: {
                            throw new IllegalArgumentException();
                        }
                        case 58: {
                            u3 = f;
                            break;
                        }
                        case 57: {
                            u3 = u.y;
                            break;
                        }
                        case 56: {
                            u3 = u.w;
                            break;
                        }
                        case 55: {
                            u3 = u.x;
                            break;
                        }
                        case 54: {
                            u3 = u.v;
                        }
                    }
                    this.b(n3, u3);
                    return;
                }
                case 25: {
                    u2 = f;
                    break;
                }
                case 24: {
                    u2 = u.y;
                    break;
                }
                case 23: {
                    u2 = u.w;
                    break;
                }
                case 22: {
                    u2 = u.x;
                    break;
                }
                case 21: {
                    u2 = u.v;
                }
            }
            this.a(n3, u2);
            return;
        }
        this.c(n3);
    }

    public void d(String string, String string2, String string3) {
        if (this.c >= 327680) {
            this.a(string, string2, string3, false);
            return;
        }
        this.d.a(183, string, string2, string3, false);
    }

    public void d(q q2) {
        this.d.a(166, q2);
    }

    public void d(u u2) {
        this.d.a(187, u2.g());
    }

    public void e() {
        this.d.a(190);
    }

    public void e(int n2, int n3) {
        this.d.a(n2, n3);
    }

    public void e(String string, String string2, String string3) {
        if (this.c >= 327680) {
            this.b(string, string2, string3, false);
            return;
        }
        this.d.a(184, string, string2, string3, false);
    }

    public void e(q q2) {
        this.d.a(153, q2);
    }

    public void e(u u2) {
        this.d.a(u2.a(172));
    }

    public void f() {
        this.d.a(191);
    }

    public void f(String string, String string2, String string3) {
        if (this.c >= 327680) {
            this.c(string, string2, string3, false);
            return;
        }
        this.d.b(182, string, string2, string3);
    }

    public void f(q q2) {
        this.d.a(156, q2);
    }

    public void f(u u2) {
        this.d.a(u2.a(79));
    }

    public void g() {
        this.d.a(89);
    }

    public void g(String string, String string2, String string3) {
        this.d.a(181, string, string2, string3);
    }

    public void g(q q2) {
        this.d.a(157, q2);
    }

    public void g(u u2) {
        this.d.a(192, u2.g());
    }

    public void h() {
        this.d.a(92);
    }

    public void h(String string, String string2, String string3) {
        this.d.a(179, string, string2, string3);
    }

    public void h(q q2) {
        this.d.a(159, q2);
    }

    public void h(u u2) {
        r r2 = this.d;
        int n2 = u2 == u.w ? 150 : 152;
        r2.a(n2);
    }

    public void i() {
        this.d.a(93);
    }

    public void i(q q2) {
        this.d.a(162, q2);
    }

    public void i(u u2) {
        r r2 = this.d;
        int n2 = u2 == u.w ? 149 : 151;
        r2.a(n2);
    }

    public void j() {
        this.d.a(94);
    }

    public void j(q q2) {
        this.d.a(163, q2);
    }

    public void j(u u2) {
        this.d.a(u2.a(108));
    }

    public void k() {
        this.d.a(90);
    }

    public void k(q q2) {
        this.d.a(164, q2);
    }

    public void k(u u2) {
        this.d.a(193, u2.g());
    }

    public void l() {
        this.d.a(91);
    }

    public void l(q q2) {
        this.d.a(161, q2);
    }

    public void l(u u2) {
        this.d.a(u2.a(104));
    }

    public void m() {
        this.d.a(148);
    }

    public void m(q q2) {
        this.d.a(160, q2);
    }

    public void m(u u2) {
        this.d.a(u2.a(116));
    }

    public void n() {
        this.d.a(194);
    }

    public void n(q q2) {
        this.d.a(158, q2);
    }

    public void n(u u2) {
        int n2;
        switch (u2.j()) {
            default: {
                this.d.a(189, u2.g());
                return;
            }
            case 8: {
                n2 = 7;
                break;
            }
            case 7: {
                n2 = 11;
                break;
            }
            case 6: {
                n2 = 6;
                break;
            }
            case 5: {
                n2 = 10;
                break;
            }
            case 4: {
                n2 = 9;
                break;
            }
            case 3: {
                n2 = 8;
                break;
            }
            case 2: {
                n2 = 5;
                break;
            }
            case 1: {
                n2 = 4;
            }
        }
        this.d.b(188, n2);
    }

    public void o() {
        this.d.a(195);
    }

    public void o(q q2) {
        this.d.a(155, q2);
    }

    public void o(u u2) {
        this.d.a(u2.a(128));
    }

    public void p() {
        this.d.a(0);
    }

    public void p(q q2) {
        this.d.a(154, q2);
    }

    public void p(u u2) {
        this.d.a(u2.a(112));
    }

    public void q() {
        this.d.a(87);
    }

    public void q(q q2) {
        this.d.a(199, q2);
    }

    public void q(u u2) {
        this.d.a(u2.a(120));
    }

    public void r() {
        this.d.a(88);
    }

    public void r(q q2) {
        this.d.a(198, q2);
    }

    public void r(u u2) {
        this.d.a(u2.a(122));
    }

    public void s() {
        this.d.a(95);
    }

    public void s(q q2) {
        this.d.a(168, q2);
    }

    public void s(u u2) {
        this.d.a(u2.a(100));
    }

    public void t(q q2) {
        this.d.a(q2);
    }

    public void t(u u2) {
        this.d.a((Object)u2);
    }

    public void u(u u2) {
        this.d.a(u2.a(124));
    }

    public void v(u u2) {
        this.d.a(u2.a(130));
    }
}

