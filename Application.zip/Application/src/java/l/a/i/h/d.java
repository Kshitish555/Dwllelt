/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.instrument.ClassDefinition
 *  java.lang.instrument.Instrumentation
 *  java.lang.instrument.UnmodifiableClassException
 *  java.lang.reflect.Method
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.ConcurrentHashMap
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.i.a
 *  l.a.i.a$c
 *  l.a.i.h.b
 *  l.a.i.h.c
 *  l.a.i.h.d$b
 *  l.a.i.h.d$c
 */
package l.a.i.h;

import java.io.File;
import java.io.IOException;
import java.lang.instrument.ClassDefinition;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import l.a.h.k.c;
import l.a.i.a;
import l.a.i.h.b;
import l.a.i.h.d;

public class d
implements l.a.i.h.c<ClassLoader> {
    private static final String o = "net.bytebuddy.agent.Installer";
    private static final String s = "getInstrumentation";
    private static final Object t;
    private final Instrumentation c;
    private final c d;
    private final b f;
    private final Map<String, Class<?>> h;

    public d(Instrumentation instrumentation, c c2) {
        this(instrumentation, c2, a.c, Collections.emptyMap());
    }

    protected d(Instrumentation instrumentation, c c2, b b2, Map<String, Class<?>> map) {
        this.c = instrumentation;
        this.d = c2.a(instrumentation);
        this.f = b2;
        this.h = map;
    }

    public static d a() {
        try {
            d d2 = d.a((Instrumentation)ClassLoader.getSystemClassLoader().loadClass(o).getMethod(s, new Class[0]).invoke(t, new Object[0]));
            return d2;
        }
        catch (Exception exception) {
            throw new IllegalStateException("The Byte Buddy agent is not installed or not accessible", (Throwable)exception);
        }
        catch (RuntimeException runtimeException) {
            throw runtimeException;
        }
    }

    public static d a(Instrumentation instrumentation) {
        block4 : {
            c c2;
            block3 : {
                block2 : {
                    if (!instrumentation.isRedefineClassesSupported()) break block2;
                    c2 = c.d;
                    break block3;
                }
                if (!instrumentation.isRetransformClassesSupported()) break block4;
                c2 = c.f;
            }
            return new d(instrumentation, c2);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instrumentation does not support manipulation of loaded classes: ");
        stringBuilder.append((Object)instrumentation);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public Map<l.a.h.k.c, Class<?>> a(ClassLoader classLoader, Map<l.a.h.k.c, byte[]> map) {
        HashMap hashMap = new HashMap(this.h);
        for (Class class_ : this.c.getInitiatedClasses(classLoader)) {
            hashMap.put((Object)c.d.f((Class)class_), (Object)class_);
        }
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        HashMap hashMap2 = new HashMap();
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Map.Entry entry : map.entrySet()) {
            Class class_ = (Class)hashMap.get((Object)((l.a.h.k.c)entry.getKey()).getName());
            if (class_ != null) {
                concurrentHashMap.put((Object)class_, (Object)new ClassDefinition(class_, (byte[])entry.getValue()));
                hashMap2.put(entry.getKey(), (Object)class_);
                continue;
            }
            linkedHashMap.put(entry.getKey(), entry.getValue());
        }
        try {
            this.d.a(this.c, (Map)concurrentHashMap);
            if (linkedHashMap.isEmpty()) return hashMap2;
            b.d d2 = classLoader == null ? this.f.a(this.c) : new b.d(classLoader);
            hashMap2.putAll(d2.a((Map)linkedHashMap));
            return hashMap2;
        }
        catch (UnmodifiableClassException unmodifiableClassException) {
            throw new IllegalStateException("Cannot redefine specified class", (Throwable)unmodifiableClassException);
        }
        catch (ClassNotFoundException classNotFoundException) {
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Could not locate classes for redefinition", (Throwable)classNotFoundException);
            throw illegalArgumentException;
        }
    }

    public d a(File file) {
        return new d(this.c, this.d, new b(file), this.h);
    }

    public /* varargs */ d a(l.a.i.a a2, Class<?> ... arrclass) throws IOException {
        if (arrclass.length > 0) {
            try {
                this.d.a(this.c, a2, Arrays.asList((Object[])arrclass));
                return this;
            }
            catch (UnmodifiableClassException unmodifiableClassException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot reset types ");
                stringBuilder.append(Arrays.toString((Object[])arrclass));
                throw new IllegalStateException(stringBuilder.toString(), (Throwable)unmodifiableClassException);
            }
            catch (ClassNotFoundException classNotFoundException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Cannot locate types ");
                stringBuilder.append(Arrays.toString((Object[])arrclass));
                throw new IllegalArgumentException(stringBuilder.toString(), (Throwable)classNotFoundException);
            }
        }
        return this;
    }

    public /* varargs */ d a(Class<?> ... arrclass) {
        HashMap hashMap = new HashMap(this.h);
        for (Class<?> class_ : arrclass) {
            hashMap.put((Object)c.d.f(class_), class_);
        }
        return new d(this.c, this.d, this.f, (Map<String, Class<?>>)hashMap);
    }

    protected boolean a(Object object) {
        return object instanceof d;
    }

    public /* varargs */ d b(Class<?> ... arrclass) throws IOException {
        if (arrclass.length == 0) {
            return this;
        }
        return this.a(a.c.a((ClassLoader)arrclass[0].getClassLoader()), arrclass);
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof d)) {
            return false;
        }
        d d2 = (d)object;
        if (!d2.a(this)) {
            return false;
        }
        Instrumentation instrumentation = this.c;
        Instrumentation instrumentation2 = d2.c;
        if (instrumentation == null ? instrumentation2 != null : !instrumentation.equals((Object)instrumentation2)) {
            return false;
        }
        c c2 = this.d;
        c c3 = d2.d;
        if (c2 == null ? c3 != null : !c2.equals((Object)c3)) {
            return false;
        }
        b b2 = this.f;
        b b3 = d2.f;
        if (b2 == null ? b3 != null : !b2.equals((Object)b3)) {
            return false;
        }
        Map<String, Class<?>> map = this.h;
        Map<String, Class<?>> map2 = d2.h;
        return !(map == null ? map2 != null : !map.equals(map2));
    }

    public int hashCode() {
        Instrumentation instrumentation = this.c;
        int n2 = 43;
        int n3 = instrumentation == null ? 43 : instrumentation.hashCode();
        int n4 = n3 + 59;
        c c2 = this.d;
        int n5 = n4 * 59;
        int n6 = c2 == null ? 43 : c2.hashCode();
        int n7 = n5 + n6;
        b b2 = this.f;
        int n8 = n7 * 59;
        int n9 = b2 == null ? 43 : b2.hashCode();
        int n10 = n8 + n9;
        Map<String, Class<?>> map = this.h;
        int n11 = n10 * 59;
        if (map != null) {
            n2 = map.hashCode();
        }
        return n11 + n2;
    }
}

