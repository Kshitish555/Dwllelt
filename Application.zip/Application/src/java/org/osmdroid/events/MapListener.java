/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.osmdroid.events;

import org.osmdroid.events.ScrollEvent;
import org.osmdroid.events.ZoomEvent;

public interface MapListener {
    public boolean onScroll(ScrollEvent var1);

    public boolean onZoom(ZoomEvent var1);
}

