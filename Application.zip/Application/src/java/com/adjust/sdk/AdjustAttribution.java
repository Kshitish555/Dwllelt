/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.ObjectStreamField
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import com.adjust.sdk.Util;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamField;
import java.io.Serializable;
import org.json.JSONObject;

public class AdjustAttribution
implements Serializable {
    private static final ObjectStreamField[] serialPersistentFields;
    private static final long serialVersionUID = 1L;
    public String adgroup;
    public String adid;
    public String campaign;
    public String clickLabel;
    public String creative;
    public String network;
    public String trackerName;
    public String trackerToken;

    static {
        ObjectStreamField[] arrobjectStreamField = new ObjectStreamField[]{new ObjectStreamField("trackerToken", String.class), new ObjectStreamField("trackerName", String.class), new ObjectStreamField("network", String.class), new ObjectStreamField("campaign", String.class), new ObjectStreamField("adgroup", String.class), new ObjectStreamField("creative", String.class), new ObjectStreamField("clickLabel", String.class), new ObjectStreamField("adid", String.class)};
        serialPersistentFields = arrobjectStreamField;
    }

    public static AdjustAttribution fromJson(JSONObject jSONObject, String string, String string2) {
        if (jSONObject == null) {
            return null;
        }
        AdjustAttribution adjustAttribution = new AdjustAttribution();
        if ("unity".equals((Object)string2)) {
            adjustAttribution.trackerToken = jSONObject.optString("tracker_token", "");
            adjustAttribution.trackerName = jSONObject.optString("tracker_name", "");
            adjustAttribution.network = jSONObject.optString("network", "");
            adjustAttribution.campaign = jSONObject.optString("campaign", "");
            adjustAttribution.adgroup = jSONObject.optString("adgroup", "");
            adjustAttribution.creative = jSONObject.optString("creative", "");
            adjustAttribution.clickLabel = jSONObject.optString("click_label", "");
            if (string == null) {
                string = "";
            }
            adjustAttribution.adid = string;
            return adjustAttribution;
        }
        adjustAttribution.trackerToken = jSONObject.optString("tracker_token", null);
        adjustAttribution.trackerName = jSONObject.optString("tracker_name", null);
        adjustAttribution.network = jSONObject.optString("network", null);
        adjustAttribution.campaign = jSONObject.optString("campaign", null);
        adjustAttribution.adgroup = jSONObject.optString("adgroup", null);
        adjustAttribution.creative = jSONObject.optString("creative", null);
        adjustAttribution.clickLabel = jSONObject.optString("click_label", null);
        adjustAttribution.adid = string;
        return adjustAttribution;
    }

    private void readObject(ObjectInputStream objectInputStream) throws ClassNotFoundException, IOException {
        objectInputStream.defaultReadObject();
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (AdjustAttribution.class != object.getClass()) {
            return false;
        }
        AdjustAttribution adjustAttribution = (AdjustAttribution)object;
        if (!Util.equalString(this.trackerToken, adjustAttribution.trackerToken)) {
            return false;
        }
        if (!Util.equalString(this.trackerName, adjustAttribution.trackerName)) {
            return false;
        }
        if (!Util.equalString(this.network, adjustAttribution.network)) {
            return false;
        }
        if (!Util.equalString(this.campaign, adjustAttribution.campaign)) {
            return false;
        }
        if (!Util.equalString(this.adgroup, adjustAttribution.adgroup)) {
            return false;
        }
        if (!Util.equalString(this.creative, adjustAttribution.creative)) {
            return false;
        }
        if (!Util.equalString(this.clickLabel, adjustAttribution.clickLabel)) {
            return false;
        }
        return Util.equalString(this.adid, adjustAttribution.adid);
    }

    public int hashCode() {
        return 37 * (37 * (37 * (37 * (37 * (37 * (37 * (629 + Util.hashString(this.trackerToken)) + Util.hashString(this.trackerName)) + Util.hashString(this.network)) + Util.hashString(this.campaign)) + Util.hashString(this.adgroup)) + Util.hashString(this.creative)) + Util.hashString(this.clickLabel)) + Util.hashString(this.adid);
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.trackerToken, this.trackerName, this.network, this.campaign, this.adgroup, this.creative, this.clickLabel, this.adid};
        return Util.formatString("tt:%s tn:%s net:%s cam:%s adg:%s cre:%s cl:%s adid:%s", arrobject);
    }
}

