/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Factory
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.strategy.Value
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Factory;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.ObjectInstance;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.stream.InputNode;

class PrimitiveFactory
extends Factory {
    public PrimitiveFactory(Context context, Type type) {
        super(context, type);
    }

    public PrimitiveFactory(Context context, Type type, Class class_) {
        super(context, type, class_);
    }

    public Object getInstance(String string2, Class class_) throws Exception {
        return this.support.read(string2, class_);
    }

    public Instance getInstance(InputNode inputNode) throws Exception {
        Value value = this.getOverride(inputNode);
        Class class_ = this.getType();
        if (value == null) {
            return this.context.getInstance(class_);
        }
        return new ObjectInstance(this.context, value);
    }

    public String getText(Object object) throws Exception {
        Class class_ = object.getClass();
        if (class_.isEnum()) {
            return this.support.write(object, class_);
        }
        return this.support.write(object, class_);
    }
}

