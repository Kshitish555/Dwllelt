/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package h.a.a.s0;

class i {
    Object a;

    public i(Object object) {
        this.a = object;
    }
}

