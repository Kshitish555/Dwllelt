/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 */
package org.simpleframework.xml.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import org.simpleframework.xml.core.Parameter;

class ParameterMap
extends LinkedHashMap<Object, Parameter>
implements Iterable<Parameter> {
    public Parameter get(int n2) {
        return (Parameter)this.getAll().get(n2);
    }

    public List<Parameter> getAll() {
        Collection collection = this.values();
        if (!collection.isEmpty()) {
            return new ArrayList(collection);
        }
        return Collections.emptyList();
    }

    public Iterator<Parameter> iterator() {
        return this.values().iterator();
    }
}

