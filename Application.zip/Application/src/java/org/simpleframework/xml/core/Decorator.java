/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.stream.OutputNode;

interface Decorator {
    public void decorate(OutputNode var1);

    public void decorate(OutputNode var1, Decorator var2);
}

