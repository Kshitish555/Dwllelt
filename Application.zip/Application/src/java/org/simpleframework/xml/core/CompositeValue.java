/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Entry
 *  org.simpleframework.xml.core.PersistenceException
 *  org.simpleframework.xml.core.Traverser
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.Style
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Entry;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Traverser;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Style;

class CompositeValue
implements Converter {
    private final Context context;
    private final Entry entry;
    private final Traverser root;
    private final Style style;
    private final Type type;

    public CompositeValue(Context context, Entry entry, Type type) throws Exception {
        this.root = new Traverser(context);
        this.style = context.getStyle();
        this.context = context;
        this.entry = entry;
        this.type = type;
    }

    private boolean validate(InputNode inputNode, String string2) throws Exception {
        InputNode inputNode2 = inputNode.getNext(this.style.getElement(string2));
        Class class_ = this.type.getType();
        if (inputNode2 == null) {
            return true;
        }
        if (inputNode2.isEmpty()) {
            return true;
        }
        return this.root.validate(inputNode2, class_);
    }

    public Object read(InputNode inputNode) throws Exception {
        InputNode inputNode2 = inputNode.getNext();
        Class class_ = this.type.getType();
        if (inputNode2 == null) {
            return null;
        }
        if (inputNode2.isEmpty()) {
            return null;
        }
        return this.root.read(inputNode2, class_);
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Class class_ = this.type.getType();
        if (object == null) {
            return this.read(inputNode);
        }
        Object[] arrobject = new Object[]{class_, this.entry};
        throw new PersistenceException("Can not read value of %s for %s", arrobject);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Class class_ = this.type.getType();
        String string2 = this.entry.getValue();
        if (string2 == null) {
            string2 = this.context.getName(class_);
        }
        return this.validate(inputNode, string2);
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Class class_ = this.type.getType();
        String string2 = this.entry.getValue();
        if (string2 == null) {
            string2 = this.context.getName(class_);
        }
        String string3 = this.style.getElement(string2);
        this.root.write(outputNode, object, class_, string3);
    }
}

