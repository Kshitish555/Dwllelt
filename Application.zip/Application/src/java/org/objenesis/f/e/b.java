/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedOutputStream
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.security.AccessController
 *  java.security.PrivilegedAction
 *  java.security.ProtectionDomain
 */
package org.objenesis.f.e;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;
import org.objenesis.ObjenesisException;

public final class b {
    public static final int A = 8192;
    public static final int B = 16384;
    public static final byte[] C = new byte[]{-54, -2, -70, -66};
    public static final byte[] D = new byte[]{0, 0, 0, 49};
    private static Method E;
    private static final ProtectionDomain F;
    public static final byte a = 42;
    public static final byte b = -73;
    public static final byte c = -79;
    public static final byte d = -69;
    public static final byte e = 89;
    public static final byte f = -80;
    public static final int g = 1;
    public static final int h = 3;
    public static final int i = 4;
    public static final int j = 5;
    public static final int k = 6;
    public static final int l = 7;
    public static final int m = 8;
    public static final int n = 9;
    public static final int o = 10;
    public static final int p = 11;
    public static final int q = 12;
    public static final int r = 15;
    public static final int s = 16;
    public static final int t = 18;
    public static final int u = 1;
    public static final int v = 16;
    public static final int w = 32;
    public static final int x = 512;
    public static final int y = 1024;
    public static final int z = 4096;

    static {
        F = (ProtectionDomain)AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<ProtectionDomain>(){

            public ProtectionDomain run() {
                return b.class.getProtectionDomain();
            }
        });
        AccessController.doPrivileged((PrivilegedAction)new PrivilegedAction<Object>(){

            public Object run() {
                try {
                    Class class_ = Class.forName((String)"java.lang.ClassLoader");
                    Class[] arrclass = new Class[]{String.class, byte[].class, Integer.TYPE, Integer.TYPE, ProtectionDomain.class};
                    E = class_.getDeclaredMethod("defineClass", arrclass);
                    E.setAccessible(true);
                    return null;
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    throw new ObjenesisException(noSuchMethodException);
                }
                catch (ClassNotFoundException classNotFoundException) {
                    throw new ObjenesisException(classNotFoundException);
                }
            }
        });
    }

    private b() {
    }

    public static <T> Class<T> a(ClassLoader classLoader, String string2) {
        try {
            Class class_ = Class.forName((String)string2, (boolean)true, (ClassLoader)classLoader);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            return null;
        }
    }

    public static <T> Class<T> a(String string2, byte[] arrby, ClassLoader classLoader) throws Exception {
        Object[] arrobject = new Object[]{string2, arrby, new Integer(0), new Integer(arrby.length), F};
        Class class_ = (Class)E.invoke((Object)classLoader, arrobject);
        Class.forName((String)string2, (boolean)true, (ClassLoader)classLoader);
        return class_;
    }

    public static String a(String string2) {
        return string2.replace('.', '/');
    }

    public static void a(String string2, byte[] arrby) throws IOException {
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream((OutputStream)new FileOutputStream(string2));
        try {
            bufferedOutputStream.write(arrby);
            return;
        }
        finally {
            bufferedOutputStream.close();
        }
    }

    public static String b(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(b.a(string2));
        stringBuilder.append(".class");
        return stringBuilder.toString();
    }

    public static byte[] c(String string2) throws IOException {
        InputStream inputStream;
        block3 : {
            String string3 = b.b(string2);
            byte[] arrby = new byte[2500];
            inputStream = b.class.getClassLoader().getResourceAsStream(string3);
            int n2 = inputStream.read(arrby);
            if (n2 >= 2500) break block3;
            byte[] arrby2 = new byte[n2];
            System.arraycopy((Object)arrby, (int)0, (Object)arrby2, (int)0, (int)n2);
            return arrby2;
        }
        throw new IllegalArgumentException("The class is longer that 2500 bytes which is currently unsupported");
        finally {
            inputStream.close();
        }
    }

}

