/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.RandomAccessFile
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Set
 *  java.util.TreeSet
 */
package org.osmdroid.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class GEMFFile {
    private static final int FILE_COPY_BUFFER_SIZE = 1024;
    private static final long FILE_SIZE_LIMIT = 0x40000000L;
    private static final int TILE_SIZE = 256;
    private static final int U32_SIZE = 4;
    private static final int U64_SIZE = 8;
    private static final int VERSION = 4;
    private int mCurrentSource;
    private final List<String> mFileNames;
    private final List<Long> mFileSizes;
    private final List<RandomAccessFile> mFiles;
    private final String mLocation;
    private final List<GEMFRange> mRangeData;
    private boolean mSourceLimited;
    private final LinkedHashMap<Integer, String> mSources;

    public GEMFFile(File file) throws FileNotFoundException, IOException {
        this(file.getAbsolutePath());
    }

    public GEMFFile(String string2) throws FileNotFoundException, IOException {
        this.mFiles = new ArrayList();
        this.mFileNames = new ArrayList();
        this.mRangeData = new ArrayList();
        this.mFileSizes = new ArrayList();
        this.mSources = new LinkedHashMap();
        this.mSourceLimited = false;
        this.mCurrentSource = 0;
        this.mLocation = string2;
        this.openFiles();
        this.readHeader();
    }

    /*
     * Exception decompiling
     */
    public GEMFFile(String var1, List<File> var2) throws FileNotFoundException, IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    private void openFiles() throws FileNotFoundException {
        File file = new File(this.mLocation);
        this.mFiles.add((Object)new RandomAccessFile(file, "r"));
        this.mFileNames.add((Object)file.getPath());
        int n2 = 0;
        do {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(this.mLocation);
            stringBuilder.append("-");
            stringBuilder.append(++n2);
            File file2 = new File(stringBuilder.toString());
            if (!file2.exists()) break;
            this.mFiles.add((Object)new RandomAccessFile(file2, "r"));
            this.mFileNames.add((Object)file2.getPath());
        } while (true);
    }

    private void readHeader() throws IOException {
        IOException iOException;
        List<RandomAccessFile> list = this.mFiles;
        int n2 = 0;
        RandomAccessFile randomAccessFile = (RandomAccessFile)list.get(0);
        for (RandomAccessFile randomAccessFile2 : this.mFiles) {
            this.mFileSizes.add((Object)randomAccessFile2.length());
        }
        int n3 = randomAccessFile.readInt();
        if (n3 == 4) {
            int n4 = randomAccessFile.readInt();
            if (n4 == 256) {
                int n5 = randomAccessFile.readInt();
                for (int i2 = 0; i2 < n5; ++i2) {
                    int n6 = randomAccessFile.readInt();
                    int n7 = randomAccessFile.readInt();
                    byte[] arrby = new byte[n7];
                    randomAccessFile.read(arrby, 0, n7);
                    String string2 = new String(arrby);
                    this.mSources.put((Object)new Integer(n6), (Object)string2);
                }
                int n8 = randomAccessFile.readInt();
                while (n2 < n8) {
                    GEMFRange gEMFRange = new GEMFRange();
                    gEMFRange.zoom = randomAccessFile.readInt();
                    gEMFRange.xMin = randomAccessFile.readInt();
                    gEMFRange.xMax = randomAccessFile.readInt();
                    gEMFRange.yMin = randomAccessFile.readInt();
                    gEMFRange.yMax = randomAccessFile.readInt();
                    gEMFRange.sourceIndex = randomAccessFile.readInt();
                    gEMFRange.offset = randomAccessFile.readLong();
                    this.mRangeData.add((Object)gEMFRange);
                    ++n2;
                }
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Bad tile size: ");
            stringBuilder.append(n4);
            throw new IOException(stringBuilder.toString());
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Bad file version: ");
        stringBuilder.append(n3);
        iOException = new IOException(stringBuilder.toString());
        throw iOException;
    }

    public void acceptAnySource() {
        this.mSourceLimited = false;
    }

    public void close() throws IOException {
        Iterator iterator = this.mFiles.iterator();
        while (iterator.hasNext()) {
            ((RandomAccessFile)iterator.next()).close();
        }
    }

    public InputStream getInputStream(int n2, int n3, int n4) {
        long l2;
        int n5;
        int n6;
        RandomAccessFile randomAccessFile;
        block10 : {
            GEMFRange gEMFRange2;
            block9 : {
                for (GEMFRange gEMFRange2 : this.mRangeData) {
                    if (n4 != gEMFRange2.zoom || n2 < gEMFRange2.xMin || n2 > gEMFRange2.xMax || n3 < gEMFRange2.yMin || n3 > gEMFRange2.yMax || this.mSourceLimited && gEMFRange2.sourceIndex != this.mCurrentSource) continue;
                    break block9;
                }
                gEMFRange2 = null;
            }
            if (gEMFRange2 == null) {
                return null;
            }
            int n7 = 1 + gEMFRange2.yMax - gEMFRange2.yMin;
            int n8 = n2 - gEMFRange2.xMin;
            long l3 = 12L * (long)(n3 - gEMFRange2.yMin + n8 * n7) + gEMFRange2.offset;
            RandomAccessFile randomAccessFile2 = (RandomAccessFile)this.mFiles.get(0);
            randomAccessFile2.seek(l3);
            l2 = randomAccessFile2.readLong();
            n6 = randomAccessFile2.readInt();
            randomAccessFile = (RandomAccessFile)this.mFiles.get(0);
            long l4 = l2 LCMP (Long)this.mFileSizes.get(0);
            if (l4 <= 0) break block10;
            int n9 = this.mFileSizes.size();
            for (n5 = 0; n5 < n9 - 1; ++n5) {
                if (l2 <= (Long)this.mFileSizes.get(n5)) break;
                l2 -= ((Long)this.mFileSizes.get(n5)).longValue();
            }
            try {
                randomAccessFile = (RandomAccessFile)this.mFiles.get(n5);
            }
            catch (IOException iOException) {
                return null;
            }
        }
        long l5 = l2;
        randomAccessFile.seek(l5);
        GEMFInputStream gEMFInputStream = new GEMFInputStream((String)this.mFileNames.get(n5), l5, n6);
        return gEMFInputStream;
    }

    public String getName() {
        return this.mLocation;
    }

    public LinkedHashMap<Integer, String> getSources() {
        return this.mSources;
    }

    public Set<Integer> getZoomLevels() {
        TreeSet treeSet = new TreeSet();
        Iterator iterator = this.mRangeData.iterator();
        while (iterator.hasNext()) {
            treeSet.add((Object)((GEMFRange)iterator.next()).zoom);
        }
        return treeSet;
    }

    public void selectSource(int n2) {
        if (this.mSources.containsKey((Object)new Integer(n2))) {
            this.mSourceLimited = true;
            this.mCurrentSource = n2;
        }
    }

    class GEMFInputStream
    extends InputStream {
        RandomAccessFile raf;
        int remainingBytes;

        GEMFInputStream(String string2, long l2, int n2) throws IOException {
            RandomAccessFile randomAccessFile;
            this.raf = randomAccessFile = new RandomAccessFile(string2, "r");
            randomAccessFile.seek(l2);
            this.remainingBytes = n2;
        }

        public int available() {
            return this.remainingBytes;
        }

        public void close() throws IOException {
            this.raf.close();
        }

        public boolean markSupported() {
            return false;
        }

        public int read() throws IOException {
            int n2 = this.remainingBytes;
            if (n2 > 0) {
                this.remainingBytes = n2 - 1;
                return this.raf.read();
            }
            throw new IOException("End of stream");
        }

        public int read(byte[] arrby, int n2, int n3) throws IOException {
            RandomAccessFile randomAccessFile = this.raf;
            int n4 = this.remainingBytes;
            if (n3 > n4) {
                n3 = n4;
            }
            int n5 = randomAccessFile.read(arrby, n2, n3);
            this.remainingBytes -= n5;
            return n5;
        }

        public long skip(long l2) {
            return 0L;
        }
    }

    private class GEMFRange {
        Long offset;
        Integer sourceIndex;
        Integer xMax;
        Integer xMin;
        Integer yMax;
        Integer yMin;
        Integer zoom;

        private GEMFRange() {
        }

        public String toString() {
            Object[] arrobject = new Object[]{this.sourceIndex, this.zoom, this.xMin, this.xMax, this.yMin, this.yMax, this.offset};
            return String.format((String)"GEMF Range: source=%d, zoom=%d, x=%d-%d, y=%d-%d, offset=0x%08X", (Object[])arrobject);
        }
    }

}

