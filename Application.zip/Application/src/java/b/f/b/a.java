/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accessibilityservice.AccessibilityServiceInfo
 *  android.content.pm.PackageManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  androidx.annotation.h0
 *  androidx.annotation.i0
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b.f.b;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.h0;
import androidx.annotation.i0;

public final class a {
    public static final int a = 1;
    public static final int b = 2;
    public static final int c = 4;
    public static final int d = 8;
    public static final int e = 32;
    public static final int f = -1;
    public static final int g = 2;
    public static final int h = 4;
    public static final int i = 8;
    public static final int j = 16;
    public static final int k = 32;

    private a() {
    }

    public static int a(@h0 AccessibilityServiceInfo accessibilityServiceInfo) {
        if (Build.VERSION.SDK_INT >= 18) {
            return accessibilityServiceInfo.getCapabilities();
        }
        return accessibilityServiceInfo.getCanRetrieveWindowContent();
    }

    @h0
    public static String a(int n2) {
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 4) {
                    if (n2 != 8) {
                        return "UNKNOWN";
                    }
                    return "CAPABILITY_CAN_FILTER_KEY_EVENTS";
                }
                return "CAPABILITY_CAN_REQUEST_ENHANCED_WEB_ACCESSIBILITY";
            }
            return "CAPABILITY_CAN_REQUEST_TOUCH_EXPLORATION";
        }
        return "CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT";
    }

    @i0
    public static String a(@h0 AccessibilityServiceInfo accessibilityServiceInfo, @h0 PackageManager packageManager) {
        if (Build.VERSION.SDK_INT >= 16) {
            return accessibilityServiceInfo.loadDescription(packageManager);
        }
        return accessibilityServiceInfo.getDescription();
    }

    @h0
    public static String b(int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        while (n2 > 0) {
            int n3 = 1 << Integer.numberOfTrailingZeros((int)n2);
            n2 &= ~n3;
            if (stringBuilder.length() > 1) {
                stringBuilder.append(", ");
            }
            if (n3 != 1) {
                if (n3 != 2) {
                    if (n3 != 4) {
                        if (n3 != 8) {
                            if (n3 != 16) continue;
                            stringBuilder.append("FEEDBACK_GENERIC");
                            continue;
                        }
                        stringBuilder.append("FEEDBACK_VISUAL");
                        continue;
                    }
                    stringBuilder.append("FEEDBACK_AUDIBLE");
                    continue;
                }
                stringBuilder.append("FEEDBACK_HAPTIC");
                continue;
            }
            stringBuilder.append("FEEDBACK_SPOKEN");
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    @i0
    public static String c(int n2) {
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 4) {
                    if (n2 != 8) {
                        if (n2 != 16) {
                            if (n2 != 32) {
                                return null;
                            }
                            return "FLAG_REQUEST_FILTER_KEY_EVENTS";
                        }
                        return "FLAG_REPORT_VIEW_IDS";
                    }
                    return "FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY";
                }
                return "FLAG_REQUEST_TOUCH_EXPLORATION_MODE";
            }
            return "FLAG_INCLUDE_NOT_IMPORTANT_VIEWS";
        }
        return "DEFAULT";
    }
}

