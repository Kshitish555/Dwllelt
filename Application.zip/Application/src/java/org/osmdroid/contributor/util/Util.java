/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Date
 *  java.util.TimeZone
 *  org.osmdroid.contributor.util.RecordedGeoPoint
 *  org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants
 */
package org.osmdroid.contributor.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import org.osmdroid.contributor.util.RecordedGeoPoint;
import org.osmdroid.contributor.util.constants.OpenStreetMapContributorConstants;
import org.osmdroid.util.BoundingBoxE6;

public class Util
implements OpenStreetMapContributorConstants {
    public static final SimpleDateFormat UTCSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

    private Util() {
        UTCSimpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)"UTC"));
    }

    public static final String convertTimestampToUTCString(long l) {
        return UTCSimpleDateFormat.format(new Date(l));
    }

    public static boolean isSufficienDataForUpload(ArrayList<RecordedGeoPoint> arrayList) {
        if (arrayList == null) {
            return false;
        }
        if (arrayList.size() < 100) {
            return false;
        }
        return BoundingBoxE6.fromGeoPoints(arrayList).getDiagonalLengthInMeters() >= 300;
    }
}

