/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.Set
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 *  org.simpleframework.xml.core.Model
 *  org.simpleframework.xml.core.ModelList
 *  org.simpleframework.xml.core.ModelMap
 *  org.simpleframework.xml.core.Policy
 *  org.simpleframework.xml.core.TreeModel$OrderList
 */
package org.simpleframework.xml.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import org.simpleframework.xml.core.AttributeException;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.Model;
import org.simpleframework.xml.core.ModelList;
import org.simpleframework.xml.core.ModelMap;
import org.simpleframework.xml.core.PathException;
import org.simpleframework.xml.core.Policy;
import org.simpleframework.xml.core.TextException;
import org.simpleframework.xml.core.TreeModel;

/*
 * Exception performing whole class analysis.
 */
class TreeModel
implements Model {
    private LabelMap attributes;
    private Detail detail;
    private LabelMap elements;
    private Expression expression;
    private int index;
    private Label list;
    private ModelMap models;
    private String name;
    private OrderList order;
    private Policy policy;
    private String prefix;
    private Label text;

    public TreeModel(Policy policy, Detail detail) {
        this(policy, detail, null, null, 1);
    }

    public TreeModel(Policy policy, Detail detail, String string2, String string3, int n) {
        this.attributes = new LabelMap(policy);
        this.elements = new LabelMap(policy);
        this.models = new ModelMap(detail);
        this.order = new /* Unavailable Anonymous Inner Class!! */;
        this.detail = detail;
        this.policy = policy;
        this.prefix = string3;
        this.index = n;
        this.name = string2;
    }

    private Model create(String string2, String string3, int n) throws Exception {
        TreeModel treeModel = new TreeModel(this.policy, this.detail, string2, string3, n);
        if (string2 != null) {
            this.models.register(string2, (Model)treeModel);
            this.order.add((Object)string2);
        }
        return treeModel;
    }

    private void validateAttributes(Class class_) throws Exception {
        for (String string2 : this.attributes.keySet()) {
            if ((Label)this.attributes.get((Object)string2) != null) {
                Expression expression = this.expression;
                if (expression == null) continue;
                expression.getAttribute(string2);
                continue;
            }
            throw new AttributeException("Ordered attribute '%s' does not exist in %s", new Object[]{string2, class_});
        }
    }

    private void validateElements(Class class_) throws Exception {
        for (String string2 : this.elements.keySet()) {
            ModelList modelList = (ModelList)this.models.get((Object)string2);
            Label label = (Label)this.elements.get((Object)string2);
            if (modelList == null && label == null) {
                throw new ElementException("Ordered element '%s' does not exist in %s", new Object[]{string2, class_});
            }
            if (modelList != null && label != null && !modelList.isEmpty()) {
                throw new ElementException("Element '%s' is also a path name in %s", new Object[]{string2, class_});
            }
            Expression expression = this.expression;
            if (expression == null) continue;
            expression.getElement(string2);
        }
    }

    private void validateExpression(Label label) throws Exception {
        Expression expression = label.getExpression();
        Expression expression2 = this.expression;
        if (expression2 != null) {
            String string2;
            String string3 = expression2.getPath();
            if (string3.equals((Object)(string2 = expression.getPath()))) {
                return;
            }
            Object[] arrobject = new Object[]{string3, string2, this.detail};
            throw new PathException("Path '%s' does not match '%s' in %s", arrobject);
        }
        this.expression = expression;
    }

    private void validateExpressions(Class class_) throws Exception {
        for (Label label : this.elements) {
            if (label == null) continue;
            this.validateExpression(label);
        }
        for (Label label : this.attributes) {
            if (label == null) continue;
            this.validateExpression(label);
        }
        Label label = this.text;
        if (label != null) {
            this.validateExpression(label);
        }
    }

    private void validateModels(Class class_) throws Exception {
        Iterator iterator = this.models.iterator();
        while (iterator.hasNext()) {
            Iterator iterator2 = ((ModelList)iterator.next()).iterator();
            int n = 1;
            while (iterator2.hasNext()) {
                Model model = (Model)iterator2.next();
                if (model == null) continue;
                String string2 = model.getName();
                int n2 = model.getIndex();
                int n3 = n + 1;
                if (n2 == n) {
                    model.validate(class_);
                    n = n3;
                    continue;
                }
                Object[] arrobject = new Object[]{string2, n2, class_};
                throw new ElementException("Path section '%s[%s]' is out of sequence in %s", arrobject);
            }
        }
    }

    private void validateText(Class class_) throws Exception {
        if (this.text != null) {
            if (this.elements.isEmpty()) {
                if (!this.isComposite()) {
                    return;
                }
                Object[] arrobject = new Object[]{this.text, class_};
                throw new TextException("Text annotation %s can not be used with paths in %s", arrobject);
            }
            Object[] arrobject = new Object[]{this.text, class_};
            throw new TextException("Text annotation %s used with elements in %s", arrobject);
        }
    }

    public LabelMap getAttributes() throws Exception {
        return this.attributes.getLabels();
    }

    public LabelMap getElements() throws Exception {
        return this.elements.getLabels();
    }

    public Expression getExpression() {
        return this.expression;
    }

    public int getIndex() {
        return this.index;
    }

    public ModelMap getModels() throws Exception {
        return this.models.getModels();
    }

    public String getName() {
        return this.name;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public Label getText() {
        Label label = this.list;
        if (label != null) {
            return label;
        }
        return this.text;
    }

    public boolean isAttribute(String string2) {
        return this.attributes.containsKey((Object)string2);
    }

    public boolean isComposite() {
        Iterator iterator = this.models.iterator();
        while (iterator.hasNext()) {
            for (Model model : (ModelList)iterator.next()) {
                if (model == null || model.isEmpty()) continue;
                return true;
            }
        }
        return true ^ this.models.isEmpty();
    }

    public boolean isElement(String string2) {
        return this.elements.containsKey((Object)string2);
    }

    public boolean isEmpty() {
        if (this.text != null) {
            return false;
        }
        if (!this.elements.isEmpty()) {
            return false;
        }
        if (!this.attributes.isEmpty()) {
            return false;
        }
        return true ^ this.isComposite();
    }

    public boolean isModel(String string2) {
        return this.models.containsKey((Object)string2);
    }

    public Iterator<String> iterator() {
        ArrayList arrayList = new ArrayList();
        Iterator iterator = this.order.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)((String)iterator.next()));
        }
        return arrayList.iterator();
    }

    public Model lookup(String string2, int n) {
        return this.models.lookup(string2, n);
    }

    public Model lookup(Expression expression) {
        Model model = this.lookup(expression.getFirst(), expression.getIndex());
        if (expression.isPath()) {
            Expression expression2 = expression.getPath(1, 0);
            if (model != null) {
                return model.lookup(expression2);
            }
        }
        return model;
    }

    public Model register(String string2, String string3, int n) throws Exception {
        Model model = this.models.lookup(string2, n);
        if (model == null) {
            return this.create(string2, string3, n);
        }
        return model;
    }

    public void register(Label label) throws Exception {
        if (label.isAttribute()) {
            this.registerAttribute(label);
            return;
        }
        if (label.isText()) {
            this.registerText(label);
            return;
        }
        this.registerElement(label);
    }

    public void registerAttribute(String string2) throws Exception {
        this.attributes.put((Object)string2, null);
    }

    public void registerAttribute(Label label) throws Exception {
        String string2 = label.getName();
        if (this.attributes.get((Object)string2) == null) {
            this.attributes.put((Object)string2, (Object)label);
            return;
        }
        throw new AttributeException("Duplicate annotation of name '%s' on %s", new Object[]{string2, label});
    }

    public void registerElement(String string2) throws Exception {
        if (!this.order.contains((Object)string2)) {
            this.order.add((Object)string2);
        }
        this.elements.put((Object)string2, null);
    }

    public void registerElement(Label label) throws Exception {
        String string2 = label.getName();
        if (this.elements.get((Object)string2) == null) {
            if (!this.order.contains((Object)string2)) {
                this.order.add((Object)string2);
            }
            if (label.isTextList()) {
                this.list = label;
            }
            this.elements.put((Object)string2, (Object)label);
            return;
        }
        throw new ElementException("Duplicate annotation of name '%s' on %s", new Object[]{string2, label});
    }

    public void registerText(Label label) throws Exception {
        if (this.text == null) {
            this.text = label;
            return;
        }
        throw new TextException("Duplicate text annotation on %s", new Object[]{label});
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.name, this.index};
        return String.format((String)"model '%s[%s]'", (Object[])arrobject);
    }

    public void validate(Class class_) throws Exception {
        this.validateExpressions(class_);
        this.validateAttributes(class_);
        this.validateElements(class_);
        this.validateModels(class_);
        this.validateText(class_);
    }
}

