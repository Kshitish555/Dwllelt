/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Constructor
 *  java.util.Iterator
 *  java.util.List
 *  org.simpleframework.xml.core.Parameter
 *  org.simpleframework.xml.core.ParameterMap
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.List;
import org.simpleframework.xml.core.Parameter;
import org.simpleframework.xml.core.ParameterMap;

class Signature
implements Iterable<Parameter> {
    private final Constructor factory;
    private final ParameterMap parameters = new ParameterMap();
    private final Class type;

    public Signature(Constructor constructor) {
        this(constructor, constructor.getDeclaringClass());
    }

    public Signature(Constructor constructor, Class class_) {
        this.factory = constructor;
        this.type = class_;
    }

    public Signature(Signature signature) {
        this(signature.factory, signature.type);
    }

    public void add(Parameter parameter) {
        Object object = parameter.getKey();
        if (object != null) {
            this.parameters.put(object, (Object)parameter);
        }
    }

    public boolean contains(Object object) {
        return this.parameters.containsKey(object);
    }

    public Signature copy() throws Exception {
        Signature signature = new Signature(this);
        Iterator<Parameter> iterator = this.iterator();
        while (iterator.hasNext()) {
            signature.add((Parameter)iterator.next());
        }
        return signature;
    }

    public Object create() throws Exception {
        if (!this.factory.isAccessible()) {
            this.factory.setAccessible(true);
        }
        return this.factory.newInstance(new Object[0]);
    }

    public Object create(Object[] arrobject) throws Exception {
        if (!this.factory.isAccessible()) {
            this.factory.setAccessible(true);
        }
        return this.factory.newInstance(arrobject);
    }

    public Parameter get(int n) {
        return this.parameters.get(n);
    }

    public Parameter get(Object object) {
        return (Parameter)this.parameters.get(object);
    }

    public List<Parameter> getAll() {
        return this.parameters.getAll();
    }

    public Class getType() {
        return this.type;
    }

    public boolean isEmpty() {
        return this.parameters.isEmpty();
    }

    public Iterator<Parameter> iterator() {
        return this.parameters.iterator();
    }

    public Parameter remove(Object object) {
        return (Parameter)this.parameters.remove(object);
    }

    public void set(Object object, Parameter parameter) {
        this.parameters.put(object, (Object)parameter);
    }

    public int size() {
        return this.parameters.size();
    }

    public String toString() {
        return this.factory.toString();
    }
}

