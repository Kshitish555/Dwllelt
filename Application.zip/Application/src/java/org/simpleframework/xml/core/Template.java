/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package org.simpleframework.xml.core;

class Template {
    protected char[] buf;
    protected String cache;
    protected int count;

    public Template() {
        this(16);
    }

    public Template(int n) {
        this.buf = new char[n];
    }

    public void append(char c2) {
        this.ensureCapacity(1 + this.count);
        char[] arrc = this.buf;
        int n = this.count;
        this.count = n + 1;
        arrc[n] = c2;
    }

    public void append(String string) {
        this.ensureCapacity(this.count + string.length());
        string.getChars(0, string.length(), this.buf, this.count);
        this.count += string.length();
    }

    public void append(String string, int n, int n2) {
        this.ensureCapacity(n2 + this.count);
        string.getChars(n, n2, this.buf, this.count);
        this.count = n2 + this.count;
    }

    public void append(Template template) {
        this.append(template.buf, 0, template.count);
    }

    public void append(Template template, int n, int n2) {
        this.append(template.buf, n, n2);
    }

    public void append(char[] arrc, int n, int n2) {
        this.ensureCapacity(n2 + this.count);
        System.arraycopy((Object)arrc, (int)n, (Object)this.buf, (int)this.count, (int)n2);
        this.count = n2 + this.count;
    }

    public void clear() {
        this.cache = null;
        this.count = 0;
    }

    protected void ensureCapacity(int n) {
        char[] arrc = this.buf;
        if (arrc.length < n) {
            char[] arrc2 = new char[Math.max((int)n, (int)(2 * arrc.length))];
            System.arraycopy((Object)this.buf, (int)0, (Object)arrc2, (int)0, (int)this.count);
            this.buf = arrc2;
        }
    }

    public int length() {
        return this.count;
    }

    public String toString() {
        return new String(this.buf, 0, this.count);
    }
}

