/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.s0.h
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Array
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.util.AbstractMap
 *  java.util.AbstractMap$SimpleEntry
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 */
package h.a.a.s0;

import h.a.a.s0.c;
import h.a.a.s0.e;
import h.a.a.s0.g;
import h.a.a.s0.h;
import h.a.a.s0.k;
import h.a.a.s0.l;
import h.a.a.s0.n;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class f {
    public static <T> T a(Class<T> class_, String string) throws IllegalArgumentException {
        return f.a(class_, string, new h.a.a.s0.a(true, false));
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static <T> T a(Class<T> class_, String string, h.a.a.s0.a a2) throws IllegalArgumentException {
        Object object;
        Object object2 = h.c((String)string);
        try {
            object = a2.c(class_).newInstance(new Object[0]);
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Could not construct object of type ");
            stringBuilder.append(class_.getName());
            throw new IllegalArgumentException(stringBuilder.toString(), (Throwable)exception);
        }
        ArrayList arrayList = new ArrayList();
        f.a(object, class_, object2, a2, f.a(object, object2), (List<Runnable>)arrayList);
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            ((Runnable)iterator.next()).run();
        }
        return (T)object;
        catch (Exception exception) {
            IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Could not parse JSON", (Throwable)exception);
            throw illegalArgumentException;
        }
    }

    private static Object a(Object object, Type type, boolean bl) {
        if (object == null) {
            return null;
        }
        if (!(object instanceof e) && !(object instanceof g)) {
            if (!(type instanceof ParameterizedType)) {
                if (type instanceof Class) {
                    Class class_ = (Class)type;
                    if (class_ == String.class) {
                        if (object instanceof CharSequence) {
                            return object.toString();
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Expected string; got ");
                        stringBuilder.append(object.getClass().getName());
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    if (class_ == CharSequence.class) {
                        if (object instanceof CharSequence) {
                            return object;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Expected CharSequence; got ");
                        stringBuilder.append(object.getClass().getName());
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    if (class_ != Integer.class && class_ != Integer.TYPE) {
                        if (class_ != Long.class && class_ != Long.TYPE) {
                            if (class_ != Short.class && class_ != Short.TYPE) {
                                if (class_ != Float.class && class_ != Float.TYPE) {
                                    if (class_ != Double.class && class_ != Double.TYPE) {
                                        if (class_ != Byte.class && class_ != Byte.TYPE) {
                                            if (class_ != Character.class && class_ != Character.TYPE) {
                                                if (class_ != Boolean.class && class_ != Boolean.TYPE) {
                                                    if (Enum.class.isAssignableFrom(class_)) {
                                                        if (object instanceof CharSequence) {
                                                            return Enum.valueOf((Class)class_, (String)object.toString());
                                                        }
                                                        StringBuilder stringBuilder = new StringBuilder();
                                                        stringBuilder.append("Expected string for enum value; got ");
                                                        stringBuilder.append(object.getClass().getName());
                                                        throw new IllegalArgumentException(stringBuilder.toString());
                                                    }
                                                    if (k.a(type).isAssignableFrom(object.getClass())) {
                                                        return object;
                                                    }
                                                    StringBuilder stringBuilder = new StringBuilder();
                                                    stringBuilder.append("Got type ");
                                                    stringBuilder.append((Object)object.getClass());
                                                    stringBuilder.append("; expected ");
                                                    stringBuilder.append((Object)type);
                                                    throw new IllegalArgumentException(stringBuilder.toString());
                                                }
                                                if (bl && object instanceof CharSequence) {
                                                    return Boolean.parseBoolean((String)object.toString());
                                                }
                                                if (object instanceof Boolean) {
                                                    return object;
                                                }
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Expected boolean; got ");
                                                stringBuilder.append(object.getClass().getName());
                                                throw new IllegalArgumentException(stringBuilder.toString());
                                            }
                                            if (object instanceof CharSequence) {
                                                CharSequence charSequence = (CharSequence)object;
                                                if (charSequence.length() == 1) {
                                                    return Character.valueOf((char)charSequence.charAt(0));
                                                }
                                                throw new IllegalArgumentException("Expected single character; got string");
                                            }
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Expected character; got ");
                                            stringBuilder.append(object.getClass().getName());
                                            throw new IllegalArgumentException(stringBuilder.toString());
                                        }
                                        if (bl && object instanceof CharSequence) {
                                            return Byte.parseByte((String)object.toString());
                                        }
                                        if (object instanceof Integer) {
                                            int n2 = (Integer)object;
                                            if (n2 >= -128 && n2 <= 127) {
                                                return (byte)n2;
                                            }
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("Expected byte; got out-of-range value ");
                                            stringBuilder.append(n2);
                                            throw new IllegalArgumentException(stringBuilder.toString());
                                        }
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Expected byte; got ");
                                        stringBuilder.append(object.getClass().getName());
                                        throw new IllegalArgumentException(stringBuilder.toString());
                                    }
                                    if (bl && object instanceof CharSequence) {
                                        return Double.parseDouble((String)object.toString());
                                    }
                                    if (object instanceof Double) {
                                        return object;
                                    }
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("Expected double; got ");
                                    stringBuilder.append(object.getClass().getName());
                                    throw new IllegalArgumentException(stringBuilder.toString());
                                }
                                if (bl && object instanceof CharSequence) {
                                    return Float.valueOf((float)Float.parseFloat((String)object.toString()));
                                }
                                if (object instanceof Double) {
                                    double d2 = (Double)object;
                                    if (!(d2 < 1.401298464324817E-45) && !(d2 > 3.4028234663852886E38)) {
                                        return Float.valueOf((float)((float)d2));
                                    }
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("Expected float; got out-of-range value ");
                                    stringBuilder.append(d2);
                                    throw new IllegalArgumentException(stringBuilder.toString());
                                }
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Expected float; got ");
                                stringBuilder.append(object.getClass().getName());
                                throw new IllegalArgumentException(stringBuilder.toString());
                            }
                            if (bl && object instanceof CharSequence) {
                                return Short.parseShort((String)object.toString());
                            }
                            if (object instanceof Integer) {
                                int n3 = (Integer)object;
                                if (n3 >= -32768 && n3 <= 32767) {
                                    return (short)n3;
                                }
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Expected short; got out-of-range value ");
                                stringBuilder.append(n3);
                                throw new IllegalArgumentException(stringBuilder.toString());
                            }
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Expected short; got ");
                            stringBuilder.append(object.getClass().getName());
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                        boolean bl2 = object instanceof Long;
                        boolean bl3 = object instanceof Integer;
                        if (bl && object instanceof CharSequence) {
                            String string = object.toString();
                            long l2 = bl2 ? Long.parseLong((String)string) : (long)Integer.parseInt((String)string);
                            return l2;
                        }
                        if (!bl2 && !bl3) {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Expected long; got ");
                            stringBuilder.append(object.getClass().getName());
                            throw new IllegalArgumentException(stringBuilder.toString());
                        }
                        if (bl2) {
                            return object;
                        }
                        return (long)((Integer)object).intValue();
                    }
                    if (bl && object instanceof CharSequence) {
                        return Integer.parseInt((String)object.toString());
                    }
                    if (object instanceof Integer) {
                        return object;
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Expected integer; got ");
                    stringBuilder.append(object.getClass().getName());
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Got illegal basic value type: ");
                stringBuilder.append((Object)type);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Got illegal ParameterizedType: ");
            stringBuilder.append((Object)type);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        throw new RuntimeException("Expected a basic value type");
    }

    private static HashMap<CharSequence, Object> a(Object object, Object object2) {
        HashMap hashMap = new HashMap();
        if (object2 != null && object2 instanceof g) {
            Object object3;
            Map.Entry entry;
            g g2 = (g)object2;
            if (g2.a.size() > 0 && ((String)(entry = (Map.Entry)g2.a.get(0)).getKey()).equals((Object)"__ID") && ((object3 = entry.getValue()) == null || !CharSequence.class.isAssignableFrom(object3.getClass()))) {
                hashMap.put((Object)((CharSequence)object3), object);
            }
        }
        return hashMap;
    }

    public static void a(Object object, String string, String string2) throws IllegalArgumentException {
        f.a(object, string, string2, new h.a.a.s0.a(true, false));
    }

    public static void a(Object object, String string, String string2, h.a.a.s0.a a2) throws IllegalArgumentException {
        IllegalArgumentException illegalArgumentException;
        if (object != null) {
            Object object2;
            try {
                object2 = h.c((String)string2);
            }
            catch (Exception exception) {
                throw new IllegalArgumentException("Could not parse JSON", (Throwable)exception);
            }
            g g2 = new g(1);
            g2.a.add((Object)new AbstractMap.SimpleEntry((Object)string, object2));
            ArrayList arrayList = new ArrayList();
            f.a(object, (Type)object.getClass(), g2, a2, (Map<CharSequence, Object>)new HashMap(), (List<Runnable>)arrayList);
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                ((Runnable)iterator.next()).run();
            }
            return;
        }
        illegalArgumentException = new IllegalArgumentException("Cannot deserialize to a field of a null object");
        throw illegalArgumentException;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static void a(Object var0, Type var1_1, Object var2_2, h.a.a.s0.a var3_3, Map<CharSequence, Object> var4_4, List<Runnable> var5_5) {
        block57 : {
            block55 : {
                block56 : {
                    var6_6 = var1_1;
                    var7_7 = var3_3;
                    if (var2_2 == null) {
                        return;
                    }
                    var8_8 = var2_2 instanceof g;
                    var9_9 = var2_2 instanceof e;
                    if (!var9_9 && !var8_8) {
                        var130_10 = new StringBuilder();
                        var130_10.append("Expected JSONObject or JSONArray, got ");
                        var130_10.append(var2_2.getClass().getSimpleName());
                        throw new IllegalArgumentException(var130_10.toString());
                    }
                    var10_11 = var8_8 != false ? (g)var2_2 : null;
                    var11_12 = var9_9 != false ? (e)var2_2 : null;
                    var12_13 = var0.getClass();
                    var13_14 = Map.class.isAssignableFrom(var12_13);
                    var14_15 = var13_14 != false ? (Map)var0 : null;
                    var15_16 = Collection.class.isAssignableFrom(var12_13);
                    var16_17 = var15_16 != false ? (Collection)var0 : null;
                    var17_18 = var12_13.isArray();
                    var18_19 = var13_14 == false && var15_16 == false && var17_18 == false;
                    var19_20 = var13_14 || var18_19;
                    if (var19_20 != var8_8) break block55;
                    var24_21 = var15_16 || var17_18;
                    if (var24_21 != var9_9) break block55;
                    if (var6_6 instanceof Class) {
                        var129_22 = (Class)var6_6;
                        if (Map.class.isAssignableFrom(var129_22)) {
                            if (var13_14 == false) throw new IllegalArgumentException("Got an unexpected map type");
                            var6_6 = var129_22.getGenericSuperclass();
                        } else if (Collection.class.isAssignableFrom(var129_22)) {
                            if (var15_16 == false) throw new IllegalArgumentException("Got an unexpected map type");
                            var6_6 = var129_22.getGenericSuperclass();
                        }
                    }
                    if (var6_6 instanceof Class) {
                        var127_23 = (Class)var6_6;
                        var33_24 = var17_18 != false ? var127_23.getComponentType() : null;
                        var128_25 = var17_18 != false && var33_24.isArray() == false;
                        var30_26 = var128_25;
                        var32_27 = null;
                        var31_28 = null;
                        var29_29 = null;
                    } else {
                        if (!(var6_6 instanceof ParameterizedType)) {
                            var124_115 = new StringBuilder();
                            var124_115.append("Got illegal type: ");
                            var124_115.append((Object)var6_6);
                            throw new IllegalArgumentException(var124_115.toString());
                        }
                        var25_30 = new n((ParameterizedType)var6_6);
                        var26_31 = var25_30.b.length;
                        if (var13_14 && var26_31 != 2) {
                            var120_32 = new StringBuilder();
                            var120_32.append("Wrong number of type arguments for Map: got ");
                            var120_32.append(var26_31);
                            var120_32.append("; expected 2");
                            throw new IllegalArgumentException(var120_32.toString());
                        }
                        if (var15_16 && var26_31 != 1) {
                            var116_33 = new StringBuilder();
                            var116_33.append("Wrong number of type arguments for Collection: got ");
                            var116_33.append(var26_31);
                            var116_33.append("; expected 1");
                            throw new IllegalArgumentException(var116_33.toString());
                        }
                        var27_34 = var13_14 != false ? var25_30.b[0] : null;
                        var28_35 = var13_14 != false ? var25_30.b[1] : (var15_16 != false ? var25_30.b[0] : null);
                        var29_29 = var28_35;
                        var30_26 = false;
                        var31_28 = var25_30;
                        var32_27 = var27_34;
                        var33_24 = null;
                    }
                    var34_36 = var29_29 == null ? null : k.a(var29_29);
                    if (var13_14 || var15_16 || var30_26 && !k.a(var33_24)) break block56;
                    var35_37 = var33_24;
                    var40_38 = var16_17;
                    var36_39 = null;
                    ** GOTO lbl82
                }
                var35_37 = var33_24;
                if (!var30_26) {
                    var33_24 = var34_36;
                }
                var36_39 = var7_7.b((Class<?>)var33_24);
                if (var36_39 != null) {
                    var40_38 = var16_17;
lbl82: // 2 sources:
                    var41_40 = null;
                } else {
                    var37_41 = var36_39;
                    var38_42 = var30_26 != false ? var35_37 : var34_36;
                    var39_43 = var7_7.c((Class<?>)var38_42);
                    var40_38 = var16_17;
                    var41_40 = var39_43;
                    var36_39 = var37_41;
                }
                if (var18_19) {
                    var115_44 = var7_7.a(var12_13);
                    var42_45 = var32_27;
                    var43_46 = var14_15;
                    var44_47 = var115_44;
                } else {
                    var42_45 = var32_27;
                    var43_46 = var14_15;
                    var44_47 = null;
                }
                var45_48 = new ArrayList();
                if (var8_8) {
                    var46_49 = var10_11.a;
                } else {
                    var46_50 = var11_12.a;
                }
                break block57;
            }
            var20_116 = new StringBuilder();
            var20_116.append("Wrong JSON type for class ");
            var20_116.append(var0.getClass().getName());
            var23_117 = new IllegalArgumentException(var20_116.toString());
            throw var23_117;
        }
        var47_52 = var46_51.size();
        var48_53 = var41_40;
        var49_54 = 0;
        do {
            block70 : {
                block71 : {
                    block69 : {
                        block68 : {
                            block67 : {
                                block60 : {
                                    block54 : {
                                        block58 : {
                                            block65 : {
                                                block64 : {
                                                    block63 : {
                                                        block62 : {
                                                            block61 : {
                                                                block59 : {
                                                                    if (var49_54 >= var47_52) break block58;
                                                                    var53_55 = var47_52;
                                                                    var54_56 = var8_8 != false ? (Map.Entry)var10_11.a.get(var49_54) : null;
                                                                    if (var8_8) {
                                                                        var114_107 = (String)var54_56.getKey();
                                                                        var55_57 = var54_56.getValue();
                                                                        var57_59 = var8_8;
                                                                        var56_58 = var11_12;
                                                                        var58_60 = var114_107;
                                                                    } else {
                                                                        var55_57 = var11_12.a.get(var49_54);
                                                                        var56_58 = var11_12;
                                                                        var57_59 = var8_8;
                                                                        var58_60 = null;
                                                                    }
                                                                    var59_61 = var55_57 instanceof g;
                                                                    var60_62 = var10_11;
                                                                    var61_63 = var55_57 instanceof e;
                                                                    if (var59_61) {
                                                                        var113_106 = (g)var55_57;
                                                                        var62_64 = var49_54;
                                                                        var63_65 = var113_106;
                                                                    } else {
                                                                        var62_64 = var49_54;
                                                                        var63_65 = null;
                                                                    }
                                                                    if (var61_63) {
                                                                        var112_105 = (e)var55_57;
                                                                        var64_66 = var36_39;
                                                                        var65_67 = var112_105;
                                                                    } else {
                                                                        var64_66 = var36_39;
                                                                        var65_67 = null;
                                                                    }
                                                                    if (var18_19) {
                                                                        var66_68 = (c)var44_47.b.get((Object)var58_60);
                                                                        if (var66_68 == null) {
                                                                            var106_108 = new StringBuilder();
                                                                            var106_108.append("Field ");
                                                                            var106_108.append(var12_13.getName());
                                                                            var106_108.append(".");
                                                                            var106_108.append(var58_60);
                                                                            var106_108.append(" does not exist or is not accessible, non-final, and non-transient");
                                                                            throw new IllegalArgumentException(var106_108.toString());
                                                                        }
                                                                    } else {
                                                                        var66_68 = null;
                                                                    }
                                                                    if (var18_19) {
                                                                        var105_104 = var66_68.a(var31_28);
                                                                        var67_69 = var44_47;
                                                                        var68_70 = var105_104;
                                                                    } else if (var17_18) {
                                                                        var67_69 = var44_47;
                                                                        var68_70 = var35_37;
                                                                    } else {
                                                                        var67_69 = var44_47;
                                                                        var68_70 = var29_29;
                                                                    }
                                                                    if (var55_57 != null) break block59;
                                                                    var76_74 = var3_3;
                                                                    var70_72 = var58_60;
                                                                    var69_71 = var31_28;
                                                                    var79_86 = var48_53;
                                                                    var36_39 = var64_66;
                                                                    var78_77 = null;
                                                                    break block60;
                                                                }
                                                                var69_71 = var31_28;
                                                                if (var68_70 != Object.class) break block61;
                                                                if (var59_61) {
                                                                    var102_100 = new HashMap();
                                                                    var45_48.add((Object)new b((Object)var102_100, l.h, var55_57));
                                                                } else if (var61_63) {
                                                                    var102_101 = new ArrayList();
                                                                    var45_48.add((Object)new b((Object)var102_101, l.o, var55_57));
                                                                } else {
                                                                    var102_102 = f.a(var55_57, var68_70, false);
                                                                }
                                                                break block62;
                                                            }
                                                            if (!k.b(var68_70)) break block63;
                                                            if (var59_61 != false) throw new IllegalArgumentException("Got JSONObject or JSONArray type when expecting a simple value type");
                                                            if (var61_63 != false) throw new IllegalArgumentException("Got JSONObject or JSONArray type when expecting a simple value type");
                                                            var102_103 = f.a(var55_57, var68_70, false);
                                                        }
                                                        var76_74 = var3_3;
                                                        var78_78 = var102_99;
                                                        var70_72 = var58_60;
                                                        break block64;
                                                    }
                                                    var70_72 = var58_60;
                                                    if (!CharSequence.class.isAssignableFrom(var55_57.getClass())) break block65;
                                                    var98_98 = var4_4.get(var55_57);
                                                    if (var98_98 == null) {
                                                        var99_109 = new StringBuilder();
                                                        var99_109.append("Object id not found: ");
                                                        var99_109.append(var55_57);
                                                        throw new IllegalArgumentException(var99_109.toString());
                                                    }
                                                    var76_74 = var3_3;
                                                    var78_80 = var98_98;
                                                }
                                                var79_86 = var48_53;
                                                var36_39 = var64_66;
                                                break block60;
                                            }
                                            if (!var59_61) {
                                                if (var61_63 == false) throw new IllegalArgumentException("Got simple value type when expecting a JSON object or JSON array");
                                            }
                                            if (!var59_61) ** GOTO lbl223
                                            try {
                                                block66 : {
                                                    var75_73 = var63_65.a.size();
                                                    break block66;
lbl223: // 1 sources:
                                                    var75_73 = var65_67.a.size();
                                                }
                                                if (var68_70 instanceof Class && ((Class)var68_70).isArray()) {
                                                    if (!var61_63) {
                                                        var95_110 = new StringBuilder();
                                                        var95_110.append("Expected JSONArray, got ");
                                                        var95_110.append(var55_57.getClass().getName());
                                                        throw new IllegalArgumentException(var95_110.toString());
                                                    }
                                                    var92_95 = Array.newInstance((Class)((Class)var68_70).getComponentType(), (int)var75_73);
                                                    var76_74 = var3_3;
                                                }
                                                break block54;
                                            }
                                            catch (Exception var71_111) {
                                                var72_112 = new StringBuilder();
                                                var72_112.append("Could not instantiate type ");
                                                var72_112.append((Object)var68_70);
                                                throw new IllegalArgumentException(var72_112.toString(), (Throwable)var71_111);
                                            }
                                        }
                                        var51_113 = var45_48.iterator();
                                        while (var51_113.hasNext() != false) {
                                            var52_114 = (b)var51_113.next();
                                            f.a(var52_114.b, var52_114.c, var52_114.a, var3_3, var4_4, var5_5);
                                        }
                                        return;
                                    }
                                    if (var15_16 || var13_14 || var30_26) {
                                        var76_74 = var3_3;
                                        if (var64_66 != null) {
                                            var77_75 = new Object[]{var75_73};
                                            var36_39 = var64_66;
                                            var78_81 = var36_39.newInstance(var77_75);
                                            var79_86 = var48_53;
                                        } else {
                                            var36_39 = var64_66;
                                            var91_94 = new Object[]{};
                                            var79_86 = var48_53;
                                            var78_82 = var79_86.newInstance(var91_94);
                                        }
                                    } else {
                                        if (var18_19) {
                                            var76_74 = var3_3;
                                            var93_96 = var66_68.a(var68_70, var76_74);
                                            if (var93_96 != null) {
                                                var94_97 = new Object[]{var75_73};
                                                var92_95 = var93_96.newInstance(var94_97);
                                            } else {
                                                var92_95 = var66_68.b(var68_70, var76_74).newInstance(new Object[0]);
                                            }
                                        } else {
                                            var76_74 = var3_3;
                                            if (var17_18 == false) throw new IllegalArgumentException("Got illegal type");
                                            if (var30_26 != false) throw new IllegalArgumentException("Got illegal type");
                                            var92_95 = Array.newInstance((Class)var12_13.getComponentType(), (int)var75_73);
                                        }
                                        var78_84 = var92_95;
                                        var79_86 = var48_53;
                                        var36_39 = var64_66;
                                    }
                                    if (var55_57 != null && var59_61 && (var89_93 = ((g)var55_57).b) != null) {
                                        var4_4.put((Object)var89_93, (Object)var78_83);
                                    }
                                    var45_48.add((Object)new b(var78_83, var68_70, var55_57));
                                }
                                if (!var18_19) break block67;
                                var66_68.a(var0, var78_76);
                                var84_90 = var40_38;
                                var81_87 = var43_46;
                                var82_88 = var42_45;
                                break block68;
                            }
                            if (!var13_14) break block69;
                            var82_88 = var42_45;
                            var87_92 = f.a((Object)var70_72, var82_88, true);
                            var81_87 = var43_46;
                            var81_87.put(var87_92, (Object)var78_76);
                            var84_90 = var40_38;
                        }
                        var83_89 = var62_64;
                        break block70;
                    }
                    var81_87 = var43_46;
                    var82_88 = var42_45;
                    if (!var17_18) break block71;
                    var83_89 = var62_64;
                    Array.set((Object)var0, (int)var83_89, (Object)var78_76);
                    ** GOTO lbl-1000
                }
                var83_89 = var62_64;
                if (var15_16) {
                    var84_90 = var40_38;
                    var5_5.add((Object)new Runnable(){

                        public void run() {
                            Collection.this.add(var78_76);
                        }
                    });
                } else lbl-1000: // 2 sources:
                {
                    var84_90 = var40_38;
                }
            }
            var85_91 = var83_89 + 1;
            var40_38 = var84_90;
            var43_46 = var81_87;
            var49_54 = var85_91;
            var42_45 = var82_88;
            var7_7 = var76_74;
            var48_53 = var79_86;
            var47_52 = var53_55;
            var11_12 = var56_58;
            var8_8 = var57_59;
            var10_11 = var60_62;
            var44_47 = var67_69;
            var31_28 = var69_71;
        } while (true);
    }

    private static class b {
        Object a;
        Object b;
        Type c;

        public b(Object object, Type type, Object object2) {
            this.a = object2;
            this.b = object;
            this.c = type;
        }
    }

}

