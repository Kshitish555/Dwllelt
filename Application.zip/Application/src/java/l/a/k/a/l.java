/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  l.a.k.a.a
 *  l.a.k.a.c
 *  l.a.k.a.d
 *  l.a.k.a.k
 *  l.a.k.a.p
 *  l.a.k.a.v
 */
package l.a.k.a;

import l.a.k.a.a;
import l.a.k.a.b;
import l.a.k.a.c;
import l.a.k.a.d;
import l.a.k.a.g;
import l.a.k.a.k;
import l.a.k.a.p;
import l.a.k.a.v;

final class l
extends k {
    private final g c;
    private final int d;
    private final int e;
    private final int f;
    private int g;
    private int h;
    private b i;
    private b j;
    private b k;
    private b l;
    private c m;

    l(g g2, int n2, String string, String string2, String string3, Object object) {
        super(327680);
        if (g2.p5 == null) {
            g2.p5 = this;
        } else {
            g2.q5.b = this;
        }
        g2.q5 = this;
        this.c = g2;
        this.d = n2;
        this.e = g2.e(string);
        this.f = g2.e(string2);
        if (string3 != null) {
            this.g = g2.e(string3);
        }
        if (object != null) {
            this.h = g2.a((Object)object).a;
        }
    }

    public a a(int n2, v v2, String string, boolean bl) {
        d d2 = new d();
        b.a(n2, v2, d2);
        d2.c(this.c.e(string)).c(0);
        b b2 = new b(this.c, true, d2, d2, -2 + d2.b);
        if (bl) {
            b2.i = this.k;
            this.k = b2;
            return b2;
        }
        b2.i = this.l;
        this.l = b2;
        return b2;
    }

    public a a(String string, boolean bl) {
        d d2 = new d();
        d2.c(this.c.e(string)).c(0);
        b b2 = new b(this.c, true, d2, d2, 2);
        if (bl) {
            b2.i = this.i;
            this.i = b2;
            return b2;
        }
        b2.i = this.j;
        this.j = b2;
        return b2;
    }

    public void a() {
    }

    public void a(c c2) {
        c2.c = this.m;
        this.m = c2;
    }

    void a(d d2) {
        c c2;
        c c3;
        int n2;
        int n3 = this.d;
        d2.c(n3 & (-1 ^ (393216 | (n3 & 262144) / 64))).c(this.e).c(this.f);
        int n4 = this.h != 0 ? 1 : 0;
        int n5 = this.d;
        if ((n5 & 4096) != 0 && ((65535 & this.c.h) < 49 || (n5 & 262144) != 0)) {
            ++n4;
        }
        if ((131072 & this.d) != 0) {
            ++n4;
        }
        if (this.g != 0) {
            ++n4;
        }
        if (this.i != null) {
            ++n4;
        }
        if (this.j != null) {
            ++n4;
        }
        if (this.k != null) {
            ++n4;
        }
        if (this.l != null) {
            ++n4;
        }
        if ((c2 = this.m) != null) {
            n4 += c2.a();
        }
        d2.c(n4);
        if (this.h != 0) {
            d2.c(this.c.e("ConstantValue"));
            d2.b(2).c(this.h);
        }
        if (((n2 = this.d) & 4096) != 0 && ((65535 & this.c.h) < 49 || (n2 & 262144) != 0)) {
            d2.c(this.c.e("Synthetic")).b(0);
        }
        if ((131072 & this.d) != 0) {
            d2.c(this.c.e("Deprecated")).b(0);
        }
        if (this.g != 0) {
            d2.c(this.c.e("Signature"));
            d2.b(2).c(this.g);
        }
        if (this.i != null) {
            d2.c(this.c.e("RuntimeVisibleAnnotations"));
            this.i.a(d2);
        }
        if (this.j != null) {
            d2.c(this.c.e("RuntimeInvisibleAnnotations"));
            this.j.a(d2);
        }
        if (this.k != null) {
            d2.c(this.c.e("RuntimeVisibleTypeAnnotations"));
            this.k.a(d2);
        }
        if (this.l != null) {
            d2.c(this.c.e("RuntimeInvisibleTypeAnnotations"));
            this.l.a(d2);
        }
        if ((c3 = this.m) != null) {
            c3.a(this.c, null, 0, -1, -1, d2);
        }
    }

    int b() {
        int n2;
        c c2;
        if (this.h != 0) {
            this.c.e("ConstantValue");
            n2 = 16;
        } else {
            n2 = 8;
        }
        int n3 = this.d;
        if ((n3 & 4096) != 0 && ((65535 & this.c.h) < 49 || (n3 & 262144) != 0)) {
            this.c.e("Synthetic");
            n2 += 6;
        }
        if ((131072 & this.d) != 0) {
            this.c.e("Deprecated");
            n2 += 6;
        }
        if (this.g != 0) {
            this.c.e("Signature");
            n2 += 8;
        }
        if (this.i != null) {
            this.c.e("RuntimeVisibleAnnotations");
            n2 += 8 + this.i.b();
        }
        if (this.j != null) {
            this.c.e("RuntimeInvisibleAnnotations");
            n2 += 8 + this.j.b();
        }
        if (this.k != null) {
            this.c.e("RuntimeVisibleTypeAnnotations");
            n2 += 8 + this.k.b();
        }
        if (this.l != null) {
            this.c.e("RuntimeInvisibleTypeAnnotations");
            n2 += 8 + this.l.b();
        }
        if ((c2 = this.m) != null) {
            n2 += c2.a(this.c, null, 0, -1, -1);
        }
        return n2;
    }
}

