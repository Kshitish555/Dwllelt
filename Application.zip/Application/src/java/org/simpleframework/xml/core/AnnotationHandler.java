/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Method
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import org.simpleframework.xml.core.Comparer;
import org.simpleframework.xml.core.PersistenceException;

class AnnotationHandler
implements InvocationHandler {
    private static final String ATTRIBUTE = "attribute";
    private static final String CLASS = "annotationType";
    private static final String EQUAL = "equals";
    private static final String REQUIRED = "required";
    private static final String STRING = "toString";
    private final boolean attribute;
    private final Comparer comparer = new Comparer();
    private final boolean required;
    private final Class type;

    public AnnotationHandler(Class class_) {
        this(class_, true);
    }

    public AnnotationHandler(Class class_, boolean bl) {
        this(class_, bl, false);
    }

    public AnnotationHandler(Class class_, boolean bl, boolean bl2) {
        this.attribute = bl2;
        this.required = bl;
        this.type = class_;
    }

    private void attributes(StringBuilder stringBuilder) {
        Method[] arrmethod = this.type.getDeclaredMethods();
        for (int i2 = 0; i2 < arrmethod.length; ++i2) {
            String string2 = arrmethod[i2].getName();
            Object object = this.value(arrmethod[i2]);
            if (i2 > 0) {
                stringBuilder.append(',');
                stringBuilder.append(' ');
            }
            stringBuilder.append(string2);
            stringBuilder.append('=');
            stringBuilder.append(object);
        }
        stringBuilder.append(')');
    }

    private boolean equals(Object object, Object[] arrobject) throws Throwable {
        Annotation annotation = (Annotation)object;
        Annotation annotation2 = (Annotation)arrobject[0];
        if (annotation.annotationType() == annotation2.annotationType()) {
            return this.comparer.equals(annotation, annotation2);
        }
        throw new PersistenceException("Annotation %s is not the same as %s", new Object[]{annotation, annotation2});
    }

    private void name(StringBuilder stringBuilder) {
        String string2 = this.type.getName();
        if (string2 != null) {
            stringBuilder.append('@');
            stringBuilder.append(string2);
            stringBuilder.append('(');
        }
    }

    private Object value(Method method) {
        String string2 = method.getName();
        if (string2.equals((Object)REQUIRED)) {
            return this.required;
        }
        if (string2.equals((Object)ATTRIBUTE)) {
            return this.attribute;
        }
        return method.getDefaultValue();
    }

    public Object invoke(Object object, Method method, Object[] arrobject) throws Throwable {
        String string2 = method.getName();
        if (string2.equals((Object)STRING)) {
            return this.toString();
        }
        if (string2.equals((Object)EQUAL)) {
            return this.equals(object, arrobject);
        }
        if (string2.equals((Object)CLASS)) {
            return this.type;
        }
        if (string2.equals((Object)REQUIRED)) {
            return this.required;
        }
        if (string2.equals((Object)ATTRIBUTE)) {
            return this.attribute;
        }
        return method.getDefaultValue();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        if (this.type != null) {
            this.name(stringBuilder);
            this.attributes(stringBuilder);
        }
        return stringBuilder.toString();
    }
}

