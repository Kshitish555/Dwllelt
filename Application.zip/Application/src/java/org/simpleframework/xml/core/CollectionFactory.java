/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.TreeSet
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Factory
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.strategy.Value
 */
package org.simpleframework.xml.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.TreeSet;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.ConversionInstance;
import org.simpleframework.xml.core.Factory;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.InstantiationException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.stream.InputNode;

class CollectionFactory
extends Factory {
    public CollectionFactory(Context context, Type type) {
        super(context, type);
    }

    private boolean isCollection(Class class_) {
        return Collection.class.isAssignableFrom(class_);
    }

    public Class getConversion(Class class_) throws Exception {
        if (class_.isAssignableFrom(ArrayList.class)) {
            return ArrayList.class;
        }
        if (class_.isAssignableFrom(HashSet.class)) {
            return HashSet.class;
        }
        if (class_.isAssignableFrom(TreeSet.class)) {
            return TreeSet.class;
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Cannot instantiate %s for %s", arrobject);
    }

    public Object getInstance() throws Exception {
        Class class_ = this.getType();
        Class class_2 = !Factory.isInstantiable((Class)class_) ? this.getConversion(class_) : class_;
        if (this.isCollection(class_2)) {
            return class_2.newInstance();
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Invalid collection %s for %s", arrobject);
    }

    public Instance getInstance(Value value) throws Exception {
        Class class_ = value.getType();
        if (!Factory.isInstantiable((Class)class_)) {
            class_ = this.getConversion(class_);
        }
        if (this.isCollection(class_)) {
            return new ConversionInstance(this.context, value, class_);
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Invalid collection %s for %s", arrobject);
    }

    public Instance getInstance(InputNode inputNode) throws Exception {
        Value value = this.getOverride(inputNode);
        Class class_ = this.getType();
        if (value != null) {
            return this.getInstance(value);
        }
        if (!Factory.isInstantiable((Class)class_)) {
            class_ = this.getConversion(class_);
        }
        if (this.isCollection(class_)) {
            return this.context.getInstance(class_);
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("Invalid collection %s for %s", arrobject);
    }
}

