/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  io.github.classgraph.utils.b
 *  io.github.classgraph.utils.m
 *  io.github.classgraph.utils.p
 *  io.github.classgraph.utils.x
 *  io.github.classgraph.utils.y
 *  io.github.classgraph.utils.y$a
 *  io.github.classgraph.utils.y$b
 *  io.github.classgraph.utils.y$c
 *  java.io.File
 *  java.lang.AutoCloseable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.FunctionalInterface
 *  java.lang.IllegalArgumentException
 *  java.lang.InterruptedException
 *  java.lang.Iterable
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.URL
 *  java.util.Iterator
 *  java.util.List
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ExecutionException
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Future
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 */
package h.a.a;

import h.a.a.e0;
import h.a.a.j0;
import h.a.a.l0;
import h.a.a.m;
import h.a.a.m0;
import io.github.classgraph.utils.p;
import io.github.classgraph.utils.x;
import io.github.classgraph.utils.y;
import java.io.File;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class h {
    private static final int c = Math.max((int)2, (int)((int)Math.ceil((double)(Math.min((float)4.0f, (float)(0.75f * (float)Runtime.getRuntime().availableProcessors())) + 1.25f * (float)Runtime.getRuntime().availableProcessors()))));
    private final l0 a = new l0();
    private p b;

    public static final String B() {
        return x.a();
    }

    private static /* synthetic */ void a(Throwable throwable, AutoCloseable autoCloseable) {
        if (throwable != null) {
            try {
                autoCloseable.close();
                return;
            }
            catch (Throwable throwable2) {
                throwable.addSuppressed(throwable2);
                return;
            }
        }
        autoCloseable.close();
    }

    public h A() {
        if (this.b == null) {
            this.b = new p();
        }
        return this;
    }

    public h a() {
        this.a.o = false;
        return this;
    }

    public h a(a a2) {
        this.a.a(a2);
        return this;
    }

    public h a(Class<? extends m> class_) {
        this.a.a(class_);
        return this;
    }

    public h a(ClassLoader classLoader) {
        this.a.a(classLoader);
        return this;
    }

    public h a(Iterable<?> iterable) {
        String string = io.github.classgraph.utils.m.a(iterable);
        if (!string.isEmpty()) {
            this.a(string);
            return this;
        }
        throw new IllegalArgumentException("Can't override classpath with an empty path");
    }

    public h a(Object object) {
        this.a.a(object);
        return this;
    }

    public h a(String string) {
        this.a.d(string);
        return this;
    }

    public /* varargs */ h a(ClassLoader ... arrclassLoader) {
        this.a.a(arrclassLoader);
        return this;
    }

    public /* varargs */ h a(Object ... arrobject) {
        String string = io.github.classgraph.utils.m.a((Object[])arrobject);
        if (!string.isEmpty()) {
            this.a(string);
            return this;
        }
        throw new IllegalArgumentException("Can't override classpath with an empty path");
    }

    public /* varargs */ h a(String ... arrstring) {
        this.h();
        for (String string : arrstring) {
            if (!string.contains((CharSequence)"*")) {
                this.a.e.a(y.k((String)string));
                this.a.f.a(y.i((String)string));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot use a glob wildcard here: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return this;
    }

    public j0 a(int n2) {
        j0 j02;
        io.github.classgraph.utils.b b2 = new io.github.classgraph.utils.b(n2);
        try {
            j02 = this.a((ExecutorService)b2, n2);
        }
        catch (Throwable throwable) {
            try {
                throw throwable;
            }
            catch (Throwable throwable2) {
                h.a(throwable, (AutoCloseable)b2);
                throw throwable2;
            }
        }
        h.a(null, (AutoCloseable)b2);
        return j02;
    }

    /*
     * Exception decompiling
     */
    public j0 a(ExecutorService var1_1, int var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[CATCHBLOCK]], but top level block is 1[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public void a(ExecutorService executorService, int n2, c c2, b b2) {
        if (c2 != null) {
            if (b2 != null) {
                m0 m02 = new m0(this.a, executorService, n2, c2, b2, this.b);
                executorService.submit((Callable)m02);
                return;
            }
            throw new IllegalArgumentException("failureHandler cannot be null");
        }
        throw new IllegalArgumentException("scanResultProcessor cannot be null");
    }

    public h b() {
        this.a.m = false;
        return this;
    }

    public /* varargs */ h b(Object ... arrobject) {
        this.a.a(arrobject);
        return this;
    }

    public /* varargs */ h b(String ... arrstring) {
        for (String string : arrstring) {
            String string2 = io.github.classgraph.utils.m.d((String)string);
            if (string2.equals((Object)string)) {
                this.a.j.a(string2);
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Can only blacklist jars by leafname: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return this;
    }

    public Future<j0> b(ExecutorService executorService, int n2) {
        m0 m02 = new m0(this.a, executorService, n2, null, null, this.b);
        return executorService.submit((Callable)m02);
    }

    public h c() {
        this.a.p = false;
        return this;
    }

    public /* varargs */ h c(String ... arrstring) {
        if (arrstring.length == 0) {
            Iterator iterator = io.github.classgraph.utils.m.b().iterator();
            while (iterator.hasNext()) {
                this.c((String)iterator.next());
            }
        } else {
            for (String string : arrstring) {
                if (io.github.classgraph.utils.m.d((String)string).equals((Object)string)) {
                    p p2;
                    boolean bl;
                    block10 : {
                        if (string.contains((CharSequence)"*")) {
                            p p3;
                            Pattern pattern = y.j((String)string);
                            Iterator iterator = io.github.classgraph.utils.m.b().iterator();
                            boolean bl2 = false;
                            while (iterator.hasNext()) {
                                String string2 = io.github.classgraph.utils.m.d((String)((String)iterator.next()));
                                if (!pattern.matcher((CharSequence)string2).matches()) continue;
                                if (!string2.contains((CharSequence)"*")) {
                                    this.c(string2);
                                }
                                bl2 = true;
                            }
                            if (bl2 || (p3 = this.b) == null) continue;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Could not find lib or ext jar matching wildcard: ");
                            stringBuilder.append(string);
                            p3.a(stringBuilder.toString());
                            continue;
                        }
                        for (String string3 : io.github.classgraph.utils.m.b()) {
                            if (!string.equals((Object)io.github.classgraph.utils.m.d((String)string3))) continue;
                            this.a.k.a(string);
                            p p4 = this.b;
                            if (p4 != null) {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Blacklisting lib or ext jar: ");
                                stringBuilder.append(string3);
                                p4.a(stringBuilder.toString());
                            }
                            bl = true;
                            break block10;
                        }
                        bl = false;
                    }
                    if (bl || (p2 = this.b) == null) continue;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Could not find lib or ext jar: ");
                    stringBuilder.append(string);
                    p2.a(stringBuilder.toString());
                    continue;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Can only blacklist jars by leafname: ");
                stringBuilder.append(string);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        return this;
    }

    public h d() {
        this.a.n = false;
        return this;
    }

    public /* varargs */ h d(String ... arrstring) {
        for (String string : arrstring) {
            this.a.i.a(string);
        }
        return this;
    }

    public h e() {
        this.h();
        this.a.A = true;
        return this;
    }

    public /* varargs */ h e(String ... arrstring) {
        this.h();
        for (String string : arrstring) {
            this.a.a.a(y.k((String)string));
            this.a.c.a(y.m((String)string));
            if (string.contains((CharSequence)"*")) continue;
            y.b b2 = this.a.b;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(y.k((String)string));
            stringBuilder.append(".");
            b2.a(stringBuilder.toString());
            this.a.d.a(y.m((String)string));
        }
        return this;
    }

    public h f() {
        this.h();
        this.j();
        this.k();
        this.g();
        this.l();
        this.r();
        this.s();
        this.t();
        return this;
    }

    public /* varargs */ h f(String ... arrstring) {
        for (String string : arrstring) {
            this.a.a.a(y.n((String)string));
            this.a.c.a(y.l((String)string));
            if (string.contains((CharSequence)"*")) continue;
            y.b b2 = this.a.b;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(y.n((String)string));
            stringBuilder.append(".");
            b2.a(stringBuilder.toString());
            this.a.d.a(y.l((String)string));
        }
        return this;
    }

    public h g() {
        this.h();
        this.a.t = true;
        return this;
    }

    public /* varargs */ h g(String ... arrstring) {
        this.h();
        for (String string : arrstring) {
            if (!string.contains((CharSequence)"*")) {
                this.a.e.b(y.k((String)string));
                this.a.f.b(y.i((String)string));
                int n2 = string.lastIndexOf(46);
                String string2 = n2 < 0 ? "" : string.substring(0, n2);
                this.a.g.b(y.k((String)string2));
                this.a.h.b(y.m((String)string2));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot use a glob wildcard here: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return this;
    }

    public h h() {
        this.a.q = true;
        return this;
    }

    public /* varargs */ h h(String ... arrstring) {
        for (String string : arrstring) {
            String string2 = io.github.classgraph.utils.m.d((String)string);
            if (string2.equals((Object)string)) {
                this.a.j.b(string2);
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Can only whitelist jars by leafname: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return this;
    }

    public h i() {
        this.h();
        this.a.v = true;
        return this;
    }

    public /* varargs */ h i(String ... arrstring) {
        if (arrstring.length == 0) {
            for (String string : io.github.classgraph.utils.m.b()) {
                String[] arrstring2 = new String[]{io.github.classgraph.utils.m.d((String)string)};
                this.i(arrstring2);
            }
        } else {
            for (String string : arrstring) {
                if (io.github.classgraph.utils.m.d((String)string).equals((Object)string)) {
                    p p2;
                    boolean bl;
                    block10 : {
                        if (string.contains((CharSequence)"*")) {
                            p p3;
                            Pattern pattern = y.j((String)string);
                            Iterator iterator = io.github.classgraph.utils.m.b().iterator();
                            boolean bl2 = false;
                            while (iterator.hasNext()) {
                                String string2 = io.github.classgraph.utils.m.d((String)((String)iterator.next()));
                                if (!pattern.matcher((CharSequence)string2).matches()) continue;
                                if (!string2.contains((CharSequence)"*")) {
                                    this.i(string2);
                                }
                                bl2 = true;
                            }
                            if (bl2 || (p3 = this.b) == null) continue;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Could not find lib or ext jar matching wildcard: ");
                            stringBuilder.append(string);
                            p3.a(stringBuilder.toString());
                            continue;
                        }
                        for (String string3 : io.github.classgraph.utils.m.b()) {
                            if (!string.equals((Object)io.github.classgraph.utils.m.d((String)string3))) continue;
                            this.a.k.b(string);
                            p p4 = this.b;
                            if (p4 != null) {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Whitelisting lib or ext jar: ");
                                stringBuilder.append(string3);
                                p4.a(stringBuilder.toString());
                            }
                            bl = true;
                            break block10;
                        }
                        bl = false;
                    }
                    if (bl || (p2 = this.b) == null) continue;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Could not find lib or ext jar: ");
                    stringBuilder.append(string);
                    p2.a(stringBuilder.toString());
                    continue;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Can only whitelist jars by leafname: ");
                stringBuilder.append(string);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
        }
        return this;
    }

    public h j() {
        this.h();
        this.a.r = true;
        return this;
    }

    public /* varargs */ h j(String ... arrstring) {
        for (String string : arrstring) {
            this.a.i.b(string);
        }
        return this;
    }

    public h k() {
        this.h();
        this.a.s = true;
        return this;
    }

    public /* varargs */ h k(String ... arrstring) {
        this.h();
        for (String string : arrstring) {
            if (!string.startsWith("!") && !string.startsWith("-")) {
                this.a.a.b(y.k((String)string));
                this.a.c.b(y.m((String)string));
                if (string.contains((CharSequence)"*")) continue;
                y.b b2 = this.a.b;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(y.k((String)string));
                stringBuilder.append(".");
                b2.b(stringBuilder.toString());
                this.a.d.b(y.m((String)string));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("This style of whitelisting/blacklisting is no longer supported: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return this;
    }

    public h l() {
        this.h();
        this.j();
        this.a.u = true;
        return this;
    }

    public /* varargs */ h l(String ... arrstring) {
        this.h();
        for (String string : arrstring) {
            if (!string.contains((CharSequence)"*")) {
                this.a.a.b(y.k((String)string));
                this.a.c.b(y.m((String)string));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot use a glob wildcard here: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return this;
    }

    public h m() {
        this.h();
        this.i(new String[0]);
        this.a.w = false;
        return this;
    }

    public /* varargs */ h m(String ... arrstring) {
        for (String string : arrstring) {
            this.a.a.b(y.n((String)string));
            this.a.c.b(y.l((String)string));
            if (string.contains((CharSequence)"*")) continue;
            y.b b2 = this.a.b;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(y.n((String)string));
            stringBuilder.append(".");
            b2.b(stringBuilder.toString());
            this.a.d.b(y.l((String)string));
        }
        return this;
    }

    public /* varargs */ h n(String ... arrstring) {
        for (String string : arrstring) {
            if (!string.contains((CharSequence)"*")) {
                this.a.a.b(y.n((String)string));
                this.a.c.b(y.l((String)string));
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Cannot use a glob wildcard here: ");
            stringBuilder.append(string);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        return this;
    }

    public String n() {
        return io.github.classgraph.utils.m.a(this.o());
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public List<File> o() {
        Throwable throwable;
        Throwable throwable2;
        block21 : {
            Throwable throwable32222;
            block20 : {
                j0 j02;
                List<File> list;
                io.github.classgraph.utils.b b2;
                block19 : {
                    b2 = new io.github.classgraph.utils.b(c);
                    this.a.l = false;
                    m0 m02 = new m0(this.a, (ExecutorService)b2, c, null, null, this.b);
                    j02 = (j0)b2.submit((Callable)m02).get();
                    list = j02.k();
                    if (j02 == null) break block19;
                    h.a(null, j02);
                }
                h.a(null, (AutoCloseable)b2);
                p p2 = this.b;
                if (p2 == null) return list;
                p2.b();
                return list;
                catch (Throwable throwable4) {
                    try {
                        throw throwable4;
                    }
                    catch (Throwable throwable5) {
                        if (j02 == null) throw throwable5;
                        try {
                            h.a(throwable4, j02);
                            throw throwable5;
                        }
                        catch (Throwable throwable6) {
                            try {
                                throw throwable6;
                            }
                            catch (Throwable throwable7) {
                                try {
                                    h.a(throwable6, (AutoCloseable)b2);
                                    throw throwable7;
                                }
                                catch (Throwable throwable32222) {
                                    break block20;
                                }
                                catch (ExecutionException executionException) {
                                    if (this.b != null) {
                                        this.b.a("Exception while getting classpath elements", (Throwable)executionException);
                                    }
                                    if ((throwable2 = executionException.getCause()) == null) {
                                        throw new RuntimeException(throwable);
                                    }
                                    break block21;
                                }
                                catch (InterruptedException interruptedException) {
                                    if (this.b == null) throw new IllegalArgumentException("Scan interrupted", (Throwable)interruptedException);
                                    this.b.a("Thread interrupted while getting classpath elements");
                                    throw new IllegalArgumentException("Scan interrupted", (Throwable)interruptedException);
                                }
                            }
                        }
                    }
                }
            }
            p p3 = this.b;
            if (p3 == null) throw throwable32222;
            p3.b();
            throw throwable32222;
        }
        throwable = throwable2;
        throw new RuntimeException(throwable);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public List<URL> p() {
        Throwable throwable2;
        Throwable throwable;
        block14 : {
            Throwable throwable32222;
            block13 : {
                io.github.classgraph.utils.b b2 = new io.github.classgraph.utils.b(c);
                this.a.l = false;
                m0 m02 = new m0(this.a, (ExecutorService)b2, c, null, null, this.b);
                List<URL> list = ((j0)b2.submit((Callable)m02).get()).l();
                h.a(null, (AutoCloseable)b2);
                p p2 = this.b;
                if (p2 == null) return list;
                p2.b();
                return list;
                catch (Throwable throwable4) {
                    try {
                        throw throwable4;
                    }
                    catch (Throwable throwable5) {
                        try {
                            h.a(throwable4, (AutoCloseable)b2);
                            throw throwable5;
                        }
                        catch (Throwable throwable32222) {
                            break block13;
                        }
                        catch (ExecutionException executionException) {
                            if (this.b != null) {
                                this.b.a("Exception while getting classpath elements", (Throwable)executionException);
                            }
                            if ((throwable = executionException.getCause()) == null) {
                                throw new RuntimeException(throwable2);
                            }
                            break block14;
                        }
                        catch (InterruptedException interruptedException) {
                            if (this.b == null) throw new IllegalArgumentException("Scan interrupted", (Throwable)interruptedException);
                            this.b.a("Thread interrupted while getting classpath elements");
                            throw new IllegalArgumentException("Scan interrupted", (Throwable)interruptedException);
                        }
                    }
                }
            }
            p p3 = this.b;
            if (p3 == null) throw throwable32222;
            p3.b();
            throw throwable32222;
        }
        throwable2 = throwable;
        throw new RuntimeException(throwable2);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public List<e0> q() {
        Throwable throwable;
        Throwable throwable2;
        block21 : {
            Throwable throwable32222;
            block20 : {
                j0 j02;
                List<e0> list;
                io.github.classgraph.utils.b b2;
                block19 : {
                    b2 = new io.github.classgraph.utils.b(c);
                    this.a.l = false;
                    m0 m02 = new m0(this.a, (ExecutorService)b2, c, null, null, this.b);
                    j02 = (j0)b2.submit((Callable)m02).get();
                    list = j02.m();
                    if (j02 == null) break block19;
                    h.a(null, j02);
                }
                h.a(null, (AutoCloseable)b2);
                p p2 = this.b;
                if (p2 == null) return list;
                p2.b();
                return list;
                catch (Throwable throwable4) {
                    try {
                        throw throwable4;
                    }
                    catch (Throwable throwable5) {
                        if (j02 == null) throw throwable5;
                        try {
                            h.a(throwable4, j02);
                            throw throwable5;
                        }
                        catch (Throwable throwable6) {
                            try {
                                throw throwable6;
                            }
                            catch (Throwable throwable7) {
                                try {
                                    h.a(throwable6, (AutoCloseable)b2);
                                    throw throwable7;
                                }
                                catch (Throwable throwable32222) {
                                    break block20;
                                }
                                catch (ExecutionException executionException) {
                                    if (this.b != null) {
                                        this.b.a("Exception while getting modules", (Throwable)executionException);
                                    }
                                    if ((throwable2 = executionException.getCause()) == null) {
                                        throw new RuntimeException(throwable);
                                    }
                                    break block21;
                                }
                                catch (InterruptedException interruptedException) {
                                    if (this.b == null) throw new IllegalArgumentException("Scan interrupted", (Throwable)interruptedException);
                                    this.b.a("Thread interrupted while getting modules");
                                    throw new IllegalArgumentException("Scan interrupted", (Throwable)interruptedException);
                                }
                            }
                        }
                    }
                }
            }
            p p3 = this.b;
            if (p3 == null) throw throwable32222;
            p3.b();
            throw throwable32222;
        }
        throwable = throwable2;
        throw new RuntimeException(throwable);
    }

    public h r() {
        this.h();
        this.a.x = true;
        return this;
    }

    public h s() {
        this.h();
        this.j();
        this.a.y = true;
        return this;
    }

    public h t() {
        this.h();
        this.k();
        this.a.z = true;
        return this;
    }

    public h u() {
        this.a.K = true;
        return this;
    }

    public h v() {
        this.a.L = true;
        return this;
    }

    public h w() {
        this.a.I = true;
        return this;
    }

    public h x() {
        this.a.J = true;
        return this;
    }

    public j0 y() {
        return this.a(c);
    }

    public h z() {
        this.a.M = true;
        return this;
    }

    @FunctionalInterface
    public static interface a {
        public boolean a(String var1);
    }

    @FunctionalInterface
    public static interface b {
        public void a(Throwable var1);
    }

    @FunctionalInterface
    public static interface c {
        public void a(j0 var1);
    }

}

