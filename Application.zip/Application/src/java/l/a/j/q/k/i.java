/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  l.a.h.h.a
 *  l.a.h.h.a$c
 *  l.a.h.i.a
 *  l.a.h.i.a$d
 *  l.a.h.i.d
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.h.k.c$f
 *  l.a.h.k.c$f$f
 *  l.a.h.k.c$f$f$b
 *  l.a.h.k.d
 *  l.a.h.k.d$f
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.j.q.k.i$d
 *  l.a.j.q.k.i$e
 *  l.a.j.q.k.i$f
 *  l.a.j.q.l.a
 *  l.a.j.q.l.c
 *  l.a.k.a.r
 */
package l.a.j.q.k;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import l.a.h.h.a;
import l.a.h.i.a;
import l.a.h.k.c;
import l.a.h.k.d;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.k.i;
import l.a.k.a.r;

/*
 * Exception performing whole class analysis.
 */
public abstract class i
implements l.a.j.q.e {
    private static final String d = "java/lang/Class";
    protected final a.d c;

    protected i(a.d d2) {
        this.c = d2;
    }

    private static List<l.a.j.q.e> a(List<l.a.h.k.c> list) {
        ArrayList arrayList = new ArrayList(list.size());
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)l.a.j.q.k.a.c((l.a.h.k.c)iterator.next()));
        }
        return arrayList;
    }

    public static c a(a.d d2) {
        if (d2.N0()) {
            return d.c;
        }
        if (d2.p1()) {
            return new /* Unavailable Anonymous Inner Class!! */;
        }
        return new /* Unavailable Anonymous Inner Class!! */;
    }

    protected abstract l.a.h.i.a a();

    public e.c a(r r2, e.d d2) {
        l.a.j.q.e[] arre = new l.a.j.q.e[]{this.b(), l.a.j.q.j.b.a((c.f)new c.f.f.b(Class.class)).a(i.a((List<l.a.h.k.c>)this.c.getParameters().E().m1())), l.a.j.q.l.c.a((l.a.h.i.a)this.a())};
        return new e.a(arre).a(r2, d2);
    }

    protected abstract l.a.j.q.e b();

    protected boolean b(Object object) {
        return object instanceof i;
    }

    public l.a.j.q.e cached() {
        if (this.c.p1()) {
            return new a(this);
        }
        return new b(this);
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof i)) {
            return false;
        }
        i i2 = (i)object;
        if (!i2.b(this)) {
            return false;
        }
        a.d d2 = this.c;
        a.d d3 = i2.c;
        return !(d2 == null ? d3 != null : !d2.equals((Object)d3));
    }

    public int hashCode() {
        a.d d2 = this.c;
        int n2 = d2 == null ? 43 : d2.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }

    protected static class a
    implements l.a.j.q.e {
        private static final l.a.h.k.c d = new c.d(Constructor.class);
        private final l.a.j.q.e c;

        protected a(l.a.j.q.e e2) {
            this.c = e2;
        }

        public e.c a(r r2, e.d d2) {
            return l.a.j.q.l.a.a((a.c)d2.a(this.c, d)).read().a(r2, d2);
        }

        protected boolean b(Object object) {
            return object instanceof a;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof a)) {
                return false;
            }
            a a2 = (a)object;
            if (!a2.b(this)) {
                return false;
            }
            l.a.j.q.e e2 = this.c;
            l.a.j.q.e e3 = a2.c;
            return !(e2 == null ? e3 != null : !e2.equals((Object)e3));
        }

        public int hashCode() {
            l.a.j.q.e e2 = this.c;
            int n2 = e2 == null ? 43 : e2.hashCode();
            return 59 + n2;
        }

        public boolean x() {
            return this.c.x();
        }
    }

    protected static class b
    implements l.a.j.q.e {
        private static final l.a.h.k.c d = new c.d(Method.class);
        private final l.a.j.q.e c;

        protected b(l.a.j.q.e e2) {
            this.c = e2;
        }

        public e.c a(r r2, e.d d2) {
            return l.a.j.q.l.a.a((a.c)d2.a(this.c, d)).read().a(r2, d2);
        }

        protected boolean b(Object object) {
            return object instanceof b;
        }

        public boolean equals(Object object) {
            if (object == this) {
                return true;
            }
            if (!(object instanceof b)) {
                return false;
            }
            b b2 = (b)object;
            if (!b2.b(this)) {
                return false;
            }
            l.a.j.q.e e2 = this.c;
            l.a.j.q.e e3 = b2.c;
            return !(e2 == null ? e3 != null : !e2.equals((Object)e3));
        }

        public int hashCode() {
            l.a.j.q.e e2 = this.c;
            int n2 = e2 == null ? 43 : e2.hashCode();
            return 59 + n2;
        }

        public boolean x() {
            return this.c.x();
        }
    }

    public static interface c
    extends l.a.j.q.e {
        public l.a.j.q.e cached();
    }

}

