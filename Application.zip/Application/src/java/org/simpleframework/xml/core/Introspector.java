/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.Path
 *  org.simpleframework.xml.Root
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.Path;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.EmptyExpression;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.PathParser;
import org.simpleframework.xml.core.Reflector;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.Format;

class Introspector {
    private final Contact contact;
    private final Format format;
    private final Label label;
    private final Annotation marker;

    public Introspector(Contact contact, Label label, Format format) {
        this.marker = contact.getAnnotation();
        this.contact = contact;
        this.format = format;
        this.label = label;
    }

    private String getDefault() throws Exception {
        String string2 = this.label.getOverride();
        if (!this.isEmpty(string2)) {
            return string2;
        }
        return this.contact.getName();
    }

    private String getName(Class class_) throws Exception {
        String string2 = this.getRoot(class_);
        if (string2 != null) {
            return string2;
        }
        return Reflector.getName(class_.getSimpleName());
    }

    private String getRoot(Class class_) {
        for (Class class_2 = class_; class_2 != null; class_2 = class_2.getSuperclass()) {
            String string2 = this.getRoot(class_, class_2);
            if (string2 == null) continue;
            return string2;
        }
        return null;
    }

    private String getRoot(Class<?> class_, Class<?> class_2) {
        String string2 = class_2.getSimpleName();
        Root root = (Root)class_2.getAnnotation(Root.class);
        if (root != null) {
            String string3 = root.name();
            if (!this.isEmpty(string3)) {
                return string3;
            }
            return Reflector.getName(string2);
        }
        return null;
    }

    public Contact getContact() {
        return this.contact;
    }

    public Type getDependent() throws Exception {
        return this.label.getDependent();
    }

    public String getEntry() throws Exception {
        Class class_ = this.getDependent().getType();
        if (class_.isArray()) {
            class_ = class_.getComponentType();
        }
        return this.getName(class_);
    }

    public Expression getExpression() throws Exception {
        String string2 = this.getPath();
        if (string2 != null) {
            return new PathParser(string2, this.contact, this.format);
        }
        return new EmptyExpression(this.format);
    }

    public String getName() throws Exception {
        String string2 = this.label.getEntry();
        if (!this.label.isInline()) {
            string2 = this.getDefault();
        }
        return string2;
    }

    public String getPath() throws Exception {
        Path path = this.contact.getAnnotation(Path.class);
        if (path == null) {
            return null;
        }
        return path.value();
    }

    public boolean isEmpty(String string2) {
        boolean bl = true;
        if (string2 != null) {
            if (string2.length() == 0) {
                return bl;
            }
            bl = false;
        }
        return bl;
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.marker, this.contact};
        return String.format((String)"%s on %s", (Object[])arrobject);
    }
}

