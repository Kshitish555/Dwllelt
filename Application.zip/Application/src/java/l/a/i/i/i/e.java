/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.Set
 *  l.a.b
 *  l.a.f.b
 *  l.a.h.a
 *  l.a.h.a$a
 *  l.a.h.a$a$a
 *  l.a.h.i.a
 *  l.a.h.i.a$h
 *  l.a.h.i.b
 *  l.a.h.k.c
 *  l.a.i.a
 *  l.a.i.b
 *  l.a.i.b$a
 *  l.a.i.b$a$a$a
 *  l.a.i.g
 *  l.a.i.g$e
 *  l.a.i.i.b
 *  l.a.i.i.d
 *  l.a.i.i.d$a
 *  l.a.i.i.e
 *  l.a.i.i.e$d
 *  l.a.i.i.g
 *  l.a.i.i.h
 *  l.a.i.i.i.c
 *  l.a.i.i.i.d
 *  l.a.j.e$d$d
 *  l.a.j.n.b
 *  l.a.j.n.c
 *  l.a.j.n.c$c
 *  l.a.j.n.f
 *  l.a.j.o.a
 *  l.a.j.o.a$a
 *  l.a.l.c0
 *  l.a.l.r
 *  l.a.l.s
 *  l.a.l.x
 *  l.a.m.a
 */
package l.a.i.i.i;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import l.a.f.b;
import l.a.h.a;
import l.a.h.i.a;
import l.a.i.b;
import l.a.i.g;
import l.a.i.i.b;
import l.a.i.i.c;
import l.a.i.i.d;
import l.a.i.i.e;
import l.a.i.i.g;
import l.a.i.i.h;
import l.a.i.i.i.d;
import l.a.j.e;
import l.a.j.n.c;
import l.a.j.n.f;
import l.a.j.o.a;
import l.a.l.c0;
import l.a.l.r;
import l.a.l.s;
import l.a.l.x;

public class e<T>
extends l.a.i.i.i.a<T> {
    private final l.a.i.i.i.c p;

    public e(c.f f2, l.a.b b2, a.a a2, c.c c2, l.a.j.n.b b3, e.d.d d2, d.a a3, g g2, c0<? super l.a.h.i.a> c02, l.a.h.k.c c3, l.a.i.a a4, l.a.i.i.i.c c4) {
        b.b b4 = new b.b();
        e.b b5 = new e.b();
        f f3 = b3.c() ? new f.c.a(c3) : f.c.c;
        this(f2, b4, b5, f3, b.e.c, b2, a2, c2, b3, d2, a3, g2, c02, c3, a4, c4);
    }

    protected e(c.f f2, b b2, l.a.i.i.e e2, f f3, l.a.f.b b3, l.a.b b4, a.a a2, c.c c2, l.a.j.n.b b5, e.d.d d2, d.a a3, g g2, c0<? super l.a.h.i.a> c02, l.a.h.k.c c3, l.a.i.a a4, l.a.i.i.i.c c4) {
        super(f2, b2, e2, f3, b3, b4, a2, c2, b5, d2, a3, g2, c02, c3, a4);
        this.p = c4;
    }

    protected b.a<T> a(c.f f2, b b2, l.a.i.i.e e2, f f3, l.a.f.b b3, l.a.b b4, a.a a2, c.c c2, l.a.j.n.b b5, e.d.d d2, d.a a3, g g2, c0<? super l.a.h.i.a> c02) {
        e<T> e3 = new e<T>(f2, b2, e2, f3, b3, b4, a2, c2, b5, d2, a3, g2, c02, this.n, this.o, this.p);
        return e3;
    }

    public b.d<T> a(l.a.i.g g2, l.a.m.a a2) {
        e.d d2 = this.c.a((c)this.a, this.k, this.l, l.a.i.i.i.b.a((c0<? super l.a.h.i.a>)this.m, this.n));
        l.a.i.i.i.d d3 = d.a.a(d2.c(), (Set<? extends a.h>)new HashSet((Collection)this.n.u().a((r)s.a((Object)this.n)).b(a.a(d2.c(), d2.d()))), this.f, this.g, this.p);
        return h.a.a(d2, this.b.a(d2.c()), this.d, this.e, this.f, this.h, this.i, this.g, this.j, this.l, a2, this.n, this.o, d3).a(g2.resolve());
    }

    @Override
    protected boolean a(Object object) {
        return object instanceof e;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof e)) {
            return false;
        }
        e e2 = (e)((Object)object);
        if (!e2.a((Object)this)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        l.a.i.i.i.c c2 = this.p;
        l.a.i.i.i.c c3 = e2.p;
        return !(c2 == null ? c3 != null : !c2.equals((Object)c3));
    }

    @Override
    public int hashCode() {
        int n = 59 + super.hashCode();
        l.a.i.i.i.c c2 = this.p;
        int n2 = n * 59;
        int n3 = c2 == null ? 43 : c2.hashCode();
        return n2 + n3;
    }

}

