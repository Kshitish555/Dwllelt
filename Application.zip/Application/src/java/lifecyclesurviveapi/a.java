/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  lifecyclesurviveapi.f
 *  lifecyclesurviveapi.n
 *  rx.functions.Action1
 */
package lifecyclesurviveapi;

import lifecyclesurviveapi.f;
import lifecyclesurviveapi.n;
import rx.functions.Action1;

public final class a
implements Action1 {
    private final /* synthetic */ f c;
    private final /* synthetic */ n d;

    public /* synthetic */ a(f f2, n n2) {
        this.c = f2;
        this.d = n2;
    }

    public final void call(Object object) {
        this.c.a(this.d, (Boolean)object);
    }
}

