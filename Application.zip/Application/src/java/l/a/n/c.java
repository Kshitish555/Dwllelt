/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.instrument.Instrumentation
 *  java.security.AccessController
 *  java.security.PrivilegedAction
 *  l.a.h.d
 *  l.a.h.d$b
 *  l.a.h.k.c
 *  l.a.n.c$a
 *  l.a.n.c$a$a
 *  l.a.n.d
 */
package l.a.n;

import java.io.InputStream;
import java.lang.instrument.Instrumentation;
import java.security.AccessController;
import java.security.PrivilegedAction;
import l.a.h.d;
import l.a.n.c;
import l.a.n.d;

public class c
implements d.b {
    public static final c d;
    private static final a f;
    private final Object c;

    static {
        f = AccessController.doPrivileged((PrivilegedAction)a.c);
    }

    protected c(Object object) {
        this.c = object;
    }

    public static c a(Object object) {
        if (d.w.c().isInstance(object)) {
            return new c(object);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Not a Java module: ");
        stringBuilder.append(object);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static c e(Class<?> class_) {
        return f.a(class_);
    }

    public static boolean g() {
        return f.c();
    }

    public boolean W() {
        return f.b(this.c);
    }

    public InputStream a(String string) {
        return f.a(this.c, string);
    }

    public ClassLoader a() {
        return f.c(this.c);
    }

    public void a(Instrumentation instrumentation, c c2) {
        f.a(instrumentation, this.c, c2.b());
    }

    public boolean a(c c2) {
        return f.a(this.c, c2.b());
    }

    public Object b() {
        return this.c;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof c)) {
            return false;
        }
        c c2 = (c)object;
        return this.c.equals(c2.c);
    }

    public int hashCode() {
        return this.c.hashCode();
    }

    public String p0() {
        return f.a(this.c);
    }

    public String toString() {
        return this.c.toString();
    }
}

