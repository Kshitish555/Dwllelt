/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.osmdroid.tileprovider.modules;

public interface INetworkAvailablityCheck {
    public boolean getCellularDataNetworkAvailable();

    public boolean getNetworkAvailable();

    public boolean getRouteToPathExists(int var1);

    public boolean getWiFiNetworkAvailable();
}

