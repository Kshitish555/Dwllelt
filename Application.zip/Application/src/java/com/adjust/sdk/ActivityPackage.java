/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.ObjectInputStream
 *  java.io.ObjectInputStream$GetField
 *  java.io.ObjectOutputStream
 *  java.io.ObjectStreamField
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.TreeMap
 */
package com.adjust.sdk;

import com.adjust.sdk.ActivityKind;
import com.adjust.sdk.Util;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamField;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class ActivityPackage
implements Serializable {
    private static final ObjectStreamField[] serialPersistentFields;
    private static final long serialVersionUID = -35935556512024097L;
    private ActivityKind activityKind = ActivityKind.UNKNOWN;
    private Map<String, String> callbackParameters;
    private long clickTimeInMilliseconds;
    private long clickTimeInSeconds;
    private String clientSdk;
    private transient int hashCode;
    private long installBeginTimeInSeconds;
    private Map<String, String> parameters;
    private Map<String, String> partnerParameters;
    private String path;
    private int retries;
    private String suffix;

    static {
        ObjectStreamField[] arrobjectStreamField = new ObjectStreamField[]{new ObjectStreamField("path", String.class), new ObjectStreamField("clientSdk", String.class), new ObjectStreamField("parameters", Map.class), new ObjectStreamField("activityKind", ActivityKind.class), new ObjectStreamField("suffix", String.class), new ObjectStreamField("callbackParameters", Map.class), new ObjectStreamField("partnerParameters", Map.class)};
        serialPersistentFields = arrobjectStreamField;
    }

    public ActivityPackage(ActivityKind activityKind) {
        this.activityKind = activityKind;
    }

    private void readObject(ObjectInputStream objectInputStream) throws ClassNotFoundException, IOException {
        ObjectInputStream.GetField getField = objectInputStream.readFields();
        this.path = Util.readStringField(getField, "path", null);
        this.clientSdk = Util.readStringField(getField, "clientSdk", null);
        this.parameters = Util.readObjectField(getField, "parameters", null);
        this.activityKind = Util.readObjectField(getField, "activityKind", ActivityKind.UNKNOWN);
        this.suffix = Util.readStringField(getField, "suffix", null);
        this.callbackParameters = Util.readObjectField(getField, "callbackParameters", null);
        this.partnerParameters = Util.readObjectField(getField, "partnerParameters", null);
    }

    private void writeObject(ObjectOutputStream objectOutputStream) throws IOException {
        objectOutputStream.defaultWriteObject();
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (ActivityPackage.class != object.getClass()) {
            return false;
        }
        ActivityPackage activityPackage = (ActivityPackage)object;
        if (!Util.equalString(this.path, activityPackage.path)) {
            return false;
        }
        if (!Util.equalString(this.clientSdk, activityPackage.clientSdk)) {
            return false;
        }
        if (!Util.equalObject(this.parameters, activityPackage.parameters)) {
            return false;
        }
        if (!Util.equalEnum(this.activityKind, activityPackage.activityKind)) {
            return false;
        }
        if (!Util.equalString(this.suffix, activityPackage.suffix)) {
            return false;
        }
        if (!Util.equalObject(this.callbackParameters, activityPackage.callbackParameters)) {
            return false;
        }
        return Util.equalObject(this.partnerParameters, activityPackage.partnerParameters);
    }

    public ActivityKind getActivityKind() {
        return this.activityKind;
    }

    public Map<String, String> getCallbackParameters() {
        return this.callbackParameters;
    }

    public long getClickTimeInMilliseconds() {
        return this.clickTimeInMilliseconds;
    }

    public long getClickTimeInSeconds() {
        return this.clickTimeInSeconds;
    }

    public String getClientSdk() {
        return this.clientSdk;
    }

    public String getExtendedString() {
        StringBuilder stringBuilder = new StringBuilder();
        Object[] arrobject = new Object[]{this.path};
        stringBuilder.append(Util.formatString("Path:      %s\n", arrobject));
        Object[] arrobject2 = new Object[]{this.clientSdk};
        stringBuilder.append(Util.formatString("ClientSdk: %s\n", arrobject2));
        if (this.parameters != null) {
            stringBuilder.append("Parameters:");
            TreeMap treeMap = new TreeMap(this.parameters);
            List list = Arrays.asList((Object[])new String[]{"app_secret", "secret_id", "event_callback_id"});
            for (Map.Entry entry : treeMap.entrySet()) {
                String string = (String)entry.getKey();
                if (list.contains((Object)string)) continue;
                Object[] arrobject3 = new Object[]{string, entry.getValue()};
                stringBuilder.append(Util.formatString("\n\t%-16s %s", arrobject3));
            }
        }
        return stringBuilder.toString();
    }

    protected String getFailureMessage() {
        Object[] arrobject = new Object[]{this.activityKind.toString(), this.suffix};
        return Util.formatString("Failed to track %s%s", arrobject);
    }

    public long getInstallBeginTimeInSeconds() {
        return this.installBeginTimeInSeconds;
    }

    public Map<String, String> getParameters() {
        return this.parameters;
    }

    public Map<String, String> getPartnerParameters() {
        return this.partnerParameters;
    }

    public String getPath() {
        return this.path;
    }

    public int getRetries() {
        return this.retries;
    }

    public String getSuffix() {
        return this.suffix;
    }

    public int hashCode() {
        if (this.hashCode == 0) {
            int n2;
            int n3;
            int n4;
            int n5;
            int n6;
            int n7;
            this.hashCode = 17;
            this.hashCode = n5 = 17 * 37 + Util.hashString(this.path);
            this.hashCode = n7 = n5 * 37 + Util.hashString(this.clientSdk);
            this.hashCode = n2 = n7 * 37 + Util.hashObject(this.parameters);
            this.hashCode = n3 = n2 * 37 + Util.hashEnum(this.activityKind);
            this.hashCode = n6 = n3 * 37 + Util.hashString(this.suffix);
            this.hashCode = n4 = n6 * 37 + Util.hashObject(this.callbackParameters);
            this.hashCode = n4 * 37 + Util.hashObject(this.partnerParameters);
        }
        return this.hashCode;
    }

    public int increaseRetries() {
        int n2;
        this.retries = n2 = 1 + this.retries;
        return n2;
    }

    public void setCallbackParameters(Map<String, String> map) {
        this.callbackParameters = map;
    }

    public void setClickTimeInMilliseconds(long l2) {
        this.clickTimeInMilliseconds = l2;
    }

    public void setClickTimeInSeconds(long l2) {
        this.clickTimeInSeconds = l2;
    }

    public void setClientSdk(String string) {
        this.clientSdk = string;
    }

    public void setInstallBeginTimeInSeconds(long l2) {
        this.installBeginTimeInSeconds = l2;
    }

    public void setParameters(Map<String, String> map) {
        this.parameters = map;
    }

    public void setPartnerParameters(Map<String, String> map) {
        this.partnerParameters = map;
    }

    public void setPath(String string) {
        this.path = string;
    }

    public void setSuffix(String string) {
        this.suffix = string;
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.activityKind.toString(), this.suffix};
        return Util.formatString("%s%s", arrobject);
    }
}

