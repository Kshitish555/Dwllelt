/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 */
package org.simpleframework.xml.core;

interface Instance {
    public Object getInstance() throws Exception;

    public Class getType();

    public boolean isReference();

    public Object setInstance(Object var1) throws Exception;
}

