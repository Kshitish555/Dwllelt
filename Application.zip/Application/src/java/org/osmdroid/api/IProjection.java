/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  java.lang.Object
 *  org.osmdroid.api.IGeoPoint
 */
package org.osmdroid.api;

import android.graphics.Point;
import org.osmdroid.api.IGeoPoint;

public interface IProjection {
    public IGeoPoint fromPixels(int var1, int var2);

    public float metersToEquatorPixels(float var1);

    public Point toPixels(IGeoPoint var1, Point var2);
}

