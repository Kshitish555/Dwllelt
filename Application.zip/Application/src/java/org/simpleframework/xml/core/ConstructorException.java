/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  org.simpleframework.xml.core.PersistenceException
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.PersistenceException;

public class ConstructorException
extends PersistenceException {
    public /* varargs */ ConstructorException(String string2, Object ... arrobject) {
        super(string2, arrobject);
    }

    public /* varargs */ ConstructorException(Throwable throwable, String string2, Object ... arrobject) {
        super(throwable, string2, arrobject);
    }
}

