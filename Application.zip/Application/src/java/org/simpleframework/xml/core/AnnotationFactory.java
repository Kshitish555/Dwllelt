/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Exception
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.Proxy
 *  java.util.Collection
 *  java.util.Map
 *  org.simpleframework.xml.Attribute
 *  org.simpleframework.xml.Element
 *  org.simpleframework.xml.ElementArray
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementMap
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.Collection;
import java.util.Map;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementArray;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.core.AnnotationHandler;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.Support;
import org.simpleframework.xml.stream.Format;
import org.simpleframework.xml.stream.Verbosity;

class AnnotationFactory {
    private final Format format;
    private final boolean required;

    public AnnotationFactory(Detail detail, Support support) {
        this.required = detail.isRequired();
        this.format = support.getFormat();
    }

    private ClassLoader getClassLoader() throws Exception {
        return AnnotationFactory.class.getClassLoader();
    }

    private Annotation getInstance(Class class_) throws Exception {
        ClassLoader classLoader = this.getClassLoader();
        Class class_2 = class_.getComponentType();
        if (class_.isArray()) {
            if (this.isPrimitive(class_2)) {
                return this.getInstance(classLoader, Element.class);
            }
            return this.getInstance(classLoader, ElementArray.class);
        }
        if (this.isPrimitive(class_) && this.isAttribute()) {
            return this.getInstance(classLoader, Attribute.class);
        }
        return this.getInstance(classLoader, Element.class);
    }

    private Annotation getInstance(ClassLoader classLoader, Class class_) throws Exception {
        return this.getInstance(classLoader, class_, false);
    }

    private Annotation getInstance(ClassLoader classLoader, Class class_, boolean bl) throws Exception {
        AnnotationHandler annotationHandler = new AnnotationHandler(class_, this.required, bl);
        return (Annotation)Proxy.newProxyInstance((ClassLoader)classLoader, (Class[])new Class[]{class_}, (InvocationHandler)annotationHandler);
    }

    private boolean isAttribute() {
        Verbosity verbosity = this.format.getVerbosity();
        boolean bl = false;
        if (verbosity != null) {
            Verbosity verbosity2 = Verbosity.LOW;
            bl = false;
            if (verbosity == verbosity2) {
                bl = true;
            }
        }
        return bl;
    }

    private boolean isPrimitive(Class class_) {
        if (Number.class.isAssignableFrom(class_)) {
            return true;
        }
        if (class_ == Boolean.class) {
            return true;
        }
        if (class_ == Character.class) {
            return true;
        }
        return class_.isPrimitive();
    }

    private boolean isPrimitiveKey(Class[] arrclass) {
        if (arrclass != null && arrclass.length > 0) {
            Class class_ = arrclass[0].getSuperclass();
            Class class_2 = arrclass[0];
            if (class_ != null) {
                if (class_.isEnum()) {
                    return true;
                }
                if (class_2.isEnum()) {
                    return true;
                }
            }
            return this.isPrimitive(class_2);
        }
        return false;
    }

    public Annotation getInstance(Class class_, Class[] arrclass) throws Exception {
        ClassLoader classLoader = this.getClassLoader();
        if (Map.class.isAssignableFrom(class_)) {
            if (this.isPrimitiveKey(arrclass) && this.isAttribute()) {
                return this.getInstance(classLoader, ElementMap.class, true);
            }
            return this.getInstance(classLoader, ElementMap.class);
        }
        if (Collection.class.isAssignableFrom(class_)) {
            return this.getInstance(classLoader, ElementList.class);
        }
        return this.getInstance(class_);
    }
}

