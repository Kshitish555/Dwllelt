/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.t
 */
package l.a.k.a.x;

import l.a.k.a.n;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.t;

public class e
extends r
implements t {
    private int f;
    private int h;

    protected e(int n2, r r2) {
        super(n2, r2);
    }

    public e(r r2) {
        this(327680, r2);
    }

    private void b(int n2, String string, String string2, String string3, boolean bl) {
        int n3;
        if (n2 == 185) {
            this.f = 5 + this.f;
            n3 = 5 + this.h;
        } else {
            this.f = 3 + this.f;
            n3 = 3 + this.h;
        }
        this.h = n3;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, string, string2, string3, bl);
        }
    }

    public void a(int n2) {
        this.f = 1 + this.f;
        this.h = 1 + this.h;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2);
        }
    }

    public void a(int n2, int n3) {
        int n4;
        if (n2 <= 255 && n3 <= 127 && n3 >= -128) {
            this.f = 3 + this.f;
            n4 = 3 + this.h;
        } else {
            this.f = 6 + this.f;
            n4 = 6 + this.h;
        }
        this.h = n4;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, n3);
        }
    }

    public /* varargs */ void a(int n2, int n3, q q2, q ... arrq) {
        this.f += 13 + 4 * arrq.length;
        this.h += 16 + 4 * arrq.length;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, n3, q2, arrq);
        }
    }

    public void a(int n2, String string) {
        this.f = 3 + this.f;
        this.h = 3 + this.h;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, string);
        }
    }

    public void a(int n2, String string, String string2, String string3) {
        this.f = 3 + this.f;
        this.h = 3 + this.h;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, string, string2, string3);
        }
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        if (this.c < 327680) {
            super.a(n2, string, string2, string3, bl);
            return;
        }
        this.b(n2, string, string2, string3, bl);
    }

    public void a(int n2, q q2) {
        this.f = 3 + this.f;
        int n3 = n2 != 167 && n2 != 168 ? 8 + this.h : 5 + this.h;
        this.h = n3;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(n2, q2);
        }
    }

    public void a(Object object) {
        int n2 = !(object instanceof Long) && !(object instanceof Double) ? 2 + this.f : 3 + this.f;
        this.f = n2;
        this.h = 3 + this.h;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(object);
        }
    }

    public void a(String string, int n2) {
        this.f = 4 + this.f;
        this.h = 4 + this.h;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(string, n2);
        }
    }

    public /* varargs */ void a(String string, String string2, n n2, Object ... arrobject) {
        this.f = 5 + this.f;
        this.h = 5 + this.h;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(string, string2, n2, arrobject);
        }
    }

    public void a(q q2, int[] arrn, q[] arrq) {
        this.f += 9 + 8 * arrn.length;
        this.h += 12 + 8 * arrn.length;
        r r2 = this.d;
        if (r2 != null) {
            r2.a(q2, arrn, arrq);
        }
    }

    public void b(int n2, int n3) {
        int n4;
        if (n2 == 17) {
            this.f = 3 + this.f;
            n4 = 3 + this.h;
        } else {
            this.f = 2 + this.f;
            n4 = 2 + this.h;
        }
        this.h = n4;
        r r2 = this.d;
        if (r2 != null) {
            r2.b(n2, n3);
        }
    }

    public void b(int n2, String string, String string2, String string3) {
        if (this.c >= 327680) {
            super.b(n2, string, string2, string3);
            return;
        }
        boolean bl = n2 == 185;
        this.b(n2, string, string2, string3, bl);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void d(int var1_1, int var2_2) {
        block2 : {
            if (var2_2 >= 4 || var1_1 == 169) break block2;
            this.f = 1 + this.f;
            var3_3 = 1 + this.h;
            ** GOTO lbl12
        }
        if (var2_2 >= 256) {
            this.f = 4 + this.f;
            this.h = 4 + this.h;
        } else {
            this.f = 2 + this.f;
            var3_3 = 2 + this.h;
lbl12: // 2 sources:
            this.h = var3_3;
        }
        var4_4 = this.d;
        if (var4_4 == null) return;
        var4_4.d(var1_1, var2_2);
    }

    public int e() {
        return this.h;
    }

    public int f() {
        return this.f;
    }
}

