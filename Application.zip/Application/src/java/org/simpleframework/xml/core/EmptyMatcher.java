/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  org.simpleframework.xml.transform.Matcher
 *  org.simpleframework.xml.transform.Transform
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.transform.Matcher;
import org.simpleframework.xml.transform.Transform;

class EmptyMatcher
implements Matcher {
    EmptyMatcher() {
    }

    public Transform match(Class class_) throws Exception {
        return null;
    }
}

