/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuffer
 *  l.a.k.a.x.n
 *  l.a.k.a.y.b
 */
package l.a.k.a.x;

import l.a.k.a.x.n;
import l.a.k.a.y.b;

public class s
extends b {
    private final b e;
    private final n f;
    private String g;

    protected s(int n2, b b2, n n3) {
        super(n2);
        this.e = b2;
        this.f = n3;
    }

    public s(b b2, n n2) {
        this(327680, b2, n2);
    }

    public b a() {
        this.e.a();
        return this;
    }

    public void a(char c2) {
        this.e.a(c2);
    }

    public void a(String string) {
        this.g = string;
        this.e.a(this.f.d(string));
    }

    public b b() {
        this.e.b();
        return this;
    }

    public b b(char c2) {
        this.e.b(c2);
        return this;
    }

    public void b(String string) {
        this.e.b(string);
    }

    public void c() {
        this.e.c();
    }

    public void c(String string) {
        String string2;
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(this.f.d(this.g));
        stringBuffer.append('$');
        String string3 = stringBuffer.toString();
        StringBuffer stringBuffer2 = new StringBuffer();
        stringBuffer2.append(this.g);
        stringBuffer2.append('$');
        stringBuffer2.append(string);
        this.g = string2 = stringBuffer2.toString();
        String string4 = this.f.d(string2);
        int n2 = string4.startsWith(string3) ? string3.length() : 1 + string4.lastIndexOf(36);
        this.e.c(string4.substring(n2));
    }

    public b d() {
        this.e.d();
        return this;
    }

    public void d(String string) {
        this.e.d(string);
    }

    public b e() {
        this.e.e();
        return this;
    }

    public b f() {
        this.e.f();
        return this;
    }

    public b g() {
        this.e.g();
        return this;
    }

    public b h() {
        this.e.h();
        return this;
    }

    public b i() {
        this.e.i();
        return this;
    }

    public void j() {
        this.e.j();
    }
}

