/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Iterator
 *  org.simpleframework.xml.util.Cache
 *  org.simpleframework.xml.util.WeakCache$Segment
 *  org.simpleframework.xml.util.WeakCache$SegmentList
 */
package org.simpleframework.xml.util;

import java.util.Iterator;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.WeakCache;

/*
 * Exception performing whole class analysis.
 */
public class WeakCache<T>
implements Cache<T> {
    private WeakCache<T> list;

    public WeakCache() {
        this(10);
    }

    public WeakCache(int n) {
        this.list = new /* Unavailable Anonymous Inner Class!! */;
    }

    private WeakCache<T> map(Object object) {
        return this.list.get(object);
    }

    public void cache(Object object, T t) {
        this.map(object).cache(object, t);
    }

    public boolean contains(Object object) {
        return this.map(object).contains(object);
    }

    public T fetch(Object object) {
        return (T)this.map(object).fetch(object);
    }

    public boolean isEmpty() {
        Iterator iterator = this.list.iterator();
        while (iterator.hasNext()) {
            if ((iterator.next()).isEmpty()) continue;
            return false;
        }
        return true;
    }

    public T take(Object object) {
        return (T)this.map(object).take(object);
    }
}

