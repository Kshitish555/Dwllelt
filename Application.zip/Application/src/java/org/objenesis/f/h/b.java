/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package org.objenesis.f.h;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.objenesis.ObjenesisException;

class b {
    b() {
    }

    private static Class<?> a() {
        try {
            Class class_ = Class.forName((String)"sun.reflect.ReflectionFactory");
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new ObjenesisException(classNotFoundException);
        }
    }

    private static Object a(Class<?> class_) {
        try {
            Object object = class_.getDeclaredMethod("getReflectionFactory", new Class[0]).invoke(null, new Object[0]);
            return object;
        }
        catch (InvocationTargetException invocationTargetException) {
            throw new ObjenesisException(invocationTargetException);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw new ObjenesisException(illegalArgumentException);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new ObjenesisException(illegalAccessException);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new ObjenesisException(noSuchMethodException);
        }
    }

    public static <T> Constructor<T> a(Class<T> class_, Constructor<?> constructor) {
        Class<?> class_2 = b.a();
        Object object = b.a(class_2);
        Method method = b.b(class_2);
        try {
            Constructor constructor2 = (Constructor)method.invoke(object, new Object[]{class_, constructor});
            return constructor2;
        }
        catch (InvocationTargetException invocationTargetException) {
            throw new ObjenesisException(invocationTargetException);
        }
        catch (IllegalAccessException illegalAccessException) {
            throw new ObjenesisException(illegalAccessException);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            throw new ObjenesisException(illegalArgumentException);
        }
    }

    private static Method b(Class<?> class_) {
        try {
            Method method = class_.getDeclaredMethod("newConstructorForSerialization", new Class[]{Class.class, Constructor.class});
            return method;
        }
        catch (NoSuchMethodException noSuchMethodException) {
            throw new ObjenesisException(noSuchMethodException);
        }
    }
}

