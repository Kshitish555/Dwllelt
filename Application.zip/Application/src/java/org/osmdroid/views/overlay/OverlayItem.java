/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  android.graphics.drawable.Drawable
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package org.osmdroid.views.overlay;

import android.graphics.Point;
import android.graphics.drawable.Drawable;
import org.osmdroid.util.GeoPoint;

public class OverlayItem {
    protected static final Point DEFAULT_MARKER_SIZE = new Point(26, 94);
    public static final int ITEM_STATE_FOCUSED_MASK = 4;
    public static final int ITEM_STATE_PRESSED_MASK = 1;
    public static final int ITEM_STATE_SELECTED_MASK = 2;
    public final String mDescription;
    public final GeoPoint mGeoPoint;
    protected HotspotPlace mHotspotPlace;
    protected Drawable mMarker;
    public final String mTitle;
    public final String mUid;

    public OverlayItem(String string2, String string3, String string4, GeoPoint geoPoint) {
        this.mTitle = string3;
        this.mDescription = string4;
        this.mGeoPoint = geoPoint;
        this.mUid = string2;
    }

    public OverlayItem(String string2, String string3, GeoPoint geoPoint) {
        this(null, string2, string3, geoPoint);
    }

    public static void setState(Drawable drawable, int n2) {
        int[] arrn = new int[3];
        int n3 = n2 & 1;
        int n4 = 0;
        if (n3 > 0) {
            arrn[0] = 16842919;
            n4 = 1;
        }
        if ((n2 & 2) > 0) {
            int n5 = n4 + 1;
            arrn[n4] = 16842913;
            n4 = n5;
        }
        if ((n2 & 4) > 0) {
            arrn[n4] = 16842908;
        }
        drawable.setState(arrn);
    }

    public Drawable getDrawable() {
        return this.mMarker;
    }

    public int getHeight() {
        return this.mMarker.getIntrinsicHeight();
    }

    public Drawable getMarker(int n2) {
        Drawable drawable = this.mMarker;
        if (drawable == null) {
            return null;
        }
        OverlayItem.setState(drawable, n2);
        return this.mMarker;
    }

    public HotspotPlace getMarkerHotspot() {
        return this.mHotspotPlace;
    }

    public GeoPoint getPoint() {
        return this.mGeoPoint;
    }

    public String getSnippet() {
        return this.mDescription;
    }

    public String getTitle() {
        return this.mTitle;
    }

    public String getUid() {
        return this.mUid;
    }

    public int getWidth() {
        return this.mMarker.getIntrinsicWidth();
    }

    public void setMarker(Drawable drawable) {
        this.mMarker = drawable;
    }

    public void setMarkerHotspot(HotspotPlace hotspotPlace) {
        if (hotspotPlace == null) {
            hotspotPlace = HotspotPlace.BOTTOM_CENTER;
        }
        this.mHotspotPlace = hotspotPlace;
    }

    public static final class HotspotPlace
    extends Enum<HotspotPlace> {
        private static final /* synthetic */ HotspotPlace[] $VALUES;
        public static final /* enum */ HotspotPlace BOTTOM_CENTER;
        public static final /* enum */ HotspotPlace CENTER;
        public static final /* enum */ HotspotPlace LEFT_CENTER;
        public static final /* enum */ HotspotPlace LOWER_LEFT_CORNER;
        public static final /* enum */ HotspotPlace LOWER_RIGHT_CORNER;
        public static final /* enum */ HotspotPlace NONE;
        public static final /* enum */ HotspotPlace RIGHT_CENTER;
        public static final /* enum */ HotspotPlace TOP_CENTER;
        public static final /* enum */ HotspotPlace UPPER_LEFT_CORNER;
        public static final /* enum */ HotspotPlace UPPER_RIGHT_CORNER;

        static {
            HotspotPlace hotspotPlace;
            NONE = new HotspotPlace();
            CENTER = new HotspotPlace();
            BOTTOM_CENTER = new HotspotPlace();
            TOP_CENTER = new HotspotPlace();
            RIGHT_CENTER = new HotspotPlace();
            LEFT_CENTER = new HotspotPlace();
            UPPER_RIGHT_CORNER = new HotspotPlace();
            LOWER_RIGHT_CORNER = new HotspotPlace();
            UPPER_LEFT_CORNER = new HotspotPlace();
            LOWER_LEFT_CORNER = hotspotPlace = new HotspotPlace();
            HotspotPlace[] arrhotspotPlace = new HotspotPlace[]{NONE, CENTER, BOTTOM_CENTER, TOP_CENTER, RIGHT_CENTER, LEFT_CENTER, UPPER_RIGHT_CORNER, LOWER_RIGHT_CORNER, UPPER_LEFT_CORNER, hotspotPlace};
            $VALUES = arrhotspotPlace;
        }

        public static HotspotPlace valueOf(String string2) {
            return (HotspotPlace)Enum.valueOf(HotspotPlace.class, (String)string2);
        }

        public static HotspotPlace[] values() {
            return (HotspotPlace[])$VALUES.clone();
        }
    }

}

