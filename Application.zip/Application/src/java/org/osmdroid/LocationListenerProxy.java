/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.location.Location
 *  android.location.LocationListener
 *  android.location.LocationManager
 *  android.os.Bundle
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.List
 */
package org.osmdroid;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import java.util.Iterator;
import java.util.List;

public class LocationListenerProxy
implements LocationListener {
    private LocationListener mListener = null;
    private final LocationManager mLocationManager;

    public LocationListenerProxy(LocationManager locationManager) {
        this.mLocationManager = locationManager;
    }

    public void onLocationChanged(Location location) {
        LocationListener locationListener = this.mListener;
        if (locationListener != null) {
            locationListener.onLocationChanged(location);
        }
    }

    public void onProviderDisabled(String string2) {
        LocationListener locationListener = this.mListener;
        if (locationListener != null) {
            locationListener.onProviderDisabled(string2);
        }
    }

    public void onProviderEnabled(String string2) {
        LocationListener locationListener = this.mListener;
        if (locationListener != null) {
            locationListener.onProviderEnabled(string2);
        }
    }

    public void onStatusChanged(String string2, int n2, Bundle bundle) {
        LocationListener locationListener = this.mListener;
        if (locationListener != null) {
            locationListener.onStatusChanged(string2, n2, bundle);
        }
    }

    public boolean startListening(LocationListener locationListener, long l2, float f2) {
        this.mListener = locationListener;
        Iterator iterator = this.mLocationManager.getProviders(true).iterator();
        boolean bl = false;
        while (iterator.hasNext()) {
            String string2 = (String)iterator.next();
            if (!"gps".equals((Object)string2) && !"network".equals((Object)string2)) continue;
            this.mLocationManager.requestLocationUpdates(string2, l2, f2, (LocationListener)this);
            bl = true;
        }
        return bl;
    }

    public void stopListening() {
        this.mListener = null;
        this.mLocationManager.removeUpdates((LocationListener)this);
    }
}

