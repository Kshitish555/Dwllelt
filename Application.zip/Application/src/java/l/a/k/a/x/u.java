/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.io.DataOutput
 *  java.io.DataOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.NoClassDefFoundError
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.security.MessageDigest
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  l.a.k.a.f
 *  l.a.k.a.k
 *  l.a.k.a.r
 *  l.a.k.a.x.t
 */
package l.a.k.a.x;

import java.io.ByteArrayOutputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import l.a.k.a.f;
import l.a.k.a.k;
import l.a.k.a.r;
import l.a.k.a.x.t;

public class u
extends f {
    static /* synthetic */ Class S4;
    private boolean P4;
    private Collection Q4 = new ArrayList();
    private Collection R4 = new ArrayList();
    private boolean f;
    private boolean h;
    private int o;
    private String s;
    private String[] t;
    private Collection w = new ArrayList();

    static {
        S4 = u.a("net.bytebuddy.jar.asm.commons.SerialVersionUIDAdder");
    }

    protected u(int n2, f f2) {
        super(n2, f2);
    }

    public u(f f2) {
        this(327680, f2);
        if (u.class == S4) {
            return;
        }
        throw new IllegalStateException();
    }

    static /* synthetic */ Class a(String string) {
        try {
            Class class_ = Class.forName((String)string);
            return class_;
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new NoClassDefFoundError(classNotFoundException.getMessage());
        }
    }

    private static void a(Collection collection, DataOutput dataOutput, boolean bl) throws IOException {
        int n2 = collection.size();
        Object[] arrobject = (t[])collection.toArray((Object[])new t[n2]);
        Arrays.sort((Object[])arrobject);
        for (int i2 = 0; i2 < n2; ++i2) {
            dataOutput.writeUTF(((t)arrobject[i2]).c);
            dataOutput.writeInt(((t)arrobject[i2]).d);
            String string = bl ? ((t)arrobject[i2]).f.replace('/', '.') : ((t)arrobject[i2]).f;
            dataOutput.writeUTF(string);
        }
    }

    public k a(int n2, String string, String string2, String string3, Object object) {
        if (this.f) {
            if ("serialVersionUID".equals((Object)string)) {
                this.f = false;
                this.h = true;
            }
            if ((n2 & 2) == 0 || (n2 & 136) == 0) {
                int n3 = n2 & 223;
                this.w.add((Object)new t(string, n3, string2));
            }
        }
        return super.a(n2, string, string2, string3, object);
    }

    /*
     * Enabled aggressive block sorting
     */
    public r a(int n2, String string, String string2, String string3, String[] arrstring) {
        t t2;
        Collection collection;
        if (!this.f) return super.a(n2, string, string2, string3, arrstring);
        if ("<clinit>".equals((Object)string)) {
            this.P4 = true;
        }
        int n3 = n2 & 3391;
        if ((n2 & 2) != 0) return super.a(n2, string, string2, string3, arrstring);
        if ("<init>".equals((Object)string)) {
            collection = this.Q4;
            t2 = new t(string, n3, string2);
        } else {
            if ("<clinit>".equals((Object)string)) return super.a(n2, string, string2, string3, arrstring);
            collection = this.R4;
            t2 = new t(string, n3, string2);
        }
        collection.add((Object)t2);
        return super.a(n2, string, string2, string3, arrstring);
    }

    public void a() {
        if (this.f && !this.h) {
            try {
                this.a(this.b());
            }
            catch (Throwable throwable) {
                StringBuffer stringBuffer = new StringBuffer();
                stringBuffer.append("Error while computing SVUID for ");
                stringBuffer.append(this.s);
                throw new RuntimeException(stringBuffer.toString(), throwable);
            }
        }
        super.a();
    }

    public void a(int n2, int n3, String string, String string2, String string3, String[] arrstring) {
        boolean bl = (n3 & 16384) == 0;
        this.f = bl;
        if (bl) {
            this.s = string;
            this.o = n3;
            String[] arrstring2 = new String[arrstring.length];
            this.t = arrstring2;
            System.arraycopy((Object)arrstring, (int)0, (Object)arrstring2, (int)0, (int)arrstring.length);
        }
        super.a(n2, n3, string, string2, string3, arrstring);
    }

    protected void a(long l2) {
        k k2 = super.a(24, "serialVersionUID", "J", null, (Object)new Long(l2));
        if (k2 != null) {
            k2.a();
        }
    }

    public void a(String string, String string2, String string3, int n2) {
        String string4 = this.s;
        if (string4 != null && string4.equals((Object)string)) {
            this.o = n2;
        }
        super.a(string, string2, string3, n2);
    }

    protected byte[] a(byte[] arrby) {
        try {
            byte[] arrby2 = MessageDigest.getInstance((String)"SHA").digest(arrby);
            return arrby2;
        }
        catch (Exception exception) {
            throw new UnsupportedOperationException(exception.toString());
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected long b() throws IOException {
        block11 : {
            var1_1 = new ByteArrayOutputStream();
            var2_2 = new DataOutputStream((OutputStream)var1_1);
            try {
                block12 : {
                    var2_2.writeUTF(this.s.replace('/', '.'));
                    var4_3 = this.o;
                    if ((var4_3 & 512) != 0) {
                        var4_3 = this.R4.size() > 0 ? (var4_3 |= 1024) : (var4_3 &= -1025);
                    }
                    var2_2.writeInt(var4_3 & 1553);
                    Arrays.sort((Object[])this.t);
                    break block12;
                    catch (Throwable var13_12) {
                        var2_2 = null;
                        var3_11 = var13_12;
                    }
                    break block11;
                }
                for (var5_4 = 0; var5_4 < this.t.length; ++var5_4) {
                    var2_2.writeUTF(this.t[var5_4].replace('/', '.'));
                }
                u.a(this.w, (DataOutput)var2_2, false);
                if (this.P4) {
                    var2_2.writeUTF("<clinit>");
                    var2_2.writeInt(8);
                    var2_2.writeUTF("()V");
                }
                u.a(this.Q4, (DataOutput)var2_2, true);
                u.a(this.R4, (DataOutput)var2_2, true);
                var2_2.flush();
                var6_5 = this.a(var1_1.toByteArray());
                var7_6 = Math.min((int)var6_5.length, (int)8) - 1;
                var8_7 = 0L;
            }
            catch (Throwable var3_10) {}
            do lbl-1000: // 2 sources:
            {
                if (var7_6 < 0) {
                    var2_2.close();
                    return var8_7;
                }
                var10_8 = var8_7 << 8;
                var12_9 = var6_5[var7_6];
                break;
            } while (true);
            {
                var8_7 = var10_8 | (long)(var12_9 & 255);
                --var7_6;
                ** while (true)
            }
        }
        if (var2_2 == null) throw var3_11;
        var2_2.close();
        throw var3_11;
    }

    public boolean c() {
        return this.h;
    }
}

