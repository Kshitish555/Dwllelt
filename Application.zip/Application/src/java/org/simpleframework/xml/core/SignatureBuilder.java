/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Constructor
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.simpleframework.xml.core.Parameter
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.simpleframework.xml.core.ConstructorException;
import org.simpleframework.xml.core.Parameter;
import org.simpleframework.xml.core.Signature;

class SignatureBuilder {
    private final Constructor factory;
    private final ParameterTable table = new ParameterTable();

    public SignatureBuilder(Constructor constructor) {
        this.factory = constructor;
    }

    private List<Signature> build(ParameterTable parameterTable) throws Exception {
        if (this.table.isEmpty()) {
            return this.create();
        }
        this.build(parameterTable, 0);
        return this.create(parameterTable);
    }

    private void build(ParameterTable parameterTable, int n) {
        this.build(parameterTable, new ParameterList(), n);
    }

    private void build(ParameterTable parameterTable, ParameterList parameterList, int n) {
        ParameterList parameterList2 = this.table.get(n);
        int n2 = parameterList2.size();
        if (-1 + this.table.width() > n) {
            for (int i = 0; i < n2; ++i) {
                ParameterList parameterList3 = new ParameterList(parameterList);
                if (parameterList == null) continue;
                parameterList3.add((Object)((Parameter)parameterList2.get(i)));
                this.build(parameterTable, parameterList3, n + 1);
            }
        } else {
            this.populate(parameterTable, parameterList, n);
        }
    }

    private List<Signature> create() throws Exception {
        ArrayList arrayList = new ArrayList();
        Signature signature = new Signature(this.factory);
        if (this.isValid()) {
            arrayList.add((Object)signature);
        }
        return arrayList;
    }

    private List<Signature> create(ParameterTable parameterTable) throws Exception {
        ArrayList arrayList = new ArrayList();
        int n = parameterTable.height();
        int n2 = parameterTable.width();
        for (int i = 0; i < n; ++i) {
            Signature signature = new Signature(this.factory);
            for (int j = 0; j < n2; ++j) {
                Parameter parameter = parameterTable.get(j, i);
                String string = parameter.getPath();
                if (!signature.contains(parameter.getKey())) {
                    signature.add(parameter);
                    continue;
                }
                Object[] arrobject = new Object[]{string, this.factory};
                throw new ConstructorException("Parameter '%s' is a duplicate in %s", arrobject);
            }
            arrayList.add((Object)signature);
        }
        return arrayList;
    }

    private void populate(ParameterTable parameterTable, ParameterList parameterList, int n) {
        ParameterList parameterList2 = this.table.get(n);
        int n2 = parameterList.size();
        int n3 = parameterList2.size();
        for (int i = 0; i < n3; ++i) {
            for (int j = 0; j < n2; ++j) {
                parameterTable.get(j).add((Object)((Parameter)parameterList.get(j)));
            }
            parameterTable.get(n).add((Object)((Parameter)parameterList2.get(i)));
        }
    }

    public List<Signature> build() throws Exception {
        return this.build(new ParameterTable());
    }

    public void insert(Parameter parameter, int n) {
        this.table.insert(parameter, n);
    }

    public boolean isValid() {
        int n;
        Class[] arrclass = this.factory.getParameterTypes();
        return arrclass.length == (n = this.table.width());
    }

    private static class ParameterList
    extends ArrayList<Parameter> {
        public ParameterList() {
        }

        public ParameterList(ParameterList parameterList) {
            super((Collection)parameterList);
        }
    }

    private static class ParameterTable
    extends ArrayList<ParameterList> {
        private int height() {
            if (this.width() > 0) {
                return this.get(0).size();
            }
            return 0;
        }

        private int width() {
            return this.size();
        }

        public Parameter get(int n, int n2) {
            return (Parameter)this.get(n).get(n2);
        }

        public ParameterList get(int n) {
            for (int i = this.size(); i <= n; ++i) {
                this.add((Object)new ParameterList());
            }
            return (ParameterList)((Object)super.get(n));
        }

        public void insert(Parameter parameter, int n) {
            ParameterList parameterList = this.get(n);
            if (parameterList != null) {
                parameterList.add((Object)parameter);
            }
        }
    }

}

