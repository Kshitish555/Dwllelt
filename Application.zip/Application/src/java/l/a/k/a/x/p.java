/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  l.a.k.a.a
 *  l.a.k.a.f
 *  l.a.k.a.k
 *  l.a.k.a.r
 *  l.a.k.a.v
 *  l.a.k.a.x.n
 *  l.a.k.a.x.r
 */
package l.a.k.a.x;

import l.a.k.a.a;
import l.a.k.a.f;
import l.a.k.a.k;
import l.a.k.a.v;
import l.a.k.a.x.n;
import l.a.k.a.x.o;
import l.a.k.a.x.q;
import l.a.k.a.x.r;

public class p
extends f {
    protected final n f;
    protected String h;

    protected p(int n2, f f2, n n3) {
        super(n2, f2);
        this.f = n3;
    }

    public p(f f2, n n2) {
        this(327680, f2, n2);
    }

    public a a(int n2, v v2, String string, boolean bl) {
        a a2 = super.a(n2, v2, this.f.b(string), bl);
        if (a2 == null) {
            return null;
        }
        return this.a(a2);
    }

    public a a(String string, boolean bl) {
        a a2 = super.a(this.f.b(string), bl);
        if (a2 == null) {
            return null;
        }
        return this.a(a2);
    }

    protected a a(a a2) {
        return new o(a2, this.f);
    }

    public k a(int n2, String string, String string2, String string3, Object object) {
        k k2 = super.a(n2, this.f.a(this.h, string, string2), this.f.b(string2), this.f.a(string3, true), this.f.a(object));
        if (k2 == null) {
            return null;
        }
        return this.a(k2);
    }

    protected k a(k k2) {
        return new q(k2, this.f);
    }

    public l.a.k.a.r a(int n2, String string, String string2, String string3, String[] arrstring) {
        String[] arrstring2;
        String string4;
        String string5 = this.f.c(string2);
        String string6 = this.f.b(this.h, string, string2);
        l.a.k.a.r r2 = super.a(n2, string6, string5, string4 = this.f.a(string3, false), arrstring2 = arrstring == null ? null : this.f.a(arrstring));
        if (r2 == null) {
            return null;
        }
        return this.a(n2, string5, r2);
    }

    protected l.a.k.a.r a(int n2, String string, l.a.k.a.r r2) {
        return new r(n2, string, r2, this.f);
    }

    public void a(int n2, int n3, String string, String string2, String string3, String[] arrstring) {
        this.h = string;
        String string4 = this.f.d(string);
        String string5 = this.f.a(string2, false);
        String string6 = this.f.d(string3);
        String[] arrstring2 = arrstring == null ? null : this.f.a(arrstring);
        super.a(n2, n3, string4, string5, string6, arrstring2);
    }

    public void a(String string, String string2, String string3) {
        String string4 = this.f.d(string);
        String string5 = string2 == null ? null : this.f.b(string, string2, string3);
        String string6 = string3 == null ? null : this.f.c(string3);
        super.a(string4, string5, string6);
    }

    public void a(String string, String string2, String string3, int n2) {
        String string4 = this.f.d(string);
        String string5 = string2 == null ? null : this.f.d(string2);
        super.a(string4, string5, string3, n2);
    }
}

