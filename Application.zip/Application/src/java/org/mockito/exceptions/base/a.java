/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package org.mockito.exceptions.base;

public class a
extends AssertionError {
    private static final long d = 1L;
    private final StackTraceElement[] c;

    public a(String string2) {
        super((Object)string2);
        this.c = this.getStackTrace();
        new org.mockito.internal.exceptions.d.a().a((Throwable)this);
    }

    public a(a a2, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append("\n");
        stringBuilder.append(a2.getMessage());
        super((Object)stringBuilder.toString());
        super.setStackTrace(a2.getStackTrace());
        this.c = a2.a();
    }

    public StackTraceElement[] a() {
        return this.c;
    }
}

