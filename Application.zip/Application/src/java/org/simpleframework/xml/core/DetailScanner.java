/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Field
 *  java.lang.reflect.Method
 *  java.lang.reflect.Modifier
 *  java.util.LinkedList
 *  java.util.List
 *  org.simpleframework.xml.Default
 *  org.simpleframework.xml.DefaultType
 *  org.simpleframework.xml.Namespace
 *  org.simpleframework.xml.NamespaceList
 *  org.simpleframework.xml.Order
 *  org.simpleframework.xml.Root
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.FieldDetail
 *  org.simpleframework.xml.core.MethodDetail
 *  org.simpleframework.xml.core.Reflector
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.LinkedList;
import java.util.List;
import org.simpleframework.xml.Default;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Namespace;
import org.simpleframework.xml.NamespaceList;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Root;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.FieldDetail;
import org.simpleframework.xml.core.MethodDetail;
import org.simpleframework.xml.core.Reflector;

class DetailScanner
implements Detail {
    private DefaultType access;
    private NamespaceList declaration;
    private List<FieldDetail> fields = new LinkedList();
    private Annotation[] labels;
    private List<MethodDetail> methods = new LinkedList();
    private String name;
    private Namespace namespace;
    private Order order;
    private DefaultType override;
    private boolean required;
    private Root root;
    private boolean strict;
    private Class type;

    public DetailScanner(Class class_) {
        this(class_, null);
    }

    public DetailScanner(Class class_, DefaultType defaultType) {
        this.labels = class_.getDeclaredAnnotations();
        this.override = defaultType;
        this.strict = true;
        this.type = class_;
        this.scan(class_);
    }

    private void access(Annotation annotation) {
        if (annotation != null) {
            Default default_ = (Default)annotation;
            this.required = default_.required();
            this.access = default_.value();
        }
    }

    private void extract(Class class_) {
        for (Annotation annotation : this.labels) {
            if (annotation instanceof Namespace) {
                this.namespace(annotation);
            }
            if (annotation instanceof NamespaceList) {
                this.scope(annotation);
            }
            if (annotation instanceof Root) {
                this.root(annotation);
            }
            if (annotation instanceof Order) {
                this.order(annotation);
            }
            if (!(annotation instanceof Default)) continue;
            this.access(annotation);
        }
    }

    private void fields(Class class_) {
        Field[] arrfield = class_.getDeclaredFields();
        int n = arrfield.length;
        for (int i = 0; i < n; ++i) {
            FieldDetail fieldDetail = new FieldDetail(arrfield[i]);
            this.fields.add((Object)fieldDetail);
        }
    }

    private boolean isEmpty(String string2) {
        return string2.length() == 0;
    }

    private void methods(Class class_) {
        Method[] arrmethod = class_.getDeclaredMethods();
        int n = arrmethod.length;
        for (int i = 0; i < n; ++i) {
            MethodDetail methodDetail = new MethodDetail(arrmethod[i]);
            this.methods.add((Object)methodDetail);
        }
    }

    private void namespace(Annotation annotation) {
        if (annotation != null) {
            this.namespace = (Namespace)annotation;
        }
    }

    private void order(Annotation annotation) {
        if (annotation != null) {
            this.order = (Order)annotation;
        }
    }

    private void root(Annotation annotation) {
        if (annotation != null) {
            Root root = (Root)annotation;
            String string2 = this.type.getSimpleName();
            if (root != null) {
                String string3 = root.name();
                if (this.isEmpty(string3)) {
                    string3 = Reflector.getName((String)string2);
                }
                this.strict = root.strict();
                this.root = root;
                this.name = string3;
            }
        }
    }

    private void scan(Class class_) {
        this.methods(class_);
        this.fields(class_);
        this.extract(class_);
    }

    private void scope(Annotation annotation) {
        if (annotation != null) {
            this.declaration = (NamespaceList)annotation;
        }
    }

    public DefaultType getAccess() {
        DefaultType defaultType = this.override;
        if (defaultType != null) {
            return defaultType;
        }
        return this.access;
    }

    public Annotation[] getAnnotations() {
        return this.labels;
    }

    public Constructor[] getConstructors() {
        return this.type.getDeclaredConstructors();
    }

    public List<FieldDetail> getFields() {
        return this.fields;
    }

    public List<MethodDetail> getMethods() {
        return this.methods;
    }

    public String getName() {
        return this.name;
    }

    public Namespace getNamespace() {
        return this.namespace;
    }

    public NamespaceList getNamespaceList() {
        return this.declaration;
    }

    public Order getOrder() {
        return this.order;
    }

    public DefaultType getOverride() {
        return this.override;
    }

    public Root getRoot() {
        return this.root;
    }

    public Class getSuper() {
        Class class_ = this.type.getSuperclass();
        if (class_ == Object.class) {
            class_ = null;
        }
        return class_;
    }

    public Class getType() {
        return this.type;
    }

    public boolean isInstantiable() {
        if (Modifier.isStatic((int)this.type.getModifiers())) {
            return true;
        }
        return true ^ this.type.isMemberClass();
    }

    public boolean isPrimitive() {
        return this.type.isPrimitive();
    }

    public boolean isRequired() {
        return this.required;
    }

    public boolean isStrict() {
        return this.strict;
    }

    public String toString() {
        return this.type.toString();
    }
}

