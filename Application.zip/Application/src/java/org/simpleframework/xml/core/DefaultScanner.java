/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  org.simpleframework.xml.DefaultType
 *  org.simpleframework.xml.Order
 *  org.simpleframework.xml.Version
 *  org.simpleframework.xml.core.Caller
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.Function
 *  org.simpleframework.xml.core.Instantiator
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.ParameterMap
 */
package org.simpleframework.xml.core;

import java.util.List;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.Order;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.Caller;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.DefaultDetail;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.Function;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.ObjectScanner;
import org.simpleframework.xml.core.ParameterMap;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.Section;
import org.simpleframework.xml.core.Signature;
import org.simpleframework.xml.core.Support;

class DefaultScanner
implements Scanner {
    private Detail detail;
    private Scanner scanner;

    public DefaultScanner(Detail detail, Support support) throws Exception {
        DefaultDetail defaultDetail = new DefaultDetail(detail, DefaultType.FIELD);
        this.detail = defaultDetail;
        this.scanner = new ObjectScanner(defaultDetail, support);
    }

    @Override
    public Caller getCaller(Context context) {
        return this.scanner.getCaller(context);
    }

    @Override
    public Function getCommit() {
        return this.scanner.getCommit();
    }

    @Override
    public Function getComplete() {
        return this.scanner.getComplete();
    }

    @Override
    public Decorator getDecorator() {
        return this.scanner.getDecorator();
    }

    @Override
    public Instantiator getInstantiator() {
        return this.scanner.getInstantiator();
    }

    @Override
    public String getName() {
        return this.detail.getName();
    }

    @Override
    public Order getOrder() {
        return this.scanner.getOrder();
    }

    @Override
    public ParameterMap getParameters() {
        return this.scanner.getParameters();
    }

    @Override
    public Function getPersist() {
        return this.scanner.getPersist();
    }

    @Override
    public Function getReplace() {
        return this.scanner.getReplace();
    }

    @Override
    public Function getResolve() {
        return this.scanner.getResolve();
    }

    @Override
    public Version getRevision() {
        return this.scanner.getRevision();
    }

    @Override
    public Section getSection() {
        return this.scanner.getSection();
    }

    @Override
    public Signature getSignature() {
        return this.scanner.getSignature();
    }

    @Override
    public List<Signature> getSignatures() {
        return this.scanner.getSignatures();
    }

    @Override
    public Label getText() {
        return this.scanner.getText();
    }

    @Override
    public Class getType() {
        return this.scanner.getType();
    }

    @Override
    public Function getValidate() {
        return this.scanner.getValidate();
    }

    @Override
    public Label getVersion() {
        return this.scanner.getVersion();
    }

    @Override
    public boolean isEmpty() {
        return this.scanner.isEmpty();
    }

    @Override
    public boolean isPrimitive() {
        return this.scanner.isPrimitive();
    }

    @Override
    public boolean isStrict() {
        return this.scanner.isStrict();
    }
}

