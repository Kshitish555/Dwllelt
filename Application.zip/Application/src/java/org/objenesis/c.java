/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Object
 *  org.objenesis.f.a
 */
package org.objenesis;

import java.io.Serializable;
import org.objenesis.d;
import org.objenesis.e;
import org.objenesis.f.a;

public final class c {
    private static final org.objenesis.a a = new e();
    private static final org.objenesis.a b = new d();

    private c() {
    }

    public static <T> a<T> a(Class<T> class_) {
        return a.b(class_);
    }

    public static <T extends Serializable> a<T> b(Class<T> class_) {
        return b.b(class_);
    }

    public static <T> T c(Class<T> class_) {
        return a.a(class_);
    }

    public static <T extends Serializable> T d(Class<T> class_) {
        return (T)((Serializable)b.a(class_));
    }
}

