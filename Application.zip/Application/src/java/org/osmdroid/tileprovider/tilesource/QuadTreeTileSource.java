/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuilder
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.ResourceProxy$string
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase
 *  org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
 */
package org.osmdroid.tileprovider.tilesource;

import org.osmdroid.ResourceProxy;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;

public class QuadTreeTileSource
extends OnlineTileSourceBase {
    public /* varargs */ QuadTreeTileSource(String string2, ResourceProxy.string string3, int n2, int n3, int n4, String string4, String ... arrstring) {
        super(string2, string3, n2, n3, n4, string4, arrstring);
    }

    public String getTileURLString(MapTile mapTile) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getBaseUrl());
        stringBuilder.append(this.quadTree(mapTile));
        stringBuilder.append(((BitmapTileSourceBase)this).mImageFilenameEnding);
        return stringBuilder.toString();
    }

    protected String quadTree(MapTile mapTile) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i2 = mapTile.getZoomLevel(); i2 > 0; --i2) {
            int n2 = 1 << i2 - 1;
            int n3 = n2 & mapTile.getX();
            int n4 = 0;
            if (n3 != 0) {
                n4 = 1;
            }
            if ((n2 & mapTile.getY()) != 0) {
                n4 += 2;
            }
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("");
            stringBuilder2.append(n4);
            stringBuilder.append(stringBuilder2.toString());
        }
        return stringBuilder.toString();
    }
}

