/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.simpleframework.xml.core.CacheParameter;
import org.simpleframework.xml.core.ClassInstantiator;
import org.simpleframework.xml.core.Comparer;
import org.simpleframework.xml.core.ConstructorException;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Creator;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.Instantiator;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.core.Parameter;
import org.simpleframework.xml.core.ParameterMap;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.Signature;
import org.simpleframework.xml.core.SignatureCreator;
import org.simpleframework.xml.core.Support;

class InstantiatorBuilder {
    private LabelMap attributes = new LabelMap();
    private Comparer comparer = new Comparer();
    private Detail detail;
    private LabelMap elements = new LabelMap();
    private Instantiator factory;
    private List<Creator> options = new ArrayList();
    private Scanner scanner;
    private LabelMap texts = new LabelMap();

    public InstantiatorBuilder(Scanner scanner, Detail detail) {
        this.scanner = scanner;
        this.detail = detail;
    }

    private Instantiator build(Detail detail) throws Exception {
        if (this.factory == null) {
            this.factory = this.create(detail);
        }
        return this.factory;
    }

    private boolean contains(String[] arrstring, String string2) throws Exception {
        for (String string3 : arrstring) {
            if (string3 == string2) {
                return true;
            }
            if (!string3.equals((Object)string2)) continue;
            return true;
        }
        return false;
    }

    private Creator create(Signature signature) {
        SignatureCreator signatureCreator = new SignatureCreator(signature);
        if (signature != null) {
            this.options.add((Object)signatureCreator);
        }
        return signatureCreator;
    }

    private Instantiator create(Detail detail) throws Exception {
        Signature signature = this.scanner.getSignature();
        ParameterMap parameterMap = this.scanner.getParameters();
        SignatureCreator signatureCreator = signature != null ? new SignatureCreator(signature) : null;
        return new ClassInstantiator(this.options, signatureCreator, parameterMap, detail);
    }

    private Parameter create(Parameter parameter) throws Exception {
        Label label = this.resolve(parameter);
        if (label != null) {
            return new CacheParameter(parameter, label);
        }
        return null;
    }

    private void populate(Detail detail) throws Exception {
        Iterator iterator = this.scanner.getSignatures().iterator();
        while (iterator.hasNext()) {
            this.populate((Signature)iterator.next());
        }
    }

    private void populate(Signature signature) throws Exception {
        Signature signature2 = new Signature(signature);
        Iterator<Parameter> iterator = signature.iterator();
        while (iterator.hasNext()) {
            Parameter parameter = this.create((Parameter)iterator.next());
            if (parameter == null) continue;
            signature2.add(parameter);
        }
        this.create(signature2);
    }

    private void register(Label label, LabelMap labelMap) throws Exception {
        String string2 = label.getName();
        String string3 = label.getPath();
        if (labelMap.containsKey((Object)string2)) {
            if (!((Label)labelMap.get((Object)string2)).getPath().equals((Object)string2)) {
                labelMap.remove((Object)string2);
            }
        } else {
            labelMap.put((Object)string2, (Object)label);
        }
        labelMap.put((Object)string3, (Object)label);
    }

    private Label resolve(Parameter parameter) throws Exception {
        if (parameter.isAttribute()) {
            return this.resolve(parameter, this.attributes);
        }
        if (parameter.isText()) {
            return this.resolve(parameter, this.texts);
        }
        return this.resolve(parameter, this.elements);
    }

    private Label resolve(Parameter parameter, LabelMap labelMap) throws Exception {
        String string2 = parameter.getName();
        Label label = (Label)labelMap.get((Object)parameter.getPath());
        if (label == null) {
            label = (Label)labelMap.get((Object)string2);
        }
        return label;
    }

    private void validate(Detail detail) throws Exception {
        for (Parameter parameter : this.scanner.getParameters().getAll()) {
            Label label = this.resolve(parameter);
            String string2 = parameter.getPath();
            if (label != null) {
                this.validateParameter(label, parameter);
                continue;
            }
            throw new ConstructorException("Parameter '%s' does not have a match in %s", string2, detail);
        }
        this.validateConstructors();
    }

    private void validateAnnotations(Label label, Parameter parameter) throws Exception {
        Annotation annotation = label.getAnnotation();
        Annotation annotation2 = parameter.getAnnotation();
        String string2 = parameter.getName();
        if (!this.comparer.equals(annotation, annotation2)) {
            Class class_;
            Class class_2 = annotation.annotationType();
            if (class_2.equals((Object)(class_ = annotation2.annotationType()))) {
                return;
            }
            throw new ConstructorException("Annotation %s does not match %s for '%s' in %s", new Object[]{class_, class_2, string2, parameter});
        }
    }

    private void validateConstructor(Label label, List<Creator> list) throws Exception {
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            Signature signature = ((Creator)iterator.next()).getSignature();
            Contact contact = label.getContact();
            Object object = label.getKey();
            if (!contact.isReadOnly() || signature.get(object) != null) continue;
            iterator.remove();
        }
    }

    private void validateConstructors() throws Exception {
        List<Creator> list = this.factory.getCreators();
        if (this.factory.isDefault()) {
            this.validateConstructors(this.elements);
            this.validateConstructors(this.attributes);
        }
        if (!list.isEmpty()) {
            this.validateConstructors(this.elements, list);
            this.validateConstructors(this.attributes, list);
        }
    }

    private void validateConstructors(LabelMap labelMap) throws Exception {
        for (Label label : labelMap) {
            if (label == null || !label.getContact().isReadOnly()) continue;
            Object[] arrobject = new Object[]{label, this.detail};
            throw new ConstructorException("Default constructor can not accept read only %s in %s", arrobject);
        }
    }

    private void validateConstructors(LabelMap labelMap, List<Creator> list) throws Exception {
        ConstructorException constructorException;
        for (Label label : labelMap) {
            if (label == null) continue;
            this.validateConstructor(label, list);
        }
        if (!list.isEmpty()) {
            return;
        }
        Object[] arrobject = new Object[]{this.detail};
        constructorException = new ConstructorException("No constructor accepts all read only values in %s", arrobject);
        throw constructorException;
    }

    private void validateNames(Label label, Parameter parameter) throws Exception {
        String string2;
        String string3;
        String[] arrstring = label.getNames();
        if (!this.contains(arrstring, string2 = parameter.getName()) && string2 != (string3 = label.getName())) {
            if (string2 != null && string3 != null) {
                if (string2.equals((Object)string3)) {
                    return;
                }
                throw new ConstructorException("Annotation does not match %s for '%s' in %s", label, string2, parameter);
            }
            throw new ConstructorException("Annotation does not match %s for '%s' in %s", label, string2, parameter);
        }
    }

    private void validateParameter(Label label, Parameter parameter) throws Exception {
        Contact contact = label.getContact();
        String string2 = parameter.getName();
        if (Support.isAssignable(parameter.getType(), contact.getType())) {
            this.validateNames(label, parameter);
            this.validateAnnotations(label, parameter);
            return;
        }
        throw new ConstructorException("Type is not compatible with %s for '%s' in %s", label, string2, parameter);
    }

    public Instantiator build() throws Exception {
        if (this.factory == null) {
            this.populate(this.detail);
            this.build(this.detail);
            this.validate(this.detail);
        }
        return this.factory;
    }

    public void register(Label label) throws Exception {
        if (label.isAttribute()) {
            this.register(label, this.attributes);
            return;
        }
        if (label.isText()) {
            this.register(label, this.texts);
            return;
        }
        this.register(label, this.elements);
    }
}

