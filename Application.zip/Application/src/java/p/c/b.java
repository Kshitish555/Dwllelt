/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.w0.o
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.i2.t.v
 *  o.c.a.d
 *  profile.dto.IdentificationItem
 */
package p.c;

import h.b.w0.o;
import java.util.List;
import kotlin.Metadata;
import kotlin.i2.t.v;
import o.c.a.d;
import p.c.b;
import profile.dto.IdentificationItem;

@Metadata(bv={1, 0, 3}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\u0018\u0000 \u00032\u00020\u0001:\u0001\u0003B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0004"}, d2={"Lprofile/utils/ContractToStatusImageMapper;", "", "()V", "Companion", "profile_release"}, k=1, mv={1, 1, 15})
public final class b {
    @d
    public static final String a = "https://static.qiwi.com/mobile/identification/android/icons/v1/anonymous";
    @d
    public static final String b = "https://static.qiwi.com/mobile/identification/android/icons/v1/ui";
    @d
    public static final String c = "https://static.qiwi.com/mobile/identification/android/icons/v1/ui";
    @d
    public static final String d = "https://static.qiwi.com/mobile/identification/android/icons/v1/pi";
    public static final a e = new a(null);

    @Metadata(bv={1, 0, 3}, d1={"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0018\u0010\b\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0004\u0012\u00020\u00040\tR\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2={"Lprofile/utils/ContractToStatusImageMapper$Companion;", "", "()V", "ANONIMOUS", "", "FULL", "SIMPLE", "VERIFIED", "getMapperFunction", "Lio/reactivex/functions/Function;", "", "Lprofile/dto/IdentificationItem;", "profile_release"}, k=1, mv={1, 1, 15})
    public static final class p.c.b$a {
        private p.c.b$a() {
        }

        public /* synthetic */ p.c.b$a(v v2) {
            this();
        }

        @d
        public final o<List<IdentificationItem>, String> a() {
            return a.c;
        }
    }

}

