/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

public final class BackoffStrategy
extends Enum<BackoffStrategy> {
    private static final /* synthetic */ BackoffStrategy[] $VALUES;
    public static final /* enum */ BackoffStrategy LONG_WAIT;
    public static final /* enum */ BackoffStrategy NO_WAIT;
    public static final /* enum */ BackoffStrategy SHORT_WAIT;
    public static final /* enum */ BackoffStrategy TEST_WAIT;
    double maxRange;
    long maxWait;
    long milliSecondMultiplier;
    double minRange;
    int minRetries;

    static {
        BackoffStrategy backoffStrategy;
        BackoffStrategy backoffStrategy2;
        BackoffStrategy backoffStrategy3;
        BackoffStrategy backoffStrategy4;
        LONG_WAIT = backoffStrategy = new BackoffStrategy(1, 120000L, 86400000L, 0.5, 1.0);
        SHORT_WAIT = backoffStrategy4 = new BackoffStrategy(1, 200L, 3600000L, 0.5, 1.0);
        TEST_WAIT = backoffStrategy3 = new BackoffStrategy(1, 200L, 1000L, 0.5, 1.0);
        NO_WAIT = backoffStrategy2 = new BackoffStrategy(100, 1L, 1000L, 1.0, 1.0);
        BackoffStrategy[] arrbackoffStrategy = new BackoffStrategy[]{LONG_WAIT, SHORT_WAIT, TEST_WAIT, backoffStrategy2};
        $VALUES = arrbackoffStrategy;
    }

    private BackoffStrategy(int n3, long l2, long l3, double d2, double d3) {
        this.minRetries = n3;
        this.milliSecondMultiplier = l2;
        this.maxWait = l3;
        this.minRange = d2;
        this.maxRange = d3;
    }

    public static BackoffStrategy valueOf(String string) {
        return (BackoffStrategy)Enum.valueOf(BackoffStrategy.class, (String)string);
    }

    public static BackoffStrategy[] values() {
        return (BackoffStrategy[])$VALUES.clone();
    }
}

