/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  android.text.TextUtils
 *  java.io.BufferedOutputStream
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.Closeable
 *  java.io.FileNotFoundException
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.UnknownHostException
 *  org.apache.http.HttpEntity
 *  org.apache.http.HttpResponse
 *  org.apache.http.StatusLine
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.DefaultHttpClient
 *  org.osmdroid.tileprovider.IMapTileProviderCallback
 *  org.osmdroid.tileprovider.MapTile
 *  org.osmdroid.tileprovider.MapTileRequestState
 *  org.osmdroid.tileprovider.modules.IFilesystemCache
 *  org.osmdroid.tileprovider.modules.INetworkAvailablityCheck
 *  org.osmdroid.tileprovider.modules.MapTileDownloader$1
 *  org.osmdroid.tileprovider.modules.MapTileModuleProviderBase$CantContinueException
 *  org.osmdroid.tileprovider.modules.MapTileModuleProviderBase$TileLoader
 *  org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase$LowMemoryException
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.tileprovider.util.StreamUtils
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.tileprovider.modules;

import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.osmdroid.tileprovider.IMapTileProviderCallback;
import org.osmdroid.tileprovider.MapTile;
import org.osmdroid.tileprovider.MapTileRequestState;
import org.osmdroid.tileprovider.modules.IFilesystemCache;
import org.osmdroid.tileprovider.modules.INetworkAvailablityCheck;
import org.osmdroid.tileprovider.modules.MapTileDownloader;
import org.osmdroid.tileprovider.modules.MapTileModuleProviderBase;
import org.osmdroid.tileprovider.tilesource.BitmapTileSourceBase;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.util.StreamUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MapTileDownloader
extends MapTileModuleProviderBase {
    private static final Logger logger = LoggerFactory.getLogger(MapTileDownloader.class);
    private final IFilesystemCache mFilesystemCache;
    private final INetworkAvailablityCheck mNetworkAvailablityCheck;
    private OnlineTileSourceBase mTileSource;

    public MapTileDownloader(ITileSource iTileSource) {
        this(iTileSource, null, null);
    }

    public MapTileDownloader(ITileSource iTileSource, IFilesystemCache iFilesystemCache) {
        this(iTileSource, iFilesystemCache, null);
    }

    public MapTileDownloader(ITileSource iTileSource, IFilesystemCache iFilesystemCache, INetworkAvailablityCheck iNetworkAvailablityCheck) {
        super(2, 40);
        this.mFilesystemCache = iFilesystemCache;
        this.mNetworkAvailablityCheck = iNetworkAvailablityCheck;
        this.setTileSource(iTileSource);
    }

    @Override
    public int getMaximumZoomLevel() {
        OnlineTileSourceBase onlineTileSourceBase = this.mTileSource;
        if (onlineTileSourceBase != null) {
            return onlineTileSourceBase.getMaximumZoomLevel();
        }
        return 22;
    }

    @Override
    public int getMinimumZoomLevel() {
        OnlineTileSourceBase onlineTileSourceBase = this.mTileSource;
        if (onlineTileSourceBase != null) {
            return onlineTileSourceBase.getMinimumZoomLevel();
        }
        return 0;
    }

    @Override
    protected String getName() {
        return "Online Tile Download Provider";
    }

    @Override
    protected String getThreadGroupName() {
        return "downloader";
    }

    @Override
    protected Runnable getTileLoader() {
        return new MapTileModuleProviderBase.TileLoader(this, null){
            final /* synthetic */ MapTileDownloader this$0;
            {
                this.this$0 = mapTileDownloader;
                super((MapTileModuleProviderBase)mapTileDownloader);
            }
            {
                this(mapTileDownloader);
            }

            /*
             * Loose catch block
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            public Drawable loadTile(MapTileRequestState mapTileRequestState) throws MapTileModuleProviderBase.CantContinueException {
                MapTile mapTile;
                UnknownHostException unknownHostException;
                block34 : {
                    InputStream inputStream;
                    BufferedOutputStream bufferedOutputStream;
                    block42 : {
                        InputStream inputStream2;
                        block35 : {
                            void var22_42;
                            block41 : {
                                InputStream inputStream3;
                                void var7_51;
                                block36 : {
                                    BitmapTileSourceBase.LowMemoryException lowMemoryException;
                                    block33 : {
                                        void var30_39;
                                        block40 : {
                                            block30 : {
                                                void var53_30;
                                                block32 : {
                                                    void var55_27;
                                                    block31 : {
                                                        Drawable drawable;
                                                        HttpEntity httpEntity;
                                                        block39 : {
                                                            block37 : {
                                                                HttpResponse httpResponse;
                                                                block38 : {
                                                                    String string2;
                                                                    boolean bl;
                                                                    OnlineTileSourceBase onlineTileSourceBase = this.this$0.mTileSource;
                                                                    inputStream = null;
                                                                    if (onlineTileSourceBase == null) {
                                                                        return null;
                                                                    }
                                                                    mapTile = mapTileRequestState.getMapTile();
                                                                    if (this.this$0.mNetworkAvailablityCheck != null && !(bl = this.this$0.mNetworkAvailablityCheck.getNetworkAvailable()) || TextUtils.isEmpty((CharSequence)(string2 = this.this$0.mTileSource.getTileURLString(mapTile)))) break block37;
                                                                    httpResponse = new DefaultHttpClient().execute((HttpUriRequest)new HttpGet(string2));
                                                                    StatusLine statusLine = httpResponse.getStatusLine();
                                                                    if (statusLine.getStatusCode() == 200) break block38;
                                                                    Logger logger = logger;
                                                                    StringBuilder stringBuilder = new StringBuilder();
                                                                    stringBuilder.append("Problem downloading MapTile: ");
                                                                    stringBuilder.append((Object)mapTile);
                                                                    stringBuilder.append(" HTTP response: ");
                                                                    stringBuilder.append((Object)statusLine);
                                                                    logger.warn(stringBuilder.toString());
                                                                    break block37;
                                                                }
                                                                httpEntity = httpResponse.getEntity();
                                                                if (httpEntity != null) break block39;
                                                                Logger logger = logger;
                                                                StringBuilder stringBuilder = new StringBuilder();
                                                                stringBuilder.append("No content downloading MapTile: ");
                                                                stringBuilder.append((Object)mapTile);
                                                                logger.warn(stringBuilder.toString());
                                                            }
                                                            StreamUtils.closeStream(null);
                                                            StreamUtils.closeStream(null);
                                                            return null;
                                                        }
                                                        inputStream3 = httpEntity.getContent();
                                                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                                                        bufferedOutputStream = new BufferedOutputStream((OutputStream)byteArrayOutputStream, 8192);
                                                        try {
                                                            StreamUtils.copy((InputStream)inputStream3, (OutputStream)bufferedOutputStream);
                                                            bufferedOutputStream.flush();
                                                            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
                                                            if (this.this$0.mFilesystemCache != null) {
                                                                this.this$0.mFilesystemCache.saveFile((ITileSource)this.this$0.mTileSource, mapTile, (InputStream)byteArrayInputStream);
                                                                byteArrayInputStream.reset();
                                                            }
                                                            drawable = this.this$0.mTileSource.getDrawable((InputStream)byteArrayInputStream);
                                                        }
                                                        catch (Throwable throwable) {
                                                            break block30;
                                                        }
                                                        catch (IOException iOException) {
                                                            break block31;
                                                        }
                                                        catch (FileNotFoundException fileNotFoundException) {
                                                            break block32;
                                                        }
                                                        catch (BitmapTileSourceBase.LowMemoryException lowMemoryException2) {
                                                            inputStream = inputStream3;
                                                            lowMemoryException = lowMemoryException2;
                                                            break block33;
                                                        }
                                                        catch (UnknownHostException unknownHostException2) {
                                                            inputStream = inputStream3;
                                                            unknownHostException = unknownHostException2;
                                                            break block34;
                                                        }
                                                        StreamUtils.closeStream((Closeable)inputStream3);
                                                        StreamUtils.closeStream((Closeable)bufferedOutputStream);
                                                        return drawable;
                                                        catch (Throwable throwable) {
                                                            bufferedOutputStream = null;
                                                            break block30;
                                                        }
                                                        catch (IOException iOException) {
                                                            bufferedOutputStream = null;
                                                        }
                                                    }
                                                    void var56_37 = var55_27;
                                                    inputStream2 = inputStream3;
                                                    var30_39 = var56_37;
                                                    break block40;
                                                    catch (FileNotFoundException fileNotFoundException) {
                                                        bufferedOutputStream = null;
                                                    }
                                                }
                                                void var54_41 = var53_30;
                                                inputStream2 = inputStream3;
                                                var22_42 = var54_41;
                                                break block41;
                                                catch (BitmapTileSourceBase.LowMemoryException lowMemoryException3) {
                                                    inputStream = inputStream3;
                                                    lowMemoryException = lowMemoryException3;
                                                    bufferedOutputStream = null;
                                                    break block33;
                                                }
                                                catch (UnknownHostException unknownHostException3) {
                                                    inputStream = inputStream3;
                                                    unknownHostException = unknownHostException3;
                                                    Object var6_17 = null;
                                                    break block34;
                                                }
                                                catch (Throwable throwable) {
                                                    inputStream3 = null;
                                                    bufferedOutputStream = null;
                                                }
                                            }
                                            try {
                                                void var37_24;
                                                Logger logger = logger;
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append("Error downloading MapTile: ");
                                                stringBuilder.append((Object)mapTile);
                                                logger.error(stringBuilder.toString(), (Throwable)var37_24);
                                            }
                                            catch (Throwable throwable) {}
                                            StreamUtils.closeStream(inputStream3);
                                            break block42;
                                            break block36;
                                            catch (IOException iOException) {
                                                inputStream2 = null;
                                                bufferedOutputStream = null;
                                            }
                                        }
                                        try {
                                            Logger logger = logger;
                                            StringBuilder stringBuilder = new StringBuilder();
                                            stringBuilder.append("IOException downloading MapTile: ");
                                            stringBuilder.append((Object)mapTile);
                                            stringBuilder.append(" : ");
                                            stringBuilder.append((Object)var30_39);
                                            logger.warn(stringBuilder.toString());
                                            break block35;
                                        }
                                        catch (Throwable throwable) {
                                            inputStream3 = inputStream2;
                                            break block36;
                                        }
                                        catch (BitmapTileSourceBase.LowMemoryException lowMemoryException4) {
                                            bufferedOutputStream = null;
                                        }
                                    }
                                    try {
                                        Logger logger = logger;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("LowMemoryException downloading MapTile: ");
                                        stringBuilder.append((Object)mapTile);
                                        stringBuilder.append(" : ");
                                        stringBuilder.append((Object)lowMemoryException);
                                        logger.warn(stringBuilder.toString());
                                        throw new /* Unavailable Anonymous Inner Class!! */;
                                    }
                                    catch (Throwable throwable) {
                                        inputStream3 = inputStream;
                                    }
                                }
                                StreamUtils.closeStream(inputStream3);
                                StreamUtils.closeStream(bufferedOutputStream);
                                throw var7_51;
                                catch (FileNotFoundException fileNotFoundException) {
                                    inputStream2 = null;
                                    bufferedOutputStream = null;
                                }
                            }
                            Logger logger = logger;
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Tile not found: ");
                            stringBuilder.append((Object)mapTile);
                            stringBuilder.append(" : ");
                            stringBuilder.append((Object)var22_42);
                            logger.warn(stringBuilder.toString());
                        }
                        StreamUtils.closeStream(inputStream2);
                    }
                    StreamUtils.closeStream(bufferedOutputStream);
                    return null;
                    catch (UnknownHostException unknownHostException4) {
                        inputStream = null;
                        Object var6_18 = null;
                    }
                }
                Logger logger = logger;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("UnknownHostException downloading MapTile: ");
                stringBuilder.append((Object)mapTile);
                stringBuilder.append(" : ");
                stringBuilder.append((Object)unknownHostException);
                logger.warn(stringBuilder.toString());
                throw new /* Unavailable Anonymous Inner Class!! */;
            }

            protected void tileLoaded(MapTileRequestState mapTileRequestState, Drawable drawable) {
                this.this$0.removeTileFromQueues(mapTileRequestState.getMapTile());
                mapTileRequestState.getCallback().mapTileRequestCompleted(mapTileRequestState, null);
            }
        };
    }

    public ITileSource getTileSource() {
        return this.mTileSource;
    }

    @Override
    public boolean getUsesDataConnection() {
        return true;
    }

    @Override
    public void setTileSource(ITileSource iTileSource) {
        if (iTileSource instanceof OnlineTileSourceBase) {
            this.mTileSource = (OnlineTileSourceBase)iTileSource;
            return;
        }
        this.mTileSource = null;
    }

}

