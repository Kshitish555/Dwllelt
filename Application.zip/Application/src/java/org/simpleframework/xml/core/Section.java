/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;

interface Section
extends Iterable<String> {
    public String getAttribute(String var1) throws Exception;

    public LabelMap getAttributes() throws Exception;

    public Label getElement(String var1) throws Exception;

    public LabelMap getElements() throws Exception;

    public String getName();

    public String getPath(String var1) throws Exception;

    public String getPrefix();

    public Section getSection(String var1) throws Exception;

    public Label getText() throws Exception;

    public boolean isSection(String var1) throws Exception;
}

