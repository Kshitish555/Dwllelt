/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package org.mockito.internal.exceptions;

public class a {
    public static final String a = "Mocking methods declared on non-public parent classes is not supported.";
}

