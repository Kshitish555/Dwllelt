/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Method
 *  org.simpleframework.xml.core.MethodName
 *  org.simpleframework.xml.core.MethodPart
 *  org.simpleframework.xml.core.MethodType
 *  org.simpleframework.xml.core.Reflector
 *  org.simpleframework.xml.util.Cache
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import org.simpleframework.xml.core.MethodName;
import org.simpleframework.xml.core.MethodPart;
import org.simpleframework.xml.core.MethodType;
import org.simpleframework.xml.core.Reflector;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.ConcurrentCache;

class GetPart
implements MethodPart {
    private final Cache<Annotation> cache = new ConcurrentCache<Annotation>();
    private final Annotation label;
    private final Annotation[] list;
    private final Method method;
    private final String name;
    private final MethodType type;

    public GetPart(MethodName methodName, Annotation annotation, Annotation[] arrannotation) {
        this.method = methodName.getMethod();
        this.name = methodName.getName();
        this.type = methodName.getType();
        this.label = annotation;
        this.list = arrannotation;
    }

    public Annotation getAnnotation() {
        return this.label;
    }

    public <T extends Annotation> T getAnnotation(Class<T> class_) {
        if (this.cache.isEmpty()) {
            for (Annotation annotation : this.list) {
                Class class_2 = annotation.annotationType();
                this.cache.cache((Object)class_2, (Object)annotation);
            }
        }
        return (T)((Annotation)this.cache.fetch(class_));
    }

    public Class getDeclaringClass() {
        return this.method.getDeclaringClass();
    }

    public Class getDependent() {
        return Reflector.getReturnDependent((Method)this.method);
    }

    public Class[] getDependents() {
        return Reflector.getReturnDependents((Method)this.method);
    }

    public Method getMethod() {
        if (!this.method.isAccessible()) {
            this.method.setAccessible(true);
        }
        return this.method;
    }

    public MethodType getMethodType() {
        return this.type;
    }

    public String getName() {
        return this.name;
    }

    public Class getType() {
        return this.method.getReturnType();
    }

    public String toString() {
        return this.method.toGenericString();
    }
}

