/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Array
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Factory
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.strategy.Value
 *  org.simpleframework.xml.stream.Position
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Array;
import org.simpleframework.xml.core.ArrayInstance;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.ElementException;
import org.simpleframework.xml.core.Factory;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.InstantiationException;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.Position;

class ArrayFactory
extends Factory {
    public ArrayFactory(Context context, Type type) {
        super(context, type);
    }

    private Class getComponentType() throws Exception {
        Class class_ = this.getType();
        if (class_.isArray()) {
            return class_.getComponentType();
        }
        Object[] arrobject = new Object[]{class_, this.type};
        throw new InstantiationException("The %s not an array for %s", arrobject);
    }

    private Instance getInstance(Value value, Class class_) throws Exception {
        Class class_2 = this.getComponentType();
        if (class_2.isAssignableFrom(class_)) {
            return new ArrayInstance(value);
        }
        Object[] arrobject = new Object[]{class_2, class_, this.type};
        throw new InstantiationException("Array of type %s cannot hold %s for %s", arrobject);
    }

    public Object getInstance() throws Exception {
        Class class_ = this.getComponentType();
        if (class_ != null) {
            return Array.newInstance((Class)class_, (int)0);
        }
        return null;
    }

    public Instance getInstance(InputNode inputNode) throws Exception {
        Position position = inputNode.getPosition();
        Value value = this.getOverride(inputNode);
        if (value != null) {
            return this.getInstance(value, value.getType());
        }
        Object[] arrobject = new Object[]{this.type, position};
        throw new ElementException("Array length required for %s at %s", arrobject);
    }
}

