/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  java.lang.Object
 *  java.lang.Runnable
 *  org.osmdroid.events.DelayedMapListener$CallbackTask
 *  org.osmdroid.events.MapEvent
 *  org.osmdroid.events.MapListener
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package org.osmdroid.events;

import android.os.Handler;
import org.osmdroid.events.DelayedMapListener;
import org.osmdroid.events.MapEvent;
import org.osmdroid.events.MapListener;
import org.osmdroid.events.ScrollEvent;
import org.osmdroid.events.ZoomEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Exception performing whole class analysis.
 */
public class DelayedMapListener
implements MapListener {
    protected static final int DEFAULT_DELAY = 100;
    private static final Logger logger;
    protected CallbackTask callback;
    protected long delay;
    protected Handler handler;
    MapListener wrappedListener;

    static {
        logger = LoggerFactory.getLogger(DelayedMapListener.class);
    }

    public DelayedMapListener(MapListener mapListener) {
        this(mapListener, 100L);
    }

    public DelayedMapListener(MapListener mapListener, long l) {
        this.wrappedListener = mapListener;
        this.delay = l;
        this.handler = new Handler();
        this.callback = null;
    }

    static /* synthetic */ Logger access$000() {
        return logger;
    }

    protected void dispatch(MapEvent mapEvent) {
        CallbackTask callbackTask;
        CallbackTask callbackTask2 = this.callback;
        if (callbackTask2 != null) {
            this.handler.removeCallbacks((Runnable)callbackTask2);
        }
        this.callback = callbackTask = new /* Unavailable Anonymous Inner Class!! */;
        this.handler.postDelayed((Runnable)callbackTask, this.delay);
    }

    public boolean onScroll(ScrollEvent scrollEvent) {
        this.dispatch(scrollEvent);
        return true;
    }

    public boolean onZoom(ZoomEvent zoomEvent) {
        this.dispatch(zoomEvent);
        return true;
    }
}

