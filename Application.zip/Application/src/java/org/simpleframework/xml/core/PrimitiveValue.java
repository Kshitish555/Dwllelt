/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Entry
 *  org.simpleframework.xml.core.PersistenceException
 *  org.simpleframework.xml.strategy.Type
 *  org.simpleframework.xml.stream.Style
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Entry;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.Primitive;
import org.simpleframework.xml.core.PrimitiveFactory;
import org.simpleframework.xml.strategy.Type;
import org.simpleframework.xml.stream.InputNode;
import org.simpleframework.xml.stream.OutputNode;
import org.simpleframework.xml.stream.Style;

class PrimitiveValue
implements Converter {
    private final Context context;
    private final Entry entry;
    private final PrimitiveFactory factory;
    private final Primitive root;
    private final Style style;
    private final Type type;

    public PrimitiveValue(Context context, Entry entry, Type type) {
        this.factory = new PrimitiveFactory(context, type);
        this.root = new Primitive(context, type);
        this.style = context.getStyle();
        this.context = context;
        this.entry = entry;
        this.type = type;
    }

    private boolean isOverridden(OutputNode outputNode, Object object) throws Exception {
        return this.factory.setOverride(this.type, object, outputNode);
    }

    private Object readAttribute(InputNode inputNode, String string2) throws Exception {
        if (string2 != null) {
            inputNode = inputNode.getAttribute(this.style.getAttribute(string2));
        }
        if (inputNode == null) {
            return null;
        }
        return this.root.read(inputNode);
    }

    private Object readElement(InputNode inputNode, String string2) throws Exception {
        InputNode inputNode2 = inputNode.getNext(this.style.getAttribute(string2));
        if (inputNode2 == null) {
            return null;
        }
        return this.root.read(inputNode2);
    }

    private boolean validateAttribute(InputNode inputNode, String string2) throws Exception {
        if (string2 != null) {
            inputNode = inputNode.getNext(this.style.getAttribute(string2));
        }
        if (inputNode == null) {
            return true;
        }
        return this.root.validate(inputNode);
    }

    private boolean validateElement(InputNode inputNode, String string2) throws Exception {
        if (inputNode.getNext(this.style.getAttribute(string2)) == null) {
            return true;
        }
        return this.root.validate(inputNode);
    }

    private void writeAttribute(OutputNode outputNode, Object object, String string2) throws Exception {
        if (object != null) {
            if (string2 != null) {
                outputNode = outputNode.setAttribute(this.style.getAttribute(string2), null);
            }
            this.root.write(outputNode, object);
        }
    }

    private void writeElement(OutputNode outputNode, Object object, String string2) throws Exception {
        OutputNode outputNode2 = outputNode.getChild(this.style.getAttribute(string2));
        if (object != null && !this.isOverridden(outputNode2, object)) {
            this.root.write(outputNode2, object);
        }
    }

    public Object read(InputNode inputNode) throws Exception {
        Class class_ = this.type.getType();
        String string2 = this.entry.getValue();
        if (!this.entry.isInline()) {
            if (string2 == null) {
                string2 = this.context.getName(class_);
            }
            return this.readElement(inputNode, string2);
        }
        return this.readAttribute(inputNode, string2);
    }

    public Object read(InputNode inputNode, Object object) throws Exception {
        Class class_ = this.type.getType();
        if (object == null) {
            return this.read(inputNode);
        }
        Object[] arrobject = new Object[]{class_, this.entry};
        throw new PersistenceException("Can not read value of %s for %s", arrobject);
    }

    public boolean validate(InputNode inputNode) throws Exception {
        Class class_ = this.type.getType();
        String string2 = this.entry.getValue();
        if (!this.entry.isInline()) {
            if (string2 == null) {
                string2 = this.context.getName(class_);
            }
            return this.validateElement(inputNode, string2);
        }
        return this.validateAttribute(inputNode, string2);
    }

    public void write(OutputNode outputNode, Object object) throws Exception {
        Class class_ = this.type.getType();
        String string2 = this.entry.getValue();
        if (!this.entry.isInline()) {
            if (string2 == null) {
                string2 = this.context.getName(class_);
            }
            this.writeElement(outputNode, object, string2);
            return;
        }
        this.writeAttribute(outputNode, object, string2);
    }
}

