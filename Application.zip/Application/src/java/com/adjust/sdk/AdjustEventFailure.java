/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.json.JSONObject
 */
package com.adjust.sdk;

import com.adjust.sdk.Util;
import org.json.JSONObject;

public class AdjustEventFailure {
    public String adid;
    public String callbackId;
    public String eventToken;
    public JSONObject jsonResponse;
    public String message;
    public String timestamp;
    public boolean willRetry;

    public String toString() {
        Object[] arrobject = new Object[]{this.message, this.timestamp, this.adid, this.eventToken, this.callbackId, this.willRetry, this.jsonResponse};
        return Util.formatString("Event Failure msg:%s time:%s adid:%s event:%s cid:%s retry:%b json:%s", arrobject);
    }
}

