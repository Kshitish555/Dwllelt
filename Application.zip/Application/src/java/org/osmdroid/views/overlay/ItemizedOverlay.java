/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Point
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  org.osmdroid.ResourceProxy
 *  org.osmdroid.api.IGeoPoint
 *  org.osmdroid.api.IProjection
 *  org.osmdroid.views.overlay.ItemizedOverlay$1
 *  org.osmdroid.views.overlay.Overlay$Snappable
 *  org.osmdroid.views.overlay.OverlayItem
 *  org.osmdroid.views.overlay.OverlayItem$HotspotPlace
 */
package org.osmdroid.views.overlay;

import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import org.osmdroid.ResourceProxy;
import org.osmdroid.api.IGeoPoint;
import org.osmdroid.api.IProjection;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.ItemizedOverlay;
import org.osmdroid.views.overlay.Overlay;
import org.osmdroid.views.overlay.OverlayItem;

public abstract class ItemizedOverlay<Item extends OverlayItem>
extends Overlay
implements Overlay.Snappable {
    private final Point mCurScreenCoords = new Point();
    protected final Drawable mDefaultMarker;
    protected boolean mDrawFocusedItem = true;
    private Item mFocusedItem;
    private final ArrayList<Item> mInternalItemList;
    private final Rect mRect = new Rect();

    public ItemizedOverlay(Drawable drawable, ResourceProxy resourceProxy) {
        super(resourceProxy);
        if (drawable != null) {
            this.mDefaultMarker = drawable;
            this.mInternalItemList = new ArrayList();
            return;
        }
        throw new IllegalArgumentException("You must pass a default marker to ItemizedOverlay.");
    }

    private Drawable getDefaultMarker(int n2) {
        OverlayItem.setState((Drawable)this.mDefaultMarker, (int)n2);
        return this.mDefaultMarker;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    protected Drawable boundToHotspot(Drawable drawable, OverlayItem.HotspotPlace hotspotPlace) {
        ItemizedOverlay itemizedOverlay = this;
        synchronized (itemizedOverlay) {
            int n2 = (int)((float)drawable.getIntrinsicWidth() * this.mScale);
            int n3 = (int)((float)drawable.getIntrinsicHeight() * this.mScale);
            this.mRect.set(0, 0, n2 + 0, n3 + 0);
            if (hotspotPlace == null) {
                hotspotPlace = OverlayItem.HotspotPlace.BOTTOM_CENTER;
            }
            switch (1.$SwitchMap$org$osmdroid$views$overlay$OverlayItem$HotspotPlace[hotspotPlace.ordinal()]) {
                case 10: {
                    this.mRect.offset(0, -n3);
                    break;
                }
                case 9: {
                    this.mRect.offset(0, 0);
                    break;
                }
                case 8: {
                    this.mRect.offset(-n2, -n3);
                    break;
                }
                case 7: {
                    this.mRect.offset(-n2, 0);
                    break;
                }
                case 6: {
                    this.mRect.offset(0, -n3 / 2);
                    break;
                }
                case 5: {
                    this.mRect.offset(-n2, -n3 / 2);
                    break;
                }
                case 4: {
                    this.mRect.offset(-n2 / 2, 0);
                    break;
                }
                case 3: {
                    this.mRect.offset(-n2 / 2, -n3);
                    break;
                }
                case 2: {
                    this.mRect.offset(-n2 / 2, -n3 / 2);
                    break;
                }
            }
            drawable.setBounds(this.mRect);
            return drawable;
        }
    }

    protected abstract Item createItem(int var1);

    @Override
    public void draw(Canvas canvas, MapView mapView, boolean bl) {
        if (bl) {
            return;
        }
        IProjection iProjection = mapView.getProjection();
        for (int i2 = -1 + this.mInternalItemList.size(); i2 >= 0; --i2) {
            Item Item = this.getItem(i2);
            iProjection.toMapPixels(((OverlayItem)Item).mGeoPoint, this.mCurScreenCoords);
            this.onDrawItem(canvas, Item, this.mCurScreenCoords);
        }
    }

    public Item getFocus() {
        return this.mFocusedItem;
    }

    public final Item getItem(int n2) {
        return (Item)((OverlayItem)this.mInternalItemList.get(n2));
    }

    protected boolean hitTest(Item Item, Drawable drawable, int n2, int n3) {
        return drawable.getBounds().contains(n2, n3);
    }

    protected void onDrawItem(Canvas canvas, Item Item, Point point) {
        int n2 = this.mDrawFocusedItem && this.mFocusedItem == Item ? 4 : 0;
        Drawable drawable = Item.getMarker(n2) == null ? this.getDefaultMarker(n2) : Item.getMarker(n2);
        this.boundToHotspot(drawable, Item.getMarkerHotspot());
        Overlay.drawAt(canvas, drawable, point.x, point.y, false);
    }

    protected final void populate() {
        int n2 = this.size();
        this.mInternalItemList.clear();
        this.mInternalItemList.ensureCapacity(n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            this.mInternalItemList.add(this.createItem(i2));
        }
    }

    public void setDrawFocusedItem(boolean bl) {
        this.mDrawFocusedItem = bl;
    }

    public void setFocus(Item Item) {
        this.mFocusedItem = Item;
    }

    public abstract int size();
}

