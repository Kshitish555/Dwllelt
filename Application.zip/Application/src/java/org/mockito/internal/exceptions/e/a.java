/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.List
 *  o.e.z.d
 *  org.mockito.internal.exceptions.c
 */
package org.mockito.internal.exceptions.e;

import java.util.List;
import o.e.z.d;
import org.mockito.internal.exceptions.c;

public class a {
    public String a(List<c> list) {
        if (list.size() == 1) {
            return "Actually, above is the only interaction with this mock.";
        }
        StringBuilder stringBuilder = new StringBuilder("***\nFor your reference, here is the list of all invocations ([?] - means unverified).\n");
        int n2 = 0;
        for (c c2 : list) {
            stringBuilder.append(++n2);
            stringBuilder.append(". ");
            if (!c2.H()) {
                stringBuilder.append("[?]");
            }
            stringBuilder.append((Object)c2.getLocation());
            stringBuilder.append("\n");
        }
        return stringBuilder.toString();
    }
}

