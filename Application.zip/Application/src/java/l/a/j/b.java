/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  l.a.h.i.a
 *  l.a.h.k.c
 *  l.a.h.k.c$d
 *  l.a.j.b$a
 *  l.a.j.e$g
 *  l.a.j.q.b
 *  l.a.j.q.b$c
 *  l.a.j.q.e
 *  l.a.j.q.e$a
 *  l.a.j.q.e$c
 *  l.a.k.a.r
 */
package l.a.j;

import l.a.h.k.c;
import l.a.i.i.c;
import l.a.j.b;
import l.a.j.e;
import l.a.j.q.b;
import l.a.j.q.e;
import l.a.j.q.g;
import l.a.k.a.r;

public class b
implements l.a.j.e,
l.a.j.q.b {
    private final l.a.h.k.c c;
    private final a d;

    public b(l.a.h.k.c c2, a a2) {
        this.c = c2;
        this.d = a2;
    }

    public static l.a.j.e a(Class<? extends Throwable> class_, String string) {
        return b.a((l.a.h.k.c)new c.d(class_), string);
    }

    public static l.a.j.e a(l.a.h.k.c c2, String string) {
        if (c2.c(Throwable.class)) {
            return new b(c2, new b(c2, string));
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((Object)c2);
        stringBuilder.append(" does not extend throwable");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static l.a.j.e b(Class<? extends Throwable> class_) {
        return b.c((l.a.h.k.c)new c.d(class_));
    }

    public static l.a.j.e c(l.a.h.k.c c2) {
        if (c2.c(Throwable.class)) {
            return new b(c2, new a(c2));
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append((Object)c2);
        stringBuilder.append(" does not extend throwable");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public c a(c c2) {
        return c2;
    }

    public b.c a(r r2, e.d d2, l.a.h.i.a a2) {
        e[] arre = new e[]{this.d.a(), g.c};
        return new b.c(new e.a(arre).a(r2, d2).a(), a2.l());
    }

    @Override
    public l.a.j.q.b a(e.g g2) {
        return this;
    }

    protected boolean a(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (!b2.a(this)) {
            return false;
        }
        l.a.h.k.c c2 = this.c;
        l.a.h.k.c c3 = b2.c;
        if (c2 == null ? c3 != null : !c2.equals((Object)c3)) {
            return false;
        }
        a a2 = this.d;
        a a3 = b2.d;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public int hashCode() {
        l.a.h.k.c c2 = this.c;
        int n2 = 43;
        int n3 = c2 == null ? 43 : c2.hashCode();
        int n4 = n3 + 59;
        a a2 = this.d;
        int n5 = n4 * 59;
        if (a2 != null) {
            n2 = a2.hashCode();
        }
        return n5 + n2;
    }
}

