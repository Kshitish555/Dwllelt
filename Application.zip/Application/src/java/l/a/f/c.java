/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  edu.umd.cs.findbugs.annotations.SuppressFBWarnings
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  l.a.b
 *  l.a.f.b
 *  l.a.h.h.a
 *  l.a.h.h.a$c
 *  l.a.h.h.b
 *  l.a.h.i.b
 *  l.a.h.k.c
 *  l.a.k.a.f
 *  l.a.k.a.r
 *  l.a.k.a.u
 *  l.a.m.a
 */
package l.a.f;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import l.a.f.b;
import l.a.h.h.a;
import l.a.j.e;
import l.a.k.a.f;
import l.a.k.a.r;
import l.a.k.a.u;

public final class c
extends Enum<c>
implements b {
    public static final /* enum */ c c;
    private static final /* synthetic */ c[] d;

    static {
        c c2;
        c = c2 = new c();
        d = new c[]{c2};
    }

    public static c valueOf(String string) {
        return (c)Enum.valueOf(c.class, (String)string);
    }

    public static c[] values() {
        return (c[])d.clone();
    }

    public int a(int n2) {
        return n2;
    }

    public f a(l.a.h.k.c c2, f f2, e.d d2, l.a.m.a a2, l.a.h.h.b<a.c> b2, l.a.h.i.b<?> b3, int n2, int n3) {
        return new a(f2);
    }

    public int b(int n2) {
        return n2;
    }

    protected static class l.a.f.c$a
    extends f {
        private boolean f;

        protected l.a.f.c$a(f f2) {
            super(327680, f2);
        }

        public r a(int n2, String string, String string2, String string3, String[] arrstring) {
            if (this.f) {
                return super.a(n2, string, string2, string3, arrstring);
            }
            return new a(super.a(n2, string, string2, string3, arrstring));
        }

        public void a(int n2, int n3, String string, String string2, String string3, String[] arrstring) {
            this.f = l.a.b.b((int)n2).b(l.a.b.t);
            super.a(n2, n3, string, string2, string3, arrstring);
        }

        protected static class a
        extends r {
            private static final String f = "java/lang/Class";
            private static final String h = "forName";
            private static final String o = "(Ljava/lang/String;)Ljava/lang/Class;";

            protected a(r r2) {
                super(327680, r2);
            }

            @SuppressFBWarnings(justification="Fall through to default case is intentional", value={"SF_SWITCH_NO_DEFAULT"})
            public void a(Object object) {
                int n2;
                u u2;
                if (object instanceof u && ((n2 = (u2 = (u)object).j()) == 9 || n2 == 10)) {
                    super.a((Object)u2.g().replace('/', '.'));
                    super.a(184, f, h, o, false);
                    return;
                }
                super.a(object);
            }
        }

    }

}

