/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package org.simpleframework.xml.core;

import java.lang.reflect.Method;
import org.simpleframework.xml.core.MethodType;

class MethodName {
    private Method method;
    private String name;
    private MethodType type;

    public MethodName(Method method, MethodType methodType, String string2) {
        this.method = method;
        this.type = methodType;
        this.name = string2;
    }

    public Method getMethod() {
        return this.method;
    }

    public String getName() {
        return this.name;
    }

    public MethodType getType() {
        return this.type;
    }
}

