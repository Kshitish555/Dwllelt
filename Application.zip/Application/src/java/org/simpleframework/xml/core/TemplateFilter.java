/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.filter.Filter
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.filter.Filter;

class TemplateFilter
implements Filter {
    private Context context;
    private Filter filter;

    public TemplateFilter(Context context, Filter filter) {
        this.context = context;
        this.filter = filter;
    }

    public String replace(String string2) {
        Object object = this.context.getAttribute((Object)string2);
        if (object != null) {
            return object.toString();
        }
        return this.filter.replace(string2);
    }
}

