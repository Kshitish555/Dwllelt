/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  l.a.h.k.c
 *  l.a.h.k.d
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 *  l.a.n.b
 *  l.a.n.b$b
 */
package l.a.j.q.l;

import l.a.h.k.c;
import l.a.h.k.d;
import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;
import l.a.n.b;

public class b
implements e {
    private static final String d = "java/lang/invoke/MethodHandle";
    private static final String f = "invokeExact";
    private final b.b c;

    public b(b.b b2) {
        this.c = b2;
    }

    public e.c a(r r2, e.d d2) {
        r2.a(182, d, f, this.c.c(), false);
        int n2 = this.c.e().l().c() - this.c.d().l();
        return new e.c(n2, Math.max((int)n2, (int)0));
    }

    protected boolean b(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (!b2.b(this)) {
            return false;
        }
        b.b b3 = this.c;
        b.b b4 = b2.c;
        return !(b3 == null ? b4 != null : !b3.equals((Object)b4));
    }

    public int hashCode() {
        b.b b2 = this.c;
        int n2 = b2 == null ? 43 : b2.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }
}

