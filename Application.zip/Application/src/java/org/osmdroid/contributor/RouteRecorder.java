/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.location.Location
 *  java.lang.Object
 *  java.lang.System
 *  java.util.ArrayList
 */
package org.osmdroid.contributor;

import android.location.Location;
import java.util.ArrayList;
import org.osmdroid.contributor.util.RecordedGeoPoint;
import org.osmdroid.util.GeoPoint;

public class RouteRecorder {
    protected final ArrayList<RecordedGeoPoint> mRecords = new ArrayList();

    public void add(Location location, int n2) {
        ArrayList<RecordedGeoPoint> arrayList = this.mRecords;
        RecordedGeoPoint recordedGeoPoint = new RecordedGeoPoint((int)(1000000.0 * location.getLatitude()), (int)(1000000.0 * location.getLongitude()), System.currentTimeMillis(), n2);
        arrayList.add((Object)recordedGeoPoint);
    }

    public void add(GeoPoint geoPoint, int n2) {
        ArrayList<RecordedGeoPoint> arrayList = this.mRecords;
        RecordedGeoPoint recordedGeoPoint = new RecordedGeoPoint(geoPoint.getLatitudeE6(), geoPoint.getLongitudeE6(), System.currentTimeMillis(), n2);
        arrayList.add((Object)recordedGeoPoint);
    }

    public ArrayList<RecordedGeoPoint> getRecordedGeoPoints() {
        return this.mRecords;
    }
}

