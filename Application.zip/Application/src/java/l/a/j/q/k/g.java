/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  l.a.j.q.e
 *  l.a.j.q.e$c
 *  l.a.j.q.f
 *  l.a.k.a.r
 *  l.a.n.b
 */
package l.a.j.q.k;

import l.a.j.e;
import l.a.j.q.e;
import l.a.j.q.f;
import l.a.k.a.r;
import l.a.n.b;

public class g
implements e {
    private final b c;

    public g(b b2) {
        this.c = b2;
    }

    public e.c a(r r2, e.d d2) {
        r2.a(this.c.a());
        return f.f.f();
    }

    protected boolean b(Object object) {
        return object instanceof g;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof g)) {
            return false;
        }
        g g2 = (g)object;
        if (!g2.b(this)) {
            return false;
        }
        b b2 = this.c;
        b b3 = g2.c;
        return !(b2 == null ? b3 != null : !b2.equals((Object)b3));
    }

    public int hashCode() {
        b b2 = this.c;
        int n2 = b2 == null ? 43 : b2.hashCode();
        return 59 + n2;
    }

    public boolean x() {
        return true;
    }
}

