/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.util.List
 *  org.osmdroid.tileprovider.IMapTileProviderCallback
 *  org.osmdroid.tileprovider.IRegisterReceiver
 *  org.osmdroid.tileprovider.MapTileProviderArray
 *  org.osmdroid.tileprovider.modules.IFilesystemCache
 *  org.osmdroid.tileprovider.modules.INetworkAvailablityCheck
 *  org.osmdroid.tileprovider.modules.MapTileDownloader
 *  org.osmdroid.tileprovider.modules.NetworkAvailabliltyCheck
 *  org.osmdroid.tileprovider.modules.TileWriter
 *  org.osmdroid.tileprovider.tilesource.ITileSource
 *  org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
 *  org.osmdroid.tileprovider.tilesource.TileSourceFactory
 *  org.osmdroid.tileprovider.util.SimpleRegisterReceiver
 */
package org.osmdroid.tileprovider;

import android.content.Context;
import java.util.List;
import org.osmdroid.tileprovider.IMapTileProviderCallback;
import org.osmdroid.tileprovider.IRegisterReceiver;
import org.osmdroid.tileprovider.MapTileProviderArray;
import org.osmdroid.tileprovider.modules.IFilesystemCache;
import org.osmdroid.tileprovider.modules.INetworkAvailablityCheck;
import org.osmdroid.tileprovider.modules.MapTileDownloader;
import org.osmdroid.tileprovider.modules.MapTileFileArchiveProvider;
import org.osmdroid.tileprovider.modules.MapTileFilesystemProvider;
import org.osmdroid.tileprovider.modules.NetworkAvailabliltyCheck;
import org.osmdroid.tileprovider.modules.TileWriter;
import org.osmdroid.tileprovider.tilesource.ITileSource;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.tileprovider.util.SimpleRegisterReceiver;

public class MapTileProviderBasic
extends MapTileProviderArray
implements IMapTileProviderCallback {
    public MapTileProviderBasic(Context context) {
        this(context, (ITileSource)TileSourceFactory.DEFAULT_TILE_SOURCE);
    }

    public MapTileProviderBasic(Context context, ITileSource iTileSource) {
        this((IRegisterReceiver)new SimpleRegisterReceiver(context), (INetworkAvailablityCheck)new NetworkAvailabliltyCheck(context), iTileSource);
    }

    public MapTileProviderBasic(IRegisterReceiver iRegisterReceiver, INetworkAvailablityCheck iNetworkAvailablityCheck, ITileSource iTileSource) {
        super(iTileSource, iRegisterReceiver);
        TileWriter tileWriter = new TileWriter();
        MapTileFilesystemProvider mapTileFilesystemProvider = new MapTileFilesystemProvider(iRegisterReceiver, iTileSource);
        this.mTileProviderList.add((Object)mapTileFilesystemProvider);
        MapTileFileArchiveProvider mapTileFileArchiveProvider = new MapTileFileArchiveProvider(iRegisterReceiver, iTileSource);
        this.mTileProviderList.add((Object)mapTileFileArchiveProvider);
        MapTileDownloader mapTileDownloader = new MapTileDownloader(iTileSource, (IFilesystemCache)tileWriter, iNetworkAvailablityCheck);
        this.mTileProviderList.add((Object)mapTileDownloader);
    }
}

