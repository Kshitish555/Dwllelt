/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Void
 *  java.lang.reflect.AccessibleObject
 *  java.lang.reflect.Field
 *  java.lang.reflect.Modifier
 *  java.lang.reflect.ParameterizedType
 *  java.lang.reflect.Type
 *  java.security.PrivilegedAction
 *  java.util.Collection
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package h.a.a.s0;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.security.PrivilegedAction;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicBoolean;

public class k {
    static final String a = "__ID";
    static final String b = "[#";
    static final String c = "]";
    private static final String[] d;
    private static final String[] e;

    static {
        String[] arrstring;
        d = new String[256];
        int n2 = 0;
        for (int i2 = 0; i2 < 256; ++i2) {
            int n3;
            if (i2 == 32) {
                i2 = 127;
            }
            int n4 = (n3 = i2 >> 4) <= 9 ? n3 + 48 : n3 + 65 - 10;
            char c2 = (char)n4;
            int n5 = i2 & 15;
            int n6 = n5 <= 9 ? n5 + 48 : n5 + 65 - 10;
            char c3 = (char)n6;
            String[] arrstring2 = d;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("\\u00");
            stringBuilder.append(Character.toString((char)c2));
            stringBuilder.append(Character.toString((char)c3));
            arrstring2[i2] = stringBuilder.toString();
        }
        String[] arrstring3 = d;
        arrstring3[34] = "\\\"";
        arrstring3[92] = "\\\\";
        arrstring3[10] = "\\n";
        arrstring3[13] = "\\r";
        arrstring3[9] = "\\t";
        arrstring3[8] = "\\b";
        arrstring3[12] = "\\f";
        e = new String[17];
        StringBuilder stringBuilder = new StringBuilder();
        while (n2 < (arrstring = e).length) {
            arrstring[n2] = stringBuilder.toString();
            stringBuilder.append(' ');
            ++n2;
        }
    }

    static Class<?> a(Type type) {
        if (type instanceof Class) {
            return (Class)type;
        }
        if (type instanceof ParameterizedType) {
            return (Class)((ParameterizedType)type).getRawType();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Illegal type: ");
        stringBuilder.append((Object)type);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    static Object a(Object object, Field field) throws IllegalArgumentException, IllegalAccessException {
        Class class_ = field.getType();
        if (class_ == Integer.TYPE) {
            return field.getInt(object);
        }
        if (class_ == Long.TYPE) {
            return field.getLong(object);
        }
        if (class_ == Short.TYPE) {
            return field.getShort(object);
        }
        if (class_ == Double.TYPE) {
            return field.getDouble(object);
        }
        if (class_ == Float.TYPE) {
            return Float.valueOf((float)field.getFloat(object));
        }
        if (class_ == Boolean.TYPE) {
            return field.getBoolean(object);
        }
        if (class_ == Byte.TYPE) {
            return field.getByte(object);
        }
        if (class_ == Character.TYPE) {
            return Character.valueOf((char)field.getChar(object));
        }
        return field.get(object);
    }

    public static String a(String string) {
        int n2;
        boolean bl;
        block9 : {
            if (string == null) {
                return string;
            }
            int n3 = string.length();
            n2 = 0;
            for (int i2 = 0; i2 < n3; ++i2) {
                char c2 = string.charAt(i2);
                if (c2 <= '\u00ff' && d[c2] == null) {
                    continue;
                }
                bl = true;
                break block9;
            }
            bl = false;
        }
        if (!bl) {
            return string;
        }
        StringBuilder stringBuilder = new StringBuilder(2 * string.length());
        int n4 = string.length();
        while (n2 < n4) {
            char c3 = string.charAt(n2);
            if (c3 > '\u00ff') {
                stringBuilder.append("\\u");
                int n5 = (61440 & c3) >> 12;
                int n6 = n5 <= 9 ? n5 + 48 : -10 + (n5 + 65);
                stringBuilder.append((char)n6);
                int n7 = (c3 & 3840) >> 8;
                int n8 = n7 <= 9 ? n7 + 48 : -10 + (n7 + 65);
                stringBuilder.append((char)n8);
                int n9 = (c3 & 240) >> 4;
                int n10 = n9 <= 9 ? n9 + 48 : -10 + (n9 + 65);
                stringBuilder.append((char)n10);
                int n11 = c3 & 15;
                int n12 = n11 <= 9 ? n11 + 48 : -10 + (n11 + 65);
                stringBuilder.append((char)n12);
            } else {
                String string2 = d[c3];
                if (string2 == null) {
                    stringBuilder.append(c3);
                } else {
                    stringBuilder.append(string2);
                }
            }
            ++n2;
        }
        return stringBuilder.toString();
    }

    static void a(int n2, int n3, StringBuilder stringBuilder) {
        int n4;
        int n5 = -1 + e.length;
        for (int i2 = n2 * n3; i2 > 0; i2 -= n4) {
            n4 = Math.min((int)i2, (int)n5);
            stringBuilder.append(e[n4]);
        }
    }

    static void a(String string, StringBuilder stringBuilder) {
        int n2;
        boolean bl;
        block9 : {
            if (string == null) {
                return;
            }
            int n3 = string.length();
            n2 = 0;
            for (int i2 = 0; i2 < n3; ++i2) {
                char c2 = string.charAt(i2);
                if (c2 <= '\u00ff' && d[c2] == null) {
                    continue;
                }
                bl = true;
                break block9;
            }
            bl = false;
        }
        if (!bl) {
            stringBuilder.append(string);
            return;
        }
        int n4 = string.length();
        while (n2 < n4) {
            char c3 = string.charAt(n2);
            if (c3 > '\u00ff') {
                stringBuilder.append("\\u");
                int n5 = (61440 & c3) >> 12;
                int n6 = n5 <= 9 ? n5 + 48 : -10 + (n5 + 65);
                stringBuilder.append((char)n6);
                int n7 = (c3 & 3840) >> 8;
                int n8 = n7 <= 9 ? n7 + 48 : -10 + (n7 + 65);
                stringBuilder.append((char)n8);
                int n9 = (c3 & 240) >> 4;
                int n10 = n9 <= 9 ? n9 + 48 : -10 + (n9 + 65);
                stringBuilder.append((char)n10);
                int n11 = c3 & 15;
                int n12 = n11 <= 9 ? n11 + 48 : -10 + (n11 + 65);
                stringBuilder.append((char)n12);
            } else {
                String string2 = d[c3];
                if (string2 == null) {
                    stringBuilder.append(c3);
                } else {
                    stringBuilder.append(string2);
                }
            }
            ++n2;
        }
    }

    static boolean a(Class<?> class_) {
        return class_ == String.class || class_ == Integer.class || class_ == Integer.TYPE || class_ == Long.class || class_ == Long.TYPE || class_ == Short.class || class_ == Short.TYPE || class_ == Float.class || class_ == Float.TYPE || class_ == Double.class || class_ == Double.TYPE || class_ == Byte.class || class_ == Byte.TYPE || class_ == Character.class || class_ == Character.TYPE || class_ == Boolean.class || class_ == Boolean.TYPE || class_.isEnum();
        {
        }
    }

    static boolean a(Object object) {
        return object == null || object instanceof String || object instanceof Integer || object instanceof Boolean || object instanceof Long || object instanceof Float || object instanceof Double || object instanceof Short || object instanceof Byte || object instanceof Character || object.getClass().isEnum();
        {
        }
    }

    /*
     * Exception decompiling
     */
    static boolean a(AccessibleObject var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl24 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    static boolean a(Field field, boolean bl) {
        int n2 = field.getModifiers();
        if (!(bl && !Modifier.isPublic((int)n2) || Modifier.isTransient((int)n2) || Modifier.isFinal((int)n2) || (n2 & 4096) != 0)) {
            return k.a((AccessibleObject)field);
        }
        return false;
    }

    static boolean b(Object object) {
        Class class_ = object.getClass();
        return Collection.class.isAssignableFrom(class_) || class_.isArray();
        {
        }
    }

    static boolean b(Type type) {
        if (type instanceof Class) {
            return k.a((Class)type);
        }
        if (type instanceof ParameterizedType) {
            return k.b(((ParameterizedType)type).getRawType());
        }
        return false;
    }

}

