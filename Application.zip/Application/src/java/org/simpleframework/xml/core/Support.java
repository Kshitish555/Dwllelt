/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.util.Collection
 *  java.util.List
 *  java.util.Map
 *  org.simpleframework.xml.DefaultType
 *  org.simpleframework.xml.core.ContactList
 *  org.simpleframework.xml.core.Detail
 *  org.simpleframework.xml.core.DetailExtractor
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.core.InstanceFactory
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelExtractor
 *  org.simpleframework.xml.core.Reflector
 *  org.simpleframework.xml.core.ScannerFactory
 *  org.simpleframework.xml.filter.Filter
 *  org.simpleframework.xml.filter.PlatformFilter
 *  org.simpleframework.xml.strategy.Value
 *  org.simpleframework.xml.stream.Format
 *  org.simpleframework.xml.stream.Style
 *  org.simpleframework.xml.transform.Matcher
 *  org.simpleframework.xml.transform.Transform
 *  org.simpleframework.xml.transform.Transformer
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.simpleframework.xml.DefaultType;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.ContactList;
import org.simpleframework.xml.core.Detail;
import org.simpleframework.xml.core.DetailExtractor;
import org.simpleframework.xml.core.EmptyMatcher;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.core.InstanceFactory;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelExtractor;
import org.simpleframework.xml.core.Reflector;
import org.simpleframework.xml.core.Scanner;
import org.simpleframework.xml.core.ScannerFactory;
import org.simpleframework.xml.filter.Filter;
import org.simpleframework.xml.filter.PlatformFilter;
import org.simpleframework.xml.strategy.Value;
import org.simpleframework.xml.stream.Format;
import org.simpleframework.xml.stream.Style;
import org.simpleframework.xml.transform.Matcher;
import org.simpleframework.xml.transform.Transform;
import org.simpleframework.xml.transform.Transformer;

class Support
implements Filter {
    private final DetailExtractor defaults = new DetailExtractor(this, DefaultType.FIELD);
    private final DetailExtractor details;
    private final Filter filter;
    private final Format format;
    private final InstanceFactory instances;
    private final LabelExtractor labels;
    private final Matcher matcher;
    private final ScannerFactory scanners;
    private final Transformer transform;

    public Support() {
        this((Filter)new PlatformFilter());
    }

    public Support(Filter filter) {
        this(filter, new EmptyMatcher());
    }

    public Support(Filter filter, Matcher matcher) {
        this(filter, matcher, new Format());
    }

    public Support(Filter filter, Matcher matcher, Format format) {
        this.transform = new Transformer(matcher);
        this.scanners = new ScannerFactory(this);
        this.details = new DetailExtractor(this);
        this.labels = new LabelExtractor(format);
        this.instances = new InstanceFactory();
        this.matcher = matcher;
        this.filter = filter;
        this.format = format;
    }

    private String getClassName(Class class_) throws Exception {
        if (class_.isArray()) {
            class_ = class_.getComponentType();
        }
        String string2 = class_.getSimpleName();
        if (class_.isPrimitive()) {
            return string2;
        }
        return Reflector.getName((String)string2);
    }

    public static Class getPrimitive(Class class_) {
        if (class_ == Double.TYPE) {
            return Double.class;
        }
        if (class_ == Float.TYPE) {
            return Float.class;
        }
        if (class_ == Integer.TYPE) {
            return Integer.class;
        }
        if (class_ == Long.TYPE) {
            return Long.class;
        }
        if (class_ == Boolean.TYPE) {
            return Boolean.class;
        }
        if (class_ == Character.TYPE) {
            return Character.class;
        }
        if (class_ == Short.TYPE) {
            return Short.class;
        }
        if (class_ == Byte.TYPE) {
            class_ = Byte.class;
        }
        return class_;
    }

    public static boolean isAssignable(Class class_, Class class_2) {
        if (class_.isPrimitive()) {
            class_ = Support.getPrimitive(class_);
        }
        if (class_2.isPrimitive()) {
            class_2 = Support.getPrimitive(class_2);
        }
        return class_2.isAssignableFrom(class_);
    }

    public static boolean isFloat(Class class_) throws Exception {
        if (class_ == Double.class) {
            return true;
        }
        if (class_ == Float.class) {
            return true;
        }
        if (class_ == Float.TYPE) {
            return true;
        }
        return class_ == Double.TYPE;
    }

    public Detail getDetail(Class class_) {
        return this.getDetail(class_, null);
    }

    public Detail getDetail(Class class_, DefaultType defaultType) {
        if (defaultType != null) {
            return this.defaults.getDetail(class_);
        }
        return this.details.getDetail(class_);
    }

    public ContactList getFields(Class class_) throws Exception {
        return this.getFields(class_, null);
    }

    public ContactList getFields(Class class_, DefaultType defaultType) throws Exception {
        if (defaultType != null) {
            return this.defaults.getFields(class_);
        }
        return this.details.getFields(class_);
    }

    public Format getFormat() {
        return this.format;
    }

    public Instance getInstance(Class class_) {
        return this.instances.getInstance(class_);
    }

    public Instance getInstance(Value value) {
        return this.instances.getInstance(value);
    }

    public Label getLabel(Contact contact, Annotation annotation) throws Exception {
        return this.labels.getLabel(contact, annotation);
    }

    public List<Label> getLabels(Contact contact, Annotation annotation) throws Exception {
        return this.labels.getList(contact, annotation);
    }

    public ContactList getMethods(Class class_) throws Exception {
        return this.getMethods(class_, null);
    }

    public ContactList getMethods(Class class_, DefaultType defaultType) throws Exception {
        if (defaultType != null) {
            return this.defaults.getMethods(class_);
        }
        return this.details.getMethods(class_);
    }

    public String getName(Class class_) throws Exception {
        String string2 = this.getScanner(class_).getName();
        if (string2 != null) {
            return string2;
        }
        return this.getClassName(class_);
    }

    public Scanner getScanner(Class class_) throws Exception {
        return this.scanners.getInstance(class_);
    }

    public Style getStyle() {
        return this.format.getStyle();
    }

    public Transform getTransform(Class class_) throws Exception {
        return this.matcher.match(class_);
    }

    public boolean isContainer(Class class_) {
        if (Collection.class.isAssignableFrom(class_)) {
            return true;
        }
        if (Map.class.isAssignableFrom(class_)) {
            return true;
        }
        return class_.isArray();
    }

    public boolean isPrimitive(Class class_) throws Exception {
        if (class_ == String.class) {
            return true;
        }
        if (class_ == Float.class) {
            return true;
        }
        if (class_ == Double.class) {
            return true;
        }
        if (class_ == Long.class) {
            return true;
        }
        if (class_ == Integer.class) {
            return true;
        }
        if (class_ == Boolean.class) {
            return true;
        }
        if (class_.isEnum()) {
            return true;
        }
        if (class_.isPrimitive()) {
            return true;
        }
        return this.transform.valid(class_);
    }

    public Object read(String string2, Class class_) throws Exception {
        return this.transform.read(string2, class_);
    }

    public String replace(String string2) {
        return this.filter.replace(string2);
    }

    public boolean valid(Class class_) throws Exception {
        return this.transform.valid(class_);
    }

    public String write(Object object, Class class_) throws Exception {
        return this.transform.write(object, class_);
    }
}

