/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.location.Address
 *  android.location.Geocoder
 *  android.location.Location
 *  android.location.LocationManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.telephony.TelephonyManager
 *  java.io.IOException
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.NoClassDefFoundError
 *  java.lang.NoSuchMethodError
 *  java.lang.NoSuchMethodException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.UUID
 */
package com.amplitude.api;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import com.amplitude.api.d;
import com.amplitude.api.i;
import com.amplitude.api.n;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class h {
    public static final String d = "com.amplitude.api.DeviceInfo";
    public static final String e = "android";
    private static final String f = "limit_ad_tracking";
    private static final String g = "advertising_id";
    private boolean a = true;
    private Context b;
    private b c;

    public h(Context context) {
        this.b = context;
    }

    public static String q() {
        return UUID.randomUUID().toString();
    }

    private b r() {
        if (this.c == null) {
            this.c = new b();
        }
        return this.c;
    }

    public String a() {
        return this.r().a;
    }

    public void a(boolean bl) {
        this.a = bl;
    }

    public String b() {
        return this.r().f;
    }

    public String c() {
        return this.r().i;
    }

    public String d() {
        return this.r().b;
    }

    protected Geocoder e() {
        return new Geocoder(this.b, Locale.ENGLISH);
    }

    public String f() {
        return this.r().j;
    }

    public String g() {
        return this.r().g;
    }

    public String h() {
        return this.r().h;
    }

    public Location i() {
        List list;
        boolean bl = this.o();
        Location location = null;
        if (!bl) {
            return null;
        }
        LocationManager locationManager = (LocationManager)this.b.getSystemService("location");
        if (locationManager == null) {
            return null;
        }
        try {
            list = locationManager.getProviders(true);
        }
        catch (SecurityException securityException) {
            i.c().a("Failed to get most recent location", securityException);
            list = null;
        }
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        for (String string : list) {
            Location location2;
            block10 : {
                try {
                    location2 = locationManager.getLastKnownLocation(string);
                    break block10;
                }
                catch (SecurityException securityException) {
                    i.c().a("Failed to get most recent location", securityException);
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    i.c().a("Failed to get most recent location", illegalArgumentException);
                }
                location2 = null;
            }
            if (location2 == null) continue;
            arrayList.add((Object)location2);
        }
        long l2 = -1L;
        for (Location location3 : arrayList) {
            if (location3.getTime() <= l2) continue;
            l2 = location3.getTime();
            location = location3;
        }
        return location;
    }

    public String j() {
        return this.r().d;
    }

    public String k() {
        return this.r().e;
    }

    public String l() {
        return this.r().c;
    }

    public boolean m() {
        return this.r().l;
    }

    public boolean n() {
        return this.r().k;
    }

    public boolean o() {
        return this.a;
    }

    public void p() {
        this.r();
    }

    private class b {
        private String a = this.b();
        private String b = this.g();
        private String c = this.p();
        private String d = this.n();
        private String e = this.o();
        private String f = this.e();
        private String g = this.l();
        private String h = this.m();
        private String i = this.f();
        private String j = this.k();
        private boolean k;
        private boolean l = this.a();

        private b() {
        }

        private boolean a() {
            boolean bl;
            block8 : {
                Method method = Class.forName((String)"com.google.android.gms.common.GooglePlayServicesUtil").getMethod("isGooglePlayServicesAvailable", new Class[]{Context.class});
                Object[] arrobject = new Object[]{h.this.b};
                Integer n2 = (Integer)method.invoke(null, arrobject);
                bl = false;
                if (n2 == null) break block8;
                try {
                    int n3 = n2;
                    bl = false;
                    if (n3 != 0) break block8;
                    bl = true;
                }
                catch (Exception exception) {
                    d d2 = d.a();
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Error when checking for Google Play Services: ");
                    stringBuilder.append((Object)exception);
                    d2.e(h.d, stringBuilder.toString());
                    i.c().a("Failed to check GPS enabled", exception);
                    return false;
                }
                catch (IllegalAccessException illegalAccessException) {
                    d.a().e(h.d, "Google Play Services not available");
                    i.c().a("Failed to check GPS enabled", illegalAccessException);
                    return false;
                }
                catch (InvocationTargetException invocationTargetException) {
                    d.a().e(h.d, "Google Play Services not available");
                    i.c().a("Failed to check GPS enabled", invocationTargetException);
                    return false;
                }
                catch (NoSuchMethodException noSuchMethodException) {
                    d.a().e(h.d, "Google Play Services not available");
                    i.c().a("Failed to check GPS enabled", noSuchMethodException);
                    return false;
                }
                catch (ClassNotFoundException classNotFoundException) {
                    d.a().e(h.d, "Google Play Services Util not found!");
                    i.c().a("Failed to check GPS enabled", classNotFoundException);
                    return false;
                }
                catch (NoClassDefFoundError noClassDefFoundError) {
                    d.a().e(h.d, "Google Play Services Util not found!");
                    i.c().a("Failed to check GPS enabled", noClassDefFoundError);
                    return false;
                }
            }
            return bl;
        }

        private String b() {
            if ("Amazon".equals((Object)this.l())) {
                return this.c();
            }
            return this.d();
        }

        private String c() {
            String string;
            ContentResolver contentResolver = h.this.b.getContentResolver();
            int n2 = Settings.Secure.getInt((ContentResolver)contentResolver, (String)h.f, (int)0);
            boolean bl = false;
            if (n2 == 1) {
                bl = true;
            }
            this.k = bl;
            this.a = string = Settings.Secure.getString((ContentResolver)contentResolver, (String)h.g);
            return string;
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private String d() {
            Object object;
            int n2;
            block5 : {
                block4 : {
                    try {
                        Class class_ = Class.forName((String)"com.google.android.gms.ads.identifier.AdvertisingIdClient");
                        n2 = 1;
                        Class[] arrclass = new Class[n2];
                        arrclass[0] = Context.class;
                        Method method = class_.getMethod("getAdvertisingIdInfo", arrclass);
                        Object[] arrobject = new Object[n2];
                        arrobject[0] = h.this.b;
                        object = method.invoke(null, arrobject);
                        Boolean bl = (Boolean)object.getClass().getMethod("isLimitAdTrackingEnabled", new Class[0]).invoke(object, new Object[0]);
                        if (bl == null || !bl.booleanValue()) break block4;
                        break block5;
                    }
                    catch (Exception exception) {
                        d.a().b(h.d, "Encountered an error connecting to Google Play Services", exception);
                        i.c().a("Failed to get ADID", exception);
                        return this.a;
                    }
                    catch (InvocationTargetException invocationTargetException) {
                        d.a().e(h.d, "Google Play Services not available");
                        i.c().a("Failed to get ADID", invocationTargetException);
                        return this.a;
                    }
                    catch (ClassNotFoundException classNotFoundException) {
                        d.a().e(h.d, "Google Play Services SDK not found!");
                        i.c().a("Failed to get ADID", classNotFoundException);
                    }
                    return this.a;
                }
                n2 = 0;
            }
            this.k = n2;
            this.a = (String)object.getClass().getMethod("getId", new Class[0]).invoke(object, new Object[0]);
            return this.a;
        }

        private String e() {
            return Build.BRAND;
        }

        private String f() {
            try {
                String string = ((TelephonyManager)h.this.b.getSystemService("phone")).getNetworkOperatorName();
                return string;
            }
            catch (Exception exception) {
                i.c().a("Failed to get carrier", exception);
                return null;
            }
        }

        private String g() {
            String string = this.i();
            if (!n.a(string)) {
                return string;
            }
            String string2 = this.j();
            if (!n.a(string2)) {
                return string2;
            }
            return this.h();
        }

        private String h() {
            return Locale.getDefault().getCountry();
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private String i() {
            Address address;
            if (!h.this.o()) {
                return null;
            }
            Location location = h.this.i();
            if (location == null) return null;
            if (!Geocoder.isPresent()) return null;
            List list = h.this.e().getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if (list == null) return null;
            Iterator iterator = list.iterator();
            do {
                if (!iterator.hasNext()) return null;
            } while ((address = (Address)iterator.next()) == null);
            try {
                return address.getCountryCode();
            }
            catch (IllegalStateException illegalStateException) {
                i.c().a("Failed to get country from location", illegalStateException);
                return null;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                i.c().a("Failed to get country from location", illegalArgumentException);
                return null;
            }
            catch (NoSuchMethodError noSuchMethodError) {
                i.c().a("Failed to get country from location", noSuchMethodError);
                return null;
            }
            catch (NullPointerException nullPointerException) {
                i.c().a("Failed to get country from location", nullPointerException);
                return null;
            }
            catch (IOException iOException) {
                i.c().a("Failed to get country from location", iOException);
            }
            return null;
        }

        /*
         * Enabled force condition propagation
         * Lifted jumps to return sites
         */
        private String j() {
            TelephonyManager telephonyManager = (TelephonyManager)h.this.b.getSystemService("phone");
            if (telephonyManager.getPhoneType() == 2) return null;
            String string = telephonyManager.getNetworkCountryIso();
            if (string == null) return null;
            try {
                return string.toUpperCase(Locale.US);
            }
            catch (Exception exception) {
                i.c().a("Failed to get country from network", exception);
            }
            return null;
        }

        private String k() {
            return Locale.getDefault().getLanguage();
        }

        private String l() {
            return Build.MANUFACTURER;
        }

        private String m() {
            return Build.MODEL;
        }

        private String n() {
            return h.e;
        }

        private String o() {
            return Build.VERSION.RELEASE;
        }

        private String p() {
            try {
                String string = h.a((h)h.this).getPackageManager().getPackageInfo((String)h.a((h)h.this).getPackageName(), (int)0).versionName;
                return string;
            }
            catch (PackageManager.NameNotFoundException nameNotFoundException) {
                i.c().a("Failed to get version name", nameNotFoundException);
                return null;
            }
        }
    }

}

