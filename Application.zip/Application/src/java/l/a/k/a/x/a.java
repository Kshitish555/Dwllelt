/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  l.a.k.a.n
 *  l.a.k.a.q
 *  l.a.k.a.r
 *  l.a.k.a.t
 *  l.a.k.a.u
 *  l.a.k.a.x.g
 *  l.a.k.a.x.k
 */
package l.a.k.a.x;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import l.a.k.a.n;
import l.a.k.a.q;
import l.a.k.a.r;
import l.a.k.a.t;
import l.a.k.a.u;
import l.a.k.a.x.g;
import l.a.k.a.x.k;

public abstract class a
extends g
implements t {
    private static final Object J5;
    private static final Object K5;
    protected int D5;
    protected String E5;
    private boolean F5;
    private boolean G5;
    private List H5;
    private Map I5;

    static {
        a.A();
        J5 = new Object();
        K5 = new Object();
    }

    protected a(int n2, r r2, int n3, String string, String string2) {
        super(n2, r2, n3, string, string2);
        this.D5 = n3;
        this.E5 = string2;
        this.F5 = "<init>".equals((Object)string);
    }

    static /* synthetic */ void A() {
    }

    private Object B() {
        List list = this.H5;
        return list.get(-1 + list.size());
    }

    private Object C() {
        List list = this.H5;
        return list.remove(-1 + list.size());
    }

    private void a(q q2, q[] arrq) {
        this.f(q2);
        for (int i2 = 0; i2 < arrq.length; ++i2) {
            this.f(arrq[i2]);
        }
    }

    private void b(int n2, String string, String string2, String string3, boolean bl) {
        block4 : {
            block7 : {
                block5 : {
                    block6 : {
                        ((r)this).d.a(n2, string, string2, string3, bl);
                        if (!this.F5) break block4;
                        u[] arru = u.a((String)string3);
                        for (int i2 = 0; i2 < arru.length; ++i2) {
                            this.C();
                            if (arru[i2].i() != 2) continue;
                            this.C();
                        }
                        if (n2 == 182) break block5;
                        if (n2 == 183) break block6;
                        if (n2 == 185) break block5;
                        break block7;
                    }
                    if (this.C() == J5 && !this.G5) {
                        this.z();
                        this.G5 = true;
                        this.F5 = false;
                    }
                    break block7;
                }
                this.C();
            }
            u u2 = u.e((String)string3);
            if (u2 != u.q) {
                this.b(K5);
                if (u2.i() == 2) {
                    this.b(K5);
                }
            }
        }
    }

    private void b(Object object) {
        this.H5.add(object);
    }

    private void f(q q2) {
        if (this.I5.containsKey((Object)q2)) {
            return;
        }
        this.I5.put((Object)q2, (Object)new ArrayList((Collection)this.H5));
    }

    /*
     * Exception decompiling
     */
    public void a(int var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:478)
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:61)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:372)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

    public /* varargs */ void a(int n2, int n3, q q2, q ... arrq) {
        ((r)this).d.a(n2, n3, q2, arrq);
        if (this.F5) {
            this.C();
            this.a(q2, arrq);
        }
    }

    public void a(int n2, String string) {
        ((r)this).d.a(n2, string);
        if (this.F5 && n2 == 187) {
            this.b(K5);
        }
    }

    public void a(int n2, String string, String string2, String string3) {
        block10 : {
            block16 : {
                boolean bl;
                block13 : {
                    block17 : {
                        block14 : {
                            block15 : {
                                block12 : {
                                    block11 : {
                                        ((r)this).d.a(n2, string, string2, string3);
                                        if (!this.F5) break block10;
                                        char c2 = string3.charAt(0);
                                        if (c2 == 'J') break block11;
                                        bl = false;
                                        if (c2 != 'D') break block12;
                                    }
                                    bl = true;
                                }
                                if (n2 == 178) break block13;
                                if (n2 == 179) break block14;
                                if (n2 == 181) break block15;
                                if (!bl) break block10;
                                break block16;
                            }
                            this.C();
                            this.C();
                            if (!bl) break block10;
                            break block17;
                        }
                        this.C();
                        if (!bl) break block10;
                    }
                    this.C();
                    return;
                }
                this.b(K5);
                if (!bl) break block10;
            }
            this.b(K5);
        }
    }

    public void a(int n2, String string, String string2, String string3, boolean bl) {
        if (((r)this).c < 327680) {
            r.super.a(n2, string, string2, string3, bl);
            return;
        }
        this.b(n2, string, string2, string3, bl);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void a(int var1_1, q var2_2) {
        this.d.a(var1_1, var2_2);
        if (this.F5 == false) return;
        if (var1_1 != 168) {
            if (var1_1 != 198 && var1_1 != 199) {
                switch (var1_1) {
                    default: {
                        ** break;
                    }
                    case 159: 
                    case 160: 
                    case 161: 
                    case 162: 
                    case 163: 
                    case 164: 
                    case 165: 
                    case 166: {
                        this.C();
                    }
                    case 153: 
                    case 154: 
                    case 155: 
                    case 156: 
                    case 157: 
                    case 158: 
                }
            }
            this.C();
            ** break;
lbl13: // 2 sources:
        } else {
            this.b(a.K5);
        }
        this.f(var2_2);
    }

    public void a(Object object) {
        ((r)this).d.a(object);
        if (this.F5) {
            this.b(K5);
            if (object instanceof Double || object instanceof Long) {
                this.b(K5);
            }
        }
    }

    public void a(String string, int n2) {
        ((r)this).d.a(string, n2);
        if (this.F5) {
            for (int i2 = 0; i2 < n2; ++i2) {
                this.C();
            }
            this.b(K5);
        }
    }

    public /* varargs */ void a(String string, String string2, n n2, Object ... arrobject) {
        ((r)this).d.a(string, string2, n2, arrobject);
        if (this.F5) {
            u[] arru = u.a((String)string2);
            for (int i2 = 0; i2 < arru.length; ++i2) {
                this.C();
                if (arru[i2].i() != 2) continue;
                this.C();
            }
            u u2 = u.e((String)string2);
            if (u2 != u.q) {
                this.b(K5);
                if (u2.i() == 2) {
                    this.b(K5);
                }
            }
        }
    }

    public void a(q q2) {
        Map map;
        List list;
        ((r)this).d.a(q2);
        if (this.F5 && (map = this.I5) != null && (list = (List)map.get((Object)q2)) != null) {
            this.H5 = list;
            this.I5.remove((Object)q2);
        }
    }

    public void a(q q2, q q3, q q4, String string) {
        r.super.a(q2, q3, q4, string);
        if (this.F5 && !this.I5.containsKey((Object)q4)) {
            ArrayList arrayList = new ArrayList();
            arrayList.add(K5);
            this.I5.put((Object)q4, (Object)arrayList);
        }
    }

    public void a(q q2, int[] arrn, q[] arrq) {
        ((r)this).d.a(q2, arrn, arrq);
        if (this.F5) {
            this.C();
            this.a(q2, arrq);
        }
    }

    public void b() {
        ((r)this).d.b();
        if (this.F5) {
            this.H5 = new ArrayList();
            this.I5 = new HashMap();
            return;
        }
        this.G5 = true;
        this.z();
    }

    public void b(int n2, int n3) {
        ((r)this).d.b(n2, n3);
        if (this.F5 && n2 != 188) {
            this.b(K5);
        }
    }

    public void b(int n2, String string, String string2, String string3) {
        if (((r)this).c >= 327680) {
            r.super.b(n2, string, string2, string3);
            return;
        }
        boolean bl = n2 == 185;
        this.b(n2, string, string2, string3, bl);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void d(int var1_1, int var2_2) {
        k.super.d(var1_1, var2_2);
        if (this.F5 == false) return;
        switch (var1_1) {
            default: {
                switch (var1_1) {
                    default: {
                        return;
                    }
                    case 55: 
                    case 57: {
                        this.C();
                    }
                    case 54: 
                    case 56: 
                    case 58: 
                }
                this.C();
                return;
            }
            case 25: {
                if (var2_2 != 0) break;
                var3_3 = a.J5;
                ** break;
            }
            case 22: 
            case 24: {
                this.b(a.K5);
            }
            case 21: 
            case 23: 
        }
        var3_3 = a.K5;
lbl21: // 2 sources:
        this.b(var3_3);
    }

    protected void i(int n2) {
    }

    protected void z() {
    }
}

