/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Instance
 *  org.simpleframework.xml.strategy.Value
 */
package org.simpleframework.xml.core;

import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Instance;
import org.simpleframework.xml.strategy.Value;

class ConversionInstance
implements Instance {
    private final Context context;
    private final Class convert;
    private final Value value;

    public ConversionInstance(Context context, Value value, Class class_) throws Exception {
        this.context = context;
        this.convert = class_;
        this.value = value;
    }

    public Object getInstance() throws Exception {
        if (this.value.isReference()) {
            return this.value.getValue();
        }
        Object object = this.getInstance(this.convert);
        if (object != null) {
            this.setInstance(object);
        }
        return object;
    }

    public Object getInstance(Class class_) throws Exception {
        return this.context.getInstance(class_).getInstance();
    }

    public Class getType() {
        return this.convert;
    }

    public boolean isReference() {
        return this.value.isReference();
    }

    public Object setInstance(Object object) throws Exception {
        Value value = this.value;
        if (value != null) {
            value.setValue(object);
        }
        return object;
    }
}

