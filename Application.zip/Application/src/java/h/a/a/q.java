/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.a.a.a
 *  h.a.a.b
 *  h.a.a.c
 *  h.a.a.e
 *  h.a.a.v
 *  h.a.a.z
 *  io.github.classgraph.utils.k
 *  io.github.classgraph.utils.p
 *  java.io.IOException
 *  java.lang.Character
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Modifier
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 */
package h.a.a;

import h.a.a.a;
import h.a.a.b;
import h.a.a.c;
import h.a.a.d;
import h.a.a.e;
import h.a.a.l;
import h.a.a.l0;
import h.a.a.r;
import h.a.a.v;
import h.a.a.z;
import io.github.classgraph.utils.k;
import io.github.classgraph.utils.p;
import java.io.IOException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class q {
    private static final c[] f = new c[0];
    private k a;
    private String b;
    private int[] c;
    private int[] d;
    private int[] e;

    q() {
    }

    private c a() throws IOException {
        String string = this.a(this.a.e());
        int n2 = this.a.e();
        ArrayList arrayList = n2 > 0 ? new ArrayList(n2) : null;
        for (int i2 = 0; i2 < n2; ++i2) {
            arrayList.add((Object)new e(this.c(this.a.e()), this.b()));
        }
        return new c(string, (List)arrayList);
    }

    private Object a(int n2, char c2, int n3) throws IOException {
        switch (n2) {
            default: {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown constant pool tag ");
                stringBuilder.append(n2);
                stringBuilder.append(", cannot continue reading class. Please report this at https://github.com/classgraph/classgraph/issues");
                throw new RuntimeException(stringBuilder.toString());
            }
            case 6: {
                return Double.longBitsToDouble((long)this.a.b(this.c[n3]));
            }
            case 5: {
                return this.a.b(this.c[n3]);
            }
            case 4: {
                return Float.valueOf((float)Float.intBitsToFloat((int)this.a.a(this.c[n3])));
            }
            case 3: {
                int n4 = this.a.a(this.c[n3]);
                if (c2 != 'B') {
                    if (c2 != 'C') {
                        if (c2 != 'I') {
                            if (c2 != 'S') {
                                if (c2 == 'Z') {
                                    boolean bl = false;
                                    if (n4 != 0) {
                                        bl = true;
                                    }
                                    return bl;
                                }
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("Unknown Constant_INTEGER type ");
                                stringBuilder.append(c2);
                                stringBuilder.append(", cannot continue reading class. Please report this at https://github.com/classgraph/classgraph/issues");
                                throw new RuntimeException(stringBuilder.toString());
                            }
                            return (short)n4;
                        }
                        return n4;
                    }
                    return Character.valueOf((char)((char)n4));
                }
                return (byte)n4;
            }
            case 1: 
            case 7: 
            case 8: 
        }
        return this.a(n3, 0);
    }

    private String a(int n2) {
        return this.a(n2, true, true);
    }

    private String a(int n2, int n3) {
        int n4 = this.b(n2, n3);
        if (n4 == 0) {
            return null;
        }
        return this.a.a(n4, false, false);
    }

    private String a(int n2, boolean bl, boolean bl2) {
        int n3 = this.b(n2, 0);
        if (n3 == 0) {
            return null;
        }
        return this.a.a(n3, bl, bl2);
    }

    private boolean a(int n2, String string) {
        int n3 = this.b(n2, 0);
        if (n3 == 0) {
            boolean bl = false;
            if (string == null) {
                bl = true;
            }
            return bl;
        }
        int n4 = this.a.d(n3);
        if (n4 != string.length()) {
            return false;
        }
        int n5 = n3 + 2;
        for (int i2 = 0; i2 < n4; ++i2) {
            if ((char)(255 & this.a.a[n5 + i2]) == string.charAt(i2)) continue;
            return false;
        }
        return true;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private int b(int n2, int n3) {
        int n4 = this.d[n2];
        if (n4 != 12 && n3 != 0 || n4 == 12 && n3 != 0 && n3 != 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Bad subfield index ");
            stringBuilder.append(n3);
            stringBuilder.append(" for tag ");
            stringBuilder.append(n4);
            stringBuilder.append(", cannot continue reading class. Please report this at https://github.com/classgraph/classgraph/issues");
            throw new RuntimeException(stringBuilder.toString());
        }
        if (n4 == 1) return this.c[n2];
        if (n4 != 7 && n4 != 8) {
            if (n4 == 12) {
                int n5 = this.e[n2];
                if (n3 == 0) {
                    n5 >>= 16;
                }
                if ((n2 = n5 & 65535) != 0 && n2 != -1) return this.c[n2];
                throw new RuntimeException("Bad string indirection index, cannot continue reading class. Please report this at https://github.com/classgraph/classgraph/issues");
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Wrong tag number ");
            stringBuilder.append(n4);
            stringBuilder.append(" at constant pool index ");
            stringBuilder.append(n2);
            stringBuilder.append(", cannot continue reading class. Please report this at https://github.com/classgraph/classgraph/issues");
            throw new RuntimeException(stringBuilder.toString());
        }
        if ((n2 = this.e[n2]) == -1) throw new RuntimeException("Bad string indirection index, cannot continue reading class. Please report this at https://github.com/classgraph/classgraph/issues");
        if (n2 != 0) return this.c[n2];
        return 0;
    }

    private Object b() throws IOException {
        char c2 = (char)this.a.d();
        if (c2 != '@') {
            if (c2 != 'F') {
                if (c2 != 'S') {
                    if (c2 != 'c') {
                        if (c2 != 'e') {
                            if (c2 != 's') {
                                if (c2 != 'I') {
                                    if (c2 != 'J') {
                                        if (c2 != 'Z') {
                                            if (c2 != '[') {
                                                switch (c2) {
                                                    default: {
                                                        StringBuilder stringBuilder = new StringBuilder();
                                                        stringBuilder.append("Class ");
                                                        stringBuilder.append(this.b);
                                                        stringBuilder.append(" has unknown annotation element type tag '");
                                                        stringBuilder.append(c2);
                                                        stringBuilder.append("': element size unknown, cannot continue reading class. Please report this at https://github.com/classgraph/classgraph/issues");
                                                        throw new RuntimeException(stringBuilder.toString());
                                                    }
                                                    case 'D': {
                                                        k k2 = this.a;
                                                        return Double.longBitsToDouble((long)k2.b(this.c[k2.e()]));
                                                    }
                                                    case 'C': {
                                                        k k3 = this.a;
                                                        return Character.valueOf((char)((char)k3.a(this.c[k3.e()])));
                                                    }
                                                    case 'B': 
                                                }
                                                k k4 = this.a;
                                                return (byte)k4.a(this.c[k4.e()]);
                                            }
                                            int n2 = this.a.e();
                                            Object[] arrobject = new Object[n2];
                                            for (int i2 = 0; i2 < n2; ++i2) {
                                                arrobject[i2] = this.b();
                                            }
                                            return arrobject;
                                        }
                                        k k5 = this.a;
                                        int n3 = k5.a(this.c[k5.e()]);
                                        boolean bl = false;
                                        if (n3 != 0) {
                                            bl = true;
                                        }
                                        return bl;
                                    }
                                    k k6 = this.a;
                                    return k6.b(this.c[k6.e()]);
                                }
                                k k7 = this.a;
                                return k7.a(this.c[k7.e()]);
                            }
                            return this.c(this.a.e());
                        }
                        return new b(this.a(this.a.e()), this.c(this.a.e()));
                    }
                    return new a(this.c(this.a.e()));
                }
                k k8 = this.a;
                return (short)k8.a(this.c[k8.e()]);
            }
            k k9 = this.a;
            return Float.valueOf((float)Float.intBitsToFloat((int)k9.a(this.c[k9.e()])));
        }
        return this.a();
    }

    private String b(int n2) {
        return this.a(n2, true, false);
    }

    private String c(int n2) {
        return this.a(n2, 0);
    }

    private byte d(int n2) {
        int n3 = this.b(n2, 0);
        if (n3 == 0) {
            return 0;
        }
        if (this.a.d(n3) == 0) {
            return 0;
        }
        return this.a.a[n3 + 2];
    }

    l a(r r2, String string, k k2, l0 l02, p p2) throws IOException {
        IOException iOException;
        block75 : {
            block76 : {
                String string2;
                String string3;
                this.a = k2;
                k2.a();
                if (k2.b() != -889275714) break block75;
                k2.e();
                k2.e();
                int n2 = k2.e();
                int[] arrn = this.c;
                if (arrn == null || arrn.length < n2) {
                    this.c = new int[n2];
                    this.d = new int[n2];
                    this.e = new int[n2];
                }
                Arrays.fill((int[])this.e, (int)0, (int)n2, (int)-1);
                int n3 = 1;
                block13 : for (int i2 = 1; i2 < n2; i2 += n3) {
                    this.d[i2] = k2.d();
                    this.c[i2] = k2.b;
                    switch (this.d[i2]) {
                        default: {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("Unknown constant pool tag ");
                            stringBuilder.append(this.d[i2]);
                            stringBuilder.append(" in classfile ");
                            stringBuilder.append(string);
                            stringBuilder.append(" (element size unknown, cannot continue reading class). Please report this at https://github.com/classgraph/classgraph/issues");
                            throw new RuntimeException(stringBuilder.toString());
                        }
                        case 20: {
                            k2.e(2);
                            continue block13;
                        }
                        case 19: {
                            k2.e(2);
                            continue block13;
                        }
                        case 18: {
                            k2.e(4);
                            continue block13;
                        }
                        case 16: {
                            k2.e(2);
                            continue block13;
                        }
                        case 15: {
                            k2.e(3);
                            continue block13;
                        }
                        case 12: {
                            int n4 = k2.e();
                            int n5 = k2.e();
                            this.e[i2] = n5 | n4 << 16;
                            continue block13;
                        }
                        case 9: 
                        case 10: 
                        case 11: {
                            k2.e(4);
                            continue block13;
                        }
                        case 7: 
                        case 8: {
                            this.e[i2] = k2.e();
                            continue block13;
                        }
                        case 5: 
                        case 6: {
                            k2.e(8);
                            ++i2;
                            continue block13;
                        }
                        case 3: 
                        case 4: {
                            k2.e(4);
                            continue block13;
                        }
                        case 1: {
                            k2.e(k2.e());
                        }
                    }
                }
                int n6 = k2.e();
                boolean bl = (n6 & 512) != 0;
                boolean bl2 = (n6 & 8192) != 0;
                boolean bl3 = (32768 & n6) != 0;
                if (bl3) {
                    return null;
                }
                String string4 = this.c(k2.e());
                this.b = string2 = string4.replace('/', '.');
                if ("java.lang.Object".equals((Object)string2)) {
                    if (p2 != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Skipping ");
                        stringBuilder.append(this.b);
                        p2.a(stringBuilder.toString());
                    }
                    return null;
                }
                if (!l02.x && !Modifier.isPublic((int)n6)) {
                    if (p2 != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Skipping non-public class: ");
                        stringBuilder.append(this.b);
                        p2.a(stringBuilder.toString());
                    }
                    return null;
                }
                if (!string.endsWith(".class")) {
                    if (p2 != null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("File ");
                        stringBuilder.append(string);
                        stringBuilder.append(" does not end in \".class\"");
                        p2.a(stringBuilder.toString());
                    }
                    return null;
                }
                int n7 = string4.length();
                if (string.length() != n7 + 6 || !string4.regionMatches(0, string, 0, n7)) break block76;
                String string5 = this.b(k2.e());
                l l2 = new l(this.b, n6, bl, bl2, r2);
                l2.c(string5);
                int n8 = k2.e();
                for (int i3 = 0; i3 < n8; ++i3) {
                    l2.b(this.b(k2.e()));
                }
                int n9 = k2.e();
                int n10 = 0;
                do {
                    int n11;
                    string3 = "RuntimeInvisibleAnnotations";
                    if (n10 >= n9) break;
                    int n12 = k2.e();
                    boolean bl4 = (n12 & 1) == n3;
                    boolean bl5 = (n12 & 24) == 24;
                    boolean bl6 = bl4 || l02.y;
                    boolean bl7 = l02.u && bl5 && bl6;
                    if (bl6 && (l02.r || bl7)) {
                        String string6 = this.c(k2.e());
                        int n13 = k2.e();
                        char c2 = (char)this.d(n13);
                        String string7 = this.c(n13);
                        int n14 = k2.e();
                        String string8 = null;
                        Object object = null;
                        d d2 = null;
                        for (int i4 = 0; i4 < n14; ++i4) {
                            int n15 = k2.e();
                            int n16 = n9;
                            int n17 = k2.b();
                            boolean bl8 = bl7;
                            if (bl7 && this.a(n15, "ConstantValue")) {
                                int n18 = k2.e();
                                object = this.a(this.d[n18], c2, n18);
                            } else if (bl6 && this.a(n15, "Signature")) {
                                string8 = this.c(k2.e());
                            } else if (l02.t && (this.a(n15, "RuntimeVisibleAnnotations") || !l02.A && this.a(n15, string3))) {
                                int n19 = k2.e();
                                d d3 = d2 == null && n19 > 0 ? new d(1) : d2;
                                for (int i5 = 0; i5 < n19; ++i5) {
                                    int n20 = n19;
                                    d3.add((Object)this.a());
                                    n19 = n20;
                                }
                                d2 = d3;
                            } else {
                                k2.e(n17);
                            }
                            n9 = n16;
                            bl7 = bl8;
                        }
                        n11 = n9;
                        if (l02.r && bl6) {
                            v v2 = new v(this.b, string6, n12, string7, string8, object, d2);
                            l2.a(v2);
                        }
                    } else {
                        n11 = n9;
                        k2.e();
                        k2.e();
                        int n21 = k2.e();
                        for (int i6 = 0; i6 < n21; ++i6) {
                            k2.e();
                            k2.e(k2.b());
                        }
                    }
                    ++n10;
                    n9 = n11;
                    n3 = 1;
                } while (true);
                int n22 = k2.e();
                for (int i7 = 0; i7 < n22; ++i7) {
                    String string9;
                    int n23;
                    String string10;
                    String string11;
                    int n24 = k2.e();
                    boolean bl9 = (n24 & 1) == 1;
                    boolean bl10 = bl9 || l02.z;
                    if (!l02.s && !bl2) {
                        k2.e(4);
                        string10 = null;
                        string9 = null;
                    } else {
                        string10 = this.c(k2.e());
                        string9 = this.c(k2.e());
                    }
                    int n25 = k2.e();
                    if (bl10 && (l02.s || bl2)) {
                        ArrayList arrayList = null;
                        d d4 = null;
                        String string12 = null;
                        String[] arrstring = null;
                        int[] arrn2 = null;
                        c[][] arrarrc = null;
                        boolean bl11 = false;
                        for (int i8 = 0; i8 < n25; ++i8) {
                            String string13;
                            int n26 = k2.e();
                            int n27 = k2.b();
                            int n28 = n22;
                            if (l02.t && (this.a(n26, "RuntimeVisibleAnnotations") || !l02.A && this.a(n26, string3))) {
                                int n29 = k2.e();
                                d d5 = d4 == null && n29 > 0 ? new d(1) : d4;
                                for (int i9 = 0; i9 < n29; ++i9) {
                                    int n30 = n29;
                                    d5.add((Object)this.a());
                                    n29 = n30;
                                }
                                d4 = d5;
                                string13 = string3;
                            } else if (l02.t && (this.a(n26, "RuntimeVisibleParameterAnnotations") || !l02.A && this.a(n26, "RuntimeInvisibleParameterAnnotations"))) {
                                int n31 = k2.d();
                                c[][] arrarrc2 = new c[n31][];
                                for (int i10 = 0; i10 < n31; ++i10) {
                                    c[] arrc;
                                    String string14;
                                    int n32 = n31;
                                    int n33 = k2.e();
                                    if (n33 == 0) {
                                        arrc = f;
                                        string14 = string3;
                                    } else {
                                        string14 = string3;
                                        arrc = new c[n33];
                                    }
                                    arrarrc2[i10] = arrc;
                                    for (int i11 = 0; i11 < n33; ++i11) {
                                        arrarrc2[i10][i11] = this.a();
                                    }
                                    n31 = n32;
                                    string3 = string14;
                                }
                                string13 = string3;
                                arrarrc = arrarrc2;
                            } else {
                                string13 = string3;
                                if (this.a(n26, "MethodParameters")) {
                                    int n34 = k2.d();
                                    String[] arrstring2 = new String[n34];
                                    int[] arrn3 = new int[n34];
                                    for (int i12 = 0; i12 < n34; ++i12) {
                                        int n35 = n34;
                                        int n36 = k2.e();
                                        String string15 = n36 == 0 ? null : this.c(n36);
                                        arrstring2[i12] = string15;
                                        arrn3[i12] = k2.e();
                                        n34 = n35;
                                    }
                                    arrstring = arrstring2;
                                    arrn2 = arrn3;
                                } else if (this.a(n26, "Signature")) {
                                    string12 = this.c(k2.e());
                                } else if (this.a(n26, "AnnotationDefault")) {
                                    if (arrayList == null) {
                                        arrayList = new ArrayList();
                                    }
                                    arrayList.add((Object)new e(string10, this.b()));
                                } else if (this.a(n26, "Code")) {
                                    k2.e(n27);
                                    bl11 = true;
                                } else {
                                    k2.e(n27);
                                }
                            }
                            n22 = n28;
                            string3 = string13;
                        }
                        n23 = n22;
                        string11 = string3;
                        if (bl2 && arrayList != null) {
                            l2.a((List<e>)arrayList);
                        }
                        if (l02.s) {
                            z z2 = new z(this.b, string10, d4, n24, string9, string12, arrstring, arrn2, arrarrc, bl11);
                            l2.a(z2);
                        }
                    } else {
                        n23 = n22;
                        string11 = string3;
                        for (int i13 = 0; i13 < n25; ++i13) {
                            k2.e(2);
                            k2.e(k2.b());
                        }
                    }
                    n22 = n23;
                    string3 = string11;
                }
                String string16 = string3;
                int n37 = k2.e();
                for (int i14 = 0; i14 < n37; ++i14) {
                    String string17;
                    block81 : {
                        int n38;
                        int n39;
                        block79 : {
                            block77 : {
                                block80 : {
                                    block78 : {
                                        n39 = k2.e();
                                        n38 = k2.b();
                                        if (!l02.t) break block77;
                                        if (this.a(n39, "RuntimeVisibleAnnotations")) break block78;
                                        if (l02.A) break block77;
                                        string17 = string16;
                                        if (!this.a(n39, string17)) break block79;
                                        break block80;
                                    }
                                    string17 = string16;
                                }
                                int n40 = k2.e();
                                for (int i15 = 0; i15 < n40; ++i15) {
                                    l2.a(this.a());
                                }
                                break block81;
                            }
                            string17 = string16;
                        }
                        if (this.a(n39, "InnerClasses")) {
                            int n41 = k2.e();
                            for (int i16 = 0; i16 < n41; ++i16) {
                                int n42 = k2.e();
                                int n43 = k2.e();
                                if (n42 != 0 && n43 != 0) {
                                    l2.a(this.b(n42), this.b(n43));
                                }
                                k2.e(2);
                                k2.e(2);
                            }
                        } else if (this.a(n39, "Signature")) {
                            l2.d(this.c(k2.e()));
                        } else if (this.a(n39, "EnclosingMethod")) {
                            String string18 = this.b(k2.e());
                            int n44 = k2.e();
                            String string19 = n44 == 0 ? "<clinit>" : this.a(n44, 0);
                            l2.a(this.b, string18);
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(string18);
                            stringBuilder.append(".");
                            stringBuilder.append(string19);
                            l2.a(stringBuilder.toString());
                        } else {
                            k2.e(n38);
                        }
                    }
                    string16 = string17;
                }
                return l2;
            }
            if (p2 != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Class ");
                stringBuilder.append(this.b);
                stringBuilder.append(" is at incorrect relative path ");
                stringBuilder.append(string);
                stringBuilder.append(" -- ignoring");
                p2.a(stringBuilder.toString());
            }
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Classfile ");
        stringBuilder.append(string);
        stringBuilder.append(" does not have correct classfile magic number");
        iOException = new IOException(stringBuilder.toString());
        throw iOException;
    }
}

