/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.util.Iterator
 *  org.simpleframework.xml.core.Extractor
 *  org.simpleframework.xml.core.ExtractorFactory
 *  org.simpleframework.xml.core.Group
 *  org.simpleframework.xml.core.GroupExtractor$Registry
 *  org.simpleframework.xml.core.Label
 *  org.simpleframework.xml.core.LabelMap
 *  org.simpleframework.xml.stream.Format
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.util.Iterator;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Extractor;
import org.simpleframework.xml.core.ExtractorFactory;
import org.simpleframework.xml.core.Group;
import org.simpleframework.xml.core.GroupExtractor;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelMap;
import org.simpleframework.xml.stream.Format;

/*
 * Exception performing whole class analysis.
 */
class GroupExtractor
implements Group {
    private final LabelMap elements;
    private final ExtractorFactory factory;
    private final Annotation label;
    private final Registry registry;

    public GroupExtractor(Contact contact, Annotation annotation, Format format) throws Exception {
        this.factory = new ExtractorFactory(contact, annotation, format);
        this.elements = new LabelMap();
        this.registry = new /* Unavailable Anonymous Inner Class!! */;
        this.label = annotation;
        this.extract();
    }

    private void extract() throws Exception {
        Extractor extractor = this.factory.getInstance();
        if (extractor != null) {
            this.extract(extractor);
        }
    }

    private void extract(Extractor extractor) throws Exception {
        Annotation[] arrannotation = extractor.getAnnotations();
        int n = arrannotation.length;
        for (int i = 0; i < n; ++i) {
            this.extract(extractor, arrannotation[i]);
        }
    }

    private void extract(Extractor extractor, Annotation annotation) throws Exception {
        Label label = extractor.getLabel(annotation);
        Class class_ = extractor.getType(annotation);
        Registry registry = this.registry;
        if (registry != null) {
            registry.register(class_, label);
        }
    }

    public LabelMap getElements() throws Exception {
        return this.elements.getLabels();
    }

    public Label getLabel(Class class_) {
        return this.registry.resolve(class_);
    }

    public String[] getNames() throws Exception {
        return this.elements.getKeys();
    }

    public String[] getPaths() throws Exception {
        return this.elements.getPaths();
    }

    public Label getText() {
        return this.registry.resolveText();
    }

    public boolean isDeclared(Class class_) {
        return this.registry.containsKey((Object)class_);
    }

    public boolean isInline() {
        Iterator iterator = this.registry.iterator();
        while (iterator.hasNext()) {
            if (((Label)iterator.next()).isInline()) continue;
            return false;
        }
        return true ^ this.registry.isEmpty();
    }

    public boolean isTextList() {
        return this.registry.isText();
    }

    public boolean isValid(Class class_) {
        return this.registry.resolve(class_) != null;
    }

    public String toString() {
        return this.label.toString();
    }
}

