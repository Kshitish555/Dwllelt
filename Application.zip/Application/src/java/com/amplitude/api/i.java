/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Class
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  m.z
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.amplitude.api;

import android.util.Log;
import com.amplitude.api.n;
import com.amplitude.api.o;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import m.z;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class i {
    public static final String j = "https://api.amplitude.com/diagnostic";
    public static final int k = 1;
    public static final int l = 50;
    public static final int m = 5;
    protected static i n;
    volatile boolean a = false;
    private volatile String b;
    private volatile z c;
    private volatile String d;
    int e = 50;
    String f = "https://api.amplitude.com/diagnostic";
    o g = new o("diagnosticThread");
    List<String> h = new ArrayList(this.e);
    Map<String, JSONObject> i = new HashMap(this.e);

    private i() {
        this.g.start();
    }

    static i c() {
        Class<i> class_ = i.class;
        synchronized (i.class) {
            if (n == null) {
                n = new i();
            }
            i i2 = n;
            // ** MonitorExit[var2] (shouldn't be in output)
            return i2;
        }
    }

    i a() {
        this.a = false;
        return this;
    }

    i a(final int n2) {
        this.a(new Runnable(){

            public void run() {
                this.e = Math.max((int)n2, (int)5);
                i i2 = this;
                i2.e = Math.min((int)i2.e, (int)50);
                i i3 = this;
                if (i3.e < i3.h.size()) {
                    for (int i4 = 0; i4 < i.this.h.size() - this.e; ++i4) {
                        String string = (String)i.this.h.remove(0);
                        i.this.i.remove((Object)string);
                    }
                }
            }
        });
        return this;
    }

    i a(String string) {
        return this.a(string, null);
    }

    i a(final String string, final Throwable throwable) {
        if (this.a && !n.a(string)) {
            if (n.a(this.d)) {
                return this;
            }
            this.a(new Runnable(){

                public void run() {
                    JSONObject jSONObject = (JSONObject)i.this.i.get((Object)string);
                    if (jSONObject == null) {
                        JSONObject jSONObject2;
                        block8 : {
                            String string3;
                            jSONObject2 = new JSONObject();
                            jSONObject2.put("error", (Object)com.amplitude.api.c.i(string));
                            jSONObject2.put("timestamp", System.currentTimeMillis());
                            jSONObject2.put("device_id", (Object)i.this.d);
                            jSONObject2.put("count", 1);
                            if (throwable != null && !n.a(string3 = Log.getStackTraceString((Throwable)throwable))) {
                                jSONObject2.put("stack_trace", (Object)com.amplitude.api.c.i(string3));
                            }
                            if (i.this.h.size() < i.this.e) break block8;
                            for (int i2 = 0; i2 < 5; ++i2) {
                                String string2 = (String)i.this.h.remove(0);
                                i.this.i.remove((Object)string2);
                            }
                        }
                        i.this.i.put((Object)string, (Object)jSONObject2);
                        i.this.h.add((Object)string);
                        return;
                    }
                    int n2 = 1 + jSONObject.optInt("count", 0);
                    try {
                        jSONObject.put("count", n2);
                    }
                    catch (JSONException jSONException) {}
                }
            });
        }
        return this;
    }

    i a(z z2, String string, String string2) {
        this.a = true;
        this.b = string;
        this.c = z2;
        this.d = string2;
        return this;
    }

    protected void a(Runnable runnable) {
        o o2;
        Thread thread = Thread.currentThread();
        if (thread != (o2 = this.g)) {
            o2.a(runnable);
            return;
        }
        runnable.run();
    }

    i b() {
        if (this.a && !n.a(this.b) && this.c != null) {
            if (n.a(this.d)) {
                return this;
            }
            this.a(new Runnable(){

                public void run() {
                    if (i.this.h.isEmpty()) {
                        return;
                    }
                    ArrayList arrayList = new ArrayList(i.this.h.size());
                    for (String string : i.this.h) {
                        arrayList.add(i.this.i.get((Object)string));
                    }
                    String string = new JSONArray((Collection)arrayList).toString();
                    if (!n.a(string)) {
                        i.this.b(string);
                    }
                }
            });
        }
        return this;
    }

    /*
     * Exception decompiling
     */
    protected void b(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1162)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:636)
        // java.lang.Thread.run(Thread.java:764)
        throw new IllegalStateException("Decompilation failed");
    }

}

