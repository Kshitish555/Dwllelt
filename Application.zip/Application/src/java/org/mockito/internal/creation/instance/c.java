/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  org.mockito.internal.creation.instance.InstantiationException
 */
package org.mockito.internal.creation.instance;

import org.mockito.internal.creation.instance.InstantiationException;

public interface c {
    public <T> T a(Class<T> var1) throws InstantiationException;
}

