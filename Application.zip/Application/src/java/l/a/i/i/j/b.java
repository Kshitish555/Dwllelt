/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Iterator
 *  java.util.List
 *  l.a.b
 *  l.a.f.b
 *  l.a.f.b$e
 *  l.a.h.i.a
 *  l.a.h.i.a$h
 *  l.a.h.k.c
 *  l.a.i.b
 *  l.a.i.b$a
 *  l.a.i.b$a$a
 *  l.a.i.b$a$a$a
 *  l.a.i.b$d
 *  l.a.i.g
 *  l.a.i.g$e
 *  l.a.i.i.b
 *  l.a.i.i.b$a
 *  l.a.i.i.b$b
 *  l.a.i.i.c
 *  l.a.i.i.c$f
 *  l.a.i.i.d
 *  l.a.i.i.d$a
 *  l.a.i.i.e
 *  l.a.i.i.e$a
 *  l.a.i.i.e$b
 *  l.a.i.i.e$d
 *  l.a.i.i.g
 *  l.a.i.i.h
 *  l.a.i.i.h$a
 *  l.a.i.i.h$b
 *  l.a.i.i.j.a
 *  l.a.i.i.j.b$a
 *  l.a.i.i.j.c
 *  l.a.i.i.j.c$b
 *  l.a.j.e
 *  l.a.j.e$d
 *  l.a.j.e$d$d
 *  l.a.j.e$g
 *  l.a.j.e$g$b
 *  l.a.j.n.b
 *  l.a.j.n.c
 *  l.a.j.n.c$c
 *  l.a.j.n.f
 *  l.a.j.n.f$c
 *  l.a.j.o.a
 *  l.a.j.o.a$a
 *  l.a.l.c0
 *  l.a.m.a
 */
package l.a.i.i.j;

import java.util.Iterator;
import java.util.List;
import l.a.f.b;
import l.a.h.i.a;
import l.a.i.b;
import l.a.i.g;
import l.a.i.i.b;
import l.a.i.i.c;
import l.a.i.i.d;
import l.a.i.i.e;
import l.a.i.i.g;
import l.a.i.i.h;
import l.a.i.i.j.b;
import l.a.i.i.j.c;
import l.a.j.e;
import l.a.j.n.c;
import l.a.j.n.f;
import l.a.j.o.a;
import l.a.l.c0;
import l.a.m.a;

/*
 * Exception performing whole class analysis.
 */
public class b<T>
extends b.a.a.a<T> {
    private final l.a.i.i.j.a n;

    public b(c.f f2, l.a.b b2, a.a a2, c.c c2, l.a.j.n.b b3, e.d.d d2, d.a a3, g g2, c0<? super l.a.h.i.a> c02, l.a.i.i.j.a a4) {
        this(f2, (l.a.i.i.b)new b.b(), (e)new e.b(), (f)f.c.c, (l.a.f.b)b.e.c, b2, a2, c2, b3, d2, a3, g2, c02, a4);
    }

    protected b(c.f f2, l.a.i.i.b b2, e e2, f f3, l.a.f.b b3, l.a.b b4, a.a a2, c.c c2, l.a.j.n.b b5, e.d.d d2, d.a a3, g g2, c0<? super l.a.h.i.a> c02, l.a.i.i.j.a a4) {
        super(f2, b2, e2, f3, b3, b4, a2, c2, b5, d2, a3, g2, c02);
        this.n = a4;
    }

    private c a(c c2) {
        if (!c2.isInterface()) {
            Iterator iterator = this.n.a((l.a.h.k.c)c2).iterator();
            while (iterator.hasNext()) {
                c2 = c2.a((a.h)iterator.next());
            }
        }
        return c2;
    }

    protected b.a<T> a(c.f f2, l.a.i.i.b b2, e e2, f f3, l.a.f.b b3, l.a.b b4, a.a a2, c.c c2, l.a.j.n.b b5, e.d.d d2, d.a a3, g g2, c0<? super l.a.h.i.a> c02) {
        b<T> b6 = new b<T>(f2, b2, e2, f3, b3, b4, a2, c2, b5, d2, a3, g2, c02, this.n);
        return b6;
    }

    public b.d<T> a(l.a.i.g g2) {
        return this.a(g2, a.d.b());
    }

    public b.d<T> a(l.a.i.g g2, l.a.m.a a2) {
        e.a a3 = this.n.a(this.c).a(this.a((c)this.a), this.k, this.l, (c0)new /* Unavailable Anonymous Inner Class!! */).a((e.g.b)c.b.d, this.f);
        return h.a.a((e.a)a3, (h.b)this.b.a(a3.c()), (f)this.d, (l.a.f.b)this.e, (l.a.b)this.f, (c.c)this.h, (l.a.j.n.b)this.i, (a.a)this.g, (e.d.d)this.j, (g)this.l, (l.a.m.a)a2).a(g2.resolve());
    }

    protected boolean a(Object object) {
        return object instanceof b;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)((Object)object);
        if (!b2.a((Object)this)) {
            return false;
        }
        if (!super.equals(object)) {
            return false;
        }
        l.a.i.i.j.a a2 = this.n;
        l.a.i.i.j.a a3 = b2.n;
        return !(a2 == null ? a3 != null : !a2.equals((Object)a3));
    }

    public int hashCode() {
        int n2 = 59 + super.hashCode();
        l.a.i.i.j.a a2 = this.n;
        int n3 = n2 * 59;
        int n4 = a2 == null ? 43 : a2.hashCode();
        return n3 + n4;
    }
}

