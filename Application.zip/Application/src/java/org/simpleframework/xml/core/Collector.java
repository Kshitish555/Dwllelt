/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Iterator
 *  org.simpleframework.xml.core.Collector$1
 *  org.simpleframework.xml.core.Collector$Registry
 *  org.simpleframework.xml.core.Criteria
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import java.util.Collection;
import java.util.Iterator;
import org.simpleframework.xml.core.Collector;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Criteria;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.Variable;

/*
 * Exception performing whole class analysis.
 */
class Collector
implements Criteria {
    private final Registry alias;
    private final Registry registry;

    public Collector() {
        this.registry = new /* Unavailable Anonymous Inner Class!! */;
        this.alias = new /* Unavailable Anonymous Inner Class!! */;
    }

    public void commit(Object object) throws Exception {
        for (Variable variable : this.registry.values()) {
            variable.getContact().set(object, variable.getValue());
        }
    }

    public Variable get(Object object) {
        return (Variable)this.registry.get(object);
    }

    public Variable get(Label label) throws Exception {
        if (label != null) {
            Object object = label.getKey();
            return (Variable)this.registry.get(object);
        }
        return null;
    }

    public Iterator<Object> iterator() {
        return this.registry.iterator();
    }

    public Variable remove(Object object) throws Exception {
        return (Variable)this.registry.remove(object);
    }

    public Variable resolve(String string2) {
        return (Variable)this.alias.get((Object)string2);
    }

    public void set(Label label, Object object) throws Exception {
        Variable variable = new Variable(label, object);
        if (label != null) {
            String[] arrstring = label.getPaths();
            Object object2 = label.getKey();
            for (String string2 : arrstring) {
                this.alias.put((Object)string2, (Object)variable);
            }
            this.registry.put(object2, (Object)variable);
        }
    }
}

