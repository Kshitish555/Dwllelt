/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.net.Uri
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import com.adjust.sdk.AdjustAttribution;
import com.adjust.sdk.AdjustConfig;
import com.adjust.sdk.AdjustEvent;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.AdjustInstance;
import com.adjust.sdk.AdjustTestOptions;
import com.adjust.sdk.OnDeviceIdsRead;
import com.adjust.sdk.Util;

public class Adjust {
    private static AdjustInstance defaultInstance;

    private Adjust() {
    }

    public static void addSessionCallbackParameter(String string, String string2) {
        Adjust.getDefaultInstance().addSessionCallbackParameter(string, string2);
    }

    public static void addSessionPartnerParameter(String string, String string2) {
        Adjust.getDefaultInstance().addSessionPartnerParameter(string, string2);
    }

    @Deprecated
    public static void appWillOpenUrl(Uri uri) {
        Adjust.getDefaultInstance().appWillOpenUrl(uri);
    }

    public static void appWillOpenUrl(Uri uri, Context context) {
        Adjust.getDefaultInstance().appWillOpenUrl(uri, context);
    }

    public static void gdprForgetMe(Context context) {
        Adjust.getDefaultInstance().gdprForgetMe(context);
    }

    public static String getAdid() {
        return Adjust.getDefaultInstance().getAdid();
    }

    public static String getAmazonAdId(Context context) {
        return Util.getFireAdvertisingId(context.getContentResolver());
    }

    public static AdjustAttribution getAttribution() {
        return Adjust.getDefaultInstance().getAttribution();
    }

    public static AdjustInstance getDefaultInstance() {
        Class<Adjust> class_ = Adjust.class;
        synchronized (Adjust.class) {
            if (defaultInstance == null) {
                defaultInstance = new AdjustInstance();
            }
            AdjustInstance adjustInstance = defaultInstance;
            // ** MonitorExit[var2] (shouldn't be in output)
            return adjustInstance;
        }
    }

    public static void getGoogleAdId(Context context, OnDeviceIdsRead onDeviceIdsRead) {
        Util.getGoogleAdId(context, onDeviceIdsRead);
    }

    public static String getSdkVersion() {
        return Adjust.getDefaultInstance().getSdkVersion();
    }

    public static boolean isEnabled() {
        return Adjust.getDefaultInstance().isEnabled();
    }

    public static void onCreate(AdjustConfig adjustConfig) {
        Adjust.getDefaultInstance().onCreate(adjustConfig);
    }

    public static void onPause() {
        Adjust.getDefaultInstance().onPause();
    }

    public static void onResume() {
        Adjust.getDefaultInstance().onResume();
    }

    public static void removeSessionCallbackParameter(String string) {
        Adjust.getDefaultInstance().removeSessionCallbackParameter(string);
    }

    public static void removeSessionPartnerParameter(String string) {
        Adjust.getDefaultInstance().removeSessionPartnerParameter(string);
    }

    public static void resetSessionCallbackParameters() {
        Adjust.getDefaultInstance().resetSessionCallbackParameters();
    }

    public static void resetSessionPartnerParameters() {
        Adjust.getDefaultInstance().resetSessionPartnerParameters();
    }

    public static void sendFirstPackages() {
        Adjust.getDefaultInstance().sendFirstPackages();
    }

    public static void setEnabled(boolean bl) {
        Adjust.getDefaultInstance().setEnabled(bl);
    }

    public static void setOfflineMode(boolean bl) {
        Adjust.getDefaultInstance().setOfflineMode(bl);
    }

    public static void setPushToken(String string) {
        Adjust.getDefaultInstance().setPushToken(string);
    }

    public static void setPushToken(String string, Context context) {
        Adjust.getDefaultInstance().setPushToken(string, context);
    }

    public static void setReferrer(String string, Context context) {
        Adjust.getDefaultInstance().sendReferrer(string, context);
    }

    public static void setTestOptions(AdjustTestOptions adjustTestOptions) {
        Boolean bl = adjustTestOptions.teardown;
        if (bl != null && bl.booleanValue()) {
            AdjustInstance adjustInstance = defaultInstance;
            if (adjustInstance != null) {
                adjustInstance.teardown();
            }
            defaultInstance = null;
            AdjustFactory.teardown(adjustTestOptions.context);
        }
        Adjust.getDefaultInstance().setTestOptions(adjustTestOptions);
    }

    public static void trackEvent(AdjustEvent adjustEvent) {
        Adjust.getDefaultInstance().trackEvent(adjustEvent);
    }
}

