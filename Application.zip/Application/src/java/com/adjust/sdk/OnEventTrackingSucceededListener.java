/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.adjust.sdk;

import com.adjust.sdk.AdjustEventSuccess;

public interface OnEventTrackingSucceededListener {
    public void onFinishedEventTrackingSucceeded(AdjustEventSuccess var1);
}

