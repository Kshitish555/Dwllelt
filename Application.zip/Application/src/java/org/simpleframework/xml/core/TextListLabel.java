/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.core.Context
 *  org.simpleframework.xml.core.Converter
 *  org.simpleframework.xml.core.Decorator
 *  org.simpleframework.xml.core.Expression
 *  org.simpleframework.xml.core.Label
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.Context;
import org.simpleframework.xml.core.Converter;
import org.simpleframework.xml.core.Decorator;
import org.simpleframework.xml.core.Expression;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.TemplateLabel;
import org.simpleframework.xml.core.TextException;
import org.simpleframework.xml.core.TextList;
import org.simpleframework.xml.strategy.Type;

class TextListLabel
extends TemplateLabel {
    private final String empty;
    private final Label label;
    private final Text text;

    public TextListLabel(Label label, Text text) {
        this.empty = text.empty();
        this.label = label;
        this.text = text;
    }

    public Annotation getAnnotation() {
        return this.label.getAnnotation();
    }

    public Contact getContact() {
        return this.label.getContact();
    }

    public Converter getConverter(Context context) throws Exception {
        Contact contact = this.getContact();
        if (this.label.isCollection()) {
            return new TextList(context, contact, this.label);
        }
        Object[] arrobject = new Object[]{contact, this.label};
        throw new TextException("Cannot use %s to represent %s", arrobject);
    }

    public Decorator getDecorator() throws Exception {
        return null;
    }

    @Override
    public Type getDependent() throws Exception {
        return this.label.getDependent();
    }

    public String getEmpty(Context context) throws Exception {
        return this.empty;
    }

    @Override
    public String getEntry() throws Exception {
        return this.label.getEntry();
    }

    public Expression getExpression() throws Exception {
        return this.label.getExpression();
    }

    @Override
    public Object getKey() throws Exception {
        return this.label.getKey();
    }

    public String getName() throws Exception {
        return this.label.getName();
    }

    @Override
    public String[] getNames() throws Exception {
        return this.label.getNames();
    }

    public String getOverride() {
        return this.label.getOverride();
    }

    public String getPath() throws Exception {
        return this.label.getPath();
    }

    @Override
    public String[] getPaths() throws Exception {
        return this.label.getPaths();
    }

    public Class getType() {
        return this.label.getType();
    }

    @Override
    public boolean isCollection() {
        return true;
    }

    public boolean isData() {
        return this.label.isData();
    }

    @Override
    public boolean isInline() {
        return this.label.isInline();
    }

    public boolean isRequired() {
        return this.label.isRequired();
    }

    @Override
    public boolean isTextList() {
        return true;
    }

    public String toString() {
        Object[] arrobject = new Object[]{this.text, this.label};
        return String.format((String)"%s %s", (Object[])arrobject);
    }
}

