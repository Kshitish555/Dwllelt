/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 */
package com.adjust.sdk;

public final class ActivityKind
extends Enum<ActivityKind> {
    private static final /* synthetic */ ActivityKind[] $VALUES;
    public static final /* enum */ ActivityKind ATTRIBUTION;
    public static final /* enum */ ActivityKind CLICK;
    public static final /* enum */ ActivityKind EVENT;
    public static final /* enum */ ActivityKind GDPR;
    public static final /* enum */ ActivityKind INFO;
    public static final /* enum */ ActivityKind REATTRIBUTION;
    public static final /* enum */ ActivityKind REVENUE;
    public static final /* enum */ ActivityKind SESSION;
    public static final /* enum */ ActivityKind UNKNOWN;

    static {
        ActivityKind activityKind;
        UNKNOWN = new ActivityKind();
        SESSION = new ActivityKind();
        EVENT = new ActivityKind();
        CLICK = new ActivityKind();
        ATTRIBUTION = new ActivityKind();
        REVENUE = new ActivityKind();
        REATTRIBUTION = new ActivityKind();
        INFO = new ActivityKind();
        GDPR = activityKind = new ActivityKind();
        ActivityKind[] arractivityKind = new ActivityKind[]{UNKNOWN, SESSION, EVENT, CLICK, ATTRIBUTION, REVENUE, REATTRIBUTION, INFO, activityKind};
        $VALUES = arractivityKind;
    }

    public static ActivityKind fromString(String string) {
        if ("session".equals((Object)string)) {
            return SESSION;
        }
        if ("event".equals((Object)string)) {
            return EVENT;
        }
        if ("click".equals((Object)string)) {
            return CLICK;
        }
        if ("attribution".equals((Object)string)) {
            return ATTRIBUTION;
        }
        if ("info".equals((Object)string)) {
            return INFO;
        }
        if ("gdpr".equals((Object)string)) {
            return GDPR;
        }
        return UNKNOWN;
    }

    public static ActivityKind valueOf(String string) {
        return (ActivityKind)Enum.valueOf(ActivityKind.class, (String)string);
    }

    public static ActivityKind[] values() {
        return (ActivityKind[])$VALUES.clone();
    }

    public String toString() {
        switch (a.a[this.ordinal()]) {
            default: {
                return "unknown";
            }
            case 6: {
                return "gdpr";
            }
            case 5: {
                return "info";
            }
            case 4: {
                return "attribution";
            }
            case 3: {
                return "click";
            }
            case 2: {
                return "event";
            }
            case 1: 
        }
        return "session";
    }

}

