/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  h.b.b0
 *  h.b.t0.f
 *  java.lang.Object
 */
package h.b;

import h.b.b0;
import h.b.t0.f;

public interface c0<T, R> {
    @f
    public R a(@f b0<T> var1);
}

