/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.annotation.Annotation
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  java.util.Collections
 *  java.util.LinkedList
 *  java.util.List
 *  org.simpleframework.xml.Attribute
 *  org.simpleframework.xml.Element
 *  org.simpleframework.xml.ElementArray
 *  org.simpleframework.xml.ElementList
 *  org.simpleframework.xml.ElementListUnion
 *  org.simpleframework.xml.ElementMap
 *  org.simpleframework.xml.ElementMapUnion
 *  org.simpleframework.xml.ElementUnion
 *  org.simpleframework.xml.Text
 *  org.simpleframework.xml.Version
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementArray;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.ElementListUnion;
import org.simpleframework.xml.ElementMap;
import org.simpleframework.xml.ElementMapUnion;
import org.simpleframework.xml.ElementUnion;
import org.simpleframework.xml.Text;
import org.simpleframework.xml.Version;
import org.simpleframework.xml.core.AttributeLabel;
import org.simpleframework.xml.core.CacheLabel;
import org.simpleframework.xml.core.Contact;
import org.simpleframework.xml.core.ElementArrayLabel;
import org.simpleframework.xml.core.ElementLabel;
import org.simpleframework.xml.core.ElementListLabel;
import org.simpleframework.xml.core.ElementListUnionLabel;
import org.simpleframework.xml.core.ElementMapLabel;
import org.simpleframework.xml.core.ElementMapUnionLabel;
import org.simpleframework.xml.core.ElementUnionLabel;
import org.simpleframework.xml.core.Label;
import org.simpleframework.xml.core.LabelGroup;
import org.simpleframework.xml.core.LabelKey;
import org.simpleframework.xml.core.PersistenceException;
import org.simpleframework.xml.core.TextLabel;
import org.simpleframework.xml.core.VersionLabel;
import org.simpleframework.xml.stream.Format;
import org.simpleframework.xml.util.Cache;
import org.simpleframework.xml.util.ConcurrentCache;

class LabelExtractor {
    private final Cache<LabelGroup> cache = new ConcurrentCache<LabelGroup>();
    private final Format format;

    public LabelExtractor(Format format) {
        this.format = format;
    }

    private Annotation[] getAnnotations(Annotation annotation) throws Exception {
        Method[] arrmethod = annotation.annotationType().getDeclaredMethods();
        if (arrmethod.length > 0) {
            return (Annotation[])arrmethod[0].invoke((Object)annotation, new Object[0]);
        }
        return new Annotation[0];
    }

    private LabelBuilder getBuilder(Annotation annotation) throws Exception {
        if (annotation instanceof Element) {
            return new LabelBuilder(ElementLabel.class, Element.class);
        }
        if (annotation instanceof ElementList) {
            return new LabelBuilder(ElementListLabel.class, ElementList.class);
        }
        if (annotation instanceof ElementArray) {
            return new LabelBuilder(ElementArrayLabel.class, ElementArray.class);
        }
        if (annotation instanceof ElementMap) {
            return new LabelBuilder(ElementMapLabel.class, ElementMap.class);
        }
        if (annotation instanceof ElementUnion) {
            return new LabelBuilder(ElementUnionLabel.class, ElementUnion.class, Element.class);
        }
        if (annotation instanceof ElementListUnion) {
            return new LabelBuilder(ElementListUnionLabel.class, ElementListUnion.class, ElementList.class);
        }
        if (annotation instanceof ElementMapUnion) {
            return new LabelBuilder(ElementMapUnionLabel.class, ElementMapUnion.class, ElementMap.class);
        }
        if (annotation instanceof Attribute) {
            return new LabelBuilder(AttributeLabel.class, Attribute.class);
        }
        if (annotation instanceof Version) {
            return new LabelBuilder(VersionLabel.class, Version.class);
        }
        if (annotation instanceof Text) {
            return new LabelBuilder(TextLabel.class, Text.class);
        }
        throw new PersistenceException("Annotation %s not supported", new Object[]{annotation});
    }

    private Constructor getConstructor(Annotation annotation) throws Exception {
        Constructor constructor = this.getBuilder(annotation).getConstructor();
        if (!constructor.isAccessible()) {
            constructor.setAccessible(true);
        }
        return constructor;
    }

    private LabelGroup getGroup(Contact contact, Annotation annotation, Object object) throws Exception {
        LabelGroup labelGroup = this.cache.fetch(object);
        if (labelGroup == null) {
            LabelGroup labelGroup2 = this.getLabels(contact, annotation);
            if (labelGroup2 != null) {
                this.cache.cache(object, labelGroup2);
            }
            return labelGroup2;
        }
        return labelGroup;
    }

    private Object getKey(Contact contact, Annotation annotation) {
        return new LabelKey(contact, annotation);
    }

    private Label getLabel(Contact contact, Annotation annotation, Annotation annotation2) throws Exception {
        Constructor constructor = this.getConstructor(annotation);
        if (annotation2 != null) {
            Object[] arrobject = new Object[]{contact, annotation, annotation2, this.format};
            return (Label)constructor.newInstance(arrobject);
        }
        Object[] arrobject = new Object[]{contact, annotation, this.format};
        return (Label)constructor.newInstance(arrobject);
    }

    private LabelGroup getLabels(Contact contact, Annotation annotation) throws Exception {
        if (annotation instanceof ElementUnion) {
            return this.getUnion(contact, annotation);
        }
        if (annotation instanceof ElementListUnion) {
            return this.getUnion(contact, annotation);
        }
        if (annotation instanceof ElementMapUnion) {
            return this.getUnion(contact, annotation);
        }
        return this.getSingle(contact, annotation);
    }

    private LabelGroup getSingle(Contact contact, Annotation annotation) throws Exception {
        Label label = this.getLabel(contact, annotation, null);
        if (label != null) {
            label = new CacheLabel(label);
        }
        return new LabelGroup(label);
    }

    private LabelGroup getUnion(Contact contact, Annotation annotation) throws Exception {
        Annotation[] arrannotation = this.getAnnotations(annotation);
        if (arrannotation.length > 0) {
            LinkedList linkedList = new LinkedList();
            int n2 = arrannotation.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                Label label = this.getLabel(contact, annotation, arrannotation[i2]);
                if (label != null) {
                    label = new CacheLabel(label);
                }
                linkedList.add((Object)label);
            }
            return new LabelGroup((List<Label>)linkedList);
        }
        return null;
    }

    public Label getLabel(Contact contact, Annotation annotation) throws Exception {
        LabelGroup labelGroup = this.getGroup(contact, annotation, this.getKey(contact, annotation));
        if (labelGroup != null) {
            return labelGroup.getPrimary();
        }
        return null;
    }

    public List<Label> getList(Contact contact, Annotation annotation) throws Exception {
        LabelGroup labelGroup = this.getGroup(contact, annotation, this.getKey(contact, annotation));
        if (labelGroup != null) {
            return labelGroup.getList();
        }
        return Collections.emptyList();
    }

    private static class LabelBuilder {
        private final Class entry;
        private final Class label;
        private final Class type;

        public LabelBuilder(Class class_, Class class_2) {
            this(class_, class_2, null);
        }

        public LabelBuilder(Class class_, Class class_2, Class class_3) {
            this.entry = class_3;
            this.label = class_2;
            this.type = class_;
        }

        private Constructor getConstructor(Class class_) throws Exception {
            return this.type.getConstructor(new Class[]{Contact.class, class_, Format.class});
        }

        private Constructor getConstructor(Class class_, Class class_2) throws Exception {
            return this.type.getConstructor(new Class[]{Contact.class, class_, class_2, Format.class});
        }

        public Constructor getConstructor() throws Exception {
            Class class_ = this.entry;
            if (class_ != null) {
                return this.getConstructor(this.label, class_);
            }
            return this.getConstructor(this.label);
        }
    }

}

