/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.util.ArrayList
 *  org.mockito.internal.exceptions.d.b
 */
package org.mockito.internal.exceptions.d;

import java.io.Serializable;
import java.util.ArrayList;
import o.e.w.a.a;
import o.e.y.d.k.f;
import org.mockito.internal.exceptions.d.b;

public class d
implements Serializable {
    static final long c = -5499819791513105700L;
    private static final a d = f.d().a((a)new b());

    public StackTraceElement[] a(StackTraceElement[] arrstackTraceElement, boolean bl) {
        ArrayList arrayList = new ArrayList();
        for (StackTraceElement stackTraceElement : arrstackTraceElement) {
            if (!d.a(stackTraceElement)) continue;
            arrayList.add((Object)stackTraceElement);
        }
        return (StackTraceElement[])arrayList.toArray((Object[])new StackTraceElement[arrayList.size()]);
    }
}

