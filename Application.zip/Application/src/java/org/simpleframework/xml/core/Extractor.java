/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.annotation.Annotation
 */
package org.simpleframework.xml.core;

import java.lang.annotation.Annotation;
import org.simpleframework.xml.core.Label;

interface Extractor<T extends Annotation> {
    public T[] getAnnotations() throws Exception;

    public Label getLabel(T var1) throws Exception;

    public Class getType(T var1) throws Exception;
}

